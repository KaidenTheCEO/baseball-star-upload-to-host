-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 23, 2021 at 02:09 PM
-- Server version: 5.7.33-0ubuntu0.16.04.1
-- PHP Version: 7.0.33-0ubuntu0.16.04.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `website`
--
CREATE DATABASE IF NOT EXISTS `website` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `website`;

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `account_activate_upd` (IN `var_email` VARCHAR(100))  NO SQL
UPDATE account a SET a.isVerified = 1, a.IsActive = 1 WHERE a.Email = var_account_email AND a.IsActive = 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_awards_sel` (IN `var_account_id` INT, IN `var_type` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	a.ID AS account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pa.award_id
    ,ma.award_name
    ,ma.award_abbr
    ,ma.award_star_bonus
    ,ma.is_weekly
    ,ma.is_monthly
    ,ma.is_yearly
    ,pa.received_date
FROM
	player_award pa
    INNER JOIN player pl ON pl.player_id = pa.player_id AND pl.is_active = 1
    INNER JOIN player_season ps ON ps.season_id = pa.season_id
    INNER JOIN master_award ma ON ma.award_id = pa.award_id AND ma.is_active = 1
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
    INNER JOIN account a ON a.ID = pl.account_id
WHERE
	ma.award_id = var_type
    AND pl.account_id = var_account_id
ORDER BY
	pa.received_date DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_bonus_sel` (IN `var_account_id` INT, IN `var_bonus_id` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	a.ID AS account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,opp.team_id AS opp_team_id
    ,opp.team_city AS opp_team_city
    ,opp.team_name AS opp_team_name
    ,opp.team_abbr AS opp_team_abbr
    ,pa.bonus_id
    ,ma.bonus_name
    ,ma.bonus_abbr
    ,ma.bonus_desc
    ,pa.bonus_value
    ,ts.game_id
    ,ts.team_score
    ,ts.opponent_score
    ,ts.innings
    ,ts.is_postseason
    ,ts.game_date
FROM
	player_game_bonus pa
    INNER JOIN player pl ON pl.player_id = pa.player_id
    INNER JOIN master_bonus ma ON ma.bonus_id = pa.bonus_id
    INNER JOIN team_schedule ts ON ts.game_id = pa.game_id AND ts.is_hidden = 0
    INNER JOIN player_season ps ON ps.season_id = ts.season_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
    INNER JOIN master_team opp ON opp.team_id = ts.opponent_id
    INNER JOIN account a ON a.ID = pl.account_id
WHERE
	ma.bonus_id = var_bonus_id
    AND pl.account_id = var_account_id
ORDER BY
	ts.game_date DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_change_email` (IN `var_email` VARCHAR(100), IN `var_new_email` VARCHAR(100))  NO SQL
UPDATE account SET Email = var_new_email, isVerified = 0
WHERE
	Email = var_email
    AND isVerified = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_change_password` (IN `var_email` VARCHAR(100), IN `var_password` VARCHAR(255))  NO SQL
UPDATE account a
SET 
	a.Password = var_password
    ,a.isVerified = 1
WHERE 
	a.Email = var_email
    AND a.isVerified = 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_customer_id_ins` (IN `var_id` INT, IN `var_customer_id` VARCHAR(250))  NO SQL
UPDATE account set customer_id = var_customer_id WHERE ID = var_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_customer_ins` (IN `var_id` VARCHAR(250), IN `var_first_name` VARCHAR(250), IN `var_last_name` VARCHAR(250), IN `var_email` VARCHAR(250), IN `var_auto_collection` VARCHAR(250), IN `var_allow_direct_debit` INT, IN `var_created_at` INT, IN `var_taxability` VARCHAR(250), IN `var_object` VARCHAR(250), IN `var_card_status` VARCHAR(250), IN `var_account_credits` INT, IN `var_refundable_credits` INT, IN `var_excess_payments` INT)  NO SQL
INSERT INTO account_customer
(customer_id, first_name, last_name, email, auto_collection, allow_direct_debit, created_at, taxability, object, card_status, account_credits, refundable_credits, excess_payments)
VALUES(var_id, var_first_name, var_last_name, var_email, var_auto_collection, var_allow_direct_debit, var_created_at, var_taxability, var_object, var_card_status, var_account_credits, var_refundable_credits, var_excess_payments)
ON DUPLICATE KEY UPDATE 
	customer_id = var_id
    ,first_name = var_first_name
    ,last_name = var_last_name
    ,email = var_email
    ,auto_collection = var_auto_collection
    ,allow_direct_debit = var_allow_direct_debit
    ,created_at = var_created_at
    ,taxability = var_taxability
    ,object = var_object
    ,card_status = var_card_status
    ,account_credits = var_account_credits
    ,refundable_credits = var_refundable_credits
    ,excess_payments = var_excess_payments$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_deactivate_unverified_inactive_sel` ()  NO SQL
SELECT
	a.Email
    ,(CASE
      WHEN DATEDIFF(CURRENT_DATE, a.Created) = 6 THEN 1
      WHEN DATEDIFF(CURRENT_DATE, a.lastLogin) = 13 THEN 1
      ELSE 0
    END) AS send_warning
FROM 
	account a
WHERE 
	a.isActive = 1
    AND 
    	(a.isVerified = 0 AND DATEDIFF(CURRENT_DATE, a.Created) >= 6)
        OR
        (a.isVerified = 1 AND DATEDIFF(CURRENT_DATE, a.lastLogin) >= 13)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_deactivate_unverified_inactive_upd` (IN `var_email` VARCHAR(100))  NO SQL
UPDATE account a SET a.isActive = 0 WHERE a.Email = var_email$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_email_duplicate_check` (IN `var_email` VARCHAR(100), IN `var_new_email` VARCHAR(100))  NO SQL
SELECT 
	a.Password
    ,(
        SELECT 
        	(CASE 
             	WHEN COUNT(ac.Email) > 0 THEN 0
             	ELSE 1
             END)
        FROM account ac
        WHERE
        	ac.Email = var_new_email
    ) AS is_unused
FROM 
	account a 
WHERE 
	a.Email = var_email$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Account_ID` (IN `var_account_email` VARCHAR(100))  NO SQL
SELECT ID FROM account WHERE email = var_account_email$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_is_active_upd` (IN `var_account_id` INT, IN `var_value` INT)  NO SQL
UPDATE account SET isActive = var_value WHERE ID = var_account_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_is_admin_upd` (IN `var_account_id` INT, IN `var_value` INT)  NO SQL
UPDATE account SET isAdmin = var_value WHERE ID = var_account_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_is_premium_upd` (IN `var_account_id` INT, IN `var_value` INT)  NO SQL
UPDATE account SET isPremium = var_value WHERE ID = var_account_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_is_verified_upd` (IN `var_account_id` INT, IN `var_value` INT)  NO SQL
UPDATE account SET isVerified = var_value WHERE ID = var_account_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_last_login_upd` (IN `var_email` VARCHAR(100))  NO SQL
UPDATE account a SET a.lastLogin = CURRENT_TIMESTAMP WHERE a.Email = var_email AND a.isActive = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Account_Login` (IN `email_in` VARCHAR(100))  NO SQL
SELECT ID, Email, Password, isVerified AS is_verified FROM account WHERE Email = email_in AND isActive = 1 LIMIT 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_login_deactivated` (IN `var_email` VARCHAR(100))  NO SQL
SELECT ID, Email, Password, isVerified AS is_verified FROM account WHERE Email = var_email AND isActive = 0 LIMIT 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_login_email_and_password` (IN `var_email` VARCHAR(100), IN `var_password` VARCHAR(255))  NO SQL
SELECT
	a.Email
FROM
	account a
WHERE
	a.Email = var_email
	AND a.Password = var_password
    AND a.isVerified = 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_manage_sel` (IN `var_account_id` INT)  NO SQL
SELECT
	a.ID AS account_id
    ,a.Email AS account_email
    ,a.username
    ,a.IpAddress
    ,a.isActive AS is_active
    ,a.isVerified AS is_verified
    ,a.isSubscribed AS is_subscribed
    ,a.isPremium AS is_premium
    ,a.isAdmin AS is_admin
    ,(SELECT COUNT(a.star_earned) + 1 FROM (SELECT AVG(pse.star_earned) AS star_earned FROM player_star pse INNER JOIN player ply ON ply.player_id = pse.player_id AND ply.is_active = 1 GROUP BY ply.account_id ORDER BY AVG(pse.star_earned) DESC) a WHERE a.star_earned > ps.star_earned) AS manager_rank
    ,a.canUnretire AS can_unretire
FROM
	account a
    LEFT JOIN (SELECT pl.account_id, AVG(ps.star_earned) AS star_earned FROM player pl INNER JOIN player_star ps ON ps.player_id = pl.player_id WHERE pl.is_active = 1 GROUP BY pl.account_id) ps ON ps.account_id = a.ID
WHERE
	a.ID = var_account_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_mark_as_unverified` (IN `var_email` VARCHAR(100))  NO SQL
UPDATE account SET isVerified = 0 WHERE Email = var_email$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Account_New` (IN `email_in` VARCHAR(100), IN `password_in` VARCHAR(255), IN `var_ip_address` VARCHAR(50))  NO SQL
INSERT INTO account (email, password, IpAddress) VALUES(email_in, password_in, var_ip_address)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_notification_new` (IN `var_account_id` INT, IN `var_player_id` INT, IN `var_template_id` INT)  NO SQL
INSERT INTO account_notification (account_id, player_id, notification_title, notification_body, notification_link)
SELECT
	var_account_id
    ,var_player_id
	,template_title
    ,template_body
    ,template_link
FROM
	notification_template
WHERE
	template_id = var_template_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_notification_pages_sel` (IN `var_account_id` INT, IN `var_player_id` INT)  NO SQL
SELECT
	COUNT(an.notification_id) AS notifications
    ,ROUND(COUNT(an.notification_id) / 15, 0) - 1 AS pages
FROM
	account_notification an
WHERE
	an.account_id = var_account_id
    AND
    	(
            an.player_id IS NULL
            OR
            an.player_id = var_player_id
         )$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_notification_sel` (IN `var_account_id` INT, IN `var_player_id` INT, IN `var_offset` INT)  NO SQL
SELECT
	n.notification_id
    ,n.recipient_first
    ,n.recipient_last
    ,n.notification_title
    ,n.notification_body
    ,n.notification_link
    ,n.notification_created
    ,n.is_read
FROM (
    SELECT
        an.notification_id
    	,'Account' AS recipient_first
        ,'' AS recipient_last
        ,an.notification_title
        ,an.notification_body
        ,an.notification_link
        ,an.notification_created
        ,an.is_read
    FROM
        account_notification an
        INNER JOIN account a ON a.ID = an.account_id AND a.ID = var_account_id AND a.IsActive = 1
    WHERE
        an.player_id IS NULL

        UNION ALL

    SELECT
    	an.notification_id
        ,pl.player_firstname AS recipient_first
        ,pl.player_lastname AS recipient_last
        ,an.notification_title
        ,an.notification_body
        ,an.notification_link
        ,an.notification_created
        ,an.is_read
    FROM
        account_notification an
        INNER JOIN account a ON a.ID = an.account_id AND a.ID = var_account_id AND a.IsActive = 1
        INNER JOIN player pl ON pl.player_id = an.player_id AND pl.player_id = var_player_id AND pl.is_active = 1
) n
ORDER BY 
	n.notification_created DESC
    ,n.notification_id DESC
LIMIT 15
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_player_list_by_stars_sel` (IN `var_account_id` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	pl.season_id
	,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_abbr
    ,mt.team_abbr
    ,an.unread_notifications
    ,ps.star_value
    ,ps.star_earned
    ,(SELECT COUNT(pse.player_id) + 1 FROM player_star pse INNER JOIN player ply ON ply.player_id = pse.player_id AND ply.is_active = 1 WHERE pse.star_earned > ps.star_earned) AS star_earned_rank
    ,(CASE WHEN smvp.season_mvp IS NULL THEN 0 ELSE smvp.season_mvp END) AS season_mvp
    ,(CASE WHEN alls.all_star IS NULL THEN 0 ELSE alls.all_star END) AS all_star
    ,(CASE WHEN pom.player_of_month IS NULL THEN 0 ELSE pom.player_of_month END) AS player_of_month
    ,(CASE WHEN pow.player_of_week IS NULL THEN 0 ELSE pow.player_of_week END) AS player_of_week
    ,(CASE WHEN gmvp.game_mvp IS NULL THEN 0 ELSE gmvp.game_mvp END) AS game_mvp
    ,(CASE WHEN ws.world_series_wins IS NULL THEN 0 ELSE ws.world_series_wins END) AS world_series_wins
    ,pl.can_sim
    ,pl.is_retired
    ,pse.is_postseason
    ,pse.is_finished
    ,(SELECT ts.game_id FROM team_schedule ts WHERE ts.season_id = pse.season_id AND is_finished = 1 ORDER BY game_date DESC LIMIT 1) AS last_game_id
    ,(SELECT ts.game_id FROM team_schedule ts WHERE ts.season_id = pse.season_id AND is_finished = 0 ORDER BY game_date ASC LIMIT 1) AS next_game_id
FROM
	player pl
    INNER JOIN player_season pse ON pse.season_id = pl.season_id AND pse.player_id = pl.player_id
    INNER JOIN master_team mt ON mt.team_id = pl.team_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    LEFT JOIN player_star ps ON ps.player_id = pl.player_id
    LEFT JOIN (
        SELECT 
        	COUNT(notification_id) AS unread_notifications
        	,account_id
        	,player_id
       	FROM 
        	account_notification
       	WHERE
        	is_read = 0
        GROUP BY account_id, player_id
   	) an ON an.account_id = pl.account_id AND an.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS season_mvp
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 11
       	GROUP BY pa.player_id
   	) smvp ON smvp.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS all_star
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 22
       	GROUP BY pa.player_id
   	) alls ON alls.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS player_of_month
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 16
       	GROUP BY pa.player_id
   	) pom ON pom.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS player_of_week
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 14
       	GROUP BY pa.player_id
   	) pow ON pow.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS world_series_wins
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 21
       	GROUP BY pa.player_id
   	) ws ON ws.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pgb.player_id
        	,COUNT(pgb.bonus_id) AS game_mvp
       	FROM 
        	player_game_bonus pgb
       	WHERE
        	pgb.bonus_id = 1
       	GROUP BY pgb.player_id
   	) gmvp ON gmvp.player_id = pl.player_id
WHERE
	pl.account_id = var_account_id
    AND pl.is_active = 1
ORDER BY
	ps.star_earned DESC
    ,pl.player_id ASC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_player_list_season_stats_by_stars_sel` (IN `var_account_id` INT)  NO SQL
SELECT
	pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_abbr
    ,mt.team_abbr
    ,an.unread_notifications
    ,pse.season_id
    ,ps.star_value
    ,ps.star_earned
    ,(SELECT COUNT(pse.player_id) + 1 FROM player_star pse INNER JOIN player ply ON ply.player_id = pse.player_id AND ply.is_active = 1 WHERE pse.star_earned > ps.star_earned) AS star_earned_rank
    ,pl.years_pro
    ,ms.stat_id
    ,ms.stat_abbr
    ,pss.stat_value
    ,gp.games_played
    ,pl.can_sim
    ,pl.is_retired
    ,pse.is_postseason
    ,pse.is_finished
FROM
	player pl
    INNER JOIN player_season pse ON pse.season_id = pl.season_id AND pse.player_id = pl.player_id
    INNER JOIN player_stat_season pss ON pss.season_id = pse.season_id AND pss.player_id = pl.player_id
    INNER JOIN master_stat ms ON ms.stat_id = pss.stat_id
    INNER JOIN master_team mt ON mt.team_id = pl.team_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    INNER JOIN (SELECT ts.season_id, COUNT(ts.game_id) AS games_played FROM team_schedule ts WHERE ts.is_finished = 1 GROUP BY ts.season_id) gp ON gp.season_id = pse.season_id
    LEFT JOIN player_star ps ON ps.player_id = pl.player_id
    LEFT JOIN (
        SELECT 
        	COUNT(notification_id) AS unread_notifications
        	,account_id
        	,player_id
       	FROM 
        	account_notification
       	WHERE
        	is_read = 0
        GROUP BY account_id, player_id
   	) an ON an.account_id = pl.account_id AND an.player_id = pl.player_id
WHERE
	pl.account_id = var_account_id
    AND pl.is_active = 1
ORDER BY
	ps.star_earned DESC
    ,pl.player_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_player_list_season_stats_sel` (IN `var_account_id` INT)  NO SQL
SELECT
	pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_abbr
    ,mt.team_abbr
    ,an.unread_notifications
    ,pse.season_id
    ,ps.star_value
    ,ps.star_earned
    ,(SELECT COUNT(pse.player_id) + 1 FROM player_star pse INNER JOIN player ply ON ply.player_id = pse.player_id AND ply.is_active = 1 WHERE pse.star_earned > ps.star_earned) AS star_earned_rank
    ,pl.years_pro
    ,ms.stat_id
    ,ms.stat_abbr
    ,pss.stat_value
    ,gp.games_played
    ,pl.can_sim
    ,pl.is_retired
    ,pse.is_postseason
    ,pse.is_finished
FROM
	player pl
    INNER JOIN player_season pse ON pse.season_id = pl.season_id AND pse.player_id = pl.player_id
    INNER JOIN player_stat_season pss ON pss.season_id = pse.season_id AND pss.player_id = pl.player_id
    INNER JOIN master_stat ms ON ms.stat_id = pss.stat_id
    INNER JOIN master_team mt ON mt.team_id = pl.team_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    INNER JOIN (SELECT ts.season_id, COUNT(ts.game_id) AS games_played FROM team_schedule ts WHERE ts.is_finished = 1 GROUP BY ts.season_id) gp ON gp.season_id = pse.season_id
    LEFT JOIN player_star ps ON ps.player_id = pl.player_id
    LEFT JOIN (
        SELECT 
        	COUNT(notification_id) AS unread_notifications
        	,account_id
        	,player_id
       	FROM 
        	account_notification
       	WHERE
        	is_read = 0
        GROUP BY account_id, player_id
   	) an ON an.account_id = pl.account_id AND an.player_id = pl.player_id
WHERE
	pl.account_id = var_account_id
    AND pl.is_active = 1
ORDER BY
	pl.player_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_player_list_sel` (IN `var_account_id` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	pl.season_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_abbr
    ,mt.team_abbr
    ,an.unread_notifications
    ,ps.star_value
    ,ps.star_earned
    ,(SELECT COUNT(pse.player_id) + 1 FROM player_star pse INNER JOIN player ply ON ply.player_id = pse.player_id AND ply.is_active = 1 WHERE pse.star_earned > ps.star_earned) AS star_earned_rank
    ,(CASE WHEN smvp.season_mvp IS NULL THEN 0 ELSE smvp.season_mvp END) AS season_mvp
    ,(CASE WHEN alls.all_star IS NULL THEN 0 ELSE alls.all_star END) AS all_star
    ,(CASE WHEN pom.player_of_month IS NULL THEN 0 ELSE pom.player_of_month END) AS player_of_month
    ,(CASE WHEN pow.player_of_week IS NULL THEN 0 ELSE pow.player_of_week END) AS player_of_week
    ,(CASE WHEN gmvp.game_mvp IS NULL THEN 0 ELSE gmvp.game_mvp END) AS game_mvp
    ,(CASE WHEN ws.world_series_wins IS NULL THEN 0 ELSE ws.world_series_wins END) AS world_series_wins
    ,pl.can_sim
    ,pl.is_retired
    ,pse.is_postseason
    ,pse.is_finished
    ,(SELECT ts.game_id FROM team_schedule ts WHERE ts.season_id = pse.season_id AND is_finished = 1 ORDER BY game_date DESC LIMIT 1) AS last_game_id
    ,(SELECT ts.game_id FROM team_schedule ts WHERE ts.season_id = pse.season_id AND is_finished = 0 ORDER BY game_date ASC LIMIT 1) AS next_game_id
FROM
	player pl
    INNER JOIN player_season pse ON pse.season_id = pl.season_id AND pse.player_id = pl.player_id
    INNER JOIN master_team mt ON mt.team_id = pl.team_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    LEFT JOIN player_star ps ON ps.player_id = pl.player_id
    LEFT JOIN (
        SELECT 
        	COUNT(notification_id) AS unread_notifications
        	,account_id
        	,player_id
       	FROM 
        	account_notification
       	WHERE
        	is_read = 0
        GROUP BY account_id, player_id
   	) an ON an.account_id = pl.account_id AND an.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS season_mvp
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 11
       	GROUP BY pa.player_id
   	) smvp ON smvp.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS all_star
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 22
       	GROUP BY pa.player_id
   	) alls ON alls.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS player_of_month
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 16
       	GROUP BY pa.player_id
   	) pom ON pom.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS player_of_week
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 14
       	GROUP BY pa.player_id
   	) pow ON pow.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS world_series_wins
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 21
       	GROUP BY pa.player_id
   	) ws ON ws.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pgb.player_id
        	,COUNT(pgb.bonus_id) AS game_mvp
       	FROM 
        	player_game_bonus pgb
       	WHERE
        	pgb.bonus_id = 1
       	GROUP BY pgb.player_id
   	) gmvp ON gmvp.player_id = pl.player_id
WHERE
	pl.account_id = var_account_id
    AND pl.is_active = 1
ORDER BY
	pl.player_id ASC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_player_simple_list_sel` (IN `var_account_id` INT)  NO SQL
SELECT
	pl.season_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_abbr
    ,mp.position_name
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,ifNull(an.unread_notifications, 0) AS unread_notifications
    ,ifNull(ps.star_value, 0) AS star_value
    ,pl.is_retired
FROM
	player pl
    INNER JOIN master_team mt ON mt.team_id = pl.team_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    INNER JOIN account a ON a.ID = pl.account_id
    LEFT JOIN player_star ps ON ps.player_id = pl.player_id
    LEFT JOIN (
        SELECT 
        	COUNT(notification_id) AS unread_notifications
        	,account_id
        	,player_id
       	FROM 
        	account_notification
       	WHERE
        	is_read = 0
        GROUP BY account_id, player_id
   	) an ON an.account_id = a.ID AND an.player_id = pl.player_id
WHERE
	a.ID = var_account_id
    AND a.IsActive = 1
    AND pl.is_active = 1
ORDER BY
	(CASE
     	WHEN pl.is_retired = 1 THEN 1
     	ELSE 0
     END) ASC
     ,pl.player_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_premium_status_sel` (IN `var_account_id` INT)  NO SQL
SELECT
	a.ID AS account_id
    ,a.isPremium AS is_premium
    ,(
        SELECT
        	COUNT(pl.player_id) AS active_players
       	FROM
        	player pl
        WHERE
        	pl.account_id = a.ID
        	AND pl.is_active = 1
                AND pl.is_retired = 0
    ) AS active_players
FROM
	account a
WHERE
    a.ID = var_account_id
    AND a.isActive = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_reactivate_upd` (IN `var_email` VARCHAR(100))  NO SQL
UPDATE account a
SET 
	a.isActive = 1
    ,a.IsVerified = 1
    ,a.lastLogin = CURRENT_TIMESTAMP
WHERE
	a.Email = var_email
    AND a.IsActive = 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_record_game_sel` (IN `var_account_id` INT, IN `var_type` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	a.ID AS account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pr.stat_id
    ,ms.stat_name
    ,ms.stat_abbr
    ,ms.stat_desc
    ,pr.stat_value AS record_value
    ,pr.game_id
    ,pl.is_retired
    ,ts.game_date
    ,ts.team_score
    ,ts.opponent_score
FROM
	player pl
 	INNER JOIN player_season ps ON ps.player_id = pl.player_id
    INNER JOIN team_schedule ts ON ts.season_id = ps.season_id AND ts.is_finished = 1
    INNER JOIN player_stat_game pr ON pr.game_id = ts.game_id
    INNER JOIN master_stat ms ON ms.stat_id = pr.stat_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
    INNER JOIN account a ON a.ID = pl.account_id
WHERE
	ms.stat_id = var_type
    AND pl.is_active = 1
    AND pl.account_id = var_account_id
    AND pr.stat_value > 0
ORDER BY
    pr.stat_value DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_record_season_sel` (IN `var_account_id` INT, IN `var_type` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	a.ID AS account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pr.stat_id
    ,ms.stat_name
    ,ms.stat_abbr
    ,ms.stat_desc
    ,pr.stat_value AS record_value
    ,pl.is_retired
FROM
	player pl
    INNER JOIN player_stat_season pr ON pr.player_id = pl.player_id
    INNER JOIN player_season ps ON ps.season_id = pr.season_id
    INNER JOIN master_stat ms ON ms.stat_id = pr.stat_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
    INNER JOIN account a ON a.ID = pl.account_id
WHERE
	ms.stat_id = var_type
    AND pl.is_active = 1
    AND pl.account_id = var_account_id
    AND pr.stat_value > 0
ORDER BY
    pr.stat_value DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_refresh_last_login` (IN `var_account_id` INT)  NO SQL
UPDATE account SET lastLogin = CURRENT_TIMESTAMP WHERE ID = var_account_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_store_new_password` (IN `var_email` VARCHAR(100), IN `var_new_password` VARCHAR(255))  NO SQL
UPDATE account a
SET 
	a.Password = var_new_password
    ,a.isVerified = 0
WHERE 
	a.Email = var_email
    AND a.isVerified = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Account_Subscriptions` (IN `email_in` VARCHAR(100))  NO SQL
SELECT acc_sub.subscription_id, sub.subscription_description, acc_sub.is_active
FROM
	account acc
    INNER JOIN account_subscription acc_sub ON acc.ID = acc_sub.account_id
    INNER JOIN subscription sub ON acc_sub.subscription_id = sub.subscription_id AND sub.is_active = 1
WHERE acc.Email = email_in AND acc.isVerified = 1 AND acc.isActive = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_toggle_emails` (IN `var_account_id` INT, IN `var_is_subscribed` INT)  NO SQL
UPDATE account SET isSubscribed = var_is_subscribed WHERE ID = var_account_id AND isActive = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_unretire_upd` (IN `var_account_id` INT, IN `var_can_unretire` INT)  NO SQL
UPDATE account SET canUnretire = var_can_unretire WHERE ID = var_account_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_username_sel` (IN `var_username` VARCHAR(50))  NO SQL
SELECT * FROM account WHERE username = var_username LIMIT 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_username_upd` (IN `var_account_id` INT, IN `var_username` VARCHAR(50))  NO SQL
UPDATE account SET username = var_username WHERE ID = var_account_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `account_verification_upd` (IN `var_account_email` VARCHAR(100))  NO SQL
UPDATE account SET isVerified = 1 WHERE Email = var_account_email AND isVerified = 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_bulk_reschedule_games_sel` ()  NO SQL
select pl.player_id from team_schedule ts inner join player pl on pl.season_id = ts.season_id and pl.is_active = 1 inner join account a on a.id = pl.account_id and a.IsActive = 1 where ts.game_date < '2021-05-16' and ts.is_finished = 0 and ts.can_sim = 1 order by ts.game_date desc$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_bulk_reschedule_games_table_sel` ()  NO SQL
select * from admin_bulk_reschedule_games$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_player_activate_toggle_upd` (IN `var_player_id` INT, IN `var_is_active` INT)  NO SQL
UPDATE player SET is_active = var_is_active WHERE player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_player_rename_upd` (IN `var_player_id` INT, IN `var_first_name` VARCHAR(25), IN `var_last_name` VARCHAR(25))  NO SQL
UPDATE player SET player_firstname = var_first_name, player_lastname = var_last_name WHERE player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_player_unstick_simulation_sel` ()  NO SQL
select pl.account_id,pl.player_id,ps.season_id,ps.team_id,mt.conference_id from player_season ps inner join player pl on pl.player_id = ps.player_id inner join master_team mt on mt.team_id = ps.team_id where ps.team_wins + ps.team_losses = 159 and ps.season_id not in (select ts.season_id from team_schedule ts where ts.game_date > NOW()) and pl.is_retired = 0 and pl.is_active = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `game_recap_batting_order_sel` (IN `var_game_id` INT)  NO SQL
SELECT
	tgbo.game_id
    ,tgbo.batting_order
    ,mp.position_name
    ,mp.position_abbr
    ,tgbo.is_owned_player
    ,tgbo.is_designated_hitter
    ,tr.first_name AS batter_first_name
    ,tr.last_name AS batter_last_name
FROM
	team_game_batting_order tgbo
    INNER JOIN master_position mp ON mp.position_id = tgbo.position_id
    INNER JOIN team_schedule ts ON ts.game_id = tgbo.game_id
    INNER JOIN team_roster tr ON tr.season_id = ts.season_id AND tr.team_id = ts.team_id AND tr.roster_id = tgbo.roster_id
WHERE
	tgbo.game_id = var_game_id
ORDER BY
	tgbo.batting_order ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `game_recap_opponent_half_inning_sel` (IN `var_game_id` INT)  NO SQL
SELECT
	inn.game_id
    ,inn.opponent_team_id
    ,inn.game_inning
    ,inn.game_half_inning AS game_inning_half
    ,inn.opponent_start_runs
    ,inn.opponent_runs_scored
    ,inn.opponent_end_runs
FROM
	team_game_opponent_half_inning inn
WHERE
	inn.game_id = var_game_id
ORDER BY
	inn.game_inning ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `game_recap_overview_sel` (IN `var_game_id` INT)  NO SQL
SELECT
	ts.season_id
    ,ts.game_id
    ,ps.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_position
    ,mp.position_name
    ,mp.position_abbr
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,(CASE WHEN ts.is_finished = 0 THEN ls.wins ELSE ts.team_wins END) team_wins
    ,(CASE WHEN ts.is_finished = 0 THEN ls.losses ELSE ts.team_losses END) team_losses
    ,ls.playoff_seed AS team_playoff_seed
    ,opp.team_city AS opp_team_city
    ,opp.team_name AS opp_team_name
    ,opp.team_abbr AS opp_team_abbr
    ,(CASE WHEN ts.is_finished = 0 THEN ls_opp.wins ELSE ts.opponent_wins END) opp_team_wins
    ,(CASE WHEN ts.is_finished = 0 THEN ls_opp.losses ELSE ts.opponent_losses END) opp_team_losses
    ,ls_opp.playoff_seed AS opp_team_playoff_seed
    ,ts.team_score
    ,ts.opponent_score
    ,ts.innings
    ,ts.game_outcome
    ,tbo.batting_order
    ,ts.is_home
    ,ts.is_postseason
    ,(CASE WHEN psg.stat_value BETWEEN -0.49 AND 0 THEN 0 ELSE ROUND(psg.stat_value, 0) END) AS stars_earned
    ,ts.game_date
    ,ts.is_finished
    ,ts.can_sim
FROM
	team_schedule ts
    INNER JOIN player_season ps ON ps.season_id = ts.season_id
    INNER JOIN player pl ON pl.player_id = ps.player_id
    INNER JOIN team_batting_order tbo ON tbo.season_id = ps.season_id AND tbo.team_id = ps.team_id AND tbo.player_id = ps.player_id
    INNER JOIN master_team mt ON mt.league_id = ps.league_id AND mt.team_id = ts.team_id
    INNER JOIN league_standings ls ON ls.season_id = ps.season_id AND ls.team_id = mt.team_id
    INNER JOIN master_team opp ON opp.league_id = ps.league_id AND opp.team_id = ts.opponent_id
    INNER JOIN league_standings ls_opp ON ls_opp.season_id = ps.season_id AND ls_opp.team_id = opp.team_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    LEFT JOIN player_stat_game psg ON psg.game_id = ts.game_id AND psg.player_id = ps.player_id AND psg.stat_id = 24
WHERE
	ts.game_id = var_game_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `game_recap_plate_appearances_sel` (IN `var_game_id` INT)  NO SQL
SELECT
	pa.game_id
    ,pa.team_id
    ,pa.game_inning
    ,pa.game_inning_half
    ,pa.game_team_score
    ,pa.game_opponent_score
    ,pa.game_outs
    ,mp_first.position_name AS position_on_first
    ,mp_first.position_abbr AS position_abbr_on_first
    ,mp_second.position_name AS position_on_second
    ,mp_second.position_abbr AS position_abbr_on_second
    ,mp_third.position_name AS position_on_third
    ,mp_third.position_abbr AS position_abbr_on_third
    ,tr.first_name AS batter_first_name
    ,tr.last_name AS batter_last_name
    ,mp.position_name AS batter_position
    ,mp.position_abbr AS batter_position_abbr
    ,ms.stat_id
    ,ms.stat_name
    ,ms.stat_desc
    ,pa.stat_value
    ,pa.ball_direction AS direction_id
    ,mbd.direction
    ,pa.runs
    ,pa.runs_batted_in
    ,pa.left_on_base
    ,pa.is_out_sac_fly
    ,pa.is_out_sac_hit
    ,pa.is_sb_attempt
    ,pa.is_sb_succeed
    ,pa.sb_position
    ,pa.sb_base
    ,pa.is_player_sb
    ,pa.is_out_double_play
    ,pa.is_walkoff
    ,(CASE WHEN pa.is_walkoff = 1 THEN 1 ELSE pa.is_inning_end END) AS is_inning_end
    ,pa.is_extra_innings
    ,(CASE 
      WHEN pa.is_owned_player = 1 THEN (SELECT tr2.roster_id FROM player_season ps INNER JOIN team_roster tr2 ON tr2.season_id = ps.season_id WHERE ps.player_id = (SELECT pl.player_id FROM player pl WHERE pl.season_id = tr.season_id LIMIT 1) AND tr2.is_player = 1 ORDER BY tr2.roster_id ASC LIMIT 1) 
      ELSE tgbo.roster_id
    END) AS face_id
    ,pa.is_owned_player
    ,pa.stars_earned
FROM
	team_game_plate_appearance pa
    INNER JOIN team_schedule ts ON ts.game_id = pa.game_id
    INNER JOIN team_game_batting_order tgbo ON tgbo.game_id = pa.game_id AND tgbo.position_id = pa.position_id
    INNER JOIN team_roster tr ON tr.season_id = ts.season_id AND tr.team_id = ts.team_id AND tr.position_id = tgbo.position_id AND tr.roster_id = tgbo.roster_id
    INNER JOIN master_position mp ON mp.position_id = pa.position_id
    INNER JOIN master_stat ms ON ms.stat_id = pa.stat_id
    LEFT JOIN master_position mp_first ON mp_first.position_id = pa.on_first_position_id
    LEFT JOIN master_position mp_second ON mp_second.position_id = pa.on_second_position_id
    LEFT JOIN master_position mp_third ON mp_third.position_id = pa.on_third_position_id
    LEFT JOIN master_ball_direction mbd ON mbd.direction_id = pa.ball_direction
WHERE
	pa.game_id = var_game_id
ORDER BY
	pa.appearance_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `game_recap_player_bonus_sel` (IN `var_game_id` INT)  NO SQL
SELECT
	pgb.game_id
    ,pgb.bonus_id
    ,mb.bonus_name
    ,mb.bonus_desc
    ,ROUND(pgb.bonus_value, 0) AS bonus_stars
FROM
	player_game_bonus pgb
    INNER JOIN master_bonus mb ON mb.bonus_id = pgb.bonus_id
WHERE
	pgb.game_id = var_game_id
ORDER BY
	pgb.bonus_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `game_recap_team_player_stats_sel` (IN `var_game_id` INT)  NO SQL
SELECT
	tr.season_id
    ,tr.first_name
    ,tr.last_name
    ,tr.position_id
    ,mp.position_name
    ,mp.position_abbr
    ,tr.team_id
    ,tgpa.stat_id
    ,ms.stat_name
    ,ms.stat_abbr
    ,ms.stat_desc
    ,tgpa.stat_value
    ,tgpa.stars_earned
    ,tgpa.runs_batted_in
    ,tgpa.left_on_base
    ,tgpa.is_out_sac_fly
    ,tgpa.is_out_sac_hit
    ,tgbo.is_owned_player
FROM
	team_roster tr
    INNER JOIN team_schedule ts ON ts.season_id = tr.season_id AND ts.team_id = tr.team_id
    INNER JOIN team_game_batting_order tgbo ON tgbo.game_id = ts.game_id AND tgbo.roster_id = tr.roster_id
    INNER JOIN team_game_plate_appearance tgpa ON tgpa.game_id = ts.game_id AND tgpa.team_id = ts.team_id AND tgpa.position_id = tgbo.position_id
    INNER JOIN master_position mp ON mp.position_id = tr.position_id
    INNER JOIN master_stat ms ON ms.stat_id = tgpa.stat_id
WHERE
	ts.game_id = var_game_id
    AND tr.pitcher_rotation_id = 0
ORDER BY
	tgbo.batting_order ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `get_playoff_opponent` (IN `var_season_id` INT, IN `var_conference_id` INT, IN `var_team_id` INT, IN `var_playoff_round` INT)  NO SQL
SELECT
	(CASE
     WHEN lps.home_team_id <> var_team_id THEN lps.home_team_id
     WHEN lps.visit_team_id <> var_team_id THEN lps.visit_team_id
     ELSE 0
     END) AS team_id
    ,(CASE
     WHEN lps.home_team_id <> var_team_id THEN lps.home_team_seed
     WHEN lps.visit_team_id <> var_team_id THEN lps.visit_team_seed
     ELSE 0
     END) AS playoff_seed
FROM
	master_team mt
    INNER JOIN league_playoff_schedule lps ON mt.team_id IN (lps.home_team_id, lps.visit_team_id)
WHERE
	mt.conference_id = var_conference_id
	AND mt.team_id = var_team_id
    AND lps.season_id = var_season_id
    AND lps.round = var_playoff_round
    AND lps.is_finished = 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `homepage_games_recent_sel` (IN `var_is_finished` INT, IN `var_limit` INT, IN `var_offset` INT, IN `var_date_diff` INT)  NO SQL
SELECT
	ts.game_id
    ,tr.roster_id AS face_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
	,mt.team_abbr AS team
    ,mt.team_city AS team_city
    ,mt.team_name AS team_name
    ,mto.team_abbr AS opponent
    ,mto.team_city AS opponent_city
    ,mto.team_name AS opponent_name
    ,ts.game_date
    ,(CASE
      	WHEN ts.is_finished = 0 THEN tbo.batting_order
      	ELSE tgbo.batting_order
      END) AS batting_order
    ,ts.season_id
    ,ts.is_home
    ,ts.is_finished
    ,ts.team_score
    ,ts.opponent_score
    ,ts.game_outcome
    ,(CASE WHEN psg.stat_value BETWEEN -0.49 AND 0 THEN 0 ELSE ROUND(psg.stat_value, 0) END) AS star_earned
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_wins ELSE pts.wins END) AS team_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_losses ELSE pts.losses END) AS team_losses
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_wins ELSE ots.wins END) AS opponent_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_losses ELSE ots.losses END) AS opponent_losses
    ,ts.innings
    ,ts.can_sim
    ,ts.is_postseason
FROM
	player pl
    INNER JOIN player_season ps ON ps.season_id = pl.season_id
	INNER JOIN team_schedule ts ON ts.season_id = pl.season_id AND ts.team_id = ps.team_id
    INNER JOIN master_team mt ON mt.team_id = ts.team_id
    INNER JOIN master_team mto ON mto.team_id = ts.opponent_id
    INNER JOIN league_standings pts ON pts.season_id = pl.season_id AND pts.team_id = pl.team_id AND pts.league_id = ps.league_id
    INNER JOIN league_standings ots ON ots.season_id = pl.season_id AND ots.team_id = ts.opponent_id AND ots.league_id = ps.league_id
    INNER JOIN team_roster tr ON tr.season_id = pl.season_id AND tr.team_id = pl.team_id AND tr.is_player = 1
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = pl.season_id AND tbo.team_id = pl.team_id
    LEFT JOIN player_stat_game psg ON psg.game_id = ts.game_id AND psg.player_id = pl.player_id AND psg.stat_id = 24
	LEFT JOIN team_game_batting_order tgbo ON tgbo.game_id = ts.game_id AND tgbo.is_owned_player = 1
WHERE
    pl.is_active = 1
    AND ts.is_finished = var_is_finished
    AND ts.is_hidden = 0
    AND ts.can_sim = 0
    AND DATEDIFF(DATE(NOW()), DATE(ts.game_date)) <= var_date_diff
ORDER BY 
	ts.game_date DESC
    ,ts.game_id DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `homepage_games_sel` (IN `var_is_finished` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	ts.game_id
    ,tr.roster_id AS face_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
	,mt.team_abbr AS team
    ,mt.team_city AS team_city
    ,mt.team_name AS team_name
    ,mto.team_abbr AS opponent
    ,mto.team_city AS opponent_city
    ,mto.team_name AS opponent_name
    ,ts.game_date
    ,(CASE
      	WHEN ts.is_finished = 0 THEN tbo.batting_order
      	ELSE tgbo.batting_order
      END) AS batting_order
    ,ts.season_id
    ,ts.is_home
    ,ts.is_finished
    ,ts.team_score
    ,ts.opponent_score
    ,ts.game_outcome
    ,(CASE WHEN psg.stat_value BETWEEN -0.49 AND 0 THEN 0 ELSE ROUND(psg.stat_value, 0) END) AS star_earned
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_wins ELSE pts.wins END) AS team_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_losses ELSE pts.losses END) AS team_losses
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_wins ELSE ots.wins END) AS opponent_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_losses ELSE ots.losses END) AS opponent_losses
    ,ts.innings
    ,ts.can_sim
    ,ts.is_postseason
FROM
	player pl
    INNER JOIN player_season ps ON ps.season_id = pl.season_id
	INNER JOIN team_schedule ts ON ts.season_id = pl.season_id AND ts.team_id = ps.team_id
    INNER JOIN master_team mt ON mt.team_id = ts.team_id
    INNER JOIN master_team mto ON mto.team_id = ts.opponent_id
    INNER JOIN league_standings pts ON pts.season_id = pl.season_id AND pts.team_id = pl.team_id AND pts.league_id = ps.league_id
    INNER JOIN league_standings ots ON ots.season_id = pl.season_id AND ots.team_id = ts.opponent_id AND ots.league_id = ps.league_id
    INNER JOIN team_roster tr ON tr.season_id = pl.season_id AND tr.team_id = pl.team_id AND tr.is_player = 1
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = pl.season_id AND tbo.team_id = pl.team_id
    LEFT JOIN player_stat_game psg ON psg.game_id = ts.game_id AND psg.player_id = pl.player_id AND psg.stat_id = 24
	LEFT JOIN team_game_batting_order tgbo ON tgbo.game_id = ts.game_id AND tgbo.is_owned_player = 1
WHERE
    pl.is_active = 1
    AND ts.is_finished = var_is_finished
    AND ts.is_hidden = 0
    AND ts.can_sim = 1
    AND DATE(ts.game_date) = DATE(NOW())
ORDER BY 
	(CASE WHEN ts.is_finished = 1 THEN ts.game_date ELSE 0 END) DESC
	,(CASE WHEN ts.is_finished = 0 THEN ts.game_date ELSE 0 END) ASC
    ,ts.game_id DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `homepage_games_sel_old` (IN `var_is_finished` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	ts.game_id
    ,0 AS face_id
    ,0 AS player_id
    ,'' AS player_firstname
    ,'' AS player_lastname
	,mt.team_abbr AS team
    ,mt.team_city AS team_city
    ,mt.team_name AS team_name
    ,mto.team_abbr AS opponent
    ,mto.team_city AS opponent_city
    ,mto.team_name AS opponent_name
    ,ts.game_date
    ,0 AS batting_order
    ,ts.season_id
    ,ts.is_home
    ,ts.is_finished
    ,ts.team_score
    ,ts.opponent_score
    ,ts.game_outcome
    ,0 AS star_earned
    ,0 AS team_wins
    ,0 AS team_losses
    ,0 AS opponent_wins
    ,0 AS opponent_losses
    ,ts.innings
    ,ts.can_sim
    ,ts.is_postseason
FROM
	team_schedule ts
    INNER JOIN master_team mt ON mt.team_id = ts.team_id
    INNER JOIN master_team mto ON mto.team_id = ts.opponent_id
WHERE
    ts.is_finished = var_is_finished
    AND ts.is_hidden = 0
    AND ts.can_sim = 1
    AND DATE(ts.game_date) = DATE(NOW())
ORDER BY 
	(CASE WHEN ts.is_finished = 1 THEN ts.game_date ELSE 0 END) DESC
	,(CASE WHEN ts.is_finished = 0 THEN ts.game_date ELSE 0 END) ASC
    ,ts.game_id DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `homepage_top_players_sel` (IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	0 AS face_id
    ,pl.season_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_abbr
    ,mt.team_abbr
    ,pl.player_age
    ,pl.years_pro AS player_seasons
    ,ps.star_earned
    ,pl.is_retired
FROM
	player_star ps
    INNER JOIN player pl ON pl.player_id = ps.player_id AND pl.is_active = 1
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    INNER JOIN master_team mt ON mt.team_id = pl.team_id
WHERE
	ps.star_earned > 0
GROUP BY 
	pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_abbr
    ,mt.team_abbr
    ,ps.star_earned
    ,pl.is_retired
ORDER BY
	ps.star_earned DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ip_address_block` (IN `var_ip_address` VARCHAR(50))  NO SQL
INSERT IGNORE INTO IpAddressLog (IpAddress, IsBlocked) VALUES(var_ip_address, 1)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ip_address_checker` (IN `var_ip_address` VARCHAR(50))  NO SQL
SELECT IsBlocked FROM IpAddressLog WHERE IpAddress = var_ip_address LIMIT 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `leaderboard_best_players_by_position_sel` (IN `var_account_id` INT, IN `var_position_abbr` VARCHAR(2), IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	a.ID AS account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,pl.season_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_abbr
    ,mt.team_abbr
    ,pl.player_age
    ,pl.years_pro AS player_seasons
    ,ps.star_earned
    ,(CASE WHEN smvp.season_mvp IS NULL THEN 0 ELSE smvp.season_mvp END) AS season_mvp
    ,(CASE WHEN alls.all_star IS NULL THEN 0 ELSE alls.all_star END) AS all_star
    ,(CASE WHEN pom.player_of_month IS NULL THEN 0 ELSE pom.player_of_month END) AS player_of_month
    ,(CASE WHEN pow.player_of_week IS NULL THEN 0 ELSE pow.player_of_week END) AS player_of_week
    ,(CASE WHEN gmvp.game_mvp IS NULL THEN 0 ELSE gmvp.game_mvp END) AS game_mvp
    ,(CASE WHEN ws.world_series_wins IS NULL THEN 0 ELSE ws.world_series_wins END) AS world_series_wins
    ,(CASE WHEN var_account_id = pl.account_id THEN 1 ELSE 0 END) AS is_account_player
    ,pl.is_retired
FROM
	player_star ps
    INNER JOIN player pl ON pl.player_id = ps.player_id AND pl.is_active = 1
    INNER JOIN account a ON a.ID = pl.account_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    INNER JOIN master_team mt ON mt.team_id = pl.team_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS season_mvp
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 11
       	GROUP BY pa.player_id
   	) smvp ON smvp.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS all_star
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 22
       	GROUP BY pa.player_id
   	) alls ON alls.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS player_of_month
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 16
       	GROUP BY pa.player_id
   	) pom ON pom.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS player_of_week
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 14
       	GROUP BY pa.player_id
   	) pow ON pow.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS world_series_wins
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 21
       	GROUP BY pa.player_id
   	) ws ON ws.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pgb.player_id
        	,COUNT(pgb.bonus_id) AS game_mvp
       	FROM 
        	player_game_bonus pgb
       	WHERE
        	pgb.bonus_id = 1
       	GROUP BY pgb.player_id
   	) gmvp ON gmvp.player_id = pl.player_id
WHERE
	ps.star_earned > 0
    AND mp.position_abbr = var_position_abbr
GROUP BY 
	pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_abbr
    ,mt.team_abbr
    ,ps.star_earned
    ,pl.is_retired
ORDER BY
	ps.star_earned DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `leaderboard_hall_of_fame_owned_sel` (IN `var_account_id` INT)  NO SQL
SELECT
	pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_abbr
    ,mt.team_abbr
    ,ps.star_earned
    ,(SELECT COUNT(pst.player_id) + 1 FROM player_star pst INNER JOIN player ply ON ply.player_id = pst.player_id AND ply.is_active = 1 WHERE pst.player_id = pl.player_id AND pst.star_earned > ps.star_earned) AS star_earned_rank
    ,pl.is_retired
    ,pl.years_pro AS player_seasons
FROM
	player_star ps
    INNER JOIN player pl ON pl.player_id = ps.player_id AND pl.is_active = 1
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    INNER JOIN master_team mt ON mt.team_id = pl.team_id
WHERE
	ps.star_earned > 0
    AND pl.account_id = var_account_id
    AND pl.is_active = 1
GROUP BY 
	pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_abbr
    ,mt.team_abbr
    ,ps.star_earned
    ,pl.is_retired
ORDER BY
	ps.star_earned DESC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `leaderboard_hall_of_fame_sel` (IN `var_account_id` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	a.ID AS account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_abbr
    ,mt.team_abbr
    ,pl.player_age
    ,pl.years_pro AS player_seasons
    ,ps.star_earned
    ,(CASE WHEN smvp.season_mvp IS NULL THEN 0 ELSE smvp.season_mvp END) AS season_mvp
    ,(CASE WHEN alls.all_star IS NULL THEN 0 ELSE alls.all_star END) AS all_star
    ,(CASE WHEN pom.player_of_month IS NULL THEN 0 ELSE pom.player_of_month END) AS player_of_month
    ,(CASE WHEN pow.player_of_week IS NULL THEN 0 ELSE pow.player_of_week END) AS player_of_week
    ,(CASE WHEN gmvp.game_mvp IS NULL THEN 0 ELSE gmvp.game_mvp END) AS game_mvp
    ,(CASE WHEN ws.world_series_wins IS NULL THEN 0 ELSE ws.world_series_wins END) AS world_series_wins
    ,(CASE WHEN var_account_id = pl.account_id THEN 1 ELSE 0 END) AS is_account_player
    ,pl.is_retired
FROM
	player_star ps
    INNER JOIN player pl ON pl.player_id = ps.player_id AND pl.is_active = 1
    INNER JOIN account a ON a.ID = pl.account_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    INNER JOIN master_team mt ON mt.team_id = pl.team_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS season_mvp
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 11
       	GROUP BY pa.player_id
   	) smvp ON smvp.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS all_star
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 22
       	GROUP BY pa.player_id
   	) alls ON alls.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS player_of_month
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 16
       	GROUP BY pa.player_id
   	) pom ON pom.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS player_of_week
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 14
       	GROUP BY pa.player_id
   	) pow ON pow.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS world_series_wins
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 21
       	GROUP BY pa.player_id
   	) ws ON ws.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pgb.player_id
        	,COUNT(pgb.bonus_id) AS game_mvp
       	FROM 
        	player_game_bonus pgb
       	WHERE
        	pgb.bonus_id = 1
       	GROUP BY pgb.player_id
   	) gmvp ON gmvp.player_id = pl.player_id
WHERE
	ps.star_earned > 0
GROUP BY 
	pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_abbr
    ,mt.team_abbr
    ,ps.star_earned
    ,pl.is_retired
ORDER BY
	ps.star_earned DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `leaderboard_misc_games_grand_slams_sel` (IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	ts.game_id
    ,tr.roster_id AS face_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
	,mt.team_abbr AS team
    ,mt.team_city AS team_city
    ,mt.team_name AS team_name
    ,mto.team_abbr AS opponent
    ,mto.team_city AS opponent_city
    ,mto.team_name AS opponent_name
    ,ts.game_date
    ,(CASE
      	WHEN ts.is_finished = 0 THEN tbo.batting_order
      	ELSE tgbo.batting_order
      END) AS batting_order
    ,ts.season_id
    ,ts.is_home
    ,ts.is_finished
    ,ts.team_score
    ,ts.opponent_score
    ,ts.game_outcome
    ,(CASE WHEN psg.stat_value BETWEEN -0.49 AND 0 THEN 0 ELSE ROUND(psg.stat_value, 0) END) AS star_earned
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_wins ELSE pts.wins END) AS team_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_losses ELSE pts.losses END) AS team_losses
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_wins ELSE ots.wins END) AS opponent_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_losses ELSE ots.losses END) AS opponent_losses
    ,ts.innings
    ,ts.can_sim
    ,ts.is_postseason
    ,sv.stat_value
FROM
	player pl
	INNER JOIN team_schedule ts ON ts.season_id = pl.season_id
    INNER JOIN master_team mt ON mt.team_id = ts.team_id
    INNER JOIN master_team mto ON mto.team_id = ts.opponent_id
    INNER JOIN league_standings pts ON pts.season_id = pl.season_id AND pts.team_id = pl.team_id AND pts.league_id = mt.league_id
    INNER JOIN league_standings ots ON ots.season_id = pl.season_id AND ots.team_id = ts.opponent_id AND ots.league_id = mto.league_id
    INNER JOIN team_roster tr ON tr.season_id = pl.season_id AND tr.team_id = pl.team_id AND tr.is_player = 1
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = pl.season_id AND tbo.team_id = pl.team_id
    INNER JOIN team_stat_game sv ON sv.game_id = ts.game_id AND sv.team_id = ts.team_id AND sv.stat_id = 25
    LEFT JOIN player_stat_game psg ON psg.game_id = ts.game_id AND psg.player_id = pl.player_id AND psg.stat_id = 24
	LEFT JOIN team_game_batting_order tgbo ON tgbo.game_id = ts.game_id AND tgbo.is_owned_player = 1
WHERE
    pl.is_active = 1
    AND ts.is_finished = 1
    AND sv.stat_value > 0
ORDER BY 
	sv.stat_value DESC
    ,ts.game_date DESC
    ,ts.game_id DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `leaderboard_misc_games_score_difference_sel` (IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	ts.game_id
    ,tr.roster_id AS face_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
	,mt.team_abbr AS team
    ,mt.team_city AS team_city
    ,mt.team_name AS team_name
    ,mto.team_abbr AS opponent
    ,mto.team_city AS opponent_city
    ,mto.team_name AS opponent_name
    ,ts.game_date
    ,(CASE
      	WHEN ts.is_finished = 0 THEN tbo.batting_order
      	ELSE tgbo.batting_order
      END) AS batting_order
    ,ts.season_id
    ,ts.is_home
    ,ts.is_finished
    ,ts.team_score
    ,ts.opponent_score
    ,ts.game_outcome
    ,(CASE WHEN psg.stat_value BETWEEN -0.49 AND 0 THEN 0 ELSE ROUND(psg.stat_value, 0) END) AS star_earned
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_wins ELSE pts.wins END) AS team_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_losses ELSE pts.losses END) AS team_losses
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_wins ELSE ots.wins END) AS opponent_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_losses ELSE ots.losses END) AS opponent_losses
    ,ts.innings
    ,ts.can_sim
    ,ts.is_postseason
    ,(CASE WHEN ts.team_score > ts.opponent_score THEN ts.team_score - ts.opponent_score ELSE ts.opponent_score - ts.team_score END) AS stat_value
FROM
	player pl
	INNER JOIN team_schedule ts ON ts.season_id = pl.season_id
    INNER JOIN master_team mt ON mt.team_id = ts.team_id
    INNER JOIN master_team mto ON mto.team_id = ts.opponent_id
    INNER JOIN league_standings pts ON pts.season_id = pl.season_id AND pts.team_id = pl.team_id AND pts.league_id = mt.league_id
    INNER JOIN league_standings ots ON ots.season_id = pl.season_id AND ots.team_id = ts.opponent_id AND ots.league_id = mto.league_id
    INNER JOIN team_roster tr ON tr.season_id = pl.season_id AND tr.team_id = pl.team_id AND tr.is_player = 1
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = pl.season_id AND tbo.team_id = pl.team_id
    LEFT JOIN player_stat_game psg ON psg.game_id = ts.game_id AND psg.player_id = pl.player_id AND psg.stat_id = 24
	LEFT JOIN team_game_batting_order tgbo ON tgbo.game_id = ts.game_id AND tgbo.is_owned_player = 1
WHERE
    pl.is_active = 1
    AND ts.is_finished = 1
ORDER BY 
	(CASE WHEN ts.team_score > ts.opponent_score THEN ts.team_score - ts.opponent_score ELSE ts.opponent_score - ts.team_score END) DESC
    ,ts.game_date DESC
    ,ts.game_id DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `leaderboard_misc_highest_scoring_games_sel` (IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	ts.game_id
    ,tr.roster_id AS face_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
	,mt.team_abbr AS team
    ,mt.team_city AS team_city
    ,mt.team_name AS team_name
    ,mto.team_abbr AS opponent
    ,mto.team_city AS opponent_city
    ,mto.team_name AS opponent_name
    ,ts.game_date
    ,(CASE
      	WHEN ts.is_finished = 0 THEN tbo.batting_order
      	ELSE tgbo.batting_order
      END) AS batting_order
    ,ts.season_id
    ,ts.is_home
    ,ts.is_finished
    ,ts.team_score
    ,ts.opponent_score
    ,ts.game_outcome
    ,(CASE WHEN psg.stat_value BETWEEN -0.49 AND 0 THEN 0 ELSE ROUND(psg.stat_value, 0) END) AS star_earned
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_wins ELSE pts.wins END) AS team_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_losses ELSE pts.losses END) AS team_losses
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_wins ELSE ots.wins END) AS opponent_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_losses ELSE ots.losses END) AS opponent_losses
    ,ts.innings
    ,ts.can_sim
    ,ts.is_postseason
FROM
	player pl
	INNER JOIN team_schedule ts ON ts.season_id = pl.season_id
    INNER JOIN master_team mt ON mt.team_id = ts.team_id
    INNER JOIN master_team mto ON mto.team_id = ts.opponent_id
    INNER JOIN league_standings pts ON pts.season_id = pl.season_id AND pts.team_id = pl.team_id AND pts.league_id = mt.league_id
    INNER JOIN league_standings ots ON ots.season_id = pl.season_id AND ots.team_id = ts.opponent_id AND ots.league_id = mto.league_id
    INNER JOIN team_roster tr ON tr.season_id = pl.season_id AND tr.team_id = pl.team_id AND tr.is_player = 1
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = pl.season_id AND tbo.team_id = pl.team_id
    LEFT JOIN player_stat_game psg ON psg.game_id = ts.game_id AND psg.player_id = pl.player_id AND psg.stat_id = 24
	LEFT JOIN team_game_batting_order tgbo ON tgbo.game_id = ts.game_id AND tgbo.is_owned_player = 1
WHERE
    pl.is_active = 1
    AND ts.is_finished = 1
ORDER BY 
	ts.team_score + ts.opponent_score DESC
    ,ts.game_date DESC
    ,ts.game_id DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `leaderboard_misc_least_stars_player_sel` (IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	ts.game_id
    ,tr.roster_id AS face_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
	,mt.team_abbr AS team
    ,mt.team_city AS team_city
    ,mt.team_name AS team_name
    ,mto.team_abbr AS opponent
    ,mto.team_city AS opponent_city
    ,mto.team_name AS opponent_name
    ,ts.game_date
    ,(CASE
      	WHEN ts.is_finished = 0 THEN tbo.batting_order
      	ELSE tgbo.batting_order
      END) AS batting_order
    ,ts.season_id
    ,ts.is_home
    ,ts.is_finished
    ,ts.team_score
    ,ts.opponent_score
    ,ts.game_outcome
    ,(CASE WHEN psg.stat_value BETWEEN -0.49 AND 0 THEN 0 ELSE ROUND(psg.stat_value, 0) END) AS star_earned
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_wins ELSE pts.wins END) AS team_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_losses ELSE pts.losses END) AS team_losses
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_wins ELSE ots.wins END) AS opponent_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_losses ELSE ots.losses END) AS opponent_losses
    ,ts.innings
    ,ts.can_sim
    ,ts.is_postseason
FROM
	player pl
	INNER JOIN team_schedule ts ON ts.season_id = pl.season_id
    INNER JOIN master_team mt ON mt.team_id = ts.team_id
    INNER JOIN master_team mto ON mto.team_id = ts.opponent_id
    INNER JOIN league_standings pts ON pts.season_id = pl.season_id AND pts.team_id = pl.team_id AND pts.league_id = mt.league_id
    INNER JOIN league_standings ots ON ots.season_id = pl.season_id AND ots.team_id = ts.opponent_id AND ots.league_id = mto.league_id
    INNER JOIN team_roster tr ON tr.season_id = pl.season_id AND tr.team_id = pl.team_id AND tr.is_player = 1
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = pl.season_id AND tbo.team_id = pl.team_id
    LEFT JOIN player_stat_game psg ON psg.game_id = ts.game_id AND psg.player_id = pl.player_id AND psg.stat_id = 24
	LEFT JOIN team_game_batting_order tgbo ON tgbo.game_id = ts.game_id AND tgbo.is_owned_player = 1
WHERE
    pl.is_active = 1
    AND ts.is_finished = 1
    AND psg.stat_value < 0
ORDER BY 
	psg.stat_value ASC
    ,ts.game_date DESC
    ,ts.game_id DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `leaderboard_misc_least_stars_team_sel` (IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	ts.game_id
    ,tr.roster_id AS face_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
	,mt.team_abbr AS team
    ,mt.team_city AS team_city
    ,mt.team_name AS team_name
    ,mto.team_abbr AS opponent
    ,mto.team_city AS opponent_city
    ,mto.team_name AS opponent_name
    ,ts.game_date
    ,(CASE
      	WHEN ts.is_finished = 0 THEN tbo.batting_order
      	ELSE tgbo.batting_order
      END) AS batting_order
    ,ts.season_id
    ,ts.is_home
    ,ts.is_finished
    ,ts.team_score
    ,ts.opponent_score
    ,ts.game_outcome
    ,(CASE WHEN psg.stat_value BETWEEN -0.49 AND 0 THEN 0 ELSE ROUND(psg.stat_value, 0) END) AS star_earned
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_wins ELSE pts.wins END) AS team_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_losses ELSE pts.losses END) AS team_losses
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_wins ELSE ots.wins END) AS opponent_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_losses ELSE ots.losses END) AS opponent_losses
    ,ts.innings
    ,ts.can_sim
    ,ts.is_postseason
    ,tsg.stat_value AS team_stars_earned
FROM
	player pl
	INNER JOIN team_schedule ts ON ts.season_id = pl.season_id
    INNER JOIN master_team mt ON mt.team_id = ts.team_id
    INNER JOIN master_team mto ON mto.team_id = ts.opponent_id
    INNER JOIN league_standings pts ON pts.season_id = pl.season_id AND pts.team_id = pl.team_id AND pts.league_id = mt.league_id
    INNER JOIN league_standings ots ON ots.season_id = pl.season_id AND ots.team_id = ts.opponent_id AND ots.league_id = mto.league_id
    INNER JOIN team_roster tr ON tr.season_id = pl.season_id AND tr.team_id = pl.team_id AND tr.is_player = 1
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = pl.season_id AND tbo.team_id = ts.team_id
    INNER JOIN team_stat_game tsg ON tsg.game_id = ts.game_id AND tsg.team_id = ts.team_id AND tsg.stat_id = 24
    LEFT JOIN player_stat_game psg ON psg.game_id = ts.game_id AND psg.player_id = pl.player_id AND psg.stat_id = 24
	LEFT JOIN team_game_batting_order tgbo ON tgbo.game_id = ts.game_id AND tgbo.is_owned_player = 1
WHERE
    pl.is_active = 1
    AND ts.is_finished = 1
    AND tsg.stat_value < 0
ORDER BY 
	tsg.stat_value ASC
    ,ts.game_date DESC
    ,ts.game_id DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `leaderboard_misc_longest_games_sel` (IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	ts.game_id
    ,tr.roster_id AS face_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
	,mt.team_abbr AS team
    ,mt.team_city AS team_city
    ,mt.team_name AS team_name
    ,mto.team_abbr AS opponent
    ,mto.team_city AS opponent_city
    ,mto.team_name AS opponent_name
    ,ts.game_date
    ,(CASE
      	WHEN ts.is_finished = 0 THEN tbo.batting_order
      	ELSE tgbo.batting_order
      END) AS batting_order
    ,ts.season_id
    ,ts.is_home
    ,ts.is_finished
    ,ts.team_score
    ,ts.opponent_score
    ,ts.game_outcome
    ,(CASE WHEN psg.stat_value BETWEEN -0.49 AND 0 THEN 0 ELSE ROUND(psg.stat_value, 0) END) AS star_earned
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_wins ELSE pts.wins END) AS team_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_losses ELSE pts.losses END) AS team_losses
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_wins ELSE ots.wins END) AS opponent_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_losses ELSE ots.losses END) AS opponent_losses
    ,ts.innings
    ,ts.can_sim
    ,ts.is_postseason
FROM
	player pl
	INNER JOIN team_schedule ts ON ts.season_id = pl.season_id
    INNER JOIN master_team mt ON mt.team_id = ts.team_id
    INNER JOIN master_team mto ON mto.team_id = ts.opponent_id
    INNER JOIN league_standings pts ON pts.season_id = pl.season_id AND pts.team_id = pl.team_id AND pts.league_id = mt.league_id
    INNER JOIN league_standings ots ON ots.season_id = pl.season_id AND ots.team_id = ts.opponent_id AND ots.league_id = mto.league_id
    INNER JOIN team_roster tr ON tr.season_id = pl.season_id AND tr.team_id = pl.team_id AND tr.is_player = 1
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = pl.season_id AND tbo.team_id = pl.team_id
    LEFT JOIN player_stat_game psg ON psg.game_id = ts.game_id AND psg.player_id = pl.player_id AND psg.stat_id = 24
	LEFT JOIN team_game_batting_order tgbo ON tgbo.game_id = ts.game_id AND tgbo.is_owned_player = 1
WHERE
    pl.is_active = 1
    AND ts.is_finished = 1
    AND ts.innings > 9
ORDER BY 
	ts.innings DESC
    ,ts.game_date DESC
    ,ts.game_id DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `leaderboard_misc_most_stars_player_sel` (IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	ts.game_id
    ,tr.roster_id AS face_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
	,mt.team_abbr AS team
    ,mt.team_city AS team_city
    ,mt.team_name AS team_name
    ,mto.team_abbr AS opponent
    ,mto.team_city AS opponent_city
    ,mto.team_name AS opponent_name
    ,ts.game_date
    ,(CASE
      	WHEN ts.is_finished = 0 THEN tbo.batting_order
      	ELSE tgbo.batting_order
      END) AS batting_order
    ,ts.season_id
    ,ts.is_home
    ,ts.is_finished
    ,ts.team_score
    ,ts.opponent_score
    ,ts.game_outcome
    ,(CASE WHEN psg.stat_value BETWEEN -0.49 AND 0 THEN 0 ELSE ROUND(psg.stat_value, 0) END) AS star_earned
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_wins ELSE pts.wins END) AS team_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_losses ELSE pts.losses END) AS team_losses
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_wins ELSE ots.wins END) AS opponent_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_losses ELSE ots.losses END) AS opponent_losses
    ,ts.innings
    ,ts.can_sim
    ,ts.is_postseason
FROM
	player pl
	INNER JOIN team_schedule ts ON ts.season_id = pl.season_id
    INNER JOIN master_team mt ON mt.team_id = ts.team_id
    INNER JOIN master_team mto ON mto.team_id = ts.opponent_id
    INNER JOIN league_standings pts ON pts.season_id = pl.season_id AND pts.team_id = pl.team_id AND pts.league_id = mt.league_id
    INNER JOIN league_standings ots ON ots.season_id = pl.season_id AND ots.team_id = ts.opponent_id AND ots.league_id = mto.league_id
    INNER JOIN team_roster tr ON tr.season_id = pl.season_id AND tr.team_id = pl.team_id AND tr.is_player = 1
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = pl.season_id AND tbo.team_id = pl.team_id
    LEFT JOIN player_stat_game psg ON psg.game_id = ts.game_id AND psg.player_id = pl.player_id AND psg.stat_id = 24
	LEFT JOIN team_game_batting_order tgbo ON tgbo.game_id = ts.game_id AND tgbo.is_owned_player = 1
WHERE
    pl.is_active = 1
    AND ts.is_finished = 1
ORDER BY 
	psg.stat_value DESC
    ,ts.game_date DESC
    ,ts.game_id DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `leaderboard_misc_most_stars_team_sel` (IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	ts.game_id
    ,tr.roster_id AS face_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
	,mt.team_abbr AS team
    ,mt.team_city AS team_city
    ,mt.team_name AS team_name
    ,mto.team_abbr AS opponent
    ,mto.team_city AS opponent_city
    ,mto.team_name AS opponent_name
    ,ts.game_date
    ,(CASE
      	WHEN ts.is_finished = 0 THEN tbo.batting_order
      	ELSE tgbo.batting_order
      END) AS batting_order
    ,ts.season_id
    ,ts.is_home
    ,ts.is_finished
    ,ts.team_score
    ,ts.opponent_score
    ,ts.game_outcome
    ,(CASE WHEN psg.stat_value BETWEEN -0.49 AND 0 THEN 0 ELSE ROUND(psg.stat_value, 0) END) AS star_earned
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_wins ELSE pts.wins END) AS team_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_losses ELSE pts.losses END) AS team_losses
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_wins ELSE ots.wins END) AS opponent_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_losses ELSE ots.losses END) AS opponent_losses
    ,ts.innings
    ,ts.can_sim
    ,ts.is_postseason
    ,tsg.stat_value AS team_stars_earned
FROM
	player pl
	INNER JOIN team_schedule ts ON ts.season_id = pl.season_id
    INNER JOIN master_team mt ON mt.team_id = ts.team_id
    INNER JOIN master_team mto ON mto.team_id = ts.opponent_id
    INNER JOIN league_standings pts ON pts.season_id = pl.season_id AND pts.team_id = pl.team_id AND pts.league_id = mt.league_id
    INNER JOIN league_standings ots ON ots.season_id = pl.season_id AND ots.team_id = ts.opponent_id AND ots.league_id = mto.league_id
    INNER JOIN team_roster tr ON tr.season_id = pl.season_id AND tr.team_id = pl.team_id AND tr.is_player = 1
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = pl.season_id AND tbo.team_id = ts.team_id
    INNER JOIN team_stat_game tsg ON tsg.game_id = ts.game_id AND tsg.team_id = ts.team_id AND tsg.stat_id = 24
    LEFT JOIN player_stat_game psg ON psg.game_id = ts.game_id AND psg.player_id = pl.player_id AND psg.stat_id = 24
	LEFT JOIN team_game_batting_order tgbo ON tgbo.game_id = ts.game_id AND tgbo.is_owned_player = 1
WHERE
    pl.is_active = 1
    AND ts.is_finished = 1
ORDER BY 
	tsg.stat_value DESC
    ,ts.game_date DESC
    ,ts.game_id DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `leaderboard_misc_top_managers_sel` (IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	a.ID AS account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,COUNT(pl.player_id) AS total_players
    ,((SUM(ps.star_earned) + (STDDEV(ps.star_earned)/ 2)) / SUM(ts.games_played)) * (CASE WHEN COUNT(pl.player_id) <= 1 THEN 100 ELSE 162 END) AS average_stars
    ,a.isAdmin AS is_admin
FROM
	account a
    INNER JOIN player pl ON pl.account_id = a.ID
    INNER JOIN player_star ps ON ps.player_id = pl.player_id
    INNER JOIN (
        SELECT 
        	pss.player_id,
        	COUNT(ts.game_id) AS games_played
       	FROM team_schedule ts 
        INNER JOIN player_season pss ON 
        	pss.season_id = ts.season_id 
        	AND ts.is_finished = 1 
       	GROUP BY 
        	pss.player_id
   	) ts ON ts.player_id = pl.player_id
WHERE
	a.isActive = 1
    AND pl.is_active = 1
    AND ps.star_earned != 0
GROUP BY
	a.ID
    ,a.username
    ,a.isAdmin
    ,a.isPremium
ORDER BY
	((SUM(ps.star_earned) + (STDDEV(ps.star_earned)/ 2)) / SUM(ts.games_played)) * (CASE WHEN COUNT(pl.player_id) <= 1 THEN 100 ELSE 162 END) DESC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `leaderboard_recent_games_sel` (IN `var_is_finished` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	ts.game_id
    ,tr.roster_id AS face_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
	,mt.team_abbr AS team
    ,mt.team_city AS team_city
    ,mt.team_name AS team_name
    ,mto.team_abbr AS opponent
    ,mto.team_city AS opponent_city
    ,mto.team_name AS opponent_name
    ,ts.game_date
    ,(CASE
      	WHEN ts.is_finished = 0 THEN tbo.batting_order
      	ELSE tgbo.batting_order
      END) AS batting_order
    ,ts.season_id
    ,ts.is_home
    ,ts.is_finished
    ,ts.team_score
    ,ts.opponent_score
    ,ts.game_outcome
    ,(CASE WHEN psg.stat_value BETWEEN -0.49 AND 0 THEN 0 ELSE ROUND(psg.stat_value, 0) END) AS star_earned
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_wins ELSE pts.wins END) AS team_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_losses ELSE pts.losses END) AS team_losses
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_wins ELSE ots.wins END) AS opponent_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_losses ELSE ots.losses END) AS opponent_losses
    ,ts.innings
    ,ts.can_sim
    ,ts.is_postseason
FROM
	player pl
    INNER JOIN player_season ps ON ps.season_id = pl.season_id
	INNER JOIN team_schedule ts ON ts.season_id = pl.season_id
    INNER JOIN master_team mt ON mt.team_id = ts.team_id
    INNER JOIN master_team mto ON mto.team_id = ts.opponent_id
    INNER JOIN league_standings pts ON pts.season_id = pl.season_id AND pts.team_id = pl.team_id AND pts.league_id = ps.league_id
    INNER JOIN league_standings ots ON ots.season_id = pl.season_id AND ots.team_id = ts.opponent_id AND ots.league_id = ps.league_id
    INNER JOIN team_roster tr ON tr.season_id = pl.season_id AND tr.team_id = pl.team_id AND tr.is_player = 1
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = pl.season_id AND tbo.team_id = pl.team_id
    LEFT JOIN player_stat_game psg ON psg.game_id = ts.game_id AND psg.player_id = pl.player_id AND psg.stat_id = 24
	LEFT JOIN team_game_batting_order tgbo ON tgbo.game_id = ts.game_id AND tgbo.is_owned_player = 1
WHERE
    pl.is_active = 1
    AND ts.is_finished = var_is_finished
    AND ts.is_hidden = 0
ORDER BY 
	ts.game_date DESC
    ,ts.game_id DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_award_by_type_sel` (IN `var_type` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	a.ID AS account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pa.award_id
    ,ma.award_name
    ,ma.award_abbr
    ,ma.award_star_bonus
    ,ma.is_weekly
    ,ma.is_monthly
    ,ma.is_yearly
    ,pa.received_date
FROM
	player_award pa
    INNER JOIN player pl ON pl.player_id = pa.player_id AND pl.is_active = 1
    INNER JOIN player_season ps ON ps.season_id = pa.season_id
    INNER JOIN master_award ma ON ma.award_id = pa.award_id AND ma.is_active = 1
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
    INNER JOIN account a ON a.ID = pl.account_id
WHERE
	ma.award_id = var_type
ORDER BY
	pa.received_date DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_bonus_sel` (IN `var_bonus_id` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	a.ID AS account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,opp.team_id AS opp_team_id
    ,opp.team_city AS opp_team_city
    ,opp.team_name AS opp_team_name
    ,opp.team_abbr AS opp_team_abbr
    ,pa.bonus_id
    ,ma.bonus_name
    ,ma.bonus_abbr
    ,ma.bonus_desc
    ,pa.bonus_value
    ,ts.game_id
    ,ts.team_score
    ,ts.opponent_score
    ,ts.innings
    ,ts.is_postseason
    ,ts.game_date
FROM
	player_game_bonus pa
    INNER JOIN player pl ON pl.player_id = pa.player_id
    INNER JOIN master_bonus ma ON ma.bonus_id = pa.bonus_id
    INNER JOIN team_schedule ts ON ts.game_id = pa.game_id AND ts.is_hidden = 0
    INNER JOIN player_season ps ON ps.season_id = ts.season_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
    INNER JOIN master_team opp ON opp.team_id = ts.opponent_id
    INNER JOIN account a ON a.ID = pl.account_id
WHERE
	ma.bonus_id = var_bonus_id
ORDER BY
	ts.game_date DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_history_teams_sel` ()  NO SQL
SELECT
	mt.league_id
    ,mt.conference_id
    ,mlc.conference_name
    ,mt.division_id
    ,mld.division_name
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,SUM(ls.wins) AS wins
    ,SUM(ls.losses) AS losses
    ,SUM(ls.is_wildcard_team) AS wild_card_appearances
    ,SUM(ls.is_division_leader) AS division_titles
    ,SUM(ls.is_conference_leader) AS conference_titles
    ,SUM(ls.is_world_series_winner) AS world_series_titles
FROM
	league_standings ls
    INNER JOIN master_team mt ON mt.team_id = ls.team_id AND mt.league_id = ls.league_id
    INNER JOIN master_league_conference mlc ON mlc.league_id = mt.league_id AND mlc.conference_id = mt.conference_id
    INNER JOIN master_league_division mld ON mld.league_id = mt.league_id AND mld.conference_id = mlc.conference_id AND mld.division_id = mt.division_id
GROUP BY
	mt.league_id
    ,mt.conference_id
    ,mlc.conference_name
    ,mt.division_id
    ,mld.division_name
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
ORDER BY
    SUM(ls.wins) DESC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_playoffs_page_pre_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	pl.round
    ,pl.season_id
	,pl.conference_id
	,pl.conference_name
	,pl.home_team_id
	,pl.home_team_city
	,pl.home_team_name
	,pl.home_team_playoff_seed
	,pl.home_team_wins
	,pl.home_team_losses
	,pl.home_team_series_wins
	,pl.visit_team_id
	,pl.visit_team_city
	,pl.visit_team_name
	,pl.visit_team_playoff_seed
	,pl.visit_team_wins
	,pl.visit_team_losses
	,pl.visit_team_series_wins
	,pl.games_played
	,pl.winner_team_id
	,pl.is_finished
	,pl.home_team_is_player_team
	,pl.visit_team_is_player_team
FROM
(
    SELECT
        1 AS round
    	,ls.season_id
		,mlc.conference_id
        ,mlc.conference_name
        ,ls.team_id AS home_team_id
        ,mt.team_city AS home_team_city
        ,mt.team_name AS home_team_name
        ,ls.playoff_seed AS home_team_playoff_seed
        ,ls.wins AS home_team_wins
        ,ls.losses AS home_team_losses
        ,0 AS home_team_series_wins
        ,ls_v.team_id AS visit_team_id
        ,mt_v.team_city AS visit_team_city
        ,mt_v.team_name AS visit_team_name
        ,ls_v.playoff_seed AS visit_team_playoff_seed
        ,ls_v.wins AS visit_team_wins
        ,ls_v.losses AS visit_team_losses
        ,0 AS visit_team_series_wins
        ,0 AS games_played
        ,0 AS winner_team_id
        ,0 AS is_finished
        ,(CASE WHEN ps.team_id = ls.team_id THEN 1 ELSE 0 END) AS home_team_is_player_team
        ,(CASE WHEN ps.team_id = ls_v.team_id THEN 1 ELSE 0 END) AS visit_team_is_player_team
    FROM
        league_standings ls
        INNER JOIN (SELECT player_id, league_id, season_id, team_id FROM player_season WHERE player_id = var_player_id ORDER BY season_id DESC LIMIT 1) ps ON ps.season_id = ls.season_id AND ps.league_id = ls.league_id
        INNER JOIN master_team mt ON mt.league_id = ls.league_id AND mt.team_id = ls.team_id
        INNER JOIN master_league_conference mlc ON mlc.league_id = ls.league_id AND mlc.conference_id = mt.conference_id
        INNER JOIN league_standings ls_v ON ls_v.season_id = ls.season_id AND ls_v.league_id = ls.league_id AND ls_v.is_wildcard_team = 1 AND ls_v.playoff_seed = 5
        INNER JOIN master_team mt_v ON mt_v.league_id = ls_v.league_id AND mt_v.team_id = ls_v.team_id AND mt_v.conference_id = mlc.conference_id
    WHERE
        ls.is_wildcard_team 	= 1
        AND ls.playoff_seed 	= 4

    UNION ALL

    SELECT
        2 AS round
    	,ls.season_id
		,mlc.conference_id
        ,mlc.conference_name
        ,ls.team_id AS home_team_id
        ,mt.team_city AS home_team_city
        ,mt.team_name AS home_team_name
        ,ls.playoff_seed AS home_team_playoff_seed
        ,ls.wins AS home_team_wins
        ,ls.losses AS home_team_losses
        ,0 AS home_team_series_wins
        ,ls_v.team_id AS visit_team_id
        ,mt_v.team_city AS visit_team_city
        ,mt_v.team_name AS visit_team_name
        ,ls_v.playoff_seed AS visit_team_playoff_seed
        ,ls_v.wins AS visit_team_wins
        ,ls_v.losses AS visit_team_losses
        ,0 AS visit_team_series_wins
        ,0 AS games_played
        ,0 AS winner_team_id
        ,0 AS is_finished
        ,(CASE WHEN ps.team_id = ls.team_id THEN 1 ELSE 0 END) AS home_team_is_player_team
        ,(CASE WHEN ps.team_id = ls_v.team_id THEN 1 ELSE 0 END) AS visit_team_is_player_team
    FROM
        league_standings ls
        INNER JOIN (SELECT player_id, league_id, season_id, team_id FROM player_season WHERE player_id = var_player_id ORDER BY season_id DESC LIMIT 1) ps ON ps.season_id = ls.season_id AND ps.league_id = ls.league_id
        INNER JOIN master_team mt ON mt.league_id = ls.league_id AND mt.team_id = ls.team_id
        INNER JOIN master_league_conference mlc ON mlc.league_id = ls.league_id AND mlc.conference_id = mt.conference_id
        INNER JOIN league_standings ls_v ON ls_v.season_id = ls.season_id AND ls_v.league_id = ls.league_id AND ls_v.is_division_leader = 1 AND ls_v.playoff_seed = 3
        INNER JOIN master_team mt_v ON mt_v.league_id = ls_v.league_id AND mt_v.team_id = ls_v.team_id AND mt_v.conference_id = mlc.conference_id
    WHERE
        ls.is_division_leader 	= 1
        AND ls.playoff_seed 	= 2

    UNION ALL

    SELECT
        2 AS round
    	,ls.season_id
		,mlc.conference_id
        ,mlc.conference_name
        ,ls.team_id AS home_team_id
        ,mt.team_city AS home_team_city
        ,mt.team_name AS home_team_name
        ,ls.playoff_seed AS home_team_playoff_seed
        ,ls.wins AS home_team_wins
        ,ls.losses AS home_team_losses
        ,0 AS home_team_series_wins
        ,0 AS visit_team_id
        ,'Winner of Wild Card' AS visit_team_city
        ,'' AS visit_team_name
        ,0 AS visit_team_playoff_seed
        ,0 AS visit_team_wins
        ,0 AS visit_team_losses
        ,0 AS visit_team_series_wins
        ,0 AS games_played
        ,0 AS winner_team_id
        ,0 AS is_finished
        ,(CASE WHEN ps.team_id = ls.team_id THEN 1 ELSE 0 END) AS home_team_is_player_team
        ,0 AS visit_team_is_player_team
    FROM
        league_standings ls
        INNER JOIN (SELECT player_id, league_id, season_id, team_id FROM player_season WHERE player_id = var_player_id ORDER BY season_id DESC LIMIT 1) ps ON ps.season_id = ls.season_id AND ps.league_id = ls.league_id
        INNER JOIN master_team mt ON mt.league_id = ls.league_id AND mt.team_id = ls.team_id
        INNER JOIN master_league_conference mlc ON mlc.league_id = ls.league_id AND mlc.conference_id = mt.conference_id
    WHERE
        ls.is_conference_leader = 1
        AND ls.playoff_seed 	= 1
) pl
ORDER BY 
pl.round ASC
,pl.conference_id ASC
,pl.home_team_playoff_seed ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_playoffs_page_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	lps.round
    ,lps.season_id
	,mlc.conference_id
    ,(CASE WHEN lps.round = 4 THEN 'World Series' ELSE mlc.conference_name END) AS conference_name
    ,mt_h.team_id AS home_team_id
    ,mt_h.team_city AS home_team_city
    ,mt_h.team_name AS home_team_name
    ,ls_h.playoff_seed AS home_team_playoff_seed
    ,ls_h.wins AS home_team_wins
    ,ls_h.losses AS home_team_losses
    ,lps.home_team_wins AS home_team_series_wins
    ,mt_v.team_id AS visit_team_id
    ,mt_v.team_city AS visit_team_city
    ,mt_v.team_name AS visit_team_name
    ,ls_v.playoff_seed AS visit_team_playoff_seed
    ,ls_v.wins AS visit_team_wins
    ,ls_v.losses AS visit_team_losses
    ,lps.visit_team_wins AS visit_team_series_wins
    ,lps.games_played
    ,lps.winner_team_id
    ,lps.is_finished
    ,(CASE WHEN ps.team_id = lps.home_team_id THEN 1 ELSE 0 END) AS home_team_is_player_team
    ,(CASE WHEN ps.team_id = lps.visit_team_id THEN 1 ELSE 0 END) AS visit_team_is_player_team
FROM
	league_playoff_schedule lps
    INNER JOIN (SELECT player_id, league_id, season_id, team_id FROM player_season WHERE player_id = var_player_id ORDER BY season_id DESC LIMIT 1) ps ON ps.season_id = lps.season_id
    INNER JOIN master_team mt_h ON mt_h.team_id = lps.home_team_id AND mt_h.league_id = ps.league_id
    INNER JOIN league_standings ls_h ON ls_h.season_id = ps.season_id AND ls_h.league_id = mt_h.league_id AND ls_h.team_id = mt_h.team_id
    INNER JOIN master_team mt_v ON mt_v.team_id = lps.visit_team_id AND mt_v.league_id = ps.league_id
    INNER JOIN league_standings ls_v ON ls_v.season_id = ps.season_id AND ls_v.league_id = mt_v.league_id AND ls_v.team_id = mt_v.team_id
    INNER JOIN master_league_conference mlc ON mlc.league_id = ps.league_id AND mlc.conference_id = lps.conference_id
ORDER BY
	lps.round ASC
	,mlc.conference_id ASC
	,ls_h.playoff_seed ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_playoffs_round_one_to_two_ins` (IN `var_season_id` INT, IN `var_winner_team_id` INT)  NO SQL
INSERT INTO league_playoff_schedule (season_id, conference_id, round, home_team_id, visit_team_id, home_team_seed, visit_team_seed)
SELECT
	var_season_id AS season_id
    ,(SELECT conference_id FROM master_team WHERE team_id = var_winner_team_id) AS conference_id
    ,2 AS round
    ,(SELECT
        ls.team_id
    FROM
        league_standings ls
        INNER JOIN master_team mt ON mt.team_id = ls.team_id AND mt.league_id = ls.league_id
    WHERE
        ls.season_id = var_season_id
        AND mt.conference_id = (SELECT conference_id FROM master_team WHERE team_id = var_winner_team_id)
        AND ls.playoff_seed = 1
    ) AS home_team_id
    ,var_winner_team_id AS visit_team_id
    ,1 AS home_team_seed
    ,(SELECT playoff_seed FROM league_standings WHERE season_id = var_season_id AND team_id = var_winner_team_id) AS visit_team_seed$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_playoff_games_by_round_sel` (IN `var_season_id` INT, IN `var_playoff_round` INT)  NO SQL
SELECT
	lps.conference_id
	,lps.home_team_id
    ,lps.visit_team_id
    ,lps.home_team_seed
    ,lps.visit_team_seed
    ,lps.home_team_wins
    ,lps.visit_team_wins
    ,lps.games_played
    ,lps.winner_team_id
    ,lps.is_finished
FROM
	league_playoff_schedule lps
WHERE
	lps.season_id = var_season_id
    AND lps.round = var_playoff_round
    AND lps.home_team_id NOT IN (SELECT home_team_id FROM league_playoff_schedule WHERE season_id = var_season_id AND round = var_playoff_round + 1)
    AND lps.home_team_id NOT IN (SELECT visit_team_id FROM league_playoff_schedule WHERE season_id = var_season_id AND round = var_playoff_round + 1)
    AND lps.visit_team_id NOT IN (SELECT home_team_id FROM league_playoff_schedule WHERE season_id = var_season_id AND round = var_playoff_round + 1)
    AND lps.visit_team_id NOT IN (SELECT visit_team_id FROM league_playoff_schedule WHERE season_id = var_season_id AND round = var_playoff_round + 1)
ORDER BY lps.conference_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_playoff_round_result_ins` (IN `var_season_id` INT, IN `var_conference_id` INT, IN `var_playoff_round` INT, IN `var_home_team_id` INT, IN `var_visit_team_id` INT, IN `var_home_team_seed` INT, IN `var_visit_team_seed` INT, IN `var_home_team_wins` INT, IN `var_visit_team_wins` INT, IN `var_games_played` INT, IN `var_winner_team_id` INT, IN `var_is_finished` INT)  NO SQL
INSERT INTO league_playoff_schedule (season_id, conference_id, round, home_team_id, visit_team_id, home_team_seed, visit_team_seed, home_team_wins, visit_team_wins, games_played, winner_team_id, is_finished) VALUES (var_season_id, var_conference_id, var_playoff_round, var_home_team_id, var_visit_team_id, var_home_team_seed, var_visit_team_seed, var_home_team_wins, var_visit_team_wins, var_games_played, var_winner_team_id, var_is_finished)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_playoff_schedule_ins` (IN `var_player_id` INT)  NO SQL
INSERT INTO league_playoff_schedule(season_id, conference_id, round, home_team_id, visit_team_id, home_team_seed, visit_team_seed)
SELECT
	ps.season_id
    ,mlc_one.conference_id
	,(CASE WHEN ls_one.playoff_seed = 2 THEN 2 ELSE 1 END) AS round
	,ls_one.team_id AS home_team_id
    ,ls_two.team_id AS visit_team_id
    ,ls_one.playoff_seed AS home_team_seed
    ,ls_two.playoff_seed AS visit_team_seed
FROM
	player pl
    
    INNER JOIN player_season ps ON ps.season_id = pl.season_id
    INNER JOIN league_standings ls_one ON ls_one.season_id = ps.season_id AND ls_one.playoff_seed BETWEEN 1 AND 5
    INNER JOIN master_team mt_one ON mt_one.team_id = ls_one.team_id AND mt_one.league_id = ps.league_id
    INNER JOIN master_league_conference mlc_one ON mlc_one.league_id = ps.league_id AND mlc_one.conference_id = mt_one.conference_id
    
    INNER JOIN league_standings ls_two ON ls_two.season_id = ps.season_id AND ls_two.team_id != ls_one.team_id AND ls_two.playoff_seed = (
        CASE 
        	WHEN ls_one.playoff_seed = 2 THEN 3
        	WHEN ls_one.playoff_seed = 4 THEN 5
        END)
    INNER JOIN master_team mt_two ON mt_two.team_id = ls_two.team_id AND mt_two.league_id = ps.league_id
    INNER JOIN master_league_conference mlc_two ON mlc_two.league_id = ps.league_id AND mlc_two.conference_id = mt_two.conference_id
WHERE
	pl.player_id = var_player_id
    AND mlc_one.conference_id = mlc_two.conference_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_playoff_schedule_round_two_ins` (IN `var_season_id` INT, IN `var_conference_one_winner` INT, IN `var_conference_two_winner` INT)  NO SQL
INSERT INTO league_playoff_schedule (season_id, conference_id, round, home_team_id, visit_team_id, home_team_seed, visit_team_seed)
SELECT
	season_id
    ,conference_id
    ,round
    ,home_team_id
    ,visit_team_id
    ,home_team_seed
    ,visit_team_seed
 FROM (
 SELECT
	var_season_id AS season_id
    ,1 AS conference_id
    ,2 AS round
    ,(SELECT 
     	ls.team_id
     FROM 
     	league_standings ls
     	INNER JOIN master_team mt ON mt.league_id = ls.league_id AND mt.team_id = ls.team_id
    	INNER JOIN master_league_conference mlc ON mlc.league_id = ls.league_id AND mlc.conference_id = mt.conference_id
     WHERE
     	ls.season_id = var_season_id
      	AND ls.playoff_seed = 1
     	AND mlc.conference_id = 1) AS home_team_id
    ,(SELECT 
     	ls.team_id
     FROM 
     	league_standings ls
     	INNER JOIN master_team mt ON mt.league_id = ls.league_id AND mt.team_id = ls.team_id
    	INNER JOIN master_league_conference mlc ON mlc.league_id = ls.league_id AND mlc.conference_id = mt.conference_id
     WHERE
     	ls.season_id = var_season_id
      	AND ls.playoff_seed = var_conference_one_winner
     	AND mlc.conference_id = 1) AS visit_team_id
    ,1 AS home_team_seed
    ,var_conference_one_winner AS visit_team_seed
    
    UNION ALL

SELECT
	var_season_id AS season_id
    ,2 AS conference_id
    ,2 AS round
    ,(SELECT 
     	ls.team_id
     FROM 
     	league_standings ls
     	INNER JOIN master_team mt ON mt.league_id = ls.league_id AND mt.team_id = ls.team_id
    	INNER JOIN master_league_conference mlc ON mlc.league_id = ls.league_id AND mlc.conference_id = mt.conference_id
     WHERE
     	ls.season_id = var_season_id
      	AND ls.playoff_seed = 1
     	AND mlc.conference_id = 2) AS home_team_id
    ,(SELECT 
     	ls.team_id
     FROM 
     	league_standings ls
     	INNER JOIN master_team mt ON mt.league_id = ls.league_id AND mt.team_id = ls.team_id
    	INNER JOIN master_league_conference mlc ON mlc.league_id = ls.league_id AND mlc.conference_id = mt.conference_id
     WHERE
     	ls.season_id = var_season_id
      	AND ls.playoff_seed = var_conference_two_winner
     	AND mlc.conference_id = 2) AS visit_team_id
    ,1 AS home_team_seed
    ,var_conference_two_winner AS visit_team_seed
) a$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_playoff_schedule_wildcard_upd` (IN `var_season_id` INT, IN `var_conference_one_winner` INT, IN `var_conference_two_winner` INT)  NO SQL
UPDATE league_playoff_schedule 
SET 
	home_team_wins = (
        CASE 
          WHEN home_team_seed = var_conference_one_winner AND conference_id = 1 THEN 1
          WHEN home_team_seed = var_conference_two_winner AND conference_id = 2 THEN 1
          ELSE 0 
        END
    )
    ,visit_team_wins = (
        CASE 
          WHEN visit_team_seed = var_conference_one_winner THEN 1 
          WHEN visit_team_seed = var_conference_two_winner AND conference_id = 2 THEN 1
          ELSE 0 
        END
    )
    ,games_played = 1
    ,winner_team_id = (CASE 
          WHEN home_team_seed = var_conference_one_winner AND conference_id = 1 THEN home_team_id
          WHEN home_team_seed = var_conference_two_winner AND conference_id = 2 THEN home_team_id
          ELSE visit_team_id
        END)
    ,is_finished = 1
WHERE
	season_id = var_season_id
    AND round = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_playoff_series_winner_upd` (IN `var_season_id` INT, IN `var_playoff_round` INT, IN `var_home_team_id` INT, IN `var_visit_team_id` INT, IN `var_home_team_wins` INT, IN `var_visit_team_wins` INT, IN `var_games_played` INT, IN `var_winner_team_id` INT, IN `var_is_finished` INT)  NO SQL
UPDATE league_playoff_schedule
SET
	home_team_wins = var_home_team_wins
    ,visit_team_wins = var_visit_team_wins
    ,games_played = var_games_played
    ,winner_team_id = var_winner_team_id
    ,is_finished = var_is_finished
WHERE
	season_id = var_season_id
    AND round = var_playoff_round
    AND is_finished = 0
    AND home_team_id = var_home_team_id
    AND visit_team_id = var_visit_team_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_records_recent_sel` (IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	a.ID AS account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
	,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pr.record_id
    ,pr.stat_id
    ,mr.record_preface
    ,ms.stat_name
    ,ms.stat_abbr
    ,ms.stat_desc
    ,pr.record_value
    ,mr.is_weekly
    ,mr.is_monthly
    ,mr.is_yearly
    ,mr.is_career
    ,mr.record_star_bonus
    ,pr.broken_date
    ,pl.is_retired
    ,mr.is_weekly
    ,mr.is_monthly
    ,mr.is_yearly
    ,mr.is_career
    ,(SELECT COUNT(npr.record_id) FROM player_record npr WHERE npr.record_id = pr.record_id AND npr.broken_date > pr.broken_date) AS is_broken
    ,IFNULL((SELECT pl.player_id FROM player_record npr INNER JOIN player pl ON pl.player_id = npr.player_id WHERE npr.record_id = pr.record_id AND npr.broken_date > pr.broken_date ORDER BY npr.broken_date DESC LIMIT 1), 0) as broken_by_player_id
FROM
	player_record pr
    INNER JOIN player pl ON pl.player_id = pr.player_id AND pl.is_active = 1
    INNER JOIN player_season ps ON ps.season_id = pr.season_id
    INNER JOIN master_record mr ON mr.record_id = pr.record_id
    INNER JOIN master_stat ms ON ms.stat_id = mr.stat_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
    INNER JOIN account a ON a.ID = pl.account_id
WHERE
	mr.stat_id IN (2, 3, 4, 5, 6, 7, 10, 11, 12, 13, 16, 17)
ORDER BY
	pr.broken_date DESC
    ,mr.stat_id ASC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_record_monthly_by_stat_id_sel` (IN `var_stat_id` INT, IN `var_limit` INT)  NO SQL
SELECT
	a.ID AS account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pr.record_id
    ,pr.stat_id
    ,mr.record_preface
    ,ms.stat_name
    ,ms.stat_abbr
    ,ms.stat_desc
    ,pr.record_value
    ,mr.is_weekly
    ,mr.is_monthly
    ,mr.is_yearly
    ,mr.is_career
    ,mr.record_star_bonus
    ,pr.broken_date
    ,pl.is_retired
FROM
	player pl
    INNER JOIN player_record pr ON pr.player_id = pl.player_id
    INNER JOIN player_season ps ON ps.season_id = pr.season_id
    INNER JOIN master_record mr ON mr.record_id = pr.record_id
    INNER JOIN master_stat ms ON ms.stat_id = mr.stat_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
    INNER JOIN account a ON a.ID = pl.account_id
WHERE
	ms.stat_id = var_stat_id
    AND mr.is_monthly = 1
    AND pl.is_active = 1
ORDER BY
    mr.is_weekly DESC
    ,mr.is_monthly DESC
    ,mr.is_yearly DESC
    ,mr.is_career DESC
    ,pr.broken_date DESC
LIMIT var_limit$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_record_stat_yearly_by_stat_id_sel` (IN `var_stat_id` INT, IN `var_limit` INT)  NO SQL
SELECT
	a.ID AS account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pr.record_id
    ,pr.stat_id
    ,mr.record_preface
    ,ms.stat_name
    ,ms.stat_abbr
    ,ms.stat_desc
    ,pr.record_value
    ,mr.is_weekly
    ,mr.is_monthly
    ,mr.is_yearly
    ,mr.is_career
    ,mr.record_star_bonus
    ,pr.broken_date
    ,pl.is_retired
FROM
	player pl
    INNER JOIN player_record pr ON pr.player_id = pl.player_id
    INNER JOIN player_season ps ON ps.season_id = pr.season_id
    INNER JOIN master_record mr ON mr.record_id = pr.record_id
    INNER JOIN master_stat ms ON ms.stat_id = mr.stat_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
    INNER JOIN account a ON a.ID = pl.account_id
WHERE
	ms.stat_id = var_stat_id
    AND mr.is_yearly = 1
    AND pl.is_active = 1
ORDER BY
    mr.is_weekly DESC
    ,mr.is_monthly DESC
    ,mr.is_yearly DESC
    ,mr.is_career DESC
    ,pr.broken_date DESC
LIMIT var_limit$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_record_weekly_by_stat_id_sel` (IN `var_stat_id` INT, IN `var_limit` INT)  NO SQL
SELECT
	a.ID AS account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pr.record_id
    ,pr.stat_id
    ,mr.record_preface
    ,ms.stat_name
    ,ms.stat_abbr
    ,ms.stat_desc
    ,pr.record_value
    ,mr.is_weekly
    ,mr.is_monthly
    ,mr.is_yearly
    ,mr.is_career
    ,mr.record_star_bonus
    ,pr.broken_date
    ,pl.is_retired
FROM
	player pl
    INNER JOIN player_record pr ON pr.player_id = pl.player_id
    INNER JOIN player_season ps ON ps.season_id = pr.season_id
    INNER JOIN master_record mr ON mr.record_id = pr.record_id
    INNER JOIN master_stat ms ON ms.stat_id = mr.stat_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
    INNER JOIN account a ON a.ID = pl.account_id
WHERE
	ms.stat_id = var_stat_id
    AND mr.is_weekly = 1
    AND pl.is_active = 1
ORDER BY
    mr.is_weekly DESC
    ,mr.is_monthly DESC
    ,mr.is_yearly DESC
    ,mr.is_career DESC
    ,pr.broken_date DESC
LIMIT var_limit$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_standings_conference_leaders_sel` (IN `var_player_id` INT)  NO SQL
SELECT
    conf_one.conference_id
    ,conf_one.division_id
    ,conf_one.team_id
FROM
    (
    SELECT
        mlc.conference_id
        ,mt.division_id
        ,ls.team_id
    FROM
        league_standings ls
        INNER JOIN master_league_conference mlc ON mlc.league_id = ls.league_id AND mlc.conference_id = 1
        INNER JOIN master_team mt ON mt.team_id = ls.team_id AND mt.conference_id = mlc.conference_id
    WHERE
        ls.season_id = (SELECT season_id FROM player WHERE player_id = var_player_id)
    ORDER BY
        mlc.conference_id ASC
        ,ls.wins DESC
    LIMIT 1
) conf_one

UNION ALL 

SELECT
    conf_two.conference_id
    ,conf_two.division_id
    ,conf_two.team_id
FROM 
(
    SELECT
        mlc.conference_id
        ,mt.division_id
        ,ls.team_id
    FROM
        league_standings ls
        INNER JOIN master_league_conference mlc ON mlc.league_id = ls.league_id AND mlc.conference_id = 2
        INNER JOIN master_team mt ON mt.team_id = ls.team_id AND mt.conference_id = mlc.conference_id
    WHERE
        ls.season_id = (SELECT season_id FROM player WHERE player_id = var_player_id)
    ORDER BY
        mlc.conference_id ASC
        ,ls.wins DESC
    LIMIT 1
) conf_two$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_standings_division_leaders_sel` (IN `var_player_id` INT, IN `var_conf_one_not_div` INT, IN `var_conf_two_not_div` INT)  NO SQL
SELECT
	tms.conference_id
    ,tms.division_id
    ,tms.team_id
FROM
	(
        SELECT 
            mld.conference_id
            ,mld.division_id
            ,(
                SELECT 
                    mt.team_id 
                FROM 
                    player_season ps
                	INNER JOIN player pl ON pl.season_id = ps.season_id AND pl.player_id = var_player_id
                    INNER JOIN master_team mt ON mt.league_id = ps.league_id AND (mt.conference_id = 1 AND mt.division_id <> var_conf_one_not_div OR mt.conference_id = 2 AND mt.division_id <> var_conf_two_not_div)
                    INNER JOIN league_standings ls ON ls.team_id = mt.team_id AND ls.season_id = ps.season_id
                WHERE
                    ps.player_id = var_player_id
                    AND mt.league_id = mld.league_id
                    AND mt.division_id = mld.division_id
                ORDER BY
                    ls.wins DESC
                LIMIT 1
            ) AS team_id
        FROM
            master_league_division mld
        WHERE
			(mld.conference_id = 1 AND mld.division_id <> var_conf_one_not_div OR mld.conference_id = 2 AND mld.division_id <> var_conf_two_not_div)
	) tms
    INNER JOIN player_season ps ON 
    	ps.player_id = var_player_id
    INNER JOIN player pl ON pl.player_id = var_player_id AND pl.season_id = ps.season_id
    INNER JOIN league_standings ls ON
    	ls.season_id = ps.season_id
        AND ls.league_id = ps.league_id
        AND ls.team_id = tms.team_id
ORDER BY 
	tms.conference_id ASC,
    ls.wins DESC,
    ls.losses ASC,
	tms.division_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_standings_ins` (IN `var_player_id` INT)  NO SQL
INSERT INTO league_standings (league_id, season_id, team_id)
SELECT
    mt.league_id
    ,(SELECT season_id FROM player WHERE player_id = var_player_id) AS season_id
    ,mt.team_id
FROM
	master_team mt
WHERE
	mt.league_id = (SELECT t.league_id FROM player pl INNER JOIN master_team t ON t.team_id = pl.team_id WHERE pl.player_id = var_player_id)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_standings_page_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	mlc.conference_name
	,mlc.conference_id
    ,mld.division_name
    ,mt.division_id
    ,ls.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,ls.season_id
    ,ls.wins
    ,ls.losses
    ,ls.playoff_seed
    ,ls.is_wildcard_team
    ,ls.is_division_leader
    ,ls.is_conference_leader
    ,ls.is_world_series_winner
    ,(CASE WHEN pl.team_id = ls.team_id THEN 1 ELSE 0 END) AS is_player_team
    ,ps.games_until_yearly
FROM
	league_standings ls
    INNER JOIN master_league_conference mlc ON mlc.league_id = ls.league_id
    INNER JOIN master_team mt ON mt.team_id = ls.team_id AND mt.league_id = mlc.league_id AND mt.conference_id = mlc.conference_id
    INNER JOIN master_league_division mld ON mld.league_id = mt.league_id AND mlc.conference_id = mld.conference_id AND mt.division_id = mld.division_id
    INNER JOIN (SELECT player_id, season_id, team_id FROM player) pl ON pl.player_id = var_player_id
    INNER JOIN player_season ps ON ps.season_id = pl.season_id
WHERE
	ls.season_id = pl.season_id
    AND mt.is_active = 1
ORDER BY
	mlc.conference_id ASC
    ,mt.division_id ASC
    ,(CASE WHEN ls.playoff_seed > 0 THEN ls.playoff_seed ELSE 100 END) ASC
    ,ls.wins DESC
    ,ls.losses ASC
    ,ls.team_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_standings_playoff_teams_upd` (IN `var_league_id` INT, IN `var_season_id` INT, IN `var_team_id` INT, IN `var_is_conference_leader` INT, IN `var_is_division_leader` INT, IN `var_is_wildcard_team` INT, IN `var_playoff_seed` INT)  NO SQL
UPDATE league_standings
SET
	is_conference_leader = var_is_conference_leader
    ,is_division_leader = var_is_division_leader
    ,is_wildcard_team = var_is_wildcard_team
    ,playoff_seed = var_playoff_seed
WHERE
	league_id = var_league_id
    AND season_id = var_season_id
    AND team_id = var_team_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_standings_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	ls.league_id
    ,ls.season_id
    ,mt.conference_id
    ,ls.team_id
    ,ls.wins
    ,ls.losses
FROM
	league_standings ls
    INNER JOIN master_team mt ON mt.team_id = ls.team_id AND mt.league_id = ls.league_id
WHERE
	ls.league_id = (SELECT mt.league_id FROM player pl INNER JOIN master_team mt ON mt.team_id = pl.team_id WHERE pl.player_id = var_player_id)
    AND ls.season_id = (SELECT pl.season_id FROM player pl WHERE pl.player_id = var_player_id)
ORDER BY 
	mt.conference_id ASC
	,ls.wins DESC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_standings_upd` (IN `var_league_id` INT, IN `var_season_id` INT, IN `var_team_id` INT, IN `var_wins` INT, IN `var_losses` INT)  NO SQL
UPDATE league_standings
SET
	wins = var_wins
    ,losses = var_losses
WHERE
	league_id = var_league_id
    AND season_id = var_season_id
    AND team_id = var_team_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_standings_wildcard_teams_sel` (IN `var_season_id` INT, IN `var_conf_one_not_team_one` INT, IN `var_conf_one_not_team_two` INT, IN `var_conf_one_not_team_three` INT, IN `var_conf_two_not_team_one` INT, IN `var_conf_two_not_team_two` INT, IN `var_conf_two_not_team_three` INT)  NO SQL
SELECT conf_one.conference_id,conf_one.division_id,conf_one.team_id FROM (
SELECT
    mt.conference_id
    ,mt.division_id
    ,ls.team_id
FROM
    league_standings ls
    INNER JOIN master_team mt ON mt.team_id = ls.team_id
WHERE
    mt.conference_id = 1
    AND ls.team_id NOT IN (var_conf_one_not_team_one, var_conf_one_not_team_two, var_conf_one_not_team_three)
    AND ls.season_id = var_season_id
ORDER BY
    ls.wins DESC
    ,ls.team_id DESC
LIMIT 2) conf_one

UNION ALL 

SELECT conf_two.conference_id,conf_two.division_id,conf_two.team_id FROM (
SELECT
    mt.conference_id
    ,mt.division_id
    ,ls.team_id
FROM
    league_standings ls
    INNER JOIN master_team mt ON mt.team_id = ls.team_id
WHERE
    mt.conference_id = 2
    AND ls.team_id NOT IN (var_conf_two_not_team_one, var_conf_two_not_team_two, var_conf_two_not_team_three)
    AND ls.season_id = var_season_id
ORDER BY
    ls.wins DESC
    ,ls.team_id DESC
LIMIT 2) conf_two$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_standings_world_series_winner_upd` (IN `var_season_id` INT)  NO SQL
UPDATE league_standings SET is_world_series_winner = 1 WHERE season_id = var_season_id AND team_id = (SELECT winner_team_id FROM league_playoff_schedule WHERE season_id = var_season_id AND round = 4 AND is_finished = 1)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_stats_career_leaders_sel` (IN `var_stat_id` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	pl.account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_position
    ,pl.player_age
    ,pl.years_pro
    ,pl.season_id
    ,mp.position_name
    ,mp.position_abbr
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,ms.stat_id
    ,ms.stat_abbr
    ,0 AS games_played
    ,SUM(pss.stat_value) AS stat_value
    ,pl.is_retired
FROM
	player pl
    INNER JOIN account a ON a.ID = pl.account_id
    INNER JOIN player_season ps ON ps.player_id = pl.player_id
    INNER JOIN player_stat_season pss ON pss.season_id = ps.season_id AND pss.player_id = pl.player_id
    INNER JOIN master_stat ms ON ms.stat_id = pss.stat_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    INNER JOIN master_team mt ON mt.team_id = pl.team_id AND mt.league_id = ps.league_id
WHERE
	ms.stat_id = var_stat_id
    AND pss.stat_value > 0
    AND pl.is_active = 1
GROUP BY
	pl.account_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_age
    ,pl.years_pro
    ,pl.season_id
    ,pl.player_position
    ,mp.position_name
    ,mp.position_abbr
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,ms.stat_id
    ,ms.stat_abbr
    ,pl.is_retired
ORDER BY
	SUM(pss.stat_value) DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_stats_career_leaders_sel_old` (IN `var_stat_id` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	pl.account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_position
    ,pl.player_age
    ,pl.years_pro
    ,pl.season_id
    ,mp.position_name
    ,mp.position_abbr
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,ms.stat_id
    ,ms.stat_abbr
    ,SUM(gp.games_played) AS games_played
    ,SUM(pss.stat_value) AS stat_value
    ,pl.is_retired
FROM
	player pl
    INNER JOIN account a ON a.ID = pl.account_id
    INNER JOIN player_season ps ON ps.player_id = pl.player_id
    INNER JOIN (SELECT ts.season_id, COUNT(ts.game_id) AS games_played FROM team_schedule ts WHERE ts.is_finished = 1 GROUP BY ts.season_id) gp ON gp.season_id = ps.season_id
    INNER JOIN player_stat_season pss ON pss.season_id = ps.season_id AND pss.player_id = pl.player_id
    INNER JOIN master_stat ms ON ms.stat_id = pss.stat_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    INNER JOIN master_team mt ON mt.team_id = pl.team_id AND mt.league_id = ps.league_id
WHERE
	ms.stat_id = var_stat_id
    AND pss.stat_value > 0
    AND pl.is_active = 1
GROUP BY
	pl.account_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_age
    ,pl.years_pro
    ,pl.season_id
    ,pl.player_position
    ,mp.position_name
    ,mp.position_abbr
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,ms.stat_id
    ,ms.stat_abbr
    ,pl.is_retired
ORDER BY
	SUM(pss.stat_value) DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_stats_game_leaders_sel` (IN `var_type` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	pl.account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_position
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mp.position_name
    ,mp.position_abbr
    ,ps.team_id
    ,ms.stat_id
    ,ms.stat_abbr
    ,pss.stat_value
    ,1 AS games_played
    ,pl.is_retired
    ,pss.game_id
    ,ts.team_score
    ,ts.opponent_score
    ,ts.game_date
FROM
	player pl
    INNER JOIN account a ON a.ID = pl.account_id
    INNER JOIN player_season ps ON ps.player_id = pl.player_id
    INNER JOIN team_schedule ts ON ts.season_id = ps.season_id AND ts.team_id = ps.team_id AND ts.is_finished = 1
    INNER JOIN player_stat_game pss ON pss.game_id = ts.game_id AND pss.player_id = pl.player_id
    INNER JOIN master_stat ms ON ms.stat_id = pss.stat_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
WHERE
	ms.stat_id = var_type
    AND pss.stat_value > 0
    AND pl.is_active = 1
ORDER BY
	pss.stat_value DESC
    ,ts.game_date DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_stats_season_leaders_sel` (IN `var_stat_id` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	pl.account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_position
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,ps.season_id
    ,mp.position_name
    ,mp.position_abbr
    ,ps.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,ms.stat_id
    ,ms.stat_abbr
    ,pss.stat_value
    ,gp.games_played
    ,pl.is_retired
FROM
	player pl
    INNER JOIN account a ON a.ID = pl.account_id
    INNER JOIN player_season ps ON ps.player_id = pl.player_id
    INNER JOIN (SELECT ts.season_id, COUNT(ts.game_id) AS games_played FROM team_schedule ts WHERE ts.is_finished = 1 GROUP BY ts.season_id) gp ON gp.season_id = ps.season_id
    INNER JOIN player_stat_season pss ON pss.season_id = ps.season_id AND pss.player_id = pl.player_id
    INNER JOIN master_stat ms ON ms.stat_id = pss.stat_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    INNER JOIN master_team mt ON mt.team_id = ps.team_id AND mt.league_id = ps.league_id
WHERE
	ms.stat_id = var_stat_id
    AND pss.stat_value > 0
    AND pl.is_active = 1
ORDER BY
	pss.stat_value DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_stats_team_game_leaders_sel` (IN `var_stat_id` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	ts.season_id
    ,ts.game_id
    ,ts.team_id
    ,mt.team_abbr
    ,mt.team_city
    ,mt.team_name
    ,ts.team_score
    ,ts.opponent_id AS opponent_team_id
    ,mto.team_abbr AS opponent_team_abbr
    ,mto.team_city AS opponent_team_city
    ,mto.team_name AS opponent_team_name
    ,ts.opponent_score
    ,ts.game_date
    ,tsg.stat_id
    ,ms.stat_abbr
    ,ms.stat_name
    ,tsg.stat_value
    ,ts.is_home
    ,ts.innings
FROM
	team_stat_game tsg
	INNER JOIN team_schedule ts ON ts.game_id = tsg.game_id
    INNER JOIN master_team mt ON mt.team_id = ts.team_id
    INNER JOIN master_team mto ON mto.team_id = ts.opponent_id
    INNER JOIN league_standings pts ON pts.season_id = ts.season_id AND pts.team_id = ts.team_id AND pts.league_id = mt.league_id
    INNER JOIN league_standings ots ON ots.season_id = ts.season_id AND ots.team_id = ts.opponent_id AND ots.league_id = mto.league_id
    INNER JOIN master_stat ms ON ms.stat_id = tsg.stat_id
WHERE
    tsg.stat_id = var_stat_id
    AND ts.is_finished = 1
    AND tsg.stat_value > 0
ORDER BY 
	tsg.stat_value DESC
    ,ts.game_date DESC
    ,ts.game_id DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_stat_career_hitting_pct_sel` (IN `var_type` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	pl.account_id
    ,ac.username AS account_username
    ,ac.isAdmin AS account_is_admin
    ,ac.isPremium AS account_is_premium
    ,a.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_position
    ,pl.player_age
    ,pl.years_pro
    ,pl.season_id
    ,mp.position_name
    ,mp.position_abbr
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pl.is_retired
    ,(CASE
      	WHEN var_type = 19 THEN 'AVG'
      	WHEN var_type = 20 THEN 'SLG'
      	WHEN var_type = 21 THEN 'ISO'
      	WHEN var_type = 22 THEN 'OBP'
      	WHEN var_type = 23 THEN 'wOBA'
      	WHEN var_type = 27 THEN 'OPS'
    END) AS stat_abbr
    ,(CASE
      	WHEN var_type = 19 THEN (CASE WHEN SUM(a.at_bats) > 250 THEN SUM(a.hits) / SUM(a.at_bats) ELSE 0 END)
      	WHEN var_type = 20 THEN (CASE WHEN SUM(a.at_bats) > 250 THEN ((((1.0 * SUM(a.singles)) + (2.0 * SUM(a.doubles)) + (3.0 * SUM(a.triples)) + (4.0 * SUM(a.homeruns))) * 1.0) / (SUM(a.at_bats) * 1.0)) ELSE 0 END)
      	WHEN var_type = 21 THEN (CASE WHEN SUM(a.at_bats) > 250 THEN (((1.0 * SUM(a.doubles)) + (2.0 * SUM(a.triples)) + (3.0 * SUM(a.homeruns))) / (SUM(a.at_bats) * 1.0)) ELSE 0 END)
      	WHEN var_type = 22 THEN (CASE WHEN SUM(a.at_bats) > 250 THEN ((SUM(a.hits) + SUM(a.walks) + SUM(a.hbp)) / (SUM(a.at_bats) + SUM(a.walks) + SUM(a.hbp) + SUM(a.sac_flies))) ELSE 0 END)
      	WHEN var_type = 23 THEN (CASE WHEN SUM(a.appearances) > 250 THEN ((0.7 * (SUM(a.walks) + SUM(a.hbp)) + 0.9 * SUM(a.singles) + 1.25 * SUM(a.doubles) + 1.6 * SUM(a.triples) + 2.0 * SUM(a.homeruns)) / SUM(a.appearances)) ELSE 0 END)
      	WHEN var_type = 27 THEN ((CASE WHEN SUM(a.at_bats) > 250 THEN ((SUM(a.hits) + SUM(a.walks) + SUM(a.hbp)) / (SUM(a.at_bats) + SUM(a.walks) + SUM(a.hbp) + SUM(a.sac_flies))) ELSE 0 END) + (CASE WHEN SUM(a.at_bats) > 250 THEN ((((1.0 * SUM(a.singles)) + (2.0 * SUM(a.doubles)) + (3.0 * SUM(a.triples)) + (4.0 * SUM(a.homeruns))) * 1.0) / (SUM(a.at_bats) * 1.0)) ELSE 0 END))
      	ELSE 0
     END) AS stat_value
     ,SUM(gp.games_played) AS games_played
FROM
    master_stat ms
    INNER JOIN (
        SELECT
            player_id
            ,stat_id
            ,(CASE WHEN stat_id = 1 THEN SUM(stat_value) ELSE 0 END) AS appearances
            ,(CASE WHEN stat_id = 2 THEN SUM(stat_value) ELSE 0 END) AS at_bats
            ,(CASE WHEN stat_id = 4 THEN SUM(stat_value) ELSE 0 END) AS hits
            ,(CASE WHEN stat_id = 6 THEN SUM(stat_value) ELSE 0 END) AS walks
            ,(CASE WHEN stat_id = 10 THEN SUM(stat_value) ELSE 0 END) AS singles
            ,(CASE WHEN stat_id = 11 THEN SUM(stat_value) ELSE 0 END) AS doubles
            ,(CASE WHEN stat_id = 12 THEN SUM(stat_value) ELSE 0 END) AS triples
            ,(CASE WHEN stat_id = 13 THEN SUM(stat_value) ELSE 0 END) AS homeruns
            ,(CASE WHEN stat_id = 16 THEN SUM(stat_value) ELSE 0 END) AS sac_flies
            ,(CASE WHEN stat_id = 26 THEN SUM(stat_value) ELSE 0 END) AS hbp
        FROM 
            player_stat_season
       	WHERE
        	stat_id IN (1,2,4,6, 10, 11, 12, 13, 16, 26)
        GROUP BY
            player_id
            ,stat_id
    ) a ON a.stat_id = ms.stat_id
    INNER JOIN player pl ON pl.player_id = a.player_id AND pl.is_active = 1
    INNER JOIN player_season ps ON ps.player_id = pl.player_id
    INNER JOIN account ac ON ac.ID = pl.account_id AND ac.IsActive = 1
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    INNER JOIN master_team mt ON mt.team_id = ps.team_id AND mt.is_active = 1
    INNER JOIN (SELECT ts.season_id, COUNT(ts.game_id) AS games_played FROM team_schedule ts WHERE ts.is_finished = 1 GROUP BY ts.season_id) gp ON gp.season_id = ps.season_id
GROUP BY
	pl.account_id
    ,ac.username
    ,ac.isAdmin
    ,ac.isPremium
    ,a.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_position
    ,pl.player_age
    ,pl.years_pro
    ,pl.season_id
    ,mp.position_name
    ,mp.position_abbr
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pl.is_retired
ORDER BY
	stat_value desc
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_stat_season_hitting_pct_sel` (IN `var_type` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	pl.account_id
    ,ac.username AS account_username
    ,ac.isAdmin AS account_is_admin
    ,ac.isPremium AS account_is_premium
    ,a.player_id
    ,a.season_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_position
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mp.position_name
    ,mp.position_abbr
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pl.is_retired
    ,(CASE
      	WHEN var_type = 19 THEN 'AVG'
      	WHEN var_type = 20 THEN 'SLG'
      	WHEN var_type = 21 THEN 'ISO'
      	WHEN var_type = 22 THEN 'OBP'
      	WHEN var_type = 23 THEN 'wOBA'
      	WHEN var_type = 27 THEN 'OPS'
    END) AS stat_abbr
    ,(CASE
      	WHEN var_type = 19 THEN (CASE WHEN SUM(a.at_bats) > 250 THEN SUM(a.hits) / SUM(a.at_bats) ELSE 0 END)
      	WHEN var_type = 20 THEN (CASE WHEN SUM(a.at_bats) > 250 THEN ((((1.0 * SUM(a.singles)) + (2.0 * SUM(a.doubles)) + (3.0 * SUM(a.triples)) + (4.0 * SUM(a.homeruns))) * 1.0) / (SUM(a.at_bats) * 1.0)) ELSE 0 END)
      	WHEN var_type = 21 THEN (CASE WHEN SUM(a.at_bats) > 250 THEN (((1.0 * SUM(a.doubles)) + (2.0 * SUM(a.triples)) + (3.0 * SUM(a.homeruns))) / (SUM(a.at_bats) * 1.0)) ELSE 0 END)
      	WHEN var_type = 22 THEN (CASE WHEN SUM(a.at_bats) > 250 THEN ((SUM(a.hits) + SUM(a.walks) + SUM(a.hbp)) / (SUM(a.at_bats) + SUM(a.walks) + SUM(a.hbp) + SUM(a.sac_flies))) ELSE 0 END)
      	WHEN var_type = 23 THEN (CASE WHEN SUM(a.appearances) > 250 THEN ((0.7 * (SUM(a.walks) + SUM(a.hbp)) + 0.9 * SUM(a.singles) + 1.25 * SUM(a.doubles) + 1.6 * SUM(a.triples) + 2.0 * SUM(a.homeruns)) / SUM(a.appearances)) ELSE 0 END)
      	WHEN var_type = 27 THEN ((CASE WHEN SUM(a.at_bats) > 250 THEN ((SUM(a.hits) + SUM(a.walks) + SUM(a.hbp)) / (SUM(a.at_bats) + SUM(a.walks) + SUM(a.hbp) + SUM(a.sac_flies))) ELSE 0 END) + (CASE WHEN SUM(a.at_bats) > 250 THEN ((((1.0 * SUM(a.singles)) + (2.0 * SUM(a.doubles)) + (3.0 * SUM(a.triples)) + (4.0 * SUM(a.homeruns))) * 1.0) / (SUM(a.at_bats) * 1.0)) ELSE 0 END))
      	ELSE 0
     END) AS stat_value
FROM
    master_stat ms
    INNER JOIN (
        SELECT
            player_id
            ,season_id
            ,stat_id
            ,(CASE WHEN stat_id = 1 THEN SUM(stat_value) ELSE 0 END) AS appearances
            ,(CASE WHEN stat_id = 2 THEN SUM(stat_value) ELSE 0 END) AS at_bats
            ,(CASE WHEN stat_id = 4 THEN SUM(stat_value) ELSE 0 END) AS hits
            ,(CASE WHEN stat_id = 6 THEN SUM(stat_value) ELSE 0 END) AS walks
            ,(CASE WHEN stat_id = 10 THEN SUM(stat_value) ELSE 0 END) AS singles
            ,(CASE WHEN stat_id = 11 THEN SUM(stat_value) ELSE 0 END) AS doubles
            ,(CASE WHEN stat_id = 12 THEN SUM(stat_value) ELSE 0 END) AS triples
            ,(CASE WHEN stat_id = 13 THEN SUM(stat_value) ELSE 0 END) AS homeruns
            ,(CASE WHEN stat_id = 16 THEN SUM(stat_value) ELSE 0 END) AS sac_flies
            ,(CASE WHEN stat_id = 26 THEN SUM(stat_value) ELSE 0 END) AS hbp
        FROM 
            player_stat_season
       	WHERE
        	stat_id IN (1,2,4,6, 10, 11, 12, 13, 16, 26)
        GROUP BY
            player_id
            ,season_id
            ,stat_id
    ) a ON a.stat_id = ms.stat_id
    INNER JOIN player pl ON pl.player_id = a.player_id AND pl.is_active = 1
    INNER JOIN player_season ps ON ps.player_id = pl.player_id AND ps.season_id = a.season_id
    INNER JOIN account ac ON ac.ID = pl.account_id AND ac.IsActive = 1
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    INNER JOIN master_team mt ON mt.team_id = ps.team_id AND mt.is_active = 1
GROUP BY
	pl.account_id
    ,ac.username
    ,ac.isAdmin
    ,ac.isPremium
    ,a.player_id
    ,a.season_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_position
    ,ps.years_pro
    ,mp.position_name
    ,mp.position_abbr
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pl.is_retired
ORDER BY
	stat_value desc
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_team_best_players_sel` (IN `var_account_id` INT, IN `var_team_abbr` VARCHAR(3), IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	a.ID AS account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,pl.season_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_abbr
    ,mt.team_abbr
    ,pl.player_age
    ,pl.years_pro AS player_seasons
    ,ps.star_earned
    ,(CASE WHEN smvp.season_mvp IS NULL THEN 0 ELSE smvp.season_mvp END) AS season_mvp
    ,(CASE WHEN alls.all_star IS NULL THEN 0 ELSE alls.all_star END) AS all_star
    ,(CASE WHEN pom.player_of_month IS NULL THEN 0 ELSE pom.player_of_month END) AS player_of_month
    ,(CASE WHEN pow.player_of_week IS NULL THEN 0 ELSE pow.player_of_week END) AS player_of_week
    ,(CASE WHEN gmvp.game_mvp IS NULL THEN 0 ELSE gmvp.game_mvp END) AS game_mvp
    ,(CASE WHEN ws.world_series_wins IS NULL THEN 0 ELSE ws.world_series_wins END) AS world_series_wins
    ,(CASE WHEN var_account_id = pl.account_id THEN 1 ELSE 0 END) AS is_account_player
    ,pl.is_retired
FROM
	player_star ps
    INNER JOIN player pl ON pl.player_id = ps.player_id AND pl.is_active = 1
    INNER JOIN account a ON a.ID = pl.account_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    INNER JOIN master_team mt ON mt.team_id = pl.team_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS season_mvp
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 11
       	GROUP BY pa.player_id
   	) smvp ON smvp.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS all_star
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 22
       	GROUP BY pa.player_id
   	) alls ON alls.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS player_of_month
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 16
       	GROUP BY pa.player_id
   	) pom ON pom.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS player_of_week
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 14
       	GROUP BY pa.player_id
   	) pow ON pow.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS world_series_wins
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 21
       	GROUP BY pa.player_id
   	) ws ON ws.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pgb.player_id
        	,COUNT(pgb.bonus_id) AS game_mvp
       	FROM 
        	player_game_bonus pgb
       	WHERE
        	pgb.bonus_id = 1
       	GROUP BY pgb.player_id
   	) gmvp ON gmvp.player_id = pl.player_id
WHERE
	ps.star_earned > 0
    AND mt.team_abbr = var_team_abbr
GROUP BY 
	pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_abbr
    ,mt.team_abbr
    ,ps.star_earned
    ,pl.is_retired
ORDER BY
	ps.star_earned DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_team_by_season_and_team_abbr_sel` (IN `var_season_id` INT, IN `var_team_abbr` VARCHAR(3))  NO SQL
SELECT
	mt.league_id
    ,ls.season_id
    ,mt.conference_id
    ,mlc.conference_name
    ,mt.division_id
    ,mld.division_name
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,ls.wins
    ,ls.losses
    ,ls.playoff_seed
    ,ls.is_wildcard_team
    ,ls.is_division_leader
    ,ls.is_conference_leader
    ,ls.is_world_series_winner
    ,(SELECT COUNT(a.team_id) FROM league_standings a WHERE a.league_id = ls.league_id AND a.team_id = ls.team_id AND a.is_wildcard_team = 1) AS wild_card_appearances
    ,(SELECT COUNT(a.team_id) FROM league_standings a WHERE a.league_id = ls.league_id AND a.team_id = ls.team_id AND a.is_division_leader = 1) AS division_titles
    ,(SELECT COUNT(a.team_id) FROM league_standings a WHERE a.league_id = ls.league_id AND a.team_id = ls.team_id AND a.is_conference_leader = 1) AS conference_titles
    ,(SELECT COUNT(b.team_id) FROM league_standings b WHERE b.league_id = ls.league_id AND b.team_id = ls.team_id AND b.is_world_series_winner = 1) AS world_series_titles
    ,(SELECT SUM(b.wins) FROM league_standings b WHERE b.league_id = ls.league_id AND b.team_id = ls.team_id) AS total_wins
    ,(SELECT SUM(b.losses) FROM league_standings b WHERE b.league_id = ls.league_id AND b.team_id = ls.team_id) AS total_losses
FROM
	league_standings ls
    INNER JOIN master_team mt ON mt.team_id = ls.team_id AND mt.league_id = ls.league_id
    INNER JOIN master_league_conference mlc ON mlc.league_id = mt.league_id AND mlc.conference_id = mt.conference_id
    INNER JOIN master_league_division mld ON mld.league_id = mt.league_id AND mld.conference_id = mlc.conference_id AND mld.division_id = mt.division_id
WHERE
	ls.season_id = var_season_id
    AND mt.team_abbr = var_team_abbr$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_team_by_season_id_sel` (IN `var_season_id` INT, IN `var_team_id` INT)  NO SQL
SELECT
	mt.league_id
    ,ls.season_id
    ,mt.conference_id
    ,mlc.conference_name
    ,mt.division_id
    ,mld.division_name
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,ls.wins
    ,ls.losses
    ,ls.playoff_seed
    ,ls.is_wildcard_team
    ,ls.is_division_leader
    ,ls.is_conference_leader
    ,ls.is_world_series_winner
    ,(SELECT COUNT(a.team_id) FROM league_standings a WHERE a.league_id = ls.league_id AND a.team_id = ls.team_id AND a.is_wildcard_team = 1) AS wild_card_appearances
    ,(SELECT COUNT(a.team_id) FROM league_standings a WHERE a.league_id = ls.league_id AND a.team_id = ls.team_id AND a.is_division_leader = 1) AS division_titles
    ,(SELECT COUNT(a.team_id) FROM league_standings a WHERE a.league_id = ls.league_id AND a.team_id = ls.team_id AND a.is_conference_leader = 1) AS conference_titles
    ,(SELECT COUNT(b.team_id) FROM league_standings b WHERE b.league_id = ls.league_id AND b.team_id = ls.team_id AND b.is_world_series_winner = 1) AS world_series_titles
    ,(SELECT SUM(b.wins) FROM league_standings b WHERE b.league_id = ls.league_id AND b.team_id = ls.team_id) AS total_wins
    ,(SELECT SUM(b.losses) FROM league_standings b WHERE b.league_id = ls.league_id AND b.team_id = ls.team_id) AS total_losses
FROM
	league_standings ls
    INNER JOIN master_team mt ON mt.team_id = ls.team_id AND mt.league_id = ls.league_id
    INNER JOIN master_league_conference mlc ON mlc.league_id = mt.league_id AND mlc.conference_id = mt.conference_id
    INNER JOIN master_league_division mld ON mld.league_id = mt.league_id AND mld.conference_id = mlc.conference_id AND mld.division_id = mt.division_id
WHERE
	ls.season_id = var_season_id
    AND ls.team_id = var_team_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_team_by_team_abbr_sel` (IN `var_team_abbr` VARCHAR(3))  NO SQL
SELECT
	mt.league_id
    ,mt.conference_id
    ,mlc.conference_name
    ,mt.division_id
    ,mld.division_name
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,SUM(ls.wins) AS total_wins
    ,SUM(ls.losses) AS total_losses
    ,SUM(ls.is_wildcard_team) AS wild_card_appearances
    ,SUM(ls.is_division_leader) AS division_titles
    ,SUM(ls.is_conference_leader) AS conference_titles
    ,SUM(ls.is_world_series_winner) AS world_series_titles
FROM
	league_standings ls
    INNER JOIN master_team mt ON mt.team_id = ls.team_id AND mt.league_id = ls.league_id
    INNER JOIN master_league_conference mlc ON mlc.league_id = mt.league_id AND mlc.conference_id = mt.conference_id
    INNER JOIN master_league_division mld ON mld.league_id = mt.league_id AND mld.conference_id = mlc.conference_id AND mld.division_id = mt.division_id
WHERE
	mt.team_abbr = var_team_abbr
GROUP BY
	mt.league_id
    ,mt.conference_id
    ,mlc.conference_name
    ,mt.division_id
    ,mld.division_name
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `league_team_by_team_id_sel` (IN `var_team_id` INT)  NO SQL
SELECT
	mt.league_id
    ,mt.conference_id
    ,mlc.conference_name
    ,mt.division_id
    ,mld.division_name
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,SUM(ls.wins) AS total_wins
    ,SUM(ls.losses) AS total_losses
    ,SUM(ls.is_wildcard_team) AS wild_card_appearances
    ,SUM(ls.is_division_leader) AS division_titles
    ,SUM(ls.is_conference_leader) AS conference_titles
    ,SUM(ls.is_world_series_winner) AS world_series_titles
FROM
	league_standings ls
    INNER JOIN master_team mt ON mt.team_id = ls.team_id AND mt.league_id = ls.league_id
    INNER JOIN master_league_conference mlc ON mlc.league_id = mt.league_id AND mlc.conference_id = mt.conference_id
    INNER JOIN master_league_division mld ON mld.league_id = mt.league_id AND mld.conference_id = mlc.conference_id AND mld.division_id = mt.division_id
WHERE
	ls.team_id = var_team_id
GROUP BY
	mt.league_id
    ,mt.conference_id
    ,mlc.conference_name
    ,mt.division_id
    ,mld.division_name
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `mark_notifications_as_read` (IN `var_account_id` INT, IN `var_player_id` INT)  NO SQL
UPDATE account_notification SET is_read = 1 WHERE is_read = 0 AND ((account_id = var_account_id AND player_id IS NULL) OR (account_id = var_account_id AND player_id = var_player_id))$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_account_count_sel` ()  NO SQL
SELECT COUNT(ID) AS total FROM account WHERE isActive = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_audit_account_list_sel` (IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	ID as account_id
    ,username AS account_username
    ,email AS account_email
    ,IpAddress
    ,isAdmin AS is_admin
    ,isPremium AS is_premium
    ,isActive AS is_active
    ,isVerified AS is_verified
    ,lastLogin AS last_login
    ,Created AS join_date
FROM
	account
ORDER BY
	ID DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_audit_max_games_not_finished_sel` ()  NO SQL
SELECT
	ps.season_id
    ,pl.player_id
    ,ps.team_id
    ,pl.player_firstname
    ,pl.player_lastname
FROM
	player pl
    INNER JOIN player_season ps ON ps.player_id = pl.player_id AND ps.season_id = pl.season_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
WHERE
	ps.is_finished = 0
    AND ps.is_postseason = 0
    AND (SELECT COUNT(ts.game_id) FROM team_schedule ts WHERE ts.season_id = ps.season_id AND ts.is_finished = 1) >= 162$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_audit_players_with_negative_stars_sel` ()  NO SQL
select ps.*,pl.player_firstname,pl.player_lastname,a.* from player_star ps inner join player pl on pl.player_id = ps.player_id inner join account a on a.ID = pl.account_id where ps.star_value < 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_audit_stats_after_date_sel` (IN `var_date` VARCHAR(15))  NO SQL
SELECT
	ms.stat_id
    ,ms.stat_name
   	,ms.stat_abbr
    ,ms.stat_desc
    ,a.stat_value
    ,(SELECT COUNT(ts.game_id) FROM team_schedule ts WHERE ts.is_finished = 1 AND ts.game_date >= var_date) AS total_games
FROM
	master_stat ms
    INNER JOIN (
        SELECT
            psg.stat_id
        	,SUM(psg.stat_value) AS stat_value
        FROM 
            team_schedule ts
            INNER JOIN player_stat_game psg ON psg.game_id = ts.game_id
        WHERE
        	ts.is_finished = 1
            AND ts.game_date >= var_date
       	GROUP BY
        	psg.stat_id
    ) a ON a.stat_id = ms.stat_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_audit_stats_before_date_sel` (IN `var_date` VARCHAR(15))  NO SQL
SELECT
	ms.stat_id
    ,ms.stat_name
   	,ms.stat_abbr
    ,ms.stat_desc
    ,a.stat_value
    ,(SELECT COUNT(ts.game_id) FROM team_schedule ts WHERE ts.is_finished = 1 AND ts.game_date < var_date) AS total_games
FROM
	master_stat ms
    INNER JOIN (
        SELECT
            psg.stat_id
        	,SUM(psg.stat_value) AS stat_value
        FROM 
            team_schedule ts
            INNER JOIN player_stat_game psg ON psg.game_id = ts.game_id
        WHERE
        	ts.is_finished = 1
            AND ts.game_date < var_date
       	GROUP BY
        	psg.stat_id
    ) a ON a.stat_id = ms.stat_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_audit_stats_sel` ()  NO SQL
SELECT
	ms.stat_id
    ,ms.stat_name
   	,ms.stat_abbr
    ,ms.stat_desc
    ,a.stat_value
    ,(SELECT COUNT(ts.game_id) FROM team_schedule ts WHERE ts.is_finished = 1) AS total_games
FROM
	master_stat ms
    INNER JOIN (
        SELECT
            stat_id
        	,SUM(stat_value) AS stat_value
        FROM 
            player_stat_season
       	GROUP BY
        	stat_id
    ) a ON a.stat_id = ms.stat_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_audit_team_score` ()  NO SQL
SELECT
	SUM(ls.team_score) AS team_score
    ,SUM(ls.opponent_score) AS opponent_score
    ,ROUND((SUM(ls.team_score) / (SUM(ls.team_score) + SUM(ls.opponent_score)) * 100), 2) AS team_score_pct
FROM
	player pl
    INNER JOIN player_season ps ON ps.player_id = pl.player_id
    INNER JOIN team_schedule ls ON ls.season_id = ps.season_id AND ls.is_finished = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_audit_team_score_after_date_sel` (IN `var_date` DATETIME)  NO SQL
SELECT
	SUM(ts.team_score) AS team_score
    ,SUM(ts.opponent_score) AS opponent_score
    ,ROUND((SUM(ts.team_score) / (SUM(ts.team_score) + SUM(ts.opponent_score)) * 100), 2) AS team_score_pct
FROM
	player pl
    INNER JOIN player_season ps ON ps.player_id = pl.player_id
    INNER JOIN team_schedule ts ON ts.season_id = ps.season_id AND ts.is_finished = 1 AND ts.game_date >= var_date$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_audit_team_score_before_date_sel` (IN `var_date` TIMESTAMP)  NO SQL
SELECT
	SUM(ts.team_score) AS team_score
    ,SUM(ts.opponent_score) AS opponent_score
    ,ROUND((SUM(ts.team_score) / (SUM(ts.team_score) + SUM(ts.opponent_score)) * 100), 2) AS team_score_pct
FROM
	player pl
    INNER JOIN player_season ps ON ps.player_id = pl.player_id
    INNER JOIN team_schedule ts ON ts.season_id = ps.season_id AND ts.is_finished = 1 AND ts.game_date <= var_date$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_audit_win_loss_record_sel` ()  NO SQL
SELECT
	SUM(ls.wins) AS wins
    ,SUM(ls.losses) AS losses
    ,ROUND((SUM(ls.wins) / (SUM(ls.wins) + SUM(ls.losses)) * 100), 2) AS win_pct
FROM
	player pl
    INNER JOIN player_season ps ON ps.player_id = pl.player_id
    INNER JOIN league_standings ls ON ls.season_id = ps.season_id AND ls.team_id = ps.team_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_player_count_sel` ()  NO SQL
SELECT
	(SELECT COUNT(player_id) FROM player WHERE is_active = 1) AS total
    ,(SELECT COUNT(player_id) FROM player WHERE is_active = 1 AND is_retired = 0) AS active
    ,(SELECT COUNT(player_id) FROM player WHERE is_active = 1 AND is_retired = 1) AS retired$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_position_sel` ()  NO SQL
SELECT 
	mp.position_id
    ,mp.position_name
    ,mp.position_abbr
FROM
	master_position mp
WHERE mp.is_active = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_position_trait_sel` ()  NO SQL
SELECT
    mpt.position_id
	,mpt.trait_id
    ,mpt.trait_value
FROM
	master_position_trait mpt$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_record_upd` (IN `var_record_id` INT, IN `var_stat_value` INT)  NO SQL
UPDATE master_record SET record_value = var_stat_value WHERE record_id = var_record_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_task_log_ins` (IN `var_task_id` INT, IN `var_is_success` INT, IN `var_success_details` VARCHAR(255))  NO SQL
INSERT INTO master_task_log (task_id,is_success,success_details) VALUES(var_task_id,var_is_success,var_success_details)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_task_log_sel` (IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	mt.task_id
    ,mt.task_name
    ,mt.task_category
    ,mtl.log_id
    ,mtl.success_details
    ,mtl.log_date
    ,mtl.is_success
    ,mt.is_daily
    ,mt.is_weekly
    ,mt.is_monthly
FROM
	master_task mt
    INNER JOIN master_task_log mtl ON mtl.task_id = mt.task_id
WHERE
	mt.is_active = 1
ORDER BY
	mtl.log_date DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_team_list_sel` ()  NO SQL
SELECT *
FROM
	master_team mt
WHERE
	mt.is_active = 1
ORDER BY
	mt.team_city ASC
    ,mt.team_name ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `master_team_sel` ()  NO SQL
SELECT 
	mt.team_id
    ,ml.league_name
    ,mlc.conference_name
    ,mld.division_name
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
FROM
	master_team mt
    INNER JOIN master_league ml ON ml.league_id = mt.league_id
    INNER JOIN master_league_conference mlc ON mlc.league_id = mt.league_id AND mlc.conference_id = mt.conference_id
    INNER JOIN master_league_division mld ON mld.league_id = mt.league_id AND mld.conference_id = mt.conference_id AND mld.division_id = mt.division_id
ORDER BY
	mt.team_abbr ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_accept_contract_ins` (IN `var_player_id` INT, IN `var_contract_length` INT)  NO SQL
INSERT INTO player_contract (player_id, team_id, season_id, contract_length, contract_remaining, is_finished)
SELECT
	pl.player_id
    ,pl.team_id
    ,pl.season_id
    ,var_contract_length
    ,var_contract_length
    ,0
FROM
	player pl
WHERE pl.player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_age_upd` (IN `var_player_id` INT)  NO SQL
UPDATE player SET player_age = player_age + 1, years_pro = years_pro + 1,can_sim = 1,is_offseason = 0 WHERE player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_award_all_star_qualified` (IN `var_player_id` INT, IN `var_number_of_games_left` INT)  NO SQL
SELECT
	(CASE WHEN var_number_of_games_left = 0 AND SUM(sg.stat_value) >= (SELECT min_stars_for_all_star FROM master_settings LIMIT 1) THEN 1 ELSE 0 END) AS all_star
FROM
    team_schedule ts
    INNER JOIN player_stat_game sg ON
        sg.game_id = ts.game_id
    INNER JOIN player pl ON pl.season_id = ts.season_id
WHERE
    sg.stat_id = 24
    AND ts.is_finished = 1
    AND pl.player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_award_ins` (IN `var_player_id` INT, IN `var_season_id` INT, IN `var_award_id` INT)  NO SQL
INSERT INTO player_award (player_id, season_id, award_id, received_date) VALUES(var_player_id, var_season_id, var_award_id, CURRENT_TIMESTAMP)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_award_monthly_sel` (IN `var_player_id` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pa.award_id
    ,ma.award_name
    ,ma.award_abbr
    ,ma.award_star_bonus
    ,ma.is_weekly
    ,ma.is_monthly
    ,ma.is_yearly
    ,pa.received_date
FROM
	player_award pa
    INNER JOIN player pl ON pl.player_id = pa.player_id
    INNER JOIN player_season ps ON ps.season_id = pa.season_id
    INNER JOIN master_award ma ON ma.award_id = pa.award_id AND ma.is_active = 1
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
WHERE
	pa.player_id = var_player_id
    AND ma.is_monthly = 1
ORDER BY
	pa.received_date DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_award_progress_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	pl.player_id
    ,ps.season_id
    ,ifNull((ls.wins + ls.losses), 0) AS games_played
     ,ifNull(st.stat_value, 0) AS stars_earned
     ,(SELECT min_stars_for_all_star FROM master_settings LIMIT 1) AS min_stars_for_all_star
     ,(SELECT min_stars_for_mvp FROM master_settings LIMIT 1) AS min_stars_for_mvp
     ,(SELECT min_pog_for_mvp FROM master_settings LIMIT 1) AS min_pog_for_mvp
     ,ifNull(pgb.pog_awards, 0) AS pog_awards 
     ,(CASE 
     	WHEN ifNull(pgb.pog_awards, 0) > 0 AND ifNull(st.stat_value, 0) > 0 THEN (
            ((pgb.pog_awards / (SELECT min_pog_for_mvp FROM master_settings LIMIT 1)) * 100) +
            (((CASE WHEN st.stat_value > (SELECT min_stars_for_mvp FROM master_settings LIMIT 1) THEN (SELECT min_stars_for_mvp FROM master_settings LIMIT 1) ELSE st.stat_value END) / (SELECT min_stars_for_mvp FROM master_settings LIMIT 1)) * 100)
        ) / 2
       	WHEN ifNull(pgb.pog_awards, 0) = 0 AND ifNull(st.stat_value, 0) > 0 THEN (
            (((CASE WHEN st.stat_value > (SELECT min_stars_for_mvp FROM master_settings LIMIT 1) THEN (SELECT min_stars_for_mvp FROM master_settings LIMIT 1) ELSE st.stat_value END) / (SELECT min_stars_for_mvp FROM master_settings LIMIT 1)) * 100)
        ) / 2
       	WHEN ifNull(pgb.pog_awards, 0) > 0 AND ifNull(st.stat_value, 0) <= 0 THEN (
            ((pgb.pog_awards / (SELECT min_pog_for_mvp FROM master_settings LIMIT 1)) * 100)
        ) / 2
     	ELSE 0
     END) AS mvp_progress
     ,(CASE
       	WHEN ifNull((ls.wins + ls.losses), 0) <= 82 AND ifNull((ls.wins + ls.losses), 0) > 0 AND ifNull(st.stat_value, 0) > 0 THEN 
       		(st.stat_value / (SELECT min_stars_for_all_star FROM master_settings LIMIT 1)) * 100
        WHEN ifNull((ls.wins + ls.losses), 0) <= 0 THEN 0
        WHEN ifNull((ls.wins + ls.losses), 0) > 82 THEN 
       		(CASE 
            	 WHEN ifNull(pa.mvp_awards, 0) = 1 THEN 100 
             	ELSE 0 
             END)
        ELSE 0
     END) AS all_star_progress
FROM
	player pl
    INNER JOIN player_season ps ON ps.season_id = pl.season_id AND ps.team_id = pl.team_id
    INNER JOIN league_standings ls ON ls.league_id = ps.league_id AND ls.season_id = ps.season_id AND ls.team_id = ps.team_id
    LEFT JOIN player_stat_season st ON st.player_id = pl.player_id AND st.season_id = pl.season_id AND st.stat_id = 24 AND st.is_postseason = 0
    LEFT JOIN (
        SELECT 
        	pa.player_id, pa.season_id, COUNT(pa.award_id) AS mvp_awards
        FROM player_award pa 
        WHERE pa.award_id = 22
        GROUP BY pa.player_id, pa.season_id
    ) pa ON pa.player_id = pl.player_id AND pa.season_id = pl.season_id
    LEFT JOIN (SELECT 
            pgb.player_id
            ,ts.season_id
            ,ts.team_id
            ,COUNT(pgb.bonus_id) AS pog_awards 
        FROM 
            team_schedule ts
            INNER JOIN player_game_bonus pgb ON pgb.game_id = ts.game_id
        WHERE 
            ts.is_finished = 1
            AND ts.is_postseason = 0
     		AND pgb.bonus_id = 1
     		AND pgb.bonus_value > 0
        GROUP BY pgb.player_id, ts.season_id, ts.team_id
     ) pgb ON pgb.player_id = pl.player_id AND pgb.season_id = pl.season_id AND pgb.team_id = pl.team_id
WHERE
	pl.player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_award_progress_sel_deprecated` (IN `var_player_id` INT)  NO SQL
SELECT
	pl.player_id
    ,ps.season_id
    ,st.games_played
     ,st.stars_earned
     ,(SELECT min_stars_for_all_star FROM master_settings LIMIT 1) AS min_stars_for_all_star
     ,(SELECT min_pog_for_mvp FROM master_settings LIMIT 1) as min_pog_for_mvp
     ,pgb.pog_awards
     ,(CASE 
     	WHEN pgb.pog_awards > 0 THEN 
     		(pgb.pog_awards / (SELECT min_pog_for_mvp FROM master_settings LIMIT 1)) * 100 
     	ELSE 0
     END) AS mvp_progress
     ,(CASE
       	WHEN st.games_played <= (SELECT games_until_midseason FROM master_settings LIMIT 1) AND st.games_played > 0 AND st.stars_earned > 0 THEN 
       		(st.stars_earned / (SELECT min_stars_for_all_star FROM master_settings LIMIT 1)) * 100
        WHEN st.games_played = 0 THEN 0
        WHEN st.stars_earned <= 0 THEN 0
        WHEN st.games_played > (SELECT games_until_midseason FROM master_settings LIMIT 1) THEN 
       		(CASE WHEN (SELECT COUNT(pa.award_id) FROM player_award pa WHERE pa.player_id = pl.player_id AND award_id = 22 AND season_id = ps.season_id LIMIT 1) = 1 THEN 100 ELSE 0 END)
        ELSE 0
     END) AS all_star_progress
FROM
	player pl
    INNER JOIN player_season ps ON
    	ps.player_id = pl.player_id
        AND ps.season_id = pl.season_id
    LEFT JOIN (
        SELECT
        	pgb.player_id
        	,COUNT(pgb.bonus_id) AS pog_awards
       	FROM
        	player_game_bonus pgb
        	INNER JOIN player pl ON pl.player_id = pgb.player_id
        	INNER JOIN team_schedule ts ON ts.game_id = pgb.game_id AND ts.season_id = pl.season_id
        WHERE
        	pgb.bonus_id = 1
        GROUP BY pgb.player_id
    ) pgb ON
    	pgb.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	sg.player_id
        	,ts.season_id
        	,COUNT(ts.game_id) AS games_played
        	,SUM(sg.stat_value) AS stars_earned
        FROM
        	team_schedule ts
        	INNER JOIN player_stat_game sg ON
        		sg.game_id = ts.game_id
       		INNER JOIN player pl ON pl.season_id = ts.season_id
        WHERE
        	sg.stat_id = 24
        	AND ts.is_finished = 1
       GROUP BY
        	sg.player_id
        	,ts.season_id
    ) st ON
    	st.player_id = pl.player_id
        AND st.season_id = ps.season_id
WHERE
	pl.player_id = var_player_id
    AND pl.is_active = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_award_qualified` (IN `var_player_id` INT, IN `var_number_games` INT)  NO SQL
SELECT
	(CASE
     	WHEN var_number_games = 6 AND ROUND(((COUNT(pgb.player_id) / var_number_games) * 100), 0) >= 20 THEN 1
     	WHEN var_number_games = 27 AND ROUND(((COUNT(pgb.player_id) / var_number_games) * 100), 0) >= 15 THEN 1
     	WHEN var_number_games = 162 AND COUNT(pgb.player_id) >= 15 AND ifNull((SELECT st.stat_value FROM player_stat_season st WHERE st.player_id = pl.player_id AND st.season_id = pl.season_id AND st.stat_id = 24 LIMIT 1), 0) >= (SELECT min_stars_for_mvp FROM master_settings LIMIT 1) THEN 1
     	ELSE 0
     END) AS is_qualified
FROM
	player pl
    INNER JOIN player_game_bonus pgb ON pgb.player_id = pl.player_id
    INNER JOIN(
        SELECT 
        	ts.season_id
        	,ts.game_id 
        FROM player_season ps
        INNER JOIN team_schedule ts ON
            ts.season_id = ps.season_id
        WHERE 
            ps.player_id = var_player_id
            AND ts.is_finished = 1
        ORDER BY
            ts.game_date DESC
        LIMIT var_number_games
    ) ts
WHERE
	pgb.player_id = var_player_id
    AND pgb.bonus_id = 1
    AND pgb.game_id = ts.game_id
    AND pl.season_id = ts.season_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_award_stars_upd` (IN `var_player_id` INT, IN `var_award_id` INT)  NO SQL
UPDATE player_star 
SET 
	star_earned = (star_earned + (SELECT award_star_bonus FROM master_award WHERE award_id = var_award_id))
	,star_value = (star_value + (SELECT award_star_bonus FROM master_award WHERE award_id = var_award_id))
WHERE player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_award_weekly_sel` (IN `var_player_id` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pa.award_id
    ,ma.award_name
    ,ma.award_abbr
    ,ma.award_star_bonus
    ,ma.is_weekly
    ,ma.is_monthly
    ,ma.is_yearly
    ,pa.received_date
FROM
	player_award pa
    INNER JOIN player pl ON pl.player_id = pa.player_id
    INNER JOIN player_season ps ON ps.season_id = pa.season_id
    INNER JOIN master_award ma ON ma.award_id = pa.award_id AND ma.is_active = 1
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
WHERE
	pa.player_id = var_player_id
    AND ma.is_weekly = 1
ORDER BY
	pa.received_date DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_award_yearly_sel` (IN `var_player_id` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pa.award_id
    ,ma.award_name
    ,ma.award_abbr
    ,ma.award_star_bonus
    ,ma.is_weekly
    ,ma.is_monthly
    ,ma.is_yearly
    ,pa.received_date
FROM
	player_award pa
    INNER JOIN player pl ON pl.player_id = pa.player_id
    INNER JOIN player_season ps ON ps.season_id = pa.season_id
    INNER JOIN master_award ma ON ma.award_id = pa.award_id AND ma.is_active = 1
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
WHERE
	pa.player_id = var_player_id
    AND ma.is_yearly = 1
ORDER BY
	pa.received_date DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_batting_order_notification_new` (IN `var_player_id` INT, IN `var_template_id` INT, IN `var_batting_order` INT)  NO SQL
INSERT INTO account_notification (account_id, player_id, notification_title, notification_body, notification_link)
SELECT
	(SELECT account_id FROM player WHERE player_id = var_player_id LIMIT 1)
    ,var_player_id
	,(CASE
      	WHEN var_template_id = 2 THEN 'Batting Order Set'
      	WHEN var_template_id = 5 THEN 'New Batting Order: Moved Up'
      	WHEN var_template_id = 6 THEN 'New Batting Order: Moved Down'
      	WHEN var_template_id = 7 THEN 'New Batting Order: No Change'
      	WHEN var_template_id = 28 THEN 'New Batting Order'
      END) AS template_title
	,(CASE
      	WHEN var_template_id = 2 THEN 'The manager of the team has chosen a new batting order. You will be batting in the number ' + var_batting_order + ' spot.'
      	WHEN var_template_id = 5 THEN CONCAT('The manager has set a new batting order for the team. Your spot in the order has moved up due to your performance over the last few games. You will be batting in the number ', var_batting_order, ' spot.')
      	WHEN var_template_id = 6 THEN CONCAT('A new batting order has been set for the team. Your productivity over the last few games has been somewhat lackluster. Your spot in the batting order has been moved down. You will be batting in the number ', var_batting_order, ' spot.')
      	WHEN var_template_id = 7 THEN CONCAT('The manager has set a new batting order. After reviewing your recent performance the manager decided not to change your spot in the order. You will be batting in the number ', var_batting_order, ' spot.')
      	WHEN var_template_id = 28 THEN CONCAT('A new batting order has been set for the team. It looks like you may have found some power in your bat over the last few games. We are going to see how you do in a power-hitting role. This should give you higher-quality batting opportunities. You will be batting in the number ', var_batting_order, ' spot.')
      END) AS template_body
    ,'/team/schedule.php?v=u' AS template_link$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_batting_order_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	tgbo.game_id
    ,tgbo.batting_order
    ,mp.position_name
    ,mp.position_abbr
    ,tgbo.is_owned_player
    ,tgbo.is_designated_hitter
    ,tr.first_name AS batter_first_name
    ,tr.last_name AS batter_last_name
FROM
	team_game_batting_order tgbo
    INNER JOIN master_position mp ON mp.position_id = tgbo.position_id
    INNER JOIN team_schedule ts ON ts.game_id = tgbo.game_id
    INNER JOIN team_roster tr ON tr.season_id = ts.season_id AND tr.team_id = ts.team_id AND tr.roster_id = tgbo.roster_id
    INNER JOIN player pl ON pl.season_id = ts.season_id
    INNER JOIN player_season ps ON ps.season_id = pl.season_id AND ps.player_id = pl.player_id
WHERE
	pl.player_id = var_player_id
    AND pl.is_active = 1
    AND ts.is_finished = 1
ORDER BY
	ts.game_date DESC
LIMIT 9$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_bonus_sel` (IN `var_player_id` INT, IN `var_bonus_id` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,opp.team_id AS opp_team_id
    ,opp.team_city AS opp_team_city
    ,opp.team_name AS opp_team_name
    ,opp.team_abbr AS opp_team_abbr
    ,pa.bonus_id
    ,ma.bonus_name
    ,ma.bonus_abbr
    ,ma.bonus_desc
    ,pa.bonus_value
    ,ts.game_id
    ,ts.team_score
    ,ts.opponent_score
    ,ts.innings
    ,ts.is_postseason
    ,ts.game_date
FROM
	player_game_bonus pa
    INNER JOIN player pl ON pl.player_id = pa.player_id
    INNER JOIN master_bonus ma ON ma.bonus_id = pa.bonus_id
    INNER JOIN team_schedule ts ON ts.game_id = pa.game_id
    INNER JOIN player_season ps ON ps.season_id = ts.season_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
    INNER JOIN master_team opp ON opp.team_id = ts.opponent_id
WHERE
	pa.player_id = var_player_id
    AND ma.bonus_id = var_bonus_id
ORDER BY
	ts.game_date DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_check_monthly_record` (IN `var_player_id` INT)  NO SQL
SELECT
	mr.record_id
	,mr.stat_id
    ,psg.stat_value
    ,mr.record_star_bonus
FROM
	master_record mr
    INNER JOIN (
        SELECT 
                psg.stat_id, SUM(psg.stat_value) AS stat_value 
        FROM
            player pl
            INNER JOIN player_stat_game psg ON psg.player_id = pl.player_id
            INNER JOIN (
                SELECT
                    ts.game_id
                FROM 
                    team_schedule ts
                WHERE
                    ts.season_id = (SELECT season_id FROM player WHERE player_id = var_player_id)
                    AND ts.is_finished = 1
                ORDER BY 
                    ts.game_id DESC 
                LIMIT 27
            ) ts ON ts.game_id = psg.game_id
        WHERE
            pl.player_id = var_player_id
            AND psg.stat_id NOT IN (8, 9, 14, 15, 18, 19, 20, 21, 22, 23, 27)
        GROUP BY
            psg.stat_id
    ) psg ON psg.stat_id = mr.stat_id
WHERE
    mr.is_monthly = 1
    AND mr.stat_id NOT IN (8, 9, 14, 15, 18, 19, 20, 21, 22, 23, 27)
	AND psg.stat_value > mr.record_value$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_check_valid_creation` (IN `var_player_id` INT)  NO SQL
SELECT
    (CASE
    	WHEN 
        	((CASE
                WHEN (SELECT COUNT(ps.season_id) FROM player_season ps WHERE ps.season_id = pl.season_id) >= 1 THEN 1
                ELSE 0
             END) +
            (CASE
                WHEN (SELECT COUNT(ts.game_id) FROM team_schedule ts WHERE ts.season_id = pl.season_id) >= 162 THEN 1
                ELSE 0
            END) +
            (CASE
                WHEN (SELECT COUNT(pc.contract_id) FROM player_contract pc WHERE pc.season_id = pl.season_id) >= 1 THEN 1
                ELSE 0
            END) +
            (CASE
                WHEN (SELECT COUNT(pt.trait_id) FROM player_trait pt WHERE pt.season_id = pl.season_id) >= 1 THEN 1
                ELSE 0
            END) +
            (CASE
                WHEN (SELECT COUNT(ps.player_id) FROM player_star ps WHERE ps.player_id = pl.player_id) >= 1 THEN 1
                ELSE 0
            END) +
            (CASE
                WHEN (SELECT COUNT(tbo.player_id) FROM team_batting_order tbo WHERE tbo.season_id = pl.season_id) >= 1 THEN 1
                ELSE 0
            END) +
            (CASE
                WHEN (SELECT COUNT(pss.stat_id) FROM player_stat_season pss WHERE pss.season_id = pl.season_id) >= 50 THEN 1
                ELSE 0
            END) +
            (CASE
                WHEN (SELECT COUNT(tss.stat_id) FROM team_stat_season tss WHERE tss.season_id = pl.season_id) >= 50 THEN 1
                ELSE 0
            END) +
            (CASE
                WHEN (SELECT COUNT(ls.team_id) FROM league_standings ls WHERE ls.season_id = pl.season_id) >= 30 THEN 1
                ELSE 0
            END)) = 9 THEN 1
    	ELSE 0
    END) AS is_valid
FROM
	player pl
WHERE
	pl.player_id = var_player_id
    AND pl.is_active = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_check_weekly_record` (IN `var_player_id` INT)  NO SQL
SELECT
	mr.record_id
	,mr.stat_id
    ,psg.stat_value
    ,mr.record_star_bonus
FROM
	master_record mr
    INNER JOIN (
        SELECT 
                psg.stat_id, SUM(psg.stat_value) AS stat_value 
        FROM
            player pl
            INNER JOIN player_stat_game psg ON psg.player_id = pl.player_id
            INNER JOIN (
                SELECT
                    ts.game_id
                FROM 
                    team_schedule ts
                WHERE
                    ts.season_id = (SELECT season_id FROM player WHERE player_id = var_player_id)
                    AND ts.is_finished = 1
                ORDER BY 
                    ts.game_id DESC 
                LIMIT 6
            ) ts ON ts.game_id = psg.game_id
        WHERE
            pl.player_id = var_player_id
            AND psg.stat_id NOT IN (8, 9, 14, 15, 18, 19, 20, 21, 22, 23, 27)
        GROUP BY
            psg.stat_id
    ) psg ON psg.stat_id = mr.stat_id
WHERE
    mr.is_weekly = 1
    AND mr.stat_id NOT IN (8, 9, 14, 15, 18, 19, 20, 21, 22, 23, 27)
	AND psg.stat_value > mr.record_value$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_check_yearly_record` (IN `var_player_id` INT)  NO SQL
SELECT
	mr.record_id
	,mr.stat_id
    ,psg.stat_value
    ,mr.record_star_bonus
FROM
	master_record mr
    INNER JOIN (
        SELECT 
                psg.stat_id, SUM(psg.stat_value) AS stat_value 
        FROM
            player pl
            INNER JOIN player_stat_game psg ON psg.player_id = pl.player_id
            INNER JOIN (
                SELECT
                    ts.game_id
                FROM 
                    team_schedule ts
                WHERE
                    ts.season_id = (SELECT season_id FROM player WHERE player_id = var_player_id)
                    AND ts.is_finished = 1
                ORDER BY 
                    ts.game_id DESC 
                LIMIT 162
            ) ts ON ts.game_id = psg.game_id
        WHERE
            pl.player_id = var_player_id
            AND psg.stat_id NOT IN (8, 9, 14, 15, 18, 19, 20, 21, 22, 23, 27)
        GROUP BY
            psg.stat_id
    ) psg ON psg.stat_id = mr.stat_id
WHERE
    mr.is_yearly = 1
    AND mr.stat_id NOT IN (8, 9, 14, 15, 18, 19, 20, 21, 22, 23, 27)
	AND psg.stat_value > mr.record_value$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_contract_interested_teams_sel` (IN `var_season_id` INT, IN `var_team_id` INT)  NO SQL
SELECT mt.team_id FROM master_team mt INNER JOIN player_season ps ON ps.league_id = mt.league_id WHERE ps.season_id = var_season_id AND mt.team_id <> var_team_id ORDER BY RAND() LIMIT 3$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_contract_offers_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	pc.player_id,
    pc.season_id,
    pc.contract_offer AS contract_offer_length,
    mt.team_id AS current_team_id,
    CONCAT(mt.team_city,' ',mt.team_name) AS current_team,
    mt1.team_id AS team_id_one,
    CONCAT(mt1.team_city,' ',mt1.team_name) AS team_one,
    mt2.team_id AS team_id_two,
    CONCAT(mt2.team_city,' ',mt2.team_name) AS team_two,
    mt3.team_id AS team_id_three,
    CONCAT(mt3.team_city,' ',mt3.team_name) AS team_three
FROM
	player pl
    INNER JOIN player_contract_offer pc ON pc.player_id = pl.player_id AND pc.season_id = pl.season_id
    INNER JOIN master_team mt ON mt.team_id = pc.team_id
    INNER JOIN master_team mt1 ON mt1.team_id = pc.interested_team_one
    INNER JOIN master_team mt2 ON mt2.team_id = pc.interested_team_two
    INNER JOIN master_team mt3 ON mt3.team_id = pc.interested_team_three
WHERE
	pl.player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_contract_offer_accept_upd` (IN `var_player_id` INT, IN `var_team_id` INT)  NO SQL
UPDATE player_contract_offer SET accepted_team_id = var_team_id, is_accepted = 1 WHERE player_id = var_player_id AND is_accepted = 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_contract_offer_ins` (IN `var_season_id` INT, IN `var_player_id` INT, IN `var_team_id` INT, IN `var_contract_length` INT, IN `var_team_one` INT, IN `var_team_two` INT, IN `var_team_three` INT)  NO SQL
INSERT INTO player_contract_offer (season_id, player_id, team_id, contract_offer, interested_team_one, interested_team_two, interested_team_three) VALUES(var_season_id, var_player_id, var_team_id, var_contract_length, var_team_one, var_team_two, var_team_three)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_contract_season_upd` (IN `var_player_id` INT)  NO SQL
UPDATE player_contract
SET season_id = (SELECT season_id FROM player WHERE player_id = var_player_id)
WHERE
	player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_contract_subtract` (IN `var_season_id` INT)  NO SQL
UPDATE player_contract SET is_finished = (CASE WHEN (contract_remaining - 1) <= 0 THEN 1 ELSE 0 END), contract_remaining = (CASE WHEN contract_remaining = 0 THEN 0 ELSE (contract_remaining - 1) END) WHERE season_id = var_season_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_create_first_contract` (IN `var_player_id` INT)  NO SQL
INSERT INTO player_contract (player_id, team_id, season_id)
SELECT
	pl.player_id
    ,pl.team_id
    ,pl.season_id
FROM
	player pl
WHERE pl.player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_create_first_stars` (IN `var_player_id` INT)  NO SQL
INSERT INTO player_star (player_id) VALUES(var_player_id)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_create_new_season` (IN `var_player_id` INT)  NO SQL
INSERT INTO player_season (league_id, league_season, team_id, player_id, years_pro) SELECT
	mt.league_id
    ,(CASE WHEN MAX(ps.league_season) IS NULL THEN 1 ELSE MAX(ps.league_season) + 1 END) AS league_season
    ,pl.team_id
    ,pl.player_id
    ,(CASE WHEN MAX(ps.league_season) IS NULL THEN 0 ELSE MAX(ps.league_season) END)
FROM
	player pl
    INNER JOIN master_team mt ON mt.team_id = pl.team_id
    LEFT JOIN player_season ps ON ps.player_id = pl.player_id AND ps.league_id = mt.league_id
WHERE
	pl.player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_default_trait_ins` (IN `var_player_id` INT)  NO SQL
INSERT INTO player_trait (player_id, season_id, trait_id, trait_value)
SELECT
	pl.player_id
    ,pl.season_id
    ,mpt.trait_id
    ,mpt.trait_value
FROM
	player pl
    INNER JOIN master_position_trait mpt ON mpt.position_id = pl.player_position
WHERE
	pl.player_id = var_player_id
    AND pl.is_active = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_email_queue_empty` (IN `var_player_id` INT)  NO SQL
DELETE FROM player_email_queue_game_result WHERE player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_email_queue_game_result_del` (IN `var_game_id` INT)  NO SQL
DELETE FROM player_email_queue_game_result WHERE game_id = var_game_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_email_queue_game_result_ins` (IN `var_player_id` INT, IN `var_game_id` INT, IN `var_is_new_batting_order` INT, IN `var_is_qualified_weekly` INT, IN `var_is_qualified_monthly` INT, IN `var_is_qualified_midseason` INT, IN `var_is_qualified_yearly` INT)  NO SQL
INSERT INTO player_email_queue_game_result(player_id, game_id, is_new_batting_order, is_qualified_weekly, is_qualified_monthly, is_qualified_midseason, is_qualified_yearly) VALUES(var_player_id, var_game_id, var_is_new_batting_order, var_is_qualified_weekly, var_is_qualified_monthly, var_is_qualified_midseason, var_is_qualified_yearly)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_email_queue_game_result_sel` ()  NO SQL
SELECT
	a.ID AS account_id
    ,a.Email AS account_email
   	,ts.game_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,plt.team_city
    ,plt.team_name
    ,ot.team_city AS opponent_team_city
    ,ot.team_name AS opponent_team_name
    ,ts.team_score
    ,ts.opponent_score
    ,ts.innings
    ,ts.game_outcome
    ,ROUND(psg.stat_value, 0) AS stars_earned
    ,ts.is_home
    ,ts.is_postseason
    ,gr.is_new_batting_order
    ,gr.is_qualified_weekly
    ,gr.is_qualified_monthly
    ,gr.is_qualified_midseason
    ,gr.is_qualified_yearly
FROM
	player_email_queue_game_result gr
    INNER JOIN team_schedule ts ON ts.game_id = gr.game_id AND ts.is_finished = 1
    INNER JOIN player pl ON pl.season_id = ts.season_id AND pl.can_email = 1
    INNER JOIN player_season ps ON ps.season_id = pl.season_id
    INNER JOIN master_team plt ON plt.league_id = ps.league_id AND plt.team_id = ps.team_id
    INNER JOIN master_team ot ON ot.league_id = ps.league_id AND ot.team_id = ts.opponent_id
    INNER JOIN player_stat_game psg ON psg.game_id = ts.game_id AND psg.stat_id = 24
    INNER JOIN account a ON a.ID = pl.account_id
ORDER BY
	a.ID ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_game_bonus_ins` (IN `var_player_id` INT, IN `var_game_id` INT, IN `var_bonus_id` INT, IN `var_bonus_value` FLOAT)  NO SQL
INSERT INTO player_game_bonus(player_id, game_id, bonus_id, bonus_value) VALUES(var_player_id, var_game_id, var_bonus_id, var_bonus_value)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_game_bonus_sel` (IN `var_game_id` INT)  NO SQL
SELECT
	mb.bonus_name
    ,mb.bonus_abbr
FROM
	player_game_bonus pgb
    INNER JOIN master_bonus mb ON mb.bonus_id = pgb.bonus_id
WHERE 
	pgb.game_id = var_game_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_game_star_earned_upd` (IN `var_player_id` INT, IN `var_star_earned` INT)  NO SQL
UPDATE player_star SET star_value = (star_value + var_star_earned), star_earned = (star_earned + var_star_earned) WHERE player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_id_by_season_sel` (IN `var_season_id` INT)  NO SQL
SELECT player_id FROM player_season WHERE season_id = var_season_id LIMIT 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_info_season_end_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	a.Email AS account_email
    ,pl.player_firstname
    ,pl.player_lastname
    ,pc.contract_remaining
    ,pl.can_email
FROM
	player pl
    INNER JOIN player_contract pc ON pc.player_id = pl.player_id AND pc.season_id = pl.season_id
    INNER JOIN account a ON a.ID = pl.account_id
WHERE
	pl.player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_info_sel` (IN `var_player_id` INT)  NO SQL
SELECT 
	a.ID AS account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,a.canUnretire AS account_can_unretire
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_abbr
    ,mt.team_id
    ,mt.team_abbr
    ,mt.team_city
    ,mt.team_name
    ,pl.player_age
    ,pl.years_pro
    ,pl.season_id
    ,ps.star_value
    ,an.unread_notifications
    ,pls.playoff_round
    ,pls.is_postseason
    ,pl.is_offseason
    ,pl.is_retired
    ,(SELECT tr.roster_id FROM player_season ps INNER JOIN team_roster tr ON tr.season_id = ps.season_id WHERE ps.player_id = pl.player_id AND tr.is_player = 1 ORDER BY tr.roster_id ASC LIMIT 1) AS face_id
FROM 
	player pl
    INNER JOIN player_season pls ON pls.season_id = pl.season_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    INNER JOIN master_team mt ON mt.team_id = pl.team_id
    LEFT JOIN (
        SELECT 
        	COUNT(notification_id) AS unread_notifications
        	,account_id
        	,player_id
       	FROM 
        	account_notification
       	WHERE
        	is_read = 0
        GROUP BY account_id, player_id
   	) an ON an.account_id = pl.account_id AND an.player_id = pl.player_id
    LEFT JOIN player_star ps ON ps.player_id = pl.player_id
    INNER JOIN account a ON a.ID = pl.account_id
WHERE 
	pl.player_id = var_player_id
    AND pl.is_active = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_ins` (IN `var_account_id` INT, IN `var_player_firstname` VARCHAR(100), IN `var_player_lastname` VARCHAR(100), IN `var_player_position` INT, IN `var_player_team` INT, IN `var_player_years_in_minors` INT)  NO SQL
INSERT INTO player (account_id, player_firstname, player_lastname, player_position, team_id, player_age, years_in_minors)
SELECT
	var_account_id
    ,var_player_firstname
    ,var_player_lastname
    ,(CASE 
      	WHEN var_player_position <= 0 THEN FLOOR(RAND()*(9-2+1))+2 
      	ELSE var_player_position 
      END)
    ,(CASE
      	WHEN var_player_team <= 0 THEN FLOOR(RAND()*(30-1+1))+1 
      	ELSE var_player_team 
      END)
    ,18 + var_player_years_in_minors
    ,var_player_years_in_minors$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_last_created` (IN `var_account_id` INT)  NO SQL
SELECT 
	pl.player_id
FROM
	player pl
WHERE
	pl.account_id = var_account_id
    AND pl.is_active = 1
ORDER BY 
 	pl.create_date DESC
LIMIT 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_league_conference_playoff_race_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	mlc.conference_name
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,ls.wins
    ,ls.losses
    ,ls.playoff_seed
    ,ls.is_wildcard_team
    ,ls.is_division_leader
    ,ls.is_conference_leader
    ,ls.is_world_series_winner
    ,(CASE WHEN ls.team_id = ps.team_id THEN 1 ELSE 0 END) AS is_player_team
FROM
	league_standings ls
    INNER JOIN player pl ON pl.player_id = var_player_id
    INNER JOIN player_season ps ON ps.player_id = pl.player_id AND ps.season_id = pl.season_id
    INNER JOIN master_team pt ON ps.league_id = pt.league_id AND pt.team_id = ps.team_id
    INNER JOIN master_league_conference mlc ON mlc.league_id = ps.league_id AND mlc.conference_id = pt.conference_id
    INNER JOIN master_team mt ON mt.league_id = pt.league_id AND mt.conference_id = mlc.conference_id AND mt.team_id = ls.team_id
WHERE
	ls.season_id = ps.season_id
    AND ls.playoff_seed > 0
ORDER BY
    ls.playoff_seed ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_manage_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	pl.player_firstname
    ,pl.player_lastname
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,mp.position_name
    ,mp.position_abbr
    ,pc.contract_length
    ,pc.contract_remaining
    ,pl.years_pro
    ,ps.star_earned
    ,(SELECT COUNT(pse.player_id) + 1 FROM player_star pse INNER JOIN player ply ON ply.player_id = pse.player_id AND ply.is_active = 1 WHERE pse.star_earned > ps.star_earned) AS star_earned_rank
    ,ps.star_spent
    ,(SELECT COUNT(pss.player_id) + 1 FROM player_star pss INNER JOIN player ply ON ply.player_id = pss.player_id AND ply.is_active = 1 WHERE pss.star_spent > ps.star_spent) AS star_spent_rank
    ,(SELECT COUNT(pse.player_id) + 1 FROM player_star pse INNER JOIN player ply ON ply.player_id = pse.player_id AND ply.is_active = 1 WHERE pse.star_earned > ps.star_earned AND ply.team_id = pl.team_id) AS star_earned_rank_by_team
    ,(SELECT COUNT(pse.player_id) + 1 FROM player_star pse INNER JOIN player ply ON ply.player_id = pse.player_id AND ply.is_active = 1 WHERE pse.star_earned > ps.star_earned AND ply.player_position = pl.player_position) AS star_earned_rank_by_position
    ,nullIF((SELECT COUNT(pr.player_id)
        FROM player_record pr
        WHERE 
        	pr.player_id = pl.player_id
        	AND (SELECT COUNT(npr.record_id) FROM player_record npr WHERE npr.record_id = pr.record_id AND npr.broken_date > pr.broken_date) = 0), 0) AS total_records
    ,pl.can_email
    ,pl.can_sim
    ,pl.is_active
    ,pl.is_retired
FROM
	player pl
    INNER JOIN master_team mt ON mt.team_id = pl.team_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    INNER JOIN player_contract pc ON pc.season_id = pl.season_id
    INNER JOIN player_star ps ON ps.player_id = pl.player_id
WHERE
	pl.player_id = var_player_id
    AND pl.is_active = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_mark_as_inactive` (IN `var_player_id` INT)  NO SQL
UPDATE player SET is_active = 0 WHERE player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_new_contract_sel` (IN `var_player_id` INT)  NO SQL
SELECT 
    (CASE
     	WHEN ROUND(AVG(pss.stat_value), 0) >= 1600 AND pl.player_age <= 30 THEN FLOOR(RAND() * 3) + 1
        WHEN ROUND(AVG(pss.stat_value), 0) >= 1350 AND pl.player_age <= 30 THEN FLOOR(RAND() * 2) + 1
     	WHEN ROUND((SUM(pss.stat_value) / (pc.contract_length * 162)), 0) - ROUND((SELECT AVG(stat_value) FROM player_stat_game WHERE stat_id = 24), 0) > 4 THEN 
     		(CASE 
            	WHEN pl.player_age * (CASE WHEN pl.player_age >= 30 THEN 2 ELSE 1 END) > FLOOR(RAND() * 100) + 1 THEN
                    (CASE
                    	WHEN pl.player_age >= 34 AND FLOOR(RAND() * 100) + 1 >= 35 THEN 0 
                     	ELSE FLOOR(RAND() * 2) + 1 
                    END)
                ELSE 4
            END)
     	WHEN ROUND((SUM(pss.stat_value) / (pc.contract_length * 162)), 0) - ROUND((SELECT AVG(stat_value) FROM player_stat_game WHERE stat_id = 24), 0) BETWEEN 1 AND 4 THEN 
            (CASE
                WHEN pl.player_age * (CASE WHEN pl.player_age >= 30 THEN 2 ELSE 1 END) > FLOOR(RAND() * 100) + 1 THEN
                    (CASE 
                        WHEN pl.player_age >= 34 AND FLOOR(RAND() * 100) + 1 >= 40 THEN 0 
                        ELSE (CASE WHEN pl.player_age <= 34 THEN FLOOR(RAND() * 2) + 1 ELSE 1 END)
                    END)
                ELSE ROUND(((pc.contract_length * 162) / SUM(pss.stat_value)), 0) - ROUND((SELECT AVG(stat_value) FROM player_stat_game WHERE stat_id = 24), 0) 
            END)
     	WHEN ROUND((SUM(pss.stat_value) / (pc.contract_length * 162)), 0) - ROUND((SELECT AVG(stat_value) FROM player_stat_game WHERE stat_id = 24), 0) BETWEEN -3 AND 0 THEN 
            (CASE 
                WHEN pl.player_age >= 27 AND pl.player_age * (CASE WHEN pl.player_age >= 31 THEN 2 ELSE 1 END)-5 > FLOOR(RAND() * 100) + 1 THEN FLOOR(RAND() * 1) + 0  
                ELSE (CASE WHEN pl.player_age <= 34 THEN FLOOR(RAND() * 2) + 1 ELSE 1 END)
            END)
     	ELSE 
            (CASE 
                WHEN pl.player_age * (CASE WHEN pl.player_age >= 30 THEN 2.1 ELSE 1.1 END) > FLOOR(RAND() * 100) + 1 THEN FLOOR(RAND() * 1) + 0
                ELSE FLOOR(RAND() * 2) + 1
            END)
     END) AS contract_length
FROM
	player_contract pc
    INNER JOIN player pl ON pl.player_id = pc.player_id AND pl.season_id = pc.season_id AND pl.is_active = 1
    INNER JOIN player_season ps ON ps.player_id = pl.player_id AND pl.team_id = ps.team_id AND ps.season_id = pl.season_id
    INNER JOIN player_stat_season pss ON pss.player_id = pl.player_id AND pss.season_id = ps.season_id AND pss.stat_id = 24 AND pss.is_postseason = 0
WHERE
	pc.player_id = var_player_id
GROUP BY
	pc.contract_length$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_notification_new` (IN `var_player_id` INT, IN `var_template_id` INT)  NO SQL
INSERT INTO account_notification (account_id, player_id, notification_title, notification_body, notification_link)
SELECT
	(SELECT account_id FROM player WHERE player_id = var_player_id LIMIT 1)
    ,var_player_id
	,template_title
    ,template_body
    ,template_link
FROM
	notification_template
WHERE
	template_id = var_template_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_offseason_upd` (IN `var_season_id` INT)  NO SQL
UPDATE player SET is_offseason = 1 WHERE season_id = var_season_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_owned_by_account` (IN `var_account_id` INT, IN `var_player_id` INT)  NO SQL
SELECT (CASE WHEN account_id = var_account_id THEN true ELSE false END) AS is_owned FROM player WHERE player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_profile_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	pl.account_id
    ,a.username AS account_username
    ,a.isAdmin AS account_is_admin
    ,a.isPremium AS account_is_premium
    ,pl.season_id
    ,(SELECT tr.roster_id FROM player_season ps INNER JOIN team_roster tr ON tr.season_id = ps.season_id WHERE ps.player_id = pl.player_id AND tr.is_player = 1 ORDER BY tr.roster_id ASC LIMIT 1) AS face_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_name
    ,mp.position_abbr
    ,mt.team_id
    ,mt.team_abbr
    ,mt.team_city
    ,mt.team_name
    ,pl.player_age
    ,pl.years_pro AS player_seasons
    ,ps.star_earned
    ,(SELECT COUNT(pse.player_id) + 1 FROM player_star pse INNER JOIN player ply ON ply.player_id = pse.player_id AND ply.is_active = 1 WHERE pse.star_earned > ps.star_earned) AS star_earned_rank
    ,(SELECT COUNT(pse.player_id) + 1 FROM player_star pse INNER JOIN player ply ON ply.player_id = pse.player_id AND ply.is_active = 1 WHERE pse.star_earned > ps.star_earned AND ply.team_id = pl.team_id) AS star_earned_rank_by_team
    ,(SELECT COUNT(pse.player_id) + 1 FROM player_star pse INNER JOIN player ply ON ply.player_id = pse.player_id AND ply.is_active = 1 WHERE pse.star_earned > ps.star_earned AND ply.player_position = pl.player_position) AS star_earned_rank_by_position
    ,(CASE WHEN smvp.season_mvp IS NULL THEN 0 ELSE smvp.season_mvp END) AS season_mvp
    ,(CASE WHEN alls.all_star IS NULL THEN 0 ELSE alls.all_star END) AS all_star
    ,(CASE WHEN pom.player_of_month IS NULL THEN 0 ELSE pom.player_of_month END) AS player_of_month
    ,(CASE WHEN pow.player_of_week IS NULL THEN 0 ELSE pow.player_of_week END) AS player_of_week
    ,(CASE WHEN gmvp.game_mvp IS NULL THEN 0 ELSE gmvp.game_mvp END) AS game_mvp
    ,(CASE WHEN ws.world_series_wins IS NULL THEN 0 ELSE ws.world_series_wins END) AS world_series_wins
    ,nullIF((SELECT COUNT(pr.player_id)
        FROM player_record pr
        WHERE 
        	pr.player_id = pl.player_id
        	AND (SELECT COUNT(npr.record_id) FROM player_record npr WHERE npr.record_id = pr.record_id AND npr.broken_date > pr.broken_date) = 0), 0) AS total_records
    ,pl.is_retired
FROM
	player pl
    INNER JOIN account a ON a.ID = pl.account_id
    INNER JOIN player_star ps ON ps.player_id = pl.player_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    INNER JOIN master_team mt ON mt.team_id = pl.team_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS season_mvp
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 11
       	GROUP BY pa.player_id
   	) smvp ON smvp.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS all_star
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 22
       	GROUP BY pa.player_id
   	) alls ON alls.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS player_of_month
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 16
       	GROUP BY pa.player_id
   	) pom ON pom.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS player_of_week
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 14
       	GROUP BY pa.player_id
   	) pow ON pow.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pa.player_id
        	,COUNT(pa.award_id) AS world_series_wins
       	FROM 
        	player_award pa
       	WHERE
        	pa.award_id = 21
       	GROUP BY pa.player_id
   	) ws ON ws.player_id = pl.player_id
    LEFT JOIN (
        SELECT
        	pgb.player_id
        	,COUNT(pgb.bonus_id) AS game_mvp
       	FROM 
        	player_game_bonus pgb
       	WHERE
        	pgb.bonus_id = 1
       	GROUP BY pgb.player_id
   	) gmvp ON gmvp.player_id = pl.player_id
WHERE
	pl.is_active = 1
    AND pl.player_id = var_player_id
GROUP BY 
	pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,mp.position_name
    ,mp.position_abbr
    ,mt.team_id
    ,mt.team_abbr
    ,mt.team_city
    ,mt.team_name
    ,ps.star_earned
    ,pl.is_retired$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_random_name_sel` ()  NO SQL
SELECT
	(SELECT name AS last_name
        FROM master_player_names
        WHERE is_first_name = 1 AND is_active = 1
        ORDER BY RAND() LIMIT 1
    ) first_name
    ,(SELECT name AS last_name
        FROM master_player_names
        WHERE is_first_name = 0 AND is_active = 1
        ORDER BY RAND() LIMIT 1
    ) last_name$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_record_by_stat_id_sel` (IN `var_stat_id` INT)  NO SQL
SELECT
	a.ID AS account_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pr.record_id
    ,pr.stat_id
    ,mr.record_preface
    ,ms.stat_name
    ,ms.stat_abbr
    ,ms.stat_desc
    ,pr.record_value
    ,mr.is_weekly
    ,mr.is_monthly
    ,mr.is_yearly
    ,mr.is_career
    ,mr.record_star_bonus
    ,pr.broken_date
FROM
	player pl
    INNER JOIN player_record pr ON pr.player_id = pl.player_id
    INNER JOIN player_season ps ON ps.season_id = pr.season_id
    INNER JOIN master_record mr ON mr.record_id = pr.record_id
    INNER JOIN master_stat ms ON ms.stat_id = mr.stat_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
    INNER JOIN account a ON a.ID = pl.account_id
WHERE
	ms.stat_id = var_stat_id
    AND pl.is_active = 1
ORDER BY
    mr.is_weekly DESC
    ,mr.is_monthly DESC
    ,mr.is_yearly DESC
    ,mr.is_career DESC
    ,pr.broken_date DESC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_record_ins` (IN `var_player_id` INT, IN `var_season_id` INT, IN `var_record_id` INT, IN `var_stat_id` INT, IN `var_stat_value` INT)  NO SQL
INSERT INTO player_record(player_id, season_id, record_id, stat_id, record_value, broken_date) VALUES(var_player_id, var_season_id, var_record_id, var_stat_id, var_stat_value, CURRENT_TIMESTAMP)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_record_monthly_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pr.record_id
    ,pr.stat_id
    ,mr.record_preface
    ,ms.stat_name
    ,ms.stat_abbr
    ,ms.stat_desc
    ,pr.record_value
    ,mr.is_weekly
    ,mr.is_monthly
    ,mr.is_yearly
    ,mr.is_career
    ,mr.record_star_bonus
    ,pr.broken_date
    ,(SELECT COUNT(npr.record_id) FROM player_record npr WHERE npr.record_id = pr.record_id AND npr.broken_date > pr.broken_date) AS is_broken
    ,IFNULL((SELECT pl.player_id FROM player_record npr INNER JOIN player pl ON pl.player_id = npr.player_id WHERE npr.record_id = pr.record_id AND npr.broken_date > pr.broken_date ORDER BY npr.broken_date DESC LIMIT 1), 0) as broken_by_player_id
FROM
	player pl
    INNER JOIN player_record pr ON pr.player_id = pl.player_id
    INNER JOIN player_season ps ON ps.season_id = pr.season_id
    INNER JOIN master_record mr ON mr.record_id = pr.record_id
    INNER JOIN master_stat ms ON ms.stat_id = mr.stat_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
WHERE
	pl.player_id = var_player_id
    AND pl.player_id <> IFNULL((SELECT pl.player_id FROM player_record npr INNER JOIN player pl ON pl.player_id = npr.player_id WHERE npr.record_id = pr.record_id AND npr.broken_date > pr.broken_date ORDER BY npr.broken_date DESC LIMIT 1), 0)
    AND mr.is_monthly = 1
ORDER BY
	pr.broken_date DESC
    ,mr.stat_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_record_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pr.record_id
    ,pr.stat_id
    ,mr.record_preface
    ,ms.stat_name
    ,ms.stat_abbr
    ,ms.stat_desc
    ,pr.record_value
    ,mr.is_weekly
    ,mr.is_monthly
    ,mr.is_yearly
    ,mr.is_career
    ,mr.record_star_bonus
    ,pr.broken_date
    ,(SELECT COUNT(npr.record_id) FROM player_record npr WHERE npr.record_id = pr.record_id AND npr.broken_date > pr.broken_date) AS is_broken
    ,IFNULL((SELECT pl.player_id FROM player_record npr INNER JOIN player pl ON pl.player_id = npr.player_id WHERE npr.record_id = pr.record_id AND npr.broken_date > pr.broken_date ORDER BY npr.broken_date DESC LIMIT 1), 0) as broken_by_player_id
FROM
	player pl
    INNER JOIN player_record pr ON pr.player_id = pl.player_id
    INNER JOIN player_season ps ON ps.season_id = pr.season_id
    INNER JOIN master_record mr ON mr.record_id = pr.record_id
    INNER JOIN master_stat ms ON ms.stat_id = mr.stat_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
WHERE
	pl.player_id = var_player_id
    AND pl.player_id <> IFNULL((SELECT pl.player_id FROM player_record npr INNER JOIN player pl ON pl.player_id = npr.player_id WHERE npr.record_id = pr.record_id AND npr.broken_date > pr.broken_date ORDER BY npr.broken_date DESC LIMIT 1), 0)
ORDER BY
	mr.stat_id ASC
    ,pr.broken_date DESC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_record_weekly_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pr.record_id
    ,pr.stat_id
    ,mr.record_preface
    ,ms.stat_name
    ,ms.stat_abbr
    ,ms.stat_desc
    ,pr.record_value
    ,mr.is_weekly
    ,mr.is_monthly
    ,mr.is_yearly
    ,mr.is_career
    ,mr.record_star_bonus
    ,pr.broken_date
    ,(SELECT COUNT(npr.record_id) FROM player_record npr WHERE npr.record_id = pr.record_id AND npr.broken_date > pr.broken_date) AS is_broken
    ,IFNULL((SELECT pl.player_id FROM player_record npr INNER JOIN player pl ON pl.player_id = npr.player_id WHERE npr.record_id = pr.record_id AND npr.broken_date > pr.broken_date ORDER BY npr.broken_date DESC LIMIT 1), 0) as broken_by_player_id
FROM
	player pl
    INNER JOIN player_record pr ON pr.player_id = pl.player_id
    INNER JOIN player_season ps ON ps.season_id = pr.season_id
    INNER JOIN master_record mr ON mr.record_id = pr.record_id
    INNER JOIN master_stat ms ON ms.stat_id = mr.stat_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
WHERE
	pl.player_id = var_player_id
    AND pl.player_id <> IFNULL((SELECT pl.player_id FROM player_record npr INNER JOIN player pl ON pl.player_id = npr.player_id WHERE npr.record_id = pr.record_id AND npr.broken_date > pr.broken_date ORDER BY npr.broken_date DESC LIMIT 1), 0)
    AND mr.is_weekly = 1
ORDER BY
	pr.broken_date DESC
    ,mr.stat_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_record_yearly_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,ps.season_id
    ,pl.player_age - (pl.years_pro - ps.years_pro) AS player_age
    ,ps.years_pro
    ,mt.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,pr.record_id
    ,pr.stat_id
    ,mr.record_preface
    ,ms.stat_name
    ,ms.stat_abbr
    ,ms.stat_desc
    ,pr.record_value
    ,mr.is_weekly
    ,mr.is_monthly
    ,mr.is_yearly
    ,mr.is_career
    ,mr.record_star_bonus
    ,pr.broken_date
    ,(SELECT COUNT(npr.record_id) FROM player_record npr WHERE npr.record_id = pr.record_id AND npr.broken_date > pr.broken_date) AS is_broken
    ,IFNULL((SELECT pl.player_id FROM player_record npr INNER JOIN player pl ON pl.player_id = npr.player_id WHERE npr.record_id = pr.record_id AND npr.broken_date > pr.broken_date ORDER BY npr.broken_date DESC LIMIT 1), 0) as broken_by_player_id
FROM
	player pl
    INNER JOIN player_record pr ON pr.player_id = pl.player_id
    INNER JOIN player_season ps ON ps.season_id = pr.season_id
    INNER JOIN master_record mr ON mr.record_id = pr.record_id
    INNER JOIN master_stat ms ON ms.stat_id = mr.stat_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
WHERE
	pl.player_id = var_player_id
    AND pl.player_id <> IFNULL((SELECT pl.player_id FROM player_record npr INNER JOIN player pl ON pl.player_id = npr.player_id WHERE npr.record_id = pr.record_id AND npr.broken_date > pr.broken_date ORDER BY npr.broken_date DESC LIMIT 1), 0)
    AND mr.is_yearly = 1
ORDER BY
	pr.broken_date DESC
    ,mr.stat_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_retire_upd` (IN `var_player_id` INT)  NO SQL
UPDATE player SET player_age = player_age + 1,years_pro = years_pro + 1,is_retired = 1,can_sim = 0 WHERE player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_schedule_games_sel` (IN `var_player_id` INT, IN `var_is_finished` INT, IN `var_limit` INT, IN `var_offset` INT)  NO SQL
SELECT
	ts.game_id
	,mt.team_abbr AS team
    ,mto.team_abbr AS opponent
    ,ts.game_date
    ,(CASE
      	WHEN ts.is_finished = 0 THEN tbo.batting_order
      	ELSE tgbo.batting_order
      END) AS batting_order
    ,ts.is_home
    ,ts.is_finished
    ,ts.team_score
    ,ts.opponent_score
    ,ts.game_outcome
    ,(CASE WHEN psg.stat_value BETWEEN -0.49 AND 0 THEN 0 ELSE ROUND(psg.stat_value, 0) END) AS star_earned
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_wins ELSE pts.wins END) AS team_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_losses ELSE pts.losses END) AS team_losses
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_wins ELSE ots.wins END) AS opponent_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_losses ELSE ots.losses END) AS opponent_losses
    ,ts.can_sim
    ,ts.is_postseason
FROM
	player pl
	INNER JOIN team_schedule ts ON ts.season_id = pl.season_id
    INNER JOIN master_team mt ON mt.team_id = ts.team_id
    INNER JOIN master_team mto ON mto.team_id = ts.opponent_id
    INNER JOIN league_standings pts ON pts.season_id = pl.season_id AND pts.team_id = pl.team_id
    INNER JOIN league_standings ots ON ots.season_id = pl.season_id AND ots.team_id = ts.opponent_id
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = pl.season_id AND tbo.team_id = pl.team_id
    LEFT JOIN player_stat_game psg ON psg.game_id = ts.game_id AND psg.player_id = pl.player_id AND psg.stat_id = 24
	LEFT JOIN team_game_batting_order tgbo ON tgbo.game_id = ts.game_id AND tgbo.is_owned_player = 1
WHERE
    pl.player_id = var_player_id
	AND pl.is_active = 1
    AND ts.is_finished = var_is_finished
ORDER BY 
	(CASE WHEN ts.is_finished = 1 THEN ts.game_date ELSE 0 END) DESC
	,(CASE WHEN ts.is_finished = 0 THEN ts.game_date ELSE 0 END) ASC
    ,ts.game_date DESC
LIMIT var_limit
OFFSET var_offset$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_season_finish` (IN `var_season_id` INT)  NO SQL
UPDATE player_season SET is_postseason = 0, playoff_round = 0, is_finished = 1 WHERE season_id = var_season_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_season_games_until_upd` (IN `var_season_id` INT, IN `var_until_weekly` INT, IN `var_until_monthly` INT, IN `var_until_midseason` INT, IN `var_until_yearly` INT)  NO SQL
UPDATE player_season SET games_until_weekly = var_until_weekly, games_until_monthly = var_until_monthly, games_until_midseason = var_until_midseason, games_until_yearly = var_until_yearly WHERE season_id = var_season_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_season_set_postseason` (IN `var_season_id` INT, IN `var_playoff_round` INT)  NO SQL
UPDATE player_season 
SET 
	is_postseason = 1
    ,playoff_round = var_playoff_round
WHERE
	season_id = var_season_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_season_stat_default_ins` (IN `var_player_id` INT)  NO SQL
INSERT INTO player_stat_season (player_id, season_id, stat_id, stat_value, is_postseason)
SELECT
	var_player_id AS player_id
    ,(SELECT season_id FROM player WHERE player_id = var_player_id) AS season_id
    ,a.stat_id
    ,a.stat_value
    ,a.is_postseason
FROM
(
    SELECT
        mt.stat_id
        ,0 AS stat_value
        ,0 AS is_postseason
    FROM
        master_stat mt
    
    UNION ALL 
    
    SELECT
        mt.stat_id
        ,0 AS stat_value
        ,1 AS is_postseason
    FROM
        master_stat mt
) a$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_season_wins_losses_upd` (IN `var_season_id` INT, IN `var_team_wins` INT, IN `var_team_losses` INT)  NO SQL
UPDATE player_season SET team_wins = var_team_wins, team_losses = var_team_losses WHERE season_id = var_season_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_standings_team_division_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	mlc.conference_name
    ,mld.division_name
	,ls.team_id
    ,mt.team_city
    ,mt.team_name
    ,ls.wins
    ,ls.losses
    ,ls.playoff_seed
    ,ls.is_wildcard_team
    ,ls.is_division_leader
    ,ls.is_conference_leader
    ,ls.is_world_series_winner
    ,(CASE WHEN ls.team_id = ps.team_id THEN 1 ELSE 0 END) AS is_player_team
FROM
	league_standings ls
    INNER JOIN player_season ps ON ps.player_id = var_player_id AND ps.is_finished = 0
    INNER JOIN player pl ON pl.player_id = var_player_id AND pl.season_id = ps.season_id
    INNER JOIN master_team pt ON ps.league_id = pt.league_id AND pt.team_id = ps.team_id
    INNER JOIN master_league_division mld ON mld.league_id = ls.league_id
    INNER JOIN master_team mt ON mt.league_id = mld.league_id AND mt.division_id = mld.division_id AND mt.team_id = ls.team_id
    INNER JOIN master_league_conference mlc ON mlc.league_id = mld.league_id AND mlc.conference_id = pt.conference_id
WHERE
	ls.season_id = ps.season_id
    AND mld.division_id = pt.division_id
ORDER BY
    ls.wins DESC
    ,ls.playoff_seed ASC
    ,ls.losses ASC
    ,ls.team_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_stars_upd` (IN `var_player_id` INT, IN `var_modify_value` INT)  NO SQL
UPDATE player_star 
SET 
	star_value = (star_value + var_modify_value)
    ,star_spent = (
        CASE 
        	WHEN var_modify_value < 0 THEN (star_spent - var_modify_value)
        	ELSE star_spent
        END)
    ,star_earned = (
        CASE 
        	WHEN var_modify_value > 0 THEN (star_earned + var_modify_value)
        	ELSE star_earned
        END)
WHERE 
	player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_star_sel` (IN `var_player_id` INT)  NO SQL
SELECT ps.star_value FROM player_star ps WHERE ps.player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_star_value_sel` (IN `var_player_id` INT)  NO SQL
SELECT star_value FROM player pl INNER JOIN player_star ps ON ps.player_id = pl.player_id WHERE pl.player_id = var_player_id LIMIT 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_stats_by_career_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	pss.season_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_age
    ,ps.years_pro
    ,pl.player_position
    ,mp.position_name
    ,mp.position_abbr
    ,ps.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,ms.stat_id
    ,ms.stat_abbr
    ,pss.stat_value
    ,pss.is_postseason
    ,ps.is_finished
    ,(162-ps.games_until_yearly) AS games_played
FROM
	player pl
    INNER JOIN player_season ps ON ps.player_id = pl.player_id
    INNER JOIN player_stat_season pss ON pss.season_id = ps.season_id AND pss.player_id = pl.player_id
    INNER JOIN master_stat ms ON ms.stat_id = pss.stat_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
WHERE
	pl.player_id = var_player_id
ORDER BY
	ps.season_id ASC
    ,pss.is_postseason ASC
    ,pss.stat_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_stats_by_current_season_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	pss.season_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_age
    ,ps.years_pro
    ,pl.player_position
    ,mp.position_name
    ,mp.position_abbr
    ,ps.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,ms.stat_id
    ,ms.stat_abbr
    ,pss.stat_value
    ,pss.is_postseason
    ,ps.is_finished
    ,(162-ps.games_until_yearly) AS games_played
FROM
	player pl
    INNER JOIN player_season ps ON ps.player_id = pl.player_id AND ps.season_id = pl.season_id
    INNER JOIN player_stat_season pss ON pss.season_id = ps.season_id AND pss.player_id = pl.player_id
    INNER JOIN master_stat ms ON ms.stat_id = pss.stat_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
WHERE
	pl.player_id = var_player_id
ORDER BY
	ps.season_id ASC
    ,pss.is_postseason ASC
    ,pss.stat_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_stats_by_season_sel` (IN `var_player_id` INT, IN `var_season_id` INT)  NO SQL
SELECT
	pss.season_id
    ,pl.player_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_age
    ,ps.years_pro
    ,pl.player_position
    ,mp.position_name
    ,mp.position_abbr
    ,ps.team_id
    ,mt.team_city
    ,mt.team_name
    ,mt.team_abbr
    ,ms.stat_id
    ,ms.stat_abbr
    ,pss.stat_value
    ,pss.is_postseason
    ,ps.is_finished
    ,(162-ps.games_until_yearly) AS games_played
FROM
	player pl
    INNER JOIN player_season ps ON ps.player_id = pl.player_id
    INNER JOIN player_stat_season pss ON pss.season_id = ps.season_id AND pss.player_id = pl.player_id
    INNER JOIN master_stat ms ON ms.stat_id = pss.stat_id
    INNER JOIN master_team mt ON mt.team_id = ps.team_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
WHERE
	pl.player_id = var_player_id
    AND ps.season_id = var_season_id
ORDER BY
	ps.season_id ASC
    ,pss.is_postseason ASC
    ,pss.stat_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_stat_game_ins` (IN `var_player_id` INT, IN `var_game_id` INT, IN `var_stat_id` INT, IN `var_stat_value` FLOAT)  NO SQL
INSERT INTO player_stat_game(player_id, game_id, stat_id, stat_value) VALUES(var_player_id, var_game_id, var_stat_id, var_stat_value)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_stat_game_sel` (IN `var_game_id` INT)  NO SQL
SELECT
	psg.game_id
    ,ms.stat_id
    ,ms.stat_abbr
    ,(CASE WHEN ms.stat_id = 24 THEN ROUND(psg.stat_value, 0) ELSE psg.stat_value END) AS stat_value
FROM
	player_stat_game psg
    INNER JOIN master_stat ms ON ms.stat_id = psg.stat_id
WHERE
	psg.game_id = var_game_id
ORDER BY
	psg.stat_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_stat_season_award_stars_upd` (IN `var_player_id` INT, IN `var_season_id` INT, IN `var_award_id` INT)  NO SQL
UPDATE player_stat_season 
SET 
	stat_value = (stat_value + (SELECT award_star_bonus FROM master_award WHERE award_id = var_award_id))
WHERE player_id = var_player_id AND season_id = var_season_id AND stat_id = 24 AND is_postseason = 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_stat_season_reset` (IN `var_season_id` INT)  NO SQL
DELETE FROM player_stat_season WHERE season_id = var_season_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_stat_season_stars_upd` (IN `var_player_id` INT, IN `var_season_id` INT, IN `var_stars` INT)  NO SQL
UPDATE player_stat_season
SET stat_value = (stat_value + var_stars)
WHERE player_id = var_player_id AND season_id = var_season_id AND is_postseason = 0 AND stat_id = 24$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_stat_season_upd` (IN `var_season_id` INT)  NO SQL
INSERT INTO player_stat_season
SELECT 
	ps.player_id,
    ps.season_id,
    psg.stat_id,
	(CASE
     	WHEN psg.stat_id = 19 THEN 0
     	WHEN psg.stat_id = 20 THEN 0
     	WHEN psg.stat_id = 21 THEN 0
     	WHEN psg.stat_id = 22 THEN 0
     	WHEN psg.stat_id = 23 THEN 0
     	WHEN psg.stat_id = 27 THEN 0
     	ELSE SUM(psg.stat_value)
    END) AS stat_value,
    ts.is_postseason
FROM
	player_season ps
    INNER JOIN team_schedule ts ON ts.season_id = ps.season_id
    INNER JOIN player_stat_game psg ON psg.game_id = ts.game_id AND psg.player_id = ps.player_id
WHERE
	ps.season_id = var_season_id
GROUP BY
	psg.stat_id,ts.is_postseason$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_stat_season_upd_old` (IN `var_player_id` INT, IN `var_season_id` INT, IN `var_stat_id` INT, IN `var_stat_value` FLOAT, IN `var_is_postseason` INT)  NO SQL
UPDATE player_stat_season SET stat_value = (stat_value + var_stat_value) WHERE player_id = var_player_id AND season_id = var_season_id AND stat_id = var_stat_id AND is_postseason = var_is_postseason$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_team_playoff_seed_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	playoff_seed
FROM
	player pl
	INNER JOIN league_standings ls ON ls.team_id = pl.team_id AND ls.season_id = pl.season_id
WHERE
	pl.player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_team_upd` (IN `var_player_id` INT, IN `var_team_id` INT)  NO SQL
UPDATE player SET team_id = var_team_id WHERE player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_toggle_emails` (IN `var_player_id` INT, IN `var_can_email` INT)  NO SQL
UPDATE player SET can_email = var_can_email WHERE player_id = var_player_id AND is_active = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_toggle_simulation` (IN `var_player_id` INT, IN `var_can_sim` INT)  NO SQL
UPDATE player SET can_sim = var_can_sim WHERE player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_traits_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	mt.trait_id
    ,mt.trait_name
    ,mt.trait_description
    ,mpt.trait_value AS master_trait_value
    ,pt.trait_value AS player_trait_value
    ,(pt.trait_value - mpt.trait_value) AS trait_value_difference
    ,(CASE WHEN pt.original_trait_value > 0 THEN pt.original_trait_value - pt.trait_value ELSE 0 END) AS regression
    ,ROUND((pt.trait_value + ((100 - mpt.trait_value) * ((pt.trait_value - mpt.trait_value) / 2.0))), 0) AS improve_cost
    ,mt.parent_trait_id
    ,mt.has_children
    ,mt.is_advanced
FROM
	master_trait mt
    INNER JOIN player_trait pt ON pt.trait_id = mt.trait_id
    INNER JOIN player pl ON pl.player_id = pt.player_id
    INNER JOIN master_position_trait mpt ON mpt.trait_id = mt.trait_id AND mpt.position_id = pl.player_position
WHERE
	pl.player_id = var_player_id 
    AND pl.is_active = 1
ORDER BY 
	mt.parent_trait_id ASC
    ,mt.trait_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_trait_regression` (IN `var_player_id` INT)  NO SQL
UPDATE player_trait pt
INNER JOIN (SELECT
        b.player_id
        ,b.season_id
        ,b.trait_id
        ,(CASE 
          WHEN b.new_trait_value >= b.original_value THEN b.original_value
          WHEN (b.original_value - b.new_trait_value) / b.original_value >= 0.1 AND ROUND(b.original_value - (b.original_value * 0.1), 0) <= b.new_trait_value THEN ROUND(b.original_value - (b.original_value * 0.1), 0) 
          ELSE b.new_trait_value
        END) AS new_trait_value
    FROM (
        SELECT
            pl.player_id
            ,pl.season_id
            ,pt.trait_id
            ,pt.trait_value - (CASE
                WHEN FLOOR(RAND() * 100) + 0 <= (pl.player_age+10) AND pt.trait_value > mpt.trait_value+1 THEN FLOOR(RAND() * (pt.trait_value-1 - mpt.trait_value+1)) + 0
                ELSE 0
             END) AS new_trait_value
        FROM
            player pl
            INNER JOIN player_trait pt ON pt.player_id = pl.player_id AND pt.season_id = pl.season_id
            INNER JOIN master_position_trait mpt ON mpt.position_id = pl.player_position AND mpt.trait_id = pt.trait_id
        WHERE
            pt.player_id = var_player_id
    ) b) a ON a.player_id = pt.player_id AND a.season_id = pt.season_id AND a.trait_id = pt.trait_id
SET
     pt.player_id = a.player_id
     ,pt.season_id = a.season_id
     ,pt.original_trait_value = pt.trait_value
     ,pt.trait_value = a.new_trait_value
WHERE pt.season_id = (SELECT season_id FROM player WHERE player_id = var_player_id LIMIT 1)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_trait_season_upd` (IN `var_player_id` INT)  NO SQL
UPDATE player_trait SET season_id = (SELECT season_id FROM player WHERE player_id = var_player_id LIMIT 1) WHERE player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_trait_upd` (IN `var_player_id` INT, IN `var_season_id` INT, IN `var_trait_id` INT, IN `var_trait_value` INT)  NO SQL
UPDATE player_trait 
SET trait_value = var_trait_value 
WHERE 
	player_id = var_player_id 
    AND season_id = var_season_id 
    AND trait_id = var_trait_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_unretire_renew_season_upd` (IN `var_player_id` INT)  NO SQL
UPDATE player_contract
SET 
	season_id = (SELECT season_id FROM player WHERE player_id = var_player_id)
    ,contract_length = 1
    ,contract_remaining = 1
    ,is_finished = 0
WHERE
	player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_unretire_upd` (IN `var_player_id` INT)  NO SQL
UPDATE player SET is_retired = 0 WHERE is_retired = 1 AND player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_update_season` (IN `var_player_id` INT)  NO SQL
UPDATE
	player pl
    INNER JOIN master_team mt ON mt.team_id = pl.team_id
    INNER JOIN (SELECT player_id, league_id, season_id FROM player_season ORDER BY create_date DESC LIMIT 1) ps ON ps.league_id = mt.league_id AND ps.player_id = ps.player_id
SET pl.season_id = ps.season_id
WHERE 
	pl.player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `player_welcome_message` (IN `var_player_id` INT)  NO SQL
SELECT
	pl.player_firstname
    ,pl.player_lastname
    ,pl.player_age
    ,pl.years_in_minors
    ,mt.team_city
    ,mt.team_name
    ,mp.position_abbr
    ,tbo.batting_order
    ,pc.contract_length
    ,ts.game_date AS next_game
    ,(SELECT first_game_hour FROM master_settings LIMIT 1) AS first_game_hour
    ,(SELECT second_game_hour FROM master_settings LIMIT 1) AS second_game_hour
    ,(SELECT third_game_hour FROM master_settings LIMIT 1) AS third_game_hour
    ,(SELECT fourth_game_hour FROM master_settings LIMIT 1) AS fourth_game_hour
    ,(SELECT fifth_game_hour FROM master_settings LIMIT 1) AS fifth_game_hour
    ,(SELECT sixth_game_hour FROM master_settings LIMIT 1) AS sixth_game_hour
FROM
	player pl
    INNER JOIN master_team mt ON mt.team_id = pl.team_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position
    INNER JOIN player_contract pc ON pc.player_id = pl.player_id AND pc.season_id = pl.season_id
    INNER JOIN team_schedule ts ON ts.season_id = pl.season_id AND ts.team_id = pl.team_id AND ts.is_finished = 0
    INNER JOIN team_batting_order tbo ON tbo.team_id = pl.team_id AND tbo.season_id = pl.season_id AND tbo.player_id = pl.player_id
WHERE
	pl.player_id = var_player_id
ORDER BY ts.game_date ASC
LIMIT 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `random_first_names_sel` (IN `var_limit` INT)  NO SQL
SELECT name AS first_name
FROM master_player_names
WHERE is_first_name = 1 AND is_active = 1
ORDER BY RAND() LIMIT var_limit$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `random_last_names_sel` (IN `var_limit` INT)  NO SQL
SELECT name AS last_name
FROM master_player_names
WHERE is_first_name = 0 AND is_active = 1
ORDER BY RAND() LIMIT var_limit$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sim_games_fail_safe_sel` ()  NO SQL
SELECT
	pl.account_id
    ,a.Email
    ,ts.season_id
    ,mt.conference_id
    ,pl.player_id
	,ts.game_id
    ,ts.team_id
    ,ts.opponent_id
    ,ts.is_home
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_position
    ,mp.position_name
    ,tbo.batting_order
    ,ps.team_wins
    ,ps.team_losses
    ,(SELECT ls_o.wins FROM league_standings ls_o WHERE ls_o.season_id = ps.season_id AND ls_o.team_id = ts.opponent_id AND ls.league_id = ps.league_id LIMIT 1) AS opponent_wins
    ,(SELECT ls_o.losses FROM league_standings ls_o WHERE ls_o.season_id = ps.season_id AND ls_o.team_id = ts.opponent_id AND ls.league_id = ps.league_id LIMIT 1) AS opponent_losses
    ,tbo.games_until_new
    ,ps.games_until_weekly
    ,ps.games_until_monthly
    ,ps.games_until_midseason
    ,ps.games_until_yearly
    ,ts.is_postseason
    ,ps.playoff_round
    ,ls.playoff_seed
    ,lps.home_team_wins AS playoff_home_wins
    ,lps.visit_team_wins AS playoff_visit_wins
    ,pl.can_email
FROM
	team_schedule ts
    INNER JOIN player pl ON pl.season_id = ts.season_id AND pl.can_sim = 1 AND pl.is_active = 1 AND pl.is_retired = 0 AND pl.is_offseason = 0 AND pl.is_retired = 0
    INNER JOIN account a ON a.ID = pl.account_id AND a.IsActive = 1
    INNER JOIN player_season ps ON ps.season_id = pl.season_id AND ps.season_id = ts.season_id AND ps.is_finished = 0
    INNER JOIN league_standings ls ON ls.season_id = ps.season_id AND ls.team_id = pl.team_id AND ls.league_id = 1
    LEFT JOIN league_playoff_schedule lps ON lps.season_id = ps.season_id AND ps.team_id IN (lps.home_team_id, lps.visit_team_id) AND lps.round = ps.playoff_round AND lps.is_finished = 0
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = ts.season_id AND tbo.team_id = pl.team_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position AND mp.is_active = 1
    INNER JOIN master_team mt ON mt.team_id = ps.team_id AND mt.league_id = ps.league_id AND mt.is_active = 1
WHERE
	ts.is_finished = 0
    AND ts.can_sim = 1
    AND DATE(ts.game_date) = DATE(NOW())
    AND HOUR(ts.game_date) = (CASE
      	WHEN HOUR(NOW()) = 9 THEN 8
      	WHEN HOUR(NOW()) = 12 THEN 11
      	WHEN HOUR(NOW()) = 15 THEN 14
      	WHEN HOUR(NOW()) = 18 THEN 17
      	WHEN HOUR(NOW()) = 21 THEN 20
     END)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sim_games_fail_safe_test_sel` ()  NO SQL
SELECT
	pl.account_id
    ,a.Email
    ,ts.season_id
    ,mt.conference_id
    ,pl.player_id
	,ts.game_id
    ,ts.team_id
    ,ts.opponent_id
    ,ts.is_home
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_position
    ,mp.position_name
    ,tbo.batting_order
    ,ps.team_wins
    ,ps.team_losses
    ,(SELECT ls_o.wins FROM league_standings ls_o WHERE ls_o.season_id = ps.season_id AND ls_o.team_id = ts.opponent_id AND ls.league_id = ps.league_id LIMIT 1) AS opponent_wins
    ,(SELECT ls_o.losses FROM league_standings ls_o WHERE ls_o.season_id = ps.season_id AND ls_o.team_id = ts.opponent_id AND ls.league_id = ps.league_id LIMIT 1) AS opponent_losses
    ,tbo.games_until_new
    ,ps.games_until_weekly
    ,ps.games_until_monthly
    ,ps.games_until_midseason
    ,ps.games_until_yearly
    ,ts.is_postseason
    ,ps.playoff_round
    ,ls.playoff_seed
    ,lps.home_team_wins AS playoff_home_wins
    ,lps.visit_team_wins AS playoff_visit_wins
    ,pl.can_email
FROM
	team_schedule ts
    INNER JOIN player pl ON pl.season_id = ts.season_id AND pl.can_sim = 1 AND pl.is_active = 1 AND pl.is_retired = 0 AND pl.is_offseason = 0 AND pl.is_retired = 0
    INNER JOIN account a ON a.ID = pl.account_id AND a.IsActive = 1
    INNER JOIN player_season ps ON ps.season_id = pl.season_id AND ps.season_id = ts.season_id AND ps.is_finished = 0
    INNER JOIN league_standings ls ON ls.season_id = ps.season_id AND ls.team_id = pl.team_id AND ls.league_id = 1
    LEFT JOIN league_playoff_schedule lps ON lps.season_id = ps.season_id AND ps.team_id IN (lps.home_team_id, lps.visit_team_id) AND lps.round = ps.playoff_round AND lps.is_finished = 0
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = ts.season_id AND tbo.team_id = pl.team_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position AND mp.is_active = 1
    INNER JOIN master_team mt ON mt.team_id = ps.team_id AND mt.league_id = ps.league_id AND mt.is_active = 1
WHERE
	ts.is_finished = 0
    AND ts.can_sim = 1
    AND DATE(ts.game_date) = DATE(NOW())
    AND HOUR(ts.game_date) = (CASE
      	WHEN HOUR(NOW()) = 9 THEN 8
      	WHEN HOUR(NOW()) = 12 THEN 11
      	WHEN HOUR(NOW()) = 15 THEN 14
      	WHEN HOUR(NOW()) = 18 THEN 17
      	WHEN HOUR(NOW()) = 21 THEN 20
     END)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sim_games_player_traits_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	mt.trait_id
    ,pt.trait_value as player_trait,mpt.trait_value as original
    ,(CASE 
      WHEN mt.trait_id = 1 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 2 AND pl.player_age <= 25 THEN ROUND((pt.trait_value + mpt.trait_value) / 2, 0)
      WHEN mt.trait_id = 1 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 2 AND pl.player_age >= 26 AND pl.player_age < 30 THEN ROUND((pt.trait_value + mpt.trait_value) / 2.5, 0)
      WHEN mt.trait_id = 1 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 2 AND pl.player_age >= 30 THEN ROUND((pt.trait_value + mpt.trait_value) / 3.5, 0)
      WHEN mt.trait_id = 8 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 1 THEN pt.trait_value + 1
      WHEN mt.trait_id = 8 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 1 AND pl.player_age >= 26 AND pl.player_age < 30 THEN pt.trait_value - 2
      WHEN mt.trait_id = 8 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 1 AND pl.player_age >= 30 THEN pt.trait_value - 3
      WHEN mt.trait_id = 9 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 1 AND pl.player_age <= 25 THEN pt.trait_value + 1
      WHEN mt.trait_id = 9 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 1 AND pl.player_age >= 26 AND pl.player_age < 30 THEN pt.trait_value - 2
      WHEN mt.trait_id = 9 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 1 AND pl.player_age >= 30 THEN pt.trait_value - 3
      WHEN mt.trait_id IN (2, 3, 4, 5, 6, 7) AND pl.player_age >= 26 AND pl.player_age < 30 THEN ROUND((pt.trait_value + mpt.trait_value) / 2.25, 0)
      WHEN mt.trait_id IN (2, 3, 4, 5, 6, 7) AND pl.player_age > 30 THEN ROUND((pt.trait_value + mpt.trait_value) / 2.5, 0)
      ELSE ROUND((pt.trait_value + mpt.trait_value) / 2, 0)
    END) AS trait_value
    ,(CASE 
      WHEN mt.trait_id = 1 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 2 AND pl.player_age <= 25 THEN (ROUND((pt.trait_value + mpt.trait_value) / 2, 0) - mpt.trait_value)
      WHEN mt.trait_id = 1 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 2 AND pl.player_age >= 26 AND pl.player_age < 30 THEN (ROUND((pt.trait_value + mpt.trait_value) / 2.5, 0) - mpt.trait_value)
      WHEN mt.trait_id = 1 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 2 AND pl.player_age >= 30 THEN (ROUND((pt.trait_value + mpt.trait_value) / 3.5, 0) - mpt.trait_value)
      WHEN mt.trait_id = 8 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 1 AND pl.player_age <= 25 THEN ((pt.trait_value + 1) - mpt.trait_value)
      WHEN mt.trait_id = 8 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 1 AND pl.player_age >= 26 AND pl.player_age < 30 THEN ((pt.trait_value - 2) - mpt.trait_value)
      WHEN mt.trait_id = 8 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 1 AND pl.player_age >= 30 THEN ((pt.trait_value - 3) - mpt.trait_value)
      WHEN mt.trait_id = 9 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 1 AND pl.player_age <= 25 THEN ((pt.trait_value + 1) - mpt.trait_value)
      WHEN mt.trait_id = 9 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 1 AND pl.player_age >= 26 AND pl.player_age < 30 THEN ((pt.trait_value - 2) - mpt.trait_value)
      WHEN mt.trait_id = 9 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 1 AND pl.player_age >= 30 THEN ((pt.trait_value - 3) - mpt.trait_value)
      WHEN mt.trait_id IN (2, 3, 4, 5, 6, 7) AND pl.player_age >= 26 AND pl.player_age < 30 THEN (ROUND((pt.trait_value + mpt.trait_value) / 2.25, 0) - mpt.trait_value)
      WHEN mt.trait_id IN (2, 3, 4, 5, 6, 7) AND pl.player_age > 30 THEN (ROUND((pt.trait_value + mpt.trait_value) / 2.5, 0) - mpt.trait_value)
      ELSE (ROUND((pt.trait_value + mpt.trait_value) / 2, 0) - mpt.trait_value)
    END) AS master_trait_difference
    ,pl.years_pro
    ,pl.player_age
FROM
	master_trait mt
    INNER JOIN player_trait pt ON pt.trait_id = mt.trait_id
    INNER JOIN player pl ON pl.player_id = pt.player_id
    INNER JOIN master_position_trait mpt ON mpt.trait_id = mt.trait_id AND mpt.position_id = pl.player_position
WHERE
	pl.player_id = var_player_id 
    AND pl.is_active = 1
ORDER BY 
	mt.parent_trait_id ASC
    ,mt.trait_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sim_games_player_traits_sel_old` (IN `var_player_id` INT)  NO SQL
SELECT
	mt.trait_id
    ,(CASE 
      WHEN mt.trait_id = 1 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 2 THEN ROUND((pt.trait_value + mpt.trait_value) / 2, 0)
      WHEN mt.trait_id = 8 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 1 THEN pt.trait_value + 1
      WHEN mt.trait_id = 9 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 1 THEN pt.trait_value + 1
      ELSE ROUND((pt.trait_value + mpt.trait_value) / 2, 0)
    END) AS trait_value
    ,(CASE 
      WHEN mt.trait_id = 1 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 2 THEN (ROUND((pt.trait_value + mpt.trait_value) / 2, 0) - mpt.trait_value)
      WHEN mt.trait_id = 8 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 1 THEN ((pt.trait_value + 1) - mpt.trait_value)
      WHEN mt.trait_id = 9 AND pt.trait_value > 0 AND (pt.trait_value - mpt.trait_value) > 1 THEN ((pt.trait_value + 1) - mpt.trait_value)
      ELSE (ROUND((pt.trait_value + mpt.trait_value) / 2, 0) - mpt.trait_value)
    END) AS master_trait_difference
    ,pl.years_pro
    ,pl.player_age
FROM
	master_trait mt
    INNER JOIN player_trait pt ON pt.trait_id = mt.trait_id
    INNER JOIN player pl ON pl.player_id = pt.player_id
    INNER JOIN master_position_trait mpt ON mpt.trait_id = mt.trait_id AND mpt.position_id = pl.player_position
WHERE
	pl.player_id = var_player_id 
    AND pl.is_active = 1
ORDER BY 
	mt.parent_trait_id ASC
    ,mt.trait_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sim_games_sel` ()  NO SQL
SELECT
	pl.account_id
    ,a.Email
    ,ts.season_id
    ,mt.conference_id
    ,pl.player_id
	,ts.game_id
    ,ts.team_id
    ,ts.opponent_id
    ,ts.is_home
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_position
    ,mp.position_name
    ,tbo.batting_order
    ,ps.team_wins
    ,ps.team_losses
    ,(SELECT ls_o.wins FROM league_standings ls_o WHERE ls_o.season_id = ps.season_id AND ls_o.team_id = ts.opponent_id AND ls.league_id = ps.league_id LIMIT 1) AS opponent_wins
    ,(SELECT ls_o.losses FROM league_standings ls_o WHERE ls_o.season_id = ps.season_id AND ls_o.team_id = ts.opponent_id AND ls.league_id = ps.league_id LIMIT 1) AS opponent_losses
    ,tbo.games_until_new
    ,ps.games_until_weekly
    ,ps.games_until_monthly
    ,ps.games_until_midseason
    ,ps.games_until_yearly
    ,ts.is_postseason
    ,ps.playoff_round
    ,ls.playoff_seed
    ,lps.home_team_wins AS playoff_home_wins
    ,lps.visit_team_wins AS playoff_visit_wins
    ,pl.can_email
FROM
	team_schedule ts
    INNER JOIN player pl ON pl.season_id = ts.season_id AND pl.can_sim = 1 AND pl.is_active = 1 AND pl.is_retired = 0 AND pl.is_offseason = 0 AND pl.is_retired = 0
    INNER JOIN account a ON a.ID = pl.account_id AND a.IsActive = 1
    INNER JOIN player_season ps ON ps.season_id = pl.season_id AND ps.season_id = ts.season_id AND ps.is_finished = 0
    INNER JOIN league_standings ls ON ls.season_id = ps.season_id AND ls.team_id = pl.team_id AND ls.league_id = 1
    LEFT JOIN league_playoff_schedule lps ON lps.season_id = ps.season_id AND ps.team_id IN (lps.home_team_id, lps.visit_team_id) AND lps.round = ps.playoff_round AND lps.is_finished = 0
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = ts.season_id AND tbo.team_id = pl.team_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position AND mp.is_active = 1
    INNER JOIN master_team mt ON mt.team_id = ps.team_id AND mt.league_id = ps.league_id AND mt.is_active = 1
WHERE
	ts.is_finished = 0
    AND ts.can_sim = 1
    AND DATE(ts.game_date) = DATE(NOW())
    AND HOUR(ts.game_date) = (CASE
      	WHEN HOUR(NOW()) <= 8 THEN 8
      	WHEN HOUR(NOW()) > 8 AND HOUR(NOW()) <= 11 THEN 11
      	WHEN HOUR(NOW()) > 11 AND HOUR(NOW()) <= 14 THEN 14
      	WHEN HOUR(NOW()) > 14 AND HOUR(NOW()) <= 17 THEN 17
      	WHEN HOUR(NOW()) > 17 AND HOUR(NOW()) <= 20 THEN 20
      	WHEN HOUR(NOW()) > 20 THEN 23
     END)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sim_games_sel_test` ()  NO SQL
SELECT
	pl.account_id
    ,a.Email
    ,ts.season_id
    ,mt.conference_id
    ,pl.player_id
	,ts.game_id
    ,ts.team_id
    ,ts.opponent_id
    ,ts.is_home
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_position
    ,mp.position_name
    ,tbo.batting_order
    ,ps.team_wins
    ,ps.team_losses
    ,(SELECT ls_o.wins FROM league_standings ls_o WHERE ls_o.season_id = ps.season_id AND ls_o.team_id = ts.opponent_id AND ls.league_id = ps.league_id LIMIT 1) AS opponent_wins
    ,(SELECT ls_o.losses FROM league_standings ls_o WHERE ls_o.season_id = ps.season_id AND ls_o.team_id = ts.opponent_id AND ls.league_id = ps.league_id LIMIT 1) AS opponent_losses
    ,tbo.games_until_new
    ,ps.games_until_weekly
    ,ps.games_until_monthly
    ,ps.games_until_midseason
    ,ps.games_until_yearly
    ,ts.is_postseason
    ,ps.playoff_round
    ,ls.playoff_seed
    ,lps.home_team_wins AS playoff_home_wins
    ,lps.visit_team_wins AS playoff_visit_wins
    ,pl.can_email
FROM
	team_schedule ts
    INNER JOIN player pl ON pl.season_id = ts.season_id AND pl.can_sim = 1 AND pl.is_active = 1 AND pl.is_retired = 0 AND pl.is_offseason = 0 AND pl.is_retired = 0
    INNER JOIN account a ON a.ID = pl.account_id AND a.IsActive = 1
    INNER JOIN player_season ps ON ps.season_id = pl.season_id AND ps.season_id = ts.season_id AND ps.is_finished = 0
    INNER JOIN league_standings ls ON ls.season_id = ps.season_id AND ls.team_id = pl.team_id AND ls.league_id = 1
    LEFT JOIN league_playoff_schedule lps ON lps.season_id = ps.season_id AND ps.team_id IN (lps.home_team_id, lps.visit_team_id) AND lps.round = ps.playoff_round AND lps.is_finished = 0
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = ts.season_id AND tbo.team_id = pl.team_id
    INNER JOIN master_position mp ON mp.position_id = pl.player_position AND mp.is_active = 1
    INNER JOIN master_team mt ON mt.team_id = ps.team_id AND mt.league_id = ps.league_id AND mt.is_active = 1
WHERE
	ts.is_finished = 0
    AND ts.can_sim = 1
    AND DATE(ts.game_date) = DATE(NOW())
    AND HOUR(ts.game_date) = (CASE
      	WHEN HOUR(NOW()) <= 8 THEN 8
      	WHEN HOUR(NOW()) > 8 AND HOUR(NOW()) <= 11 THEN 11
      	WHEN HOUR(NOW()) > 11 AND HOUR(NOW()) <= 14 THEN 14
      	WHEN HOUR(NOW()) > 14 AND HOUR(NOW()) <= 17 THEN 17
      	WHEN HOUR(NOW()) > 17 AND HOUR(NOW()) <= 20 THEN 20
      	WHEN HOUR(NOW()) > 20 THEN 23
     END)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_batting_order_first_ins` (IN `var_player_id` INT)  NO SQL
INSERT INTO team_batting_order (team_id, season_id, player_id, batting_order)
SELECT
	pl.team_id
    ,pl.season_id
    ,pl.player_id
    ,FLOOR(RAND()*(8-6+1))+6 AS batting_order
FROM
	player pl
WHERE
	pl.player_id = var_player_id
    AND pl.is_active = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_batting_order_new_season_ins` (IN `var_player_id` INT)  NO SQL
INSERT INTO team_batting_order (team_id, season_id, player_id, batting_order)
SELECT
	pl.team_id
    ,pl.season_id
    ,pl.player_id
    ,IFNULL((SELECT b.batting_order FROM team_batting_order b WHERE b.player_id = pl.player_id ORDER BY b.season_id DESC LIMIT 1), FLOOR(RAND()*(8-6+1))+6) AS batting_order
FROM
	player pl
WHERE
	pl.player_id = var_player_id
    AND pl.is_active = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_batting_order_new_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	ABS((
        (CASE
            WHEN ifNull(a.woba, 0) >= 0.445 THEN 8
            WHEN ifNull(a.woba, 0) >= 0.430 THEN 7
            WHEN ifNull(a.woba, 0) >= 0.415 THEN 6
            WHEN ifNull(a.woba, 0) >= 0.405 THEN 5
            WHEN ifNull(a.woba, 0) >= 0.390 THEN 4
            WHEN ifNull(a.woba, 0) >= 0.375 THEN 3
            WHEN ifNull(a.woba, 0) >= 0.355 THEN 2
            WHEN ifNull(a.woba, 0) >= 0.330 AND ifNull(c.batting_order, 8) >= 6 THEN 2
            WHEN ifNull(a.woba, 0) >= 0.330 AND ifNull(c.batting_order, 8) <= 5 THEN 0
            WHEN ifNull(a.woba, 0) <= 0.270 THEN -8
            WHEN ifNull(a.woba, 0) <= 0.280 THEN -7
            WHEN ifNull(a.woba, 0) <= 0.290 THEN -6
            WHEN ifNull(a.woba, 0) <= 0.295 THEN -5
            WHEN ifNull(a.woba, 0) <= 0.300 THEN -4
            WHEN ifNull(a.woba, 0) <= 0.310 THEN -3
            WHEN ifNull(a.woba, 0) <= 0.320 THEN -2
            WHEN ifNull(a.woba, 0) < 0.330 AND ifNull(c.batting_order, 8) <= 2 THEN -4
            WHEN ifNull(a.woba, 0) < 0.330 AND ifNull(c.batting_order, 8) <= 4 THEN -2
            ELSE 0
     	END)
    )) AS order_change
    ,(CASE
        WHEN ifNull(a.woba, 0) >= 0.355 THEN 'up'
        WHEN ifNull(a.woba, 0) <= 0.320 THEN 'down'
      	WHEN ifNull(a.woba, 0) >= 0.330 AND ifNull(c.batting_order, 8) >= 6 THEN 'up'
      	WHEN ifNull(a.woba, 0) < 0.330 AND ifNull(c.batting_order, 8) <= 4 THEN 'down'
      	ELSE 'same'
    END) AS change_direction
    ,ifNull(a.woba, 0) AS avg_woba
    ,ifNull(b.slg, 0) AS avg_slg
    ,(CASE WHEN ifNull(b.slg, 0) >= 0.475 THEN 1 ELSE 0 END) AS power_override
FROM  
	player pl
    INNER JOIN (SELECT player_id, ROUND(AVG(z.stat_value), 3) AS woba FROM (SELECT player_id, stat_value FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) z GROUP BY z.player_id) a ON a.player_id = pl.player_id
    INNER JOIN (SELECT player_id, ROUND(AVG(z.stat_value), 3) AS slg FROM (SELECT player_id, stat_value FROM player_stat_game WHERE stat_id = 20 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) z GROUP BY z.player_id) b ON b.player_id = pl.player_id
    INNER JOIN (SELECT season_id, batting_order FROM team_batting_order where player_id = var_player_id ORDER BY season_id DESC LIMIT 1) c ON c.season_id = pl.season_id
WHERE
	pl.player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_batting_order_new_sel_deprecated` (IN `var_player_id` INT)  NO SQL
SELECT
	ABS((
        (CASE
            WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) >= 8 THEN 8
            WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) = 7 THEN 7
            WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) = 6 THEN 6
            WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) = 5 THEN 5
            WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) = 4 THEN 4
            WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) = 3 THEN 3
            WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) = 2 THEN 2
            WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) = 1 THEN 1
            WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) = 0 THEN 0
            WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) = -1 THEN -1
            WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) = -2 THEN -2
            WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) = -3 THEN -3
            WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) = -4 THEN -4
            WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) = -5 THEN -5
            WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) = -6 THEN -6
            WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) = -7 THEN -7
            WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) <= -8 THEN -8
     	END)
    )) AS order_change
    ,(CASE
        WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) >= 1 THEN 'up'
        WHEN (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) - (SELECT ROUND(AVG(stat_value), 0) FROM player_stat_game WHERE stat_id = 24) <= -1 THEN 'down'
      	ELSE 'same'
    END) AS change_direction
    ,(SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 20 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) AS avg_slg
    ,(SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 27 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) AS avg_ops$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_batting_order_new_sel_deprecated_newer` (IN `var_player_id` INT)  NO SQL
SELECT
	ABS((
        (CASE
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) >= 0.430 THEN 8
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) >= 0.415 THEN 7
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) >= 0.400 THEN 6
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) >= 0.485 THEN 5
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) >= 0.370 THEN 4
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) >= 0.355 THEN 3
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) >= 0.340 THEN 2
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) >= 0.320 AND (SELECT batting_order FROM team_batting_order where player_id = var_player_id ORDER BY season_id DESC LIMIT 1) >= 6 THEN 2
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) >= 0.320 AND (SELECT batting_order FROM team_batting_order where player_id = var_player_id ORDER BY season_id DESC LIMIT 1) <= 5 THEN 0
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) <= 0.270 THEN -8
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) <= 0.280 THEN -7
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) <= 0.290 THEN -6
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) <= 0.295 THEN -5
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) <= 0.300 THEN -4
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) <= 0.305 THEN -3
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) <= 0.310 THEN -2
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) < 0.320 AND (SELECT batting_order FROM team_batting_order where player_id = var_player_id ORDER BY season_id DESC LIMIT 1) <= 2 THEN -4
            WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) < 0.320 AND (SELECT batting_order FROM team_batting_order where player_id = var_player_id ORDER BY season_id DESC LIMIT 1) <= 4 THEN -2
            ELSE 0
     	END)
    )) AS order_change
    ,(CASE
        WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) >= 0.340 THEN 'up'
        WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) <= 0.310 THEN 'down'
      	WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) >= 0.320 AND (SELECT batting_order FROM team_batting_order where player_id = var_player_id ORDER BY season_id DESC LIMIT 1) >= 6 THEN 'up'
      	WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) < 0.320 AND (SELECT batting_order FROM team_batting_order where player_id = var_player_id ORDER BY season_id DESC LIMIT 1) <= 4 THEN 'down'
      	ELSE 'same'
    END) AS change_direction
    ,(SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 23 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) AS avg_woba
    ,(SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 20 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) AS avg_slg
    ,(CASE WHEN (SELECT ROUND(AVG(stat_value), 3) FROM player_stat_game WHERE stat_id = 20 AND player_id = var_player_id ORDER BY game_id DESC LIMIT 12) >= 0.475 THEN 1 ELSE 0 END) AS power_override$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_batting_order_upd` (IN `var_season_id` INT, IN `var_until_new_order` INT, IN `var_batting_order` INT)  NO SQL
UPDATE team_batting_order
SET
	batting_order = var_batting_order
    ,games_until_new = var_until_new_order
WHERE
	season_id = var_season_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_game_batting_order_ins` (IN `var_game_id` INT, IN `var_team_id` INT, IN `var_batting_order` INT, IN `var_position_id` INT, IN `var_is_owned_player` INT, IN `var_is_designated_hitter` INT)  NO SQL
INSERT INTO team_game_batting_order (game_id, team_id, batting_order, roster_id, position_id, is_owned_player, is_designated_hitter) VALUES
	(var_game_id, var_team_id, var_batting_order, (SELECT tr.roster_id FROM team_schedule ts INNER JOIN team_roster tr ON tr.season_id = ts.season_id AND tr.team_id = ts.team_id WHERE ts.game_id = var_game_id AND tr.position_id = var_position_id AND tr.is_player = var_is_owned_player LIMIT 1), var_position_id, var_is_owned_player, var_is_designated_hitter)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_game_opponent_half_inning_ins` (IN `var_game_id` INT, IN `var_opponent_team_id` INT, IN `var_game_inning` INT, IN `var_game_half_inning` VARCHAR(1), IN `var_opponent_start_runs` INT, IN `var_opponent_runs_scored` INT, IN `var_opponent_end_runs` INT)  NO SQL
INSERT IGNORE INTO team_game_opponent_half_inning(game_id, opponent_team_id, game_inning, game_half_inning, opponent_start_runs, opponent_runs_scored, opponent_end_runs) VALUES(var_game_id, var_opponent_team_id, var_game_inning, var_game_half_inning, var_opponent_start_runs, var_opponent_runs_scored, var_opponent_end_runs)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_game_plate_appearance_ins` (IN `var_game_id` INT, IN `var_team_id` INT, IN `var_position_id` INT, IN `var_stat_id` INT, IN `var_stat_value` INT, IN `var_is_out_sac_fly` INT, IN `var_is_out_sac_hit` INT, IN `var_is_out_double_play` INT, IN `var_is_sb_attempt` INT, IN `var_is_sb_succeed` INT, IN `var_sb_position` INT, IN `var_sb_base` VARCHAR(20), IN `var_is_player_sb` INT, IN `var_is_walkoff` INT, IN `var_runs` INT, IN `var_runs_batted_in` INT, IN `var_left_on_base` INT, IN `var_game_inning` INT, IN `var_game_inning_half` VARCHAR(1), IN `var_game_outs` INT, IN `var_game_team_score` INT, IN `var_game_opponent_score` INT, IN `var_on_first_position_id` INT, IN `var_on_second_position_id` INT, IN `var_on_third_position_id` INT, IN `var_is_inning_end` INT, IN `var_is_extra_innings` INT, IN `var_is_owned_player` INT, IN `var_ball_direction` INT, IN `var_stars_earned` FLOAT)  NO SQL
INSERT INTO team_game_plate_appearance(game_id, team_id, position_id, stat_id, stat_value, ball_direction, is_out_sac_fly, is_out_sac_hit, is_out_double_play, is_sb_attempt, is_sb_succeed, sb_position, sb_base, is_player_sb, is_walkoff, runs, runs_batted_in, left_on_base, game_inning, game_inning_half, game_outs, game_team_score, game_opponent_score, on_first_position_id, on_second_position_id, on_third_position_id, is_inning_end, is_extra_innings, is_owned_player, stars_earned) VALUES (var_game_id, var_team_id, var_position_id, var_stat_id, var_stat_value, var_ball_direction, var_is_out_sac_fly, var_is_out_sac_hit, var_is_out_double_play, var_is_sb_attempt, var_is_sb_succeed, var_sb_position, var_sb_base, var_is_player_sb, var_is_walkoff, var_runs, var_runs_batted_in, var_left_on_base, var_game_inning, var_game_inning_half, var_game_outs, var_game_team_score, var_game_opponent_score, var_on_first_position_id, var_on_second_position_id, var_on_third_position_id, var_is_inning_end, var_is_extra_innings, var_is_owned_player, var_stars_earned)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_game_recap_sel` (IN `var_game_id` INT)  NO SQL
SELECT
	*
FROM
	team_game_plate_appearance tm
    INNER JOIN team_game_opponent_half_inning opp ON opp.game_id = tm.game_id AND opp.game_inning = tm.game_inning
WHERE
	tm.game_id = var_game_id
ORDER BY
	tm.game_inning ASC
    ,(CASE
      	WHEN tm.game_inning_half = 'T' THEN 1
      	ELSE 2
      END) DESC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_playoff_schedule_upd` (IN `var_season_id` INT, IN `var_team_id` INT, IN `var_opponent_id` INT, IN `var_playoff_seed` INT, IN `var_is_win` INT)  NO SQL
UPDATE league_playoff_schedule
SET
	home_team_wins = (
        CASE 
        	WHEN home_team_seed = var_playoff_seed AND visit_team_seed <> var_playoff_seed AND var_is_win = 1 THEN home_team_wins + 1
        	WHEN home_team_seed <> var_playoff_seed AND visit_team_seed = var_playoff_seed AND var_is_win <> 1 THEN home_team_wins + 1
        	WHEN home_team_seed = visit_team_seed AND home_team_id = var_team_id AND var_is_win = 1 THEN home_team_wins + 1
        	WHEN home_team_seed = visit_team_seed AND home_team_id = var_opponent_id AND var_is_win <> 1 THEN home_team_wins + 1
        	ELSE home_team_wins 
        END)
    ,visit_team_wins = (
        CASE 
        	WHEN visit_team_seed = var_playoff_seed AND home_team_seed <> var_playoff_seed AND var_is_win = 1 THEN visit_team_wins + 1
        	WHEN visit_team_seed <> var_playoff_seed AND home_team_seed = var_playoff_seed AND var_is_win <> 1 THEN visit_team_wins + 1
        	WHEN home_team_seed = visit_team_seed AND visit_team_id = var_team_id AND var_is_win = 1 THEN visit_team_wins + 1
        	WHEN home_team_seed = visit_team_seed AND visit_team_id = var_opponent_id AND var_is_win <> 1 THEN visit_team_wins + 1
        	ELSE visit_team_wins 
        END)
    ,games_played = (games_played + 1)
WHERE 
	season_id = var_season_id 
    AND (
        (home_team_id = var_team_id AND visit_team_id = var_opponent_id) 
        OR
        (home_team_id = var_opponent_id AND visit_team_id = var_team_id)
    )
    AND is_finished = 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_playoff_schedule_winner_upd` (IN `var_season_id` INT, IN `var_team_id` INT, IN `var_opponent_id` INT)  NO SQL
UPDATE league_playoff_schedule 
SET 
	winner_team_id = 
        (CASE
         WHEN home_team_wins = 1 AND round = 1 THEN home_team_id
         WHEN visit_team_wins = 1 AND round = 1 THEN visit_team_id
         WHEN home_team_wins = 3 AND round = 2 THEN home_team_id
         WHEN visit_team_wins = 3 AND round = 2 THEN visit_team_id
         WHEN home_team_wins = 4 AND round > 2 THEN home_team_id
         WHEN visit_team_wins = 4 AND round > 2 THEN visit_team_id
         ELSE 0
         END)
    ,is_finished = (CASE
         WHEN home_team_wins = 1 AND round = 1 THEN 1
         WHEN visit_team_wins = 1 AND round = 1 THEN 1
         WHEN home_team_wins = 3 AND round = 2 THEN 1
         WHEN visit_team_wins = 3 AND round = 2 THEN 1
         WHEN home_team_wins = 4 AND round > 2 THEN 1
         WHEN visit_team_wins = 4 AND round > 2 THEN 1
         ELSE 0
         END)
WHERE 
	season_id = var_season_id
    AND (
        (home_team_id = var_team_id AND visit_team_id = var_opponent_id) 
        OR (home_team_id = var_opponent_id AND visit_team_id = var_team_id)
    ) 
    AND winner_team_id = 0
    AND is_finished = 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_playoff_series_winner_sel` (IN `var_season_id` INT, IN `var_playoff_round` INT, IN `var_team_id` INT)  NO SQL
SELECT 
	winner_team_id
    ,is_finished
FROM 
	league_playoff_schedule
WHERE
	season_id = var_season_id
    AND round = var_playoff_round
    AND var_team_id IN (home_team_id,visit_team_id)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_roster_copy_to_new_season` (IN `var_player_id` INT)  NO SQL
INSERT INTO team_roster
SELECT
	roster_id
    ,(SELECT season_id FROM player WHERE player_id = var_player_id LIMIT 1) AS season_id
    ,team_id
    ,position_id
    ,first_name
    ,last_name
    ,pitcher_rotation_id
    ,is_bench
    ,is_player
    ,is_replaced
    ,is_active
FROM
	team_roster tr
WHERE
	tr.season_id = (SELECT season_id FROM player_season WHERE player_id = var_player_id ORDER BY season_id DESC LIMIT 1 OFFSET 1)
  	AND tr.is_replaced = 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_roster_deactivate_player` (IN `var_roster_id` INT)  NO SQL
UPDATE team_roster SET is_active = 0, is_replaced = 1 WHERE roster_id = var_roster_id AND is_active = 1 AND is_replaced = 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_roster_generate` (IN `var_player_id` INT)  NO SQL
SELECT
    pl.season_id
    ,pl.team_id
    ,pl.player_firstname
    ,pl.player_lastname
    ,pl.player_position AS taken_position
    ,f.first_name
    ,(
        SELECT name AS last_name
        FROM master_player_names
        WHERE is_first_name = 0 AND is_active = 1
        ORDER BY RAND() LIMIT 1
    ) last_name
FROM
    player pl
    INNER JOIN (
        SELECT name AS first_name
        FROM master_player_names
        WHERE is_first_name = 1 AND is_active = 1
        ORDER BY RAND() LIMIT 24
    ) f ON f.first_name <> pl.player_firstname
WHERE
	pl.player_id = var_player_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_roster_ins` (IN `var_season_id` INT, IN `var_team_id` INT, IN `var_first_name` VARCHAR(50), IN `var_last_name` VARCHAR(50), IN `var_position_id` INT, IN `var_rotation_id` INT, IN `var_is_bench` INT, IN `var_is_player` INT)  NO SQL
INSERT INTO team_roster (season_id, team_id, first_name, last_name, position_id, pitcher_rotation_id, is_bench, is_player) VALUES(var_season_id, var_team_id, var_first_name, var_last_name, var_position_id, var_rotation_id, var_is_bench, var_is_player)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_roster_replace_deactivated` (IN `var_roster_id` INT)  NO SQL
INSERT INTO team_roster(season_id, team_id, position_id, first_name, last_name, pitcher_rotation_id, is_bench, is_player, is_replaced, is_active)
SELECT
	tr.season_id
    ,tr.team_id
    ,tr.position_id
    ,(
        SELECT nln.name AS first_name
        FROM master_player_names nln
        WHERE nln.is_first_name = 1 AND nln.is_active = 1 AND nln.name <> tr.first_name
        ORDER BY RAND() LIMIT 1
    ) first_name
    ,(
        SELECT nln.name AS last_name
        FROM master_player_names nln
        WHERE nln.is_first_name = 0 AND nln.is_active = 1 AND nln.name <> tr.last_name
        ORDER BY RAND() LIMIT 1
    ) last_name
    ,tr.pitcher_rotation_id
    ,tr.is_bench
    ,tr.is_player
    ,0 AS is_replaced
    ,1 AS is_active
FROM 
	team_roster tr
WHERE 
	tr.roster_id = var_roster_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_roster_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	tr.roster_id
    ,tr.season_id
    ,tr.team_id
    ,tr.position_id
    ,tr.first_name
    ,tr.last_name
    ,tr.pitcher_rotation_id
    ,tr.is_bench
    ,tr.is_player
FROM
	team_roster tr
WHERE
	tr.season_id = (SELECT season_id FROM player WHERE player_id = var_player_id LIMIT 1)
    AND tr.is_active = 1
ORDER BY
	tr.position_id ASC
    ,tr.pitcher_rotation_id ASC
    ,tr.is_bench ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_schedule_from_pause_upd` (IN `var_game_id` INT, IN `var_game_date` DATETIME)  NO SQL
UPDATE 
	team_schedule 
SET 
	game_date = var_game_date
    ,can_sim = 1
WHERE
	game_id = var_game_id
    AND can_sim = 0
    AND is_finished = 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_schedule_game_upd` (IN `var_game_id` INT, IN `var_team_runs` INT, IN `var_opponent_runs` INT, IN `var_innings` INT, IN `var_team_wins` INT, IN `var_team_losses` INT, IN `var_opponent_wins` INT, IN `var_opponent_losses` INT, IN `var_is_win` INT)  NO SQL
UPDATE team_schedule 
SET 
	is_finished = 1
    ,can_sim = 0
    ,team_score = var_team_runs
    ,opponent_score = var_opponent_runs
    ,innings = var_innings
    ,team_wins = var_team_wins
    ,team_losses = var_team_losses
    ,opponent_wins = var_opponent_wins
    ,opponent_losses = var_opponent_losses
    ,game_outcome = var_is_win
WHERE
	game_id = var_game_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_schedule_generate` (IN `var_player_id` INT)  NO SQL
SELECT
	*
FROM
    (
    (SELECT 
        pl.team_id
        ,mtd.team_id AS opponent_id
        ,pl.season_id
    FROM
        player pl
        INNER JOIN master_team mt ON mt.team_id = pl.team_id
        INNER JOIN master_team mtd ON mtd.league_id = mt.league_id AND mtd.conference_id = mt.conference_id AND mtd.division_id <> mt.division_id AND mtd.team_id <> mt.team_id AND mtd.is_active = 1
    WHERE
        pl.player_id = var_player_id
        AND mt.is_active = 1
    ORDER BY RAND())

        UNION ALL

    (SELECT 
        pl.team_id
        ,mtd.team_id AS opponent_id
        ,pl.season_id
    FROM
        player pl
        INNER JOIN master_team mt ON mt.team_id = pl.team_id
        INNER JOIN master_team mtd ON mtd.league_id = mt.league_id AND mtd.conference_id = mt.conference_id AND mtd.division_id = mt.division_id AND mtd.team_id <> mt.team_id AND mtd.is_active = 1
    WHERE
        pl.player_id = var_player_id
        AND mt.is_active = 1
    ORDER BY RAND())

        UNION ALL

    (SELECT 
        pl.team_id
        ,mtd.team_id AS opponent_id
        ,pl.season_id
    FROM
        player pl
        INNER JOIN master_team mt ON mt.team_id = pl.team_id
        INNER JOIN master_team mtd ON mtd.league_id = mt.league_id AND mtd.conference_id <> mt.conference_id AND mtd.is_active = 1
    WHERE
        pl.player_id = var_player_id
        AND mt.is_active = 1
    ORDER BY RAND())

        UNION ALL

    (SELECT 
        pl.team_id
        ,mtd.team_id AS opponent_id
        ,pl.season_id
    FROM
        player pl
        INNER JOIN master_team mt ON mt.team_id = pl.team_id
        INNER JOIN master_team mtd ON mtd.league_id = mt.league_id AND mtd.conference_id = mt.conference_id AND mtd.division_id = mt.division_id AND mtd.team_id <> mt.team_id AND mtd.is_active = 1
    WHERE
        pl.player_id = var_player_id
        AND mt.is_active = 1
    ORDER BY RAND())

        UNION ALL

    (SELECT 
        pl.team_id
        ,mtd.team_id AS opponent_id
        ,pl.season_id
    FROM
        player pl
        INNER JOIN master_team mt ON mt.team_id = pl.team_id
        INNER JOIN master_team mtd ON mtd.league_id = mt.league_id AND mtd.conference_id = mt.conference_id AND mtd.division_id <> mt.division_id AND mtd.team_id <> mt.team_id AND mtd.is_active = 1
    WHERE
        pl.player_id = var_player_id
        AND mt.is_active = 1
    ORDER BY RAND())

        UNION ALL

    (SELECT 
		pl.team_id
		,mtd.team_id AS opponent_id
		,pl.season_id
	FROM
		player pl
		INNER JOIN master_team mt ON mt.team_id = pl.team_id
		INNER JOIN master_team mtd ON mtd.league_id = mt.league_id AND mtd.conference_id <> mt.conference_id AND mtd.is_active = 1
	WHERE
		pl.player_id = var_player_id
		AND mt.is_active = 1
	ORDER BY RAND()
	LIMIT 7)

        UNION ALL

    (SELECT 
        pl.team_id
        ,mtd.team_id AS opponent_id
        ,pl.season_id
    FROM
        player pl
        INNER JOIN master_team mt ON mt.team_id = pl.team_id
        INNER JOIN master_team mtd ON mtd.league_id = mt.league_id AND mtd.conference_id = mt.conference_id AND mtd.division_id = mt.division_id AND mtd.team_id <> mt.team_id AND mtd.is_active = 1
    WHERE
        pl.player_id = var_player_id
        AND mt.is_active = 1
    ORDER BY RAND())
) sched$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_schedule_generate_from_pause` (IN `var_player_id` INT)  NO SQL
SELECT
	ts.game_id
FROM
	team_schedule ts
WHERE
	ts.season_id = (SELECT pl.season_id FROM player pl WHERE pl.player_id = var_player_id AND pl.can_sim = 1)
    AND ts.can_sim = 0
    AND ts.is_finished = 0
ORDER BY
	ts.game_date ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_schedule_ins` (IN `var_team_id` INT, IN `var_opponent_id` INT, IN `var_season_id` INT, IN `var_game_one_date` DATETIME, IN `var_game_two_date` DATETIME, IN `var_game_three_date` DATETIME, IN `var_is_home` INT)  NO SQL
INSERT INTO team_schedule (team_id, opponent_id, season_id, game_date, is_home) VALUES
(var_team_id, var_opponent_id, var_season_id, var_game_one_date, var_is_home),
(var_team_id, var_opponent_id, var_season_id, var_game_two_date, var_is_home),
(var_team_id, var_opponent_id, var_season_id, var_game_three_date, var_is_home)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_schedule_ins_old` (IN `var_team_id` INT, IN `var_opponent_id` INT, IN `var_season_id` INT, IN `var_game_one_date` DATETIME, IN `var_game_two_date` DATETIME, IN `var_game_three_date` DATETIME, IN `var_game_four_date` DATETIME, IN `var_game_five_date` DATETIME, IN `var_game_six_date` DATETIME, IN `var_is_home` INT)  NO SQL
INSERT INTO team_schedule (team_id, opponent_id, season_id, game_date, is_home) VALUES
(var_team_id, var_opponent_id, var_season_id, var_game_one_date, var_is_home),
(var_team_id, var_opponent_id, var_season_id, var_game_two_date, var_is_home),
(var_team_id, var_opponent_id, var_season_id, var_game_three_date, var_is_home),
(var_team_id, var_opponent_id, var_season_id, var_game_four_date, var_is_home),
(var_team_id, var_opponent_id, var_season_id, var_game_five_date, var_is_home),
(var_team_id, var_opponent_id, var_season_id, var_game_six_date, var_is_home)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_schedule_list_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	ts.game_id
	,mt.team_abbr AS team
    ,mto.team_abbr AS opponent
    ,ts.game_date
    ,(CASE
      	WHEN ts.is_finished = 0 THEN tbo.batting_order
      	ELSE tgbo.batting_order
      END) AS batting_order
    ,ts.is_home
    ,ts.is_finished
    ,ts.team_score
    ,ts.opponent_score
    ,ts.game_outcome
    ,(CASE WHEN psg.stat_value BETWEEN -0.49 AND 0 THEN 0 ELSE ROUND(psg.stat_value, 0) END) AS star_earned
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_wins ELSE pts.wins END) AS team_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_losses ELSE pts.losses END) AS team_losses
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_wins ELSE ots.wins END) AS opponent_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_losses ELSE ots.losses END) AS opponent_losses
    ,ts.can_sim
    ,ts.is_postseason
FROM
	player pl
	INNER JOIN team_schedule ts ON ts.season_id = pl.season_id
    INNER JOIN master_team mt ON mt.team_id = ts.team_id
    INNER JOIN master_team mto ON mto.team_id = ts.opponent_id
    INNER JOIN league_standings pts ON pts.season_id = pl.season_id AND pts.team_id = pl.team_id
    INNER JOIN league_standings ots ON ots.season_id = pl.season_id AND ots.team_id = ts.opponent_id
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = pl.season_id AND tbo.team_id = pl.team_id
    LEFT JOIN player_stat_game psg ON psg.game_id = ts.game_id AND psg.player_id = pl.player_id AND psg.stat_id = 24
	LEFT JOIN team_game_batting_order tgbo ON tgbo.game_id = ts.game_id AND tgbo.is_owned_player = 1
WHERE
    pl.player_id = var_player_id
	AND pl.is_active = 1
ORDER BY 
	ts.game_date ASC
    ,ts.game_id ASC
    ,ts.is_postseason ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_schedule_most_recent_game_sel` (IN `var_player_id` INT, IN `var_is_finished` INT)  NO SQL
SELECT
	ts.game_id
	,mt.team_abbr AS team
    ,mto.team_abbr AS opponent
    ,ts.game_date
    ,(CASE
      	WHEN ts.is_finished = 0 THEN tbo.batting_order
      	ELSE tgbo.batting_order
      END) AS batting_order
    ,ts.is_home
    ,ts.is_finished
    ,ts.team_score
    ,ts.opponent_score
    ,ts.game_outcome
    ,(CASE WHEN psg.stat_value BETWEEN -0.49 AND 0 THEN 0 ELSE ROUND(psg.stat_value, 0) END) AS star_earned
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_wins ELSE pts.wins END) AS team_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.team_losses ELSE pts.losses END) AS team_losses
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_wins ELSE ots.wins END) AS opponent_wins
    ,(CASE WHEN ts.is_finished = 1 THEN ts.opponent_losses ELSE ots.losses END) AS opponent_losses
    ,ts.can_sim
    ,ts.is_postseason
FROM
	player pl
	INNER JOIN team_schedule ts ON ts.season_id = pl.season_id
    INNER JOIN master_team mt ON mt.team_id = ts.team_id
    INNER JOIN master_team mto ON mto.team_id = ts.opponent_id
    INNER JOIN league_standings pts ON pts.season_id = pl.season_id AND pts.team_id = pl.team_id
    INNER JOIN league_standings ots ON ots.season_id = pl.season_id AND ots.team_id = ts.opponent_id
    INNER JOIN team_batting_order tbo ON tbo.player_id = pl.player_id AND tbo.season_id = pl.season_id AND tbo.team_id = pl.team_id
    LEFT JOIN player_stat_game psg ON psg.game_id = ts.game_id AND psg.player_id = pl.player_id AND psg.stat_id = 24
	LEFT JOIN team_game_batting_order tgbo ON tgbo.game_id = ts.game_id AND tgbo.is_owned_player = 1
WHERE
    pl.player_id = var_player_id
	AND pl.is_active = 1
    AND ts.is_finished = var_is_finished
ORDER BY 
	(CASE WHEN ts.is_finished = 1 THEN ts.game_date ELSE 0 END) DESC
	,(CASE WHEN ts.is_finished = 0 THEN ts.game_date ELSE 0 END) ASC
LIMIT 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_schedule_pagination_progress_sel` (IN `var_player_id` INT)  NO SQL
SELECT
	COUNT(ts.game_id) AS games
    ,(COUNT(ts.game_id) - ps.games_until_yearly) AS games_played
    ,ROUND(COUNT(ts.game_id) / 27, 0) AS pages
    ,ROUND((COUNT(ts.game_id) - ps.games_until_yearly) / 27, 0) AS page_default
FROM 
	team_schedule ts
    INNER JOIN player_season ps ON ps.season_id = ts.season_id
    INNER JOIN player pl ON pl.player_id = ps.player_id AND pl.season_id = ps.season_id
WHERE
	ps.player_id = var_player_id
GROUP BY
	ts.season_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_schedule_playoff_divisional_series_ins` (IN `var_team_id` INT, IN `var_opponent_id` INT, IN `var_season_id` INT, IN `var_game_one_date` DATETIME, IN `var_game_two_date` DATETIME, IN `var_game_three_date` DATETIME, IN `var_game_four_date` DATETIME, IN `var_game_five_date` DATETIME, IN `var_is_home` INT)  NO SQL
INSERT INTO team_schedule (team_id, opponent_id, season_id, game_date, is_home, is_postseason) VALUES
(var_team_id, var_opponent_id, var_season_id, var_game_one_date, var_is_home, 1),
(var_team_id, var_opponent_id, var_season_id, var_game_two_date, var_is_home, 1),
(var_team_id, var_opponent_id, var_season_id, var_game_three_date, (CASE WHEN var_is_home = 0 THEN 1 WHEN var_is_home = 1 THEN 0 ELSE var_is_home END), 1),
(var_team_id, var_opponent_id, var_season_id, var_game_four_date, (CASE WHEN var_is_home = 0 THEN 1 WHEN var_is_home = 1 THEN 0 ELSE var_is_home END), 1),
(var_team_id, var_opponent_id, var_season_id, var_game_five_date, var_is_home, 1)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_schedule_playoff_series_ins` (IN `var_team_id` INT, IN `var_opponent_id` INT, IN `var_season_id` INT, IN `var_game_one_date` DATETIME, IN `var_game_two_date` DATETIME, IN `var_game_three_date` DATETIME, IN `var_game_four_date` DATETIME, IN `var_game_five_date` DATETIME, IN `var_game_six_date` DATETIME, IN `var_game_seven_date` DATETIME, IN `var_is_home` INT)  NO SQL
INSERT INTO team_schedule (team_id, opponent_id, season_id, game_date, is_home, is_postseason) VALUES
(var_team_id, var_opponent_id, var_season_id, var_game_one_date, var_is_home, 1),
(var_team_id, var_opponent_id, var_season_id, var_game_two_date, var_is_home, 1),
(var_team_id, var_opponent_id, var_season_id, var_game_three_date, (CASE WHEN var_is_home = 0 THEN 1 WHEN var_is_home = 1 THEN 0 ELSE var_is_home END), 1),
(var_team_id, var_opponent_id, var_season_id, var_game_four_date, (CASE WHEN var_is_home = 0 THEN 1 WHEN var_is_home = 1 THEN 0 ELSE var_is_home END), 1),
(var_team_id, var_opponent_id, var_season_id, var_game_five_date, (CASE WHEN var_is_home = 0 THEN 1 WHEN var_is_home = 1 THEN 0 ELSE var_is_home END), 1),
(var_team_id, var_opponent_id, var_season_id, var_game_six_date, var_is_home, 1),
(var_team_id, var_opponent_id, var_season_id, var_game_seven_date, var_is_home, 1)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_schedule_stop_simulation` (IN `var_player_id` INT)  NO SQL
UPDATE
	team_schedule 
SET 
	can_sim = 0
WHERE
	season_id = (SELECT pl.season_id FROM player pl WHERE pl.player_id = var_player_id AND pl.can_sim = 0)
    AND can_sim = 1
    AND is_finished = 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_schedule_unfinished_series_del` (IN `var_season_id` INT)  NO SQL
DELETE FROM team_schedule WHERE season_id = var_season_id AND is_postseason = 1 AND is_finished = 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_schedule_upcoming_games_sel` (IN `var_player_id` INT, IN `var_number_games` INT)  NO SQL
SELECT
	ts.game_id
    ,mt_pt.team_city
    ,mt_pt.team_name
    ,ls_pt.wins AS team_wins
    ,ls_pt.losses AS team_losses
    ,ls_pt.playoff_seed AS team_playoff_seed
    ,mt_opp.team_city AS opp_team_city
    ,mt_opp.team_name AS opp_team_name
    ,ls_opp.wins AS opp_team_wins
    ,ls_opp.losses AS opp_team_losses
    ,ls_opp.playoff_seed AS opp_team_playoff_seed
    ,ts.is_home
    ,ts.is_postseason
    ,ts.game_date
    
FROM
	team_schedule ts
    INNER JOIN player_season ps ON ps.season_id = ts.season_id AND ps.player_id = var_player_id
    INNER JOIN player pl ON pl.player_id = ps.player_id AND pl.season_id = ps.season_id
    INNER JOIN master_team mt_pt ON mt_pt.league_id = ps.league_id AND mt_pt.team_id = ts.team_id
    INNER JOIN league_standings ls_pt ON ls_pt.season_id = ps.season_id AND ls_pt.team_id = mt_pt.team_id
    INNER JOIN master_team mt_opp ON mt_opp.league_id = ps.league_id AND mt_opp.team_id = ts.opponent_id
    INNER JOIN league_standings ls_opp ON ls_opp.season_id = ps.season_id AND ls_opp.team_id = mt_opp.team_id
WHERE
	ts.is_finished = 0
    AND ts.can_sim = 1
ORDER BY
	ts.game_id ASC
LIMIT var_number_games$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_schedule_wildcard_ins` (IN `var_team_id` INT, IN `var_opponent_id` INT, IN `var_season_id` INT, IN `var_game_one_date` DATETIME, IN `var_is_home` INT)  NO SQL
INSERT INTO team_schedule (team_id, opponent_id, season_id, game_date, is_home, is_postseason) VALUES
(var_team_id, var_opponent_id, var_season_id, var_game_one_date, var_is_home, 1)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_season_stat_default_ins` (IN `var_player_id` INT)  NO SQL
INSERT INTO team_stat_season (team_id, season_id, stat_id, stat_value, is_postseason)
SELECT
	(SELECT team_id FROM player WHERE player_id = var_player_id) AS team_id
    ,(SELECT season_id FROM player WHERE player_id = var_player_id) AS season_id
    ,a.stat_id
    ,a.stat_value
    ,a.is_postseason
FROM
(
    SELECT
        mt.stat_id
        ,0 AS stat_value
        ,0 AS is_postseason
    FROM
        master_stat mt
    
    UNION ALL 
    
    SELECT
        mt.stat_id
        ,0 AS stat_value
        ,1 AS is_postseason
    FROM
        master_stat mt
) a$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_stat_game_ins` (IN `var_team_id` INT, IN `var_game_id` INT, IN `var_stat_id` INT, IN `var_stat_value` FLOAT)  NO SQL
INSERT IGNORE INTO team_stat_game(team_id, game_id, stat_id, stat_value) VALUES(var_team_id, var_game_id, var_stat_id, var_stat_value)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_stat_game_sel` (IN `var_game_id` INT)  NO SQL
SELECT
	tsg.game_id
    ,ms.stat_id
    ,ms.stat_abbr
    ,(CASE WHEN ms.stat_id = 24 THEN ROUND(tsg.stat_value, 0) ELSE tsg.stat_value END) AS stat_value
FROM
	team_stat_game tsg
    INNER JOIN master_stat ms ON ms.stat_id = tsg.stat_id
WHERE
	tsg.game_id = var_game_id
ORDER BY
	tsg.stat_id ASC$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `team_stat_season_upd` (IN `var_team_id` INT, IN `var_season_id` INT, IN `var_stat_id` INT, IN `var_stat_value` FLOAT, IN `var_is_postseason` INT)  NO SQL
UPDATE team_stat_season SET stat_value = (stat_value + var_stat_value) WHERE team_id = var_team_id AND season_id = var_season_id AND stat_id = var_stat_id AND is_postseason = var_is_postseason$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `ID` int(11) NOT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `customer_id` varchar(250) DEFAULT NULL,
  `Created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastLogin` datetime DEFAULT NULL,
  `isPremium` tinyint(1) NOT NULL DEFAULT '0',
  `premiumStartDate` datetime DEFAULT NULL,
  `IpAddress` varchar(50) DEFAULT NULL,
  `canUnretire` tinyint(1) NOT NULL DEFAULT '1',
  `isSubscribed` smallint(6) NOT NULL DEFAULT '1',
  `IsVerified` bit(1) NOT NULL DEFAULT b'0',
  `IsActive` bit(1) NOT NULL DEFAULT b'1',
  `IsAdmin` bit(1) NOT NULL DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `account_customer`
--

CREATE TABLE `account_customer` (
  `account_id` int(11) NOT NULL,
  `customer_id` varchar(250) NOT NULL,
  `first_name` varchar(250) NOT NULL,
  `last_name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `auto_collection` varchar(250) NOT NULL,
  `allow_direct_debit` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL,
  `taxability` varchar(250) NOT NULL,
  `object` varchar(250) NOT NULL,
  `card_status` varchar(250) NOT NULL,
  `account_credits` int(11) NOT NULL,
  `refundable_credits` int(11) NOT NULL,
  `excess_payments` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `account_notification`
--

CREATE TABLE `account_notification` (
  `notification_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `notification_title` varchar(100) NOT NULL,
  `notification_body` varchar(250) NOT NULL,
  `notification_link` varchar(100) NOT NULL,
  `notification_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_read` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `account_season`
--

CREATE TABLE `account_season` (
  `account_id` int(11) NOT NULL,
  `season_value` double NOT NULL,
  `season_earned` double NOT NULL,
  `season_spent` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `account_subscription`
--

CREATE TABLE `account_subscription` (
  `account_id` int(11) NOT NULL,
  `id` varchar(250) NOT NULL,
  `customer_id` varchar(250) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `plan_quantity` varchar(250) NOT NULL,
  `status` int(11) NOT NULL,
  `start_date` int(11) NOT NULL,
  `trial_start` int(11) NOT NULL,
  `trial_end` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `cancelled_at` int(11) NOT NULL,
  `remaining_billing_cycles` int(11) NOT NULL,
  `current_term_start` int(11) NOT NULL,
  `current_term_end` int(11) NOT NULL,
  `has_scheduled_changes` tinyint(4) NOT NULL DEFAULT '0',
  `object` varchar(250) NOT NULL,
  `due_invoices_count` int(11) NOT NULL,
  `due_since` int(11) NOT NULL,
  `total_dues` int(11) NOT NULL,
  `has_access` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admin_bulk_reschedule_games`
--

CREATE TABLE `admin_bulk_reschedule_games` (
  `player_id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `segment` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `IpAddressLog`
--

CREATE TABLE `IpAddressLog` (
  `IpAddress` varchar(50) NOT NULL,
  `InsertTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `IsBlocked` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `league_playoff_schedule`
--

CREATE TABLE `league_playoff_schedule` (
  `season_id` int(11) NOT NULL,
  `conference_id` int(11) NOT NULL,
  `round` int(11) NOT NULL,
  `home_team_id` int(11) NOT NULL,
  `visit_team_id` int(11) NOT NULL,
  `home_team_seed` int(11) NOT NULL,
  `visit_team_seed` int(11) NOT NULL,
  `home_team_wins` int(11) NOT NULL DEFAULT '0',
  `visit_team_wins` int(11) NOT NULL DEFAULT '0',
  `games_played` int(11) NOT NULL DEFAULT '0',
  `winner_team_id` int(11) NOT NULL DEFAULT '0',
  `is_finished` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `league_standings`
--

CREATE TABLE `league_standings` (
  `league_id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `wins` int(11) NOT NULL DEFAULT '0',
  `losses` int(11) NOT NULL DEFAULT '0',
  `playoff_seed` int(11) NOT NULL DEFAULT '0',
  `is_wildcard_team` tinyint(1) NOT NULL DEFAULT '0',
  `is_division_leader` tinyint(1) NOT NULL DEFAULT '0',
  `is_conference_leader` tinyint(1) NOT NULL DEFAULT '0',
  `is_world_series_winner` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `master_award`
--

CREATE TABLE `master_award` (
  `award_id` int(11) NOT NULL,
  `award_name` varchar(100) NOT NULL,
  `award_abbr` varchar(20) NOT NULL,
  `award_star_bonus` int(11) NOT NULL DEFAULT '1000',
  `is_weekly` tinyint(1) NOT NULL DEFAULT '0',
  `is_monthly` tinyint(1) NOT NULL DEFAULT '0',
  `is_yearly` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_award`
--

INSERT INTO `master_award` (`award_id`, `award_name`, `award_abbr`, `award_star_bonus`, `is_weekly`, `is_monthly`, `is_yearly`, `is_active`) VALUES
(11, 'Major League MVP', 'ML MVP', 500, 0, 0, 1, 1),
(14, 'Major League Player of the Week', 'ML POW', 50, 1, 0, 0, 1),
(16, 'Major League Player of the Month', 'ML POM', 100, 0, 1, 0, 1),
(17, 'Playoffs: Advanced to Wild Card', 'wild_card', 20, 0, 0, 1, 1),
(18, 'Playoffs: Advanced to Divisional Series', 'divisional', 30, 0, 0, 1, 1),
(19, 'Playoffs: Advanced to Championship Series', 'championship', 40, 0, 0, 1, 1),
(20, 'Playoffs: Advanced to World Series', 'world_series', 50, 0, 0, 1, 1),
(21, 'Playoffs: Won World Series', 'won_world_series', 100, 0, 0, 1, 1),
(22, 'Major League All-Star', 'all_star', 250, 0, 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `master_ball_direction`
--

CREATE TABLE `master_ball_direction` (
  `direction_id` int(11) NOT NULL,
  `direction` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_ball_direction`
--

INSERT INTO `master_ball_direction` (`direction_id`, `direction`) VALUES
(1, 'left'),
(2, 'center'),
(3, 'right');

-- --------------------------------------------------------

--
-- Table structure for table `master_bonus`
--

CREATE TABLE `master_bonus` (
  `bonus_id` int(11) NOT NULL,
  `bonus_name` varchar(100) NOT NULL,
  `bonus_abbr` varchar(20) NOT NULL,
  `bonus_desc` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_bonus`
--

INSERT INTO `master_bonus` (`bonus_id`, `bonus_name`, `bonus_abbr`, `bonus_desc`) VALUES
(1, 'Game MVP', 'bonus_mvp', 'Was chosen as the MVP of the game!'),
(2, 'Had Walk-Off', 'bonus_walkoff', 'Had a walk-off to win the game!');

-- --------------------------------------------------------

--
-- Table structure for table `master_league`
--

CREATE TABLE `master_league` (
  `league_id` int(11) NOT NULL,
  `league_name` varchar(100) NOT NULL,
  `league_level` varchar(3) NOT NULL,
  `league_season` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_league`
--

INSERT INTO `master_league` (`league_id`, `league_name`, `league_level`, `league_season`, `is_active`) VALUES
(1, 'Major League', 'PRO', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `master_league_conference`
--

CREATE TABLE `master_league_conference` (
  `conference_id` int(11) NOT NULL,
  `league_id` int(11) NOT NULL,
  `conference_name` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_league_conference`
--

INSERT INTO `master_league_conference` (`conference_id`, `league_id`, `conference_name`, `is_active`) VALUES
(1, 1, 'American', 1),
(2, 1, 'National', 1);

-- --------------------------------------------------------

--
-- Table structure for table `master_league_division`
--

CREATE TABLE `master_league_division` (
  `division_id` int(11) NOT NULL,
  `league_id` int(11) NOT NULL,
  `conference_id` int(11) NOT NULL,
  `division_name` varchar(50) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_league_division`
--

INSERT INTO `master_league_division` (`division_id`, `league_id`, `conference_id`, `division_name`, `is_active`) VALUES
(1, 1, 1, 'East', 1),
(2, 1, 1, 'Central', 1),
(3, 1, 1, 'West', 1),
(4, 1, 2, 'East', 1),
(5, 1, 2, 'Central', 1),
(6, 1, 2, 'West', 1);

-- --------------------------------------------------------

--
-- Table structure for table `master_player_names`
--

CREATE TABLE `master_player_names` (
  `name_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `is_first_name` tinyint(1) NOT NULL DEFAULT '1',
  `is_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_player_names`
--

INSERT INTO `master_player_names` (`name_id`, `name`, `is_first_name`, `is_active`) VALUES
(8305, 'Aardsma', 0, 1),
(8306, 'Abad', 0, 1),
(8307, 'Abbott', 0, 1),
(8308, 'Abdullah', 0, 1),
(8309, 'Abeita', 0, 1),
(8310, 'Abel', 0, 1),
(8311, 'Abercrombie', 0, 1),
(8312, 'Abernathy', 0, 1),
(8313, 'Abreau', 0, 1),
(8314, 'Abreu', 0, 1),
(8315, 'Abruzzo', 0, 1),
(8316, 'Accardo', 0, 1),
(8317, 'Accomando', 0, 1),
(8318, 'Acevedo', 0, 1),
(8319, 'Aceves', 0, 1),
(8320, 'Achter', 0, 1),
(8321, 'Ackerman', 0, 1),
(8322, 'Ackley', 0, 1),
(8323, 'Acord', 0, 1),
(8324, 'Acosta', 0, 1),
(8325, 'Acre', 0, 1),
(8326, 'Acuna', 0, 1),
(8327, 'Adam', 0, 1),
(8328, 'Adames', 0, 1),
(8329, 'Adams', 0, 1),
(8330, 'Adamson', 0, 1),
(8331, 'Adcock', 0, 1),
(8332, 'Additon', 0, 1),
(8333, 'Adduci', 0, 1),
(8334, 'Adebaser', 0, 1),
(8335, 'Adell', 0, 1),
(8336, 'Ademan', 0, 1),
(8337, 'Adenhart', 0, 1),
(8338, 'Adkins', 0, 1),
(8339, 'Adleman', 0, 1),
(8340, 'Adolfo', 0, 1),
(8341, 'Adon', 0, 1),
(8342, 'Adrianza', 0, 1),
(8343, 'Afenir', 0, 1),
(8344, 'Affeldt', 0, 1),
(8345, 'Affronti', 0, 1),
(8346, 'Agamennone', 0, 1),
(8347, 'Agbayani', 0, 1),
(8348, 'Agosta', 0, 1),
(8349, 'Agosto', 0, 1),
(8350, 'Agrazal', 0, 1),
(8351, 'Aguasviva', 0, 1),
(8352, 'Aguero', 0, 1),
(8353, 'Aguila', 0, 1),
(8354, 'Aguilar', 0, 1),
(8355, 'Aguilera', 0, 1),
(8356, 'Agustin', 0, 1),
(8357, 'Ahearne', 0, 1),
(8358, 'Ahmed', 0, 1),
(8359, 'Ahn', 0, 1),
(8360, 'Ahrens', 0, 1),
(8361, 'Aikawa', 0, 1),
(8362, 'Aiken', 0, 1),
(8363, 'Ainsworth', 0, 1),
(8364, 'Airoso', 0, 1),
(8365, 'Akashian', 0, 1),
(8366, 'Akin', 0, 1),
(8367, 'Akins', 0, 1),
(8368, 'Akiyama', 0, 1),
(8369, 'Alaniz', 0, 1),
(8370, 'Albaladejo', 0, 1),
(8371, 'Albano', 0, 1),
(8372, 'Albernaz', 0, 1),
(8373, 'Alberro', 0, 1),
(8374, 'Albers', 0, 1),
(8375, 'Albert', 0, 1),
(8376, 'Alberto', 0, 1),
(8377, 'Albertos', 0, 1),
(8378, 'Albies', 0, 1),
(8379, 'Albitz', 0, 1),
(8380, 'Albritton', 0, 1),
(8381, 'Alburquerque', 0, 1),
(8382, 'Albury', 0, 1),
(8383, 'Alcala', 0, 1),
(8384, 'Alcantara', 0, 1),
(8385, 'Alderson', 0, 1),
(8386, 'Aldred', 0, 1),
(8387, 'Aldridge', 0, 1),
(8388, 'Alemais', 0, 1),
(8389, 'Alexander', 0, 1),
(8390, 'Alexy', 0, 1),
(8391, 'Alfaro', 0, 1),
(8392, 'Alfonseca', 0, 1),
(8393, 'Alfonso', 0, 1),
(8394, 'Alfonzo', 0, 1),
(8395, 'Alford', 0, 1),
(8396, 'Alia', 0, 1),
(8397, 'Alicea', 0, 1),
(8398, 'Aliotti', 0, 1),
(8399, 'Allar', 0, 1),
(8400, 'Allard', 0, 1),
(8401, 'Allegheny', 0, 1),
(8402, 'Allegra', 0, 1),
(8403, 'Allen', 0, 1),
(8404, 'Allensworth', 0, 1),
(8405, 'Alley', 0, 1),
(8406, 'Allie', 0, 1),
(8407, 'Allison', 0, 1),
(8408, 'Allman', 0, 1),
(8409, 'Almanza', 0, 1),
(8410, 'Almanzar', 0, 1),
(8411, 'Almonte', 0, 1),
(8412, 'Almora', 0, 1),
(8413, 'Alomar', 0, 1),
(8414, 'Alomar Jr.', 0, 1),
(8415, 'Alonso', 0, 1),
(8416, 'Alou', 0, 1),
(8417, 'Alston', 0, 1),
(8418, 'Alsup', 0, 1),
(8419, 'Altavilla', 0, 1),
(8420, 'Altherr', 0, 1),
(8421, 'Altman', 0, 1),
(8422, 'Altuve', 0, 1),
(8423, 'Alvarado', 0, 1),
(8424, 'Alvarez', 0, 1),
(8425, 'Alzolay', 0, 1),
(8426, 'Amador', 0, 1),
(8427, 'Amaral', 0, 1),
(8428, 'Amarista', 0, 1),
(8429, 'Amaro', 0, 1),
(8430, 'Amaya', 0, 1),
(8431, 'Ambres', 0, 1),
(8432, 'Ambriz', 0, 1),
(8433, 'Ambrose', 0, 1),
(8434, 'Ames', 0, 1),
(8435, 'Amezaga', 0, 1),
(8436, 'Amezcua', 0, 1),
(8437, 'Ammons', 0, 1),
(8438, 'Amora', 0, 1),
(8439, 'Amundaray', 0, 1),
(8440, 'Anderson', 0, 1),
(8441, 'Andino', 0, 1),
(8442, 'Andrade', 0, 1),
(8443, 'Andrelcyzk', 0, 1),
(8444, 'Andreoli', 0, 1),
(8445, 'Andrews', 0, 1),
(8446, 'Andriese', 0, 1),
(8447, 'Andrus', 0, 1),
(8448, 'Andujar', 0, 1),
(8449, 'Anetsberger', 0, 1),
(8450, 'Angelini', 0, 1),
(8451, 'Angle', 0, 1),
(8452, 'Ankiel', 0, 1),
(8453, 'Anna', 0, 1),
(8454, 'Ansman', 0, 1),
(8455, 'Anthony', 0, 1),
(8456, 'Antolin', 0, 1),
(8457, 'Anton', 0, 1),
(8458, 'Antonelli', 0, 1),
(8459, 'Antonini', 0, 1),
(8460, 'Antonio', 0, 1),
(8461, 'Antuna', 0, 1),
(8462, 'Anundsen', 0, 1),
(8463, 'Aoki', 0, 1),
(8464, 'Aparicio', 0, 1),
(8465, 'Aplin', 0, 1),
(8466, 'Apodaca', 0, 1),
(8467, 'Apostel', 0, 1),
(8468, 'Appel', 0, 1),
(8469, 'Appier', 0, 1),
(8470, 'Aquino', 0, 1),
(8471, 'Aracena', 0, 1),
(8472, 'Arai', 0, 1),
(8473, 'Arakaki', 0, 1),
(8474, 'Aramboles', 0, 1),
(8475, 'Arano', 0, 1),
(8476, 'Araujo', 0, 1),
(8477, 'Arauz', 0, 1),
(8478, 'Arburr', 0, 1),
(8479, 'Archer', 0, 1),
(8480, 'Arcia', 0, 1),
(8481, 'Ardoin', 0, 1),
(8482, 'Arenado', 0, 1),
(8483, 'Arencibia', 0, 1),
(8484, 'Arguelles', 0, 1),
(8485, 'Arhart', 0, 1),
(8486, 'Arias', 0, 1),
(8487, 'Arlis', 0, 1),
(8488, 'Armas', 0, 1),
(8489, 'Armenteros', 0, 1),
(8490, 'Armitage', 0, 1),
(8491, 'Armstrong', 0, 1),
(8492, 'Armstrong Jr', 0, 1),
(8493, 'Arnett', 0, 1),
(8494, 'Arnold', 0, 1),
(8495, 'Aro', 0, 1),
(8496, 'Arocha', 0, 1),
(8497, 'Arozarena', 0, 1),
(8498, 'Arraez', 0, 1),
(8499, 'Arredondo', 0, 1),
(8500, 'Arriera', 0, 1),
(8501, 'Arrieta', 0, 1),
(8502, 'Arrojo', 0, 1),
(8503, 'Arrowood', 0, 1),
(8504, 'Arroyo', 0, 1),
(8505, 'Arruebarrena', 0, 1),
(8506, 'Arteaga ', 0, 1),
(8507, 'Artsen', 0, 1),
(8508, 'Asadoorian', 0, 1),
(8509, 'Asahina', 0, 1),
(8510, 'Asao', 0, 1),
(8511, 'Ascanio', 0, 1),
(8512, 'Asche', 0, 1),
(8513, 'Asencio', 0, 1),
(8514, 'Ash', 0, 1),
(8515, 'Ashby', 0, 1),
(8516, 'Asher', 0, 1),
(8517, 'Ashley', 0, 1),
(8518, 'Aspito', 0, 1),
(8519, 'Assad', 0, 1),
(8520, 'Assenmacher', 0, 1),
(8521, 'Astacio', 0, 1),
(8522, 'Astin', 0, 1),
(8523, 'Astorri', 0, 1),
(8524, 'Astudillo', 0, 1),
(8525, 'Asuaje', 0, 1),
(8526, 'Atchison', 0, 1),
(8527, 'Atchley', 0, 1),
(8528, 'Athas', 0, 1),
(8529, 'Atilano', 0, 1),
(8530, 'Atkins', 0, 1),
(8531, 'Atlanta', 0, 1),
(8532, 'Atlee', 0, 1),
(8533, 'Aubrey', 0, 1),
(8534, 'Aucoin', 0, 1),
(8535, 'Aude', 0, 1),
(8536, 'Auer', 0, 1),
(8537, 'Augenstein', 0, 1),
(8538, 'Aumont', 0, 1),
(8539, 'Aune', 0, 1),
(8540, 'Aurilia', 0, 1),
(8541, 'Ausmus', 0, 1),
(8542, 'Austin', 0, 1),
(8543, 'Autrey', 0, 1),
(8544, 'Avedano', 0, 1),
(8545, 'Avelino', 0, 1),
(8546, 'Aven', 0, 1),
(8547, 'Averette', 0, 1),
(8548, 'Avery', 0, 1),
(8549, 'Avila', 0, 1),
(8550, 'Avilan', 0, 1),
(8551, 'Aviles', 0, 1),
(8552, 'Axelrod', 0, 1),
(8553, 'Axelson', 0, 1),
(8554, 'Axford', 0, 1),
(8555, 'Ayala', 0, 1),
(8556, 'Aybar', 0, 1),
(8557, 'Ayers', 0, 1),
(8558, 'Ayrault', 0, 1),
(8559, 'Azocar', 0, 1),
(8560, 'Babin', 0, 1),
(8561, 'Babineau', 0, 1),
(8562, 'Babrick', 0, 1),
(8563, 'Bachanov', 0, 1),
(8564, 'Bachar', 0, 1),
(8565, 'Backe', 0, 1),
(8566, 'Bacon', 0, 1),
(8567, 'Bacot', 0, 1),
(8568, 'Bacsik', 0, 1),
(8569, 'Bacus', 0, 1),
(8570, 'Baddoo', 0, 1),
(8571, 'Badeaux', 0, 1),
(8572, 'Badenhop', 0, 1),
(8573, 'Bader', 0, 1),
(8574, 'Bae', 0, 1),
(8575, 'Baek', 0, 1),
(8576, 'Baerga', 0, 1),
(8577, 'Baerlocher', 0, 1),
(8578, 'Baez', 0, 1),
(8579, 'Bagwell', 0, 1),
(8580, 'Bailes', 0, 1),
(8581, 'Bailey', 0, 1),
(8582, 'Baines', 0, 1),
(8583, 'Baird', 0, 1),
(8584, 'Baisley', 0, 1),
(8585, 'Bajenaru', 0, 1),
(8586, 'Baker', 0, 1),
(8587, 'Bako', 0, 1),
(8588, 'Balaguert', 0, 1),
(8589, 'Balcom-Miller', 0, 1),
(8590, 'Baldelli', 0, 1),
(8591, 'Baldiris', 0, 1),
(8592, 'Baldoquin', 0, 1),
(8593, 'Baldwin', 0, 1),
(8594, 'Baldwin III', 0, 1),
(8595, 'Bale', 0, 1),
(8596, 'Balentien', 0, 1),
(8597, 'Balester', 0, 1),
(8598, 'Balfour', 0, 1),
(8599, 'Balkcom', 0, 1),
(8600, 'Ball', 0, 1),
(8601, 'Ballard', 0, 1),
(8602, 'Ballew', 0, 1),
(8603, 'Ballouli', 0, 1),
(8604, 'Balog', 0, 1),
(8605, 'Baltz', 0, 1),
(8606, 'Banda', 0, 1),
(8607, 'Bandy', 0, 1),
(8608, 'Banks', 0, 1),
(8609, 'Bankston', 0, 1),
(8610, 'Bannister', 0, 1),
(8611, 'Bannon', 0, 1),
(8612, 'Bantz', 0, 1),
(8613, 'Banuelos', 0, 1),
(8614, 'Banwart', 0, 1),
(8615, 'Baptist', 0, 1),
(8616, 'Barajas', 0, 1),
(8617, 'Barba', 0, 1),
(8618, 'Barbato', 0, 1),
(8619, 'Barber', 0, 1),
(8620, 'Barberie', 0, 1),
(8621, 'Barbosa', 0, 1),
(8622, 'Barcelo', 0, 1),
(8623, 'Bard', 0, 1),
(8624, 'Barden', 0, 1),
(8625, 'Barfield', 0, 1),
(8626, 'Bargas', 0, 1),
(8627, 'Barker', 0, 1),
(8628, 'Barkett', 0, 1),
(8629, 'Barkley', 0, 1),
(8630, 'Barley', 0, 1),
(8631, 'Barlow', 0, 1),
(8632, 'Barmes', 0, 1),
(8633, 'Barnes', 0, 1),
(8634, 'Barnese', 0, 1),
(8635, 'Barnett', 0, 1),
(8636, 'Barnette', 0, 1),
(8637, 'Barney', 0, 1),
(8638, 'Barnhart', 0, 1),
(8639, 'Barnum', 0, 1),
(8640, 'Barnwell', 0, 1),
(8641, 'Baron', 0, 1),
(8642, 'Barone', 0, 1),
(8643, 'Barraclough', 0, 1),
(8644, 'Barratt', 0, 1),
(8645, 'Barrera', 0, 1),
(8646, 'Barreto', 0, 1),
(8647, 'Barrett', 0, 1),
(8648, 'Barria', 0, 1),
(8649, 'Barrie', 0, 1),
(8650, 'Barrios', 0, 1),
(8651, 'Barron', 0, 1),
(8652, 'Barry', 0, 1),
(8653, 'Bartee', 0, 1),
(8654, 'Barthmaier', 0, 1),
(8655, 'Bartlett', 0, 1),
(8656, 'Bartolone', 0, 1),
(8657, 'Barton', 0, 1),
(8658, 'Bartosh', 0, 1),
(8659, 'Bartsch', 0, 1),
(8660, 'Barzilla', 0, 1),
(8661, 'Barzoban', 0, 1),
(8662, 'Basabe', 0, 1),
(8663, 'Basak', 0, 1),
(8664, 'Bascom', 0, 1),
(8665, 'Basham', 0, 1),
(8666, 'Bashlor', 0, 1),
(8667, 'Bashore', 0, 1),
(8668, 'Basner', 0, 1),
(8669, 'Bass', 0, 1),
(8670, 'Bassitt', 0, 1),
(8671, 'Bastardo', 0, 1),
(8672, 'Basto', 0, 1),
(8673, 'Batchelor', 0, 1),
(8674, 'Bateman', 0, 1),
(8675, 'Bates', 0, 1),
(8676, 'Batista', 0, 1),
(8677, 'Batiste', 0, 1),
(8678, 'Battle', 0, 1),
(8679, 'Batts', 0, 1),
(8680, 'Bauer', 0, 1),
(8681, 'Bauers', 0, 1),
(8682, 'Baugh', 0, 1),
(8683, 'Baughman', 0, 1),
(8684, 'Baumann', 0, 1),
(8685, 'Bauserman', 0, 1),
(8686, 'Bausher', 0, 1),
(8687, 'Bautista', 0, 1),
(8688, 'Bawcom', 0, 1),
(8689, 'Baxendale', 0, 1),
(8690, 'Baxter', 0, 1),
(8691, 'Bay', 0, 1),
(8692, 'Bayliss', 0, 1),
(8693, 'Baz', 0, 1),
(8694, 'Bazardo', 0, 1),
(8695, 'Bazzell', 0, 1),
(8696, 'Beachy', 0, 1),
(8697, 'Beam', 0, 1),
(8698, 'Beamon', 0, 1),
(8699, 'Bean', 0, 1),
(8700, 'Bear', 0, 1),
(8701, 'Beato', 0, 1),
(8702, 'Beattie', 0, 1),
(8703, 'Beaty', 0, 1),
(8704, 'Beaulac', 0, 1),
(8705, 'Beavan', 0, 1),
(8706, 'Becerra', 0, 1),
(8707, 'Bechler', 0, 1),
(8708, 'Bechtold', 0, 1),
(8709, 'Beck', 0, 1),
(8710, 'Becker', 0, 1),
(8711, 'Beckett', 0, 1),
(8712, 'Beckham', 0, 1),
(8713, 'Beckstead', 0, 1),
(8714, 'Beckwith', 0, 1),
(8715, 'Bedard', 0, 1),
(8716, 'Beddes', 0, 1),
(8717, 'Bednar', 0, 1),
(8718, 'Bedrosian', 0, 1),
(8719, 'Beech', 0, 1),
(8720, 'Beede', 0, 1),
(8721, 'Beeker', 0, 1),
(8722, 'Beeks', 0, 1),
(8723, 'Beeler', 0, 1),
(8724, 'Beerer', 0, 1),
(8725, 'Begg', 0, 1),
(8726, 'Beime', 0, 1),
(8727, 'Beimel', 0, 1),
(8728, 'Beirne', 0, 1),
(8729, 'Belcher', 0, 1),
(8730, 'Belen', 0, 1),
(8731, 'Belfiore', 0, 1),
(8732, 'Belge', 0, 1),
(8733, 'Belinda', 0, 1),
(8734, 'Belisario', 0, 1),
(8735, 'Belisle', 0, 1),
(8736, 'Belitz', 0, 1),
(8737, 'Beliveau', 0, 1),
(8738, 'Belizario', 0, 1),
(8739, 'Belk', 0, 1),
(8740, 'Bell', 0, 1),
(8741, 'Bellamy', 0, 1),
(8742, 'Bellatti', 0, 1),
(8743, 'Belle', 0, 1),
(8744, 'Bellhorn', 0, 1),
(8745, 'Belliard', 0, 1),
(8746, 'Bellinger', 0, 1),
(8747, 'Bello', 0, 1),
(8748, 'Bellorin', 0, 1),
(8749, 'Bellows', 0, 1),
(8750, 'Belnome', 0, 1),
(8751, 'Belonis', 0, 1),
(8752, 'Below', 0, 1),
(8753, 'Belt', 0, 1),
(8754, 'Beltran', 0, 1),
(8755, 'Beltre', 0, 1),
(8756, 'Benard', 0, 1),
(8757, 'Benavente', 0, 1),
(8758, 'Bencosme', 0, 1),
(8759, 'Benedetti', 0, 1),
(8760, 'Benes', 0, 1),
(8761, 'Benham', 0, 1),
(8762, 'Benintendi', 0, 1),
(8763, 'Benitez', 0, 1),
(8764, 'Benjamin', 0, 1),
(8765, 'Bennett', 0, 1),
(8766, 'Beno', 0, 1),
(8767, 'Benoit', 0, 1),
(8768, 'Benson', 0, 1),
(8769, 'Bentz', 0, 1),
(8770, 'Berardi', 0, 1),
(8771, 'Beras', 0, 1),
(8772, 'Berblinger', 0, 1),
(8773, 'Bere', 0, 1),
(8774, 'Beresford', 0, 1),
(8775, 'Berg', 0, 1),
(8776, 'Berger', 0, 1),
(8777, 'Bergeron', 0, 1),
(8778, 'Bergesen', 0, 1),
(8779, 'Berglund', 0, 1),
(8780, 'Bergman', 0, 1),
(8781, 'Bergmann', 0, 1),
(8782, 'Bergolla', 0, 1),
(8783, 'Berken', 0, 1),
(8784, 'Berkman', 0, 1),
(8785, 'Berlind', 0, 1),
(8786, 'Bernadina', 0, 1),
(8787, 'Bernard', 0, 1),
(8788, 'Bernero', 0, 1),
(8789, 'Bernier', 0, 1),
(8790, 'Berrios', 0, 1),
(8791, 'Berroa', 0, 1),
(8792, 'Berry', 0, 1),
(8793, 'Berryhill', 0, 1),
(8794, 'Berti', 0, 1),
(8795, 'Bertotti', 0, 1),
(8796, 'Berumen', 0, 1),
(8797, 'Betances', 0, 1),
(8798, 'Betancourt', 0, 1),
(8799, 'Betemit', 0, 1),
(8800, 'Bethancourt', 0, 1),
(8801, 'Betsill', 0, 1),
(8802, 'Bettis', 0, 1),
(8803, 'Betts', 0, 1),
(8804, 'Beverlin', 0, 1),
(8805, 'Bevil', 0, 1),
(8806, 'Bevis', 0, 1),
(8807, 'Biagini', 0, 1),
(8808, 'Bianchi', 0, 1),
(8809, 'Bianco', 0, 1),
(8810, 'Biangini', 0, 1),
(8811, 'Bianucci', 0, 1),
(8812, 'Bibbs', 0, 1),
(8813, 'Bibens-Dirkx', 0, 1),
(8814, 'Bichette', 0, 1),
(8815, 'Bichette Jr.', 0, 1),
(8816, 'Bickford', 0, 1),
(8817, 'Bicondoa', 0, 1),
(8818, 'Biddle', 0, 1),
(8819, 'BiddleX', 0, 1),
(8820, 'Bieber', 0, 1),
(8821, 'Bielecki', 0, 1),
(8822, 'Biell', 0, 1),
(8823, 'Bierbrodt', 0, 1),
(8824, 'Bierd', 0, 1),
(8825, 'Biery', 0, 1),
(8826, 'Bieser', 0, 1),
(8827, 'Bigbie', 0, 1),
(8828, 'Biggio', 0, 1),
(8829, 'Billings', 0, 1),
(8830, 'Billingsley', 0, 1),
(8831, 'Billo', 0, 1),
(8832, 'Binford', 0, 1),
(8833, 'Binick', 0, 1),
(8834, 'Bird', 0, 1),
(8835, 'Birkins', 0, 1),
(8836, 'Bisenius', 0, 1),
(8837, 'Bishop', 0, 1),
(8838, 'Bisson', 0, 1),
(8839, 'Bittle', 0, 1),
(8840, 'Bittner', 0, 1),
(8841, 'Bivens', 0, 1),
(8842, 'Bixler', 0, 1),
(8843, 'Blach', 0, 1),
(8844, 'Black', 0, 1),
(8845, 'Blackburn', 0, 1),
(8846, 'Blackley', 0, 1),
(8847, 'Blackmar', 0, 1),
(8848, 'Blackmon', 0, 1),
(8849, 'Blackwell', 0, 1),
(8850, 'Bladergroen', 0, 1),
(8851, 'Blair', 0, 1),
(8852, 'Blake', 0, 1),
(8853, 'Blalock', 0, 1),
(8854, 'Blanco', 0, 1),
(8855, 'Bland', 0, 1),
(8856, 'Blandford', 0, 1),
(8857, 'Blandino', 0, 1),
(8858, 'Blank', 0, 1),
(8859, 'Blanke', 0, 1),
(8860, 'Blankenhorn', 0, 1),
(8861, 'Blanks', 0, 1),
(8862, 'Blanton', 0, 1),
(8863, 'Blasdell', 0, 1),
(8864, 'Blash', 0, 1),
(8865, 'Blaski', 0, 1),
(8866, 'Blasko', 0, 1),
(8867, 'Blauser', 0, 1),
(8868, 'Blazek', 0, 1),
(8869, 'Blazier', 0, 1),
(8870, 'Bleich', 0, 1),
(8871, 'Bleier', 0, 1),
(8872, 'Blevins', 0, 1),
(8873, 'Blewett', 0, 1),
(8874, 'Blood', 0, 1),
(8875, 'Bloom', 0, 1),
(8876, 'Bloomquist', 0, 1),
(8877, 'Blowers', 0, 1),
(8878, 'Blue', 0, 1),
(8879, 'Blum', 0, 1),
(8880, 'Bluma', 0, 1),
(8881, 'Blyleven', 0, 1),
(8882, 'Bocachica', 0, 1),
(8883, 'Bochtler', 0, 1),
(8884, 'Bochy', 0, 1),
(8885, 'Bocock', 0, 1),
(8886, 'Boehringer', 0, 1),
(8887, 'Boer', 0, 1),
(8888, 'Boesch', 0, 1),
(8889, 'Boeve', 0, 1),
(8890, 'Boever', 0, 1),
(8891, 'Bogaerts', 0, 1),
(8892, 'Bogar', 0, 1),
(8893, 'Boggan', 0, 1),
(8894, 'Boggs', 0, 1),
(8895, 'Bogusevic', 0, 1),
(8896, 'Bohanon', 0, 1),
(8897, 'Bohn', 0, 1),
(8898, 'Bolanos', 0, 1),
(8899, 'Bolden', 0, 1),
(8900, 'Boldt', 0, 1),
(8901, 'Boleska', 0, 1),
(8902, 'Bolick', 0, 1),
(8903, 'Bolivar', 0, 1),
(8904, 'Bolsinger', 0, 1),
(8905, 'Bolt', 0, 1),
(8906, 'Bond', 0, 1),
(8907, 'Bonderman', 0, 1),
(8908, 'Bonds', 0, 1),
(8909, 'Bones', 0, 1),
(8910, 'Bong', 0, 1),
(8911, 'Bonifacio', 0, 1),
(8912, 'Bonifay', 0, 1),
(8913, 'Bonilla', 0, 1),
(8914, 'Bonine', 0, 1),
(8915, 'Bonnin', 0, 1),
(8916, 'Bono', 0, 1),
(8917, 'Bonser', 0, 1),
(8918, 'Bonvechio', 0, 1),
(8919, 'Booker', 0, 1),
(8920, 'Boone', 0, 1),
(8921, 'Bootcheck', 0, 1),
(8922, 'Boothe', 0, 1),
(8923, 'Booty', 0, 1),
(8924, 'Borbon', 0, 1),
(8925, 'Borchard', 0, 1),
(8926, 'Borchering', 0, 1),
(8927, 'Borden', 0, 1),
(8928, 'Borders', 0, 1),
(8929, 'Bordick', 0, 1),
(8930, 'Borenstein', 0, 1),
(8931, 'Borkowski', 0, 1),
(8932, 'Borland', 0, 1),
(8933, 'Bormann', 0, 1),
(8934, 'Borner', 0, 1),
(8935, 'Borowski', 0, 1),
(8936, 'Borquin', 0, 1),
(8937, 'Borrell', 0, 1),
(8938, 'Bortnick', 0, 1),
(8939, 'Borucki', 0, 1),
(8940, 'Boscan', 0, 1),
(8941, 'Boshers', 0, 1),
(8942, 'Bosio', 0, 1),
(8943, 'Boskie', 0, 1),
(8944, 'Boss', 0, 1),
(8945, 'Bostick', 0, 1),
(8946, 'Bote', 0, 1),
(8947, 'Bott', 0, 1),
(8948, 'Bottalico', 0, 1),
(8949, 'Bottenfield', 0, 1),
(8950, 'Botts', 0, 1),
(8951, 'Bouchard', 0, 1),
(8952, 'Bouchie', 0, 1),
(8953, 'Bouknight', 0, 1),
(8954, 'Boumtje', 0, 1),
(8955, 'Bour', 0, 1),
(8956, 'Bourgeois', 0, 1),
(8957, 'Bourjos', 0, 1),
(8958, 'Bourn', 0, 1),
(8959, 'Bournigal', 0, 1),
(8960, 'Bourquin', 0, 1),
(8961, 'Bousfield', 0, 1),
(8962, 'Boutwell', 0, 1),
(8963, 'Bovee', 0, 1),
(8964, 'Bowden', 0, 1),
(8965, 'Bowe', 0, 1),
(8966, 'Bowen', 0, 1),
(8967, 'Bowers', 0, 1),
(8968, 'Bowie', 0, 1),
(8969, 'Bowker', 0, 1),
(8970, 'Bowles', 0, 1),
(8971, 'Bowman', 0, 1),
(8972, 'Bowyer', 0, 1),
(8973, 'Boxberger', 0, 1),
(8974, 'Boyd', 0, 1),
(8975, 'Boyer', 0, 1),
(8976, 'Bozied', 0, 1),
(8977, 'Brach', 0, 1),
(8978, 'Bracho', 0, 1),
(8979, 'Brackman', 0, 1),
(8980, 'Braddock', 0, 1),
(8981, 'Braden', 0, 1),
(8982, 'Bradford', 0, 1),
(8983, 'Bradley', 0, 1),
(8984, 'Bradshaw', 0, 1),
(8985, 'Brady', 0, 1),
(8986, 'Bragg', 0, 1),
(8987, 'Bramhall', 0, 1),
(8988, 'Brammer', 0, 1),
(8989, 'Brandenburg', 0, 1),
(8990, 'Brandt', 0, 1),
(8991, 'Branham', 0, 1),
(8992, 'Brannan', 0, 1),
(8993, 'Brannen', 0, 1),
(8994, 'Branson', 0, 1),
(8995, 'Brantley', 0, 1),
(8996, 'Brantly', 0, 1),
(8997, 'Branyan', 0, 1),
(8998, 'Brasier', 0, 1),
(8999, 'Brasoban', 0, 1),
(9000, 'Brault', 0, 1),
(9001, 'Braun', 0, 1),
(9002, 'Bray', 0, 1),
(9003, 'Brazell', 0, 1),
(9004, 'Brazelton', 0, 1),
(9005, 'Brazis', 0, 1),
(9006, 'Brazoban', 0, 1),
(9007, 'Brea', 0, 1),
(9008, 'Brebbia', 0, 1),
(9009, 'Brede', 0, 1),
(9010, 'Bregman', 0, 1),
(9011, 'Breit', 0, 1),
(9012, 'Brejtfus', 0, 1),
(9013, 'Brennan', 0, 1),
(9014, 'Brentz', 0, 1),
(9015, 'Breslow', 0, 1),
(9016, 'Bresnahan', 0, 1),
(9017, 'Bresnehan', 0, 1),
(9018, 'Brester', 0, 1),
(9019, 'Brett', 0, 1),
(9020, 'Brewer', 0, 1),
(9021, 'Brewington', 0, 1),
(9022, 'Brice', 0, 1),
(9023, 'Briceno', 0, 1),
(9024, 'Brickhouse', 0, 1),
(9025, 'Bridges', 0, 1),
(9026, 'Bridwell', 0, 1),
(9027, 'Brigham', 0, 1),
(9028, 'Brigman', 0, 1),
(9029, 'Brignac', 0, 1),
(9030, 'Brinkley', 0, 1),
(9031, 'Brinson', 0, 1),
(9032, 'Brisker', 0, 1),
(9033, 'Bristow', 0, 1),
(9034, 'Brito', 0, 1),
(9035, 'Britton', 0, 1),
(9036, 'Broadway', 0, 1),
(9037, 'Brocail', 0, 1),
(9038, 'Brock', 0, 1),
(9039, 'Broderick', 0, 1),
(9040, 'Brodey', 0, 1),
(9041, 'Brogna', 0, 1),
(9042, 'Brohawn', 0, 1),
(9043, 'Bromberg', 0, 1),
(9044, 'Brooks', 0, 1),
(9045, 'Brosius', 0, 1),
(9046, 'Brothers', 0, 1),
(9047, 'Broussard', 0, 1),
(9048, 'Brow', 0, 1),
(9049, 'Brower', 0, 1),
(9050, 'Brown', 0, 1),
(9051, 'Browning', 0, 1),
(9052, 'Brownlie', 0, 1),
(9053, 'Brownson', 0, 1),
(9054, 'Broxton', 0, 1),
(9055, 'Bruback', 0, 1),
(9056, 'Bruce', 0, 1),
(9057, 'Brugman', 0, 1),
(9058, 'Brujan', 0, 1),
(9059, 'Brumbaugh', 0, 1),
(9060, 'Brumfield', 0, 1),
(9061, 'Brummett', 0, 1),
(9062, 'Brunette', 0, 1),
(9063, 'Bruney', 0, 1),
(9064, 'Brunson', 0, 1),
(9065, 'Bruntlett', 0, 1),
(9066, 'Brusa', 0, 1),
(9067, 'Bruske', 0, 1),
(9068, 'Bruso', 0, 1),
(9069, 'Bryan', 0, 1),
(9070, 'Bryant', 0, 1),
(9071, 'Bryson', 0, 1),
(9072, 'Bubela', 0, 1),
(9073, 'Bucardo', 0, 1),
(9074, 'Bucci', 0, 1),
(9075, 'Buchanan', 0, 1),
(9076, 'Buchholz', 0, 1),
(9077, 'Buchmann', 0, 1),
(9078, 'Buchter', 0, 1),
(9079, 'Buck', 0, 1),
(9080, 'Buckel', 0, 1),
(9081, 'Buckley', 0, 1),
(9082, 'Buckner', 0, 1),
(9083, 'Bucktrot', 0, 1),
(9084, 'Budde', 0, 1),
(9085, 'Buddie', 0, 1),
(9086, 'Budzinski', 0, 1),
(9087, 'Buehler', 0, 1),
(9088, 'Buehrle', 0, 1),
(9089, 'Bueno', 0, 1),
(9090, 'Buente', 0, 1),
(9091, 'Buford', 0, 1),
(9092, 'Buglovsky', 0, 1),
(9093, 'Buhner', 0, 1),
(9094, 'Bukauskas', 0, 1),
(9095, 'Bukvich', 0, 1),
(9096, 'Bulger', 0, 1),
(9097, 'Bullett', 0, 1),
(9098, 'Bullinger', 0, 1),
(9099, 'Bullington', 0, 1),
(9100, 'Bullock', 0, 1),
(9101, 'Bumgarner', 0, 1),
(9102, 'Bummer', 0, 1),
(9103, 'Bump', 0, 1),
(9104, 'Bumstead', 0, 1),
(9105, 'Bunch', 0, 1),
(9106, 'Bundy', 0, 1),
(9107, 'Bunton', 0, 1),
(9108, 'Burawa', 0, 1),
(9109, 'Burba', 0, 1),
(9110, 'Burch', 0, 1),
(9111, 'Burdi', 0, 1),
(9112, 'Burgamy', 0, 1),
(9113, 'Burger', 0, 1),
(9114, 'Burgess', 0, 1),
(9115, 'Burgoon', 0, 1),
(9116, 'Burgos', 0, 1),
(9117, 'Burke', 0, 1),
(9118, 'Burkett', 0, 1),
(9119, 'Burkhart', 0, 1),
(9120, 'Burks', 0, 1),
(9121, 'Burnes', 0, 1),
(9122, 'Burnett', 0, 1),
(9123, 'Burnitz', 0, 1),
(9124, 'Burns', 0, 1),
(9125, 'Burnside', 0, 1),
(9126, 'Burrell', 0, 1),
(9127, 'Burres', 0, 1),
(9128, 'Burriss', 0, 1),
(9129, 'Burroughs', 0, 1),
(9130, 'Burrows', 0, 1),
(9131, 'Burrus', 0, 1),
(9132, 'Burt', 0, 1),
(9133, 'Burt Jr.', 0, 1),
(9134, 'Burton', 0, 1),
(9135, 'Busby', 0, 1),
(9136, 'Busch', 0, 1),
(9137, 'Buscher', 0, 1),
(9138, 'Buschini', 0, 1),
(9139, 'Buschmann', 0, 1),
(9140, 'Busenitz', 0, 1),
(9141, 'Bush', 0, 1),
(9142, 'Bushue', 0, 1),
(9143, 'Buss', 0, 1),
(9144, 'Butcher', 0, 1),
(9145, 'Butera', 0, 1),
(9146, 'Butia', 0, 1),
(9147, 'Butler', 0, 1),
(9148, 'Butterworth', 0, 1),
(9149, 'Buttler', 0, 1),
(9150, 'Butto', 0, 1),
(9151, 'Buttrey', 0, 1),
(9152, 'Buxton', 0, 1),
(9153, 'Buzachero', 0, 1),
(9154, 'Bxxxxxx', 0, 0),
(9155, 'Byler', 0, 1),
(9156, 'Bynum', 0, 1),
(9157, 'Byrd', 0, 1),
(9158, 'Byrdak', 0, 1),
(9159, 'Byrnes', 0, 1),
(9160, 'Bywater', 0, 1),
(9161, 'Caballero', 0, 1),
(9162, 'Cabbage', 0, 1),
(9163, 'Cabello', 0, 1),
(9164, 'Cabezas', 0, 1),
(9165, 'Cabral', 0, 1),
(9166, 'Cabrera', 0, 1),
(9167, 'Caceres', 0, 1),
(9168, 'Cadaret', 0, 1),
(9169, 'Cahill', 0, 1),
(9170, 'Cain', 0, 1),
(9171, 'Cairncross', 0, 1),
(9172, 'Cairo', 0, 1),
(9173, 'Calderone', 0, 1),
(9174, 'Caldwell', 0, 1),
(9175, 'Calero', 0, 1),
(9176, 'Calhoun', 0, 1),
(9177, 'Cali', 0, 1),
(9178, 'Calixte', 0, 1),
(9179, 'Call', 0, 1),
(9180, 'Callahan', 0, 1),
(9181, 'Callaspo', 0, 1),
(9182, 'Callaway', 0, 1),
(9183, 'Calloway', 0, 1),
(9184, 'Calomeni', 0, 1),
(9185, 'Calzado', 0, 1),
(9186, 'Camacaro', 0, 1),
(9187, 'Camargo', 0, 1),
(9188, 'Cameron', 0, 1),
(9189, 'Caminero', 0, 1),
(9190, 'Caminiti', 0, 1),
(9191, 'Cammack', 0, 1),
(9192, 'Camp', 0, 1),
(9193, 'Campana', 0, 1),
(9194, 'Campbell', 0, 1),
(9195, 'Campillo', 0, 1),
(9196, 'Campos', 0, 1),
(9197, 'Campusano', 0, 1),
(9198, 'Canario', 0, 1),
(9199, 'Cancel', 0, 1),
(9200, 'Candaele', 0, 1),
(9201, 'Candelario', 0, 1),
(9202, 'Candiotti', 0, 1),
(9203, 'Canelo', 0, 1),
(9204, 'Cangelosi', 0, 1),
(9205, 'Canha', 0, 1),
(9206, 'Canham', 0, 1),
(9207, 'Canizares', 0, 1),
(9208, 'Canizaro', 0, 1),
(9209, 'Canning', 0, 1),
(9210, 'Cannizaro', 0, 1),
(9211, 'Cannon', 0, 1),
(9212, 'Cano', 0, 1),
(9213, 'Canseco', 0, 1),
(9214, 'Cantrell', 0, 1),
(9215, 'Cantu', 0, 1),
(9216, 'Cantwell', 0, 1),
(9217, 'Canzler', 0, 1),
(9218, 'Capel', 0, 1),
(9219, 'Capellan', 0, 1),
(9220, 'Caple', 0, 1),
(9221, 'Capps', 0, 1),
(9222, 'Capra', 0, 1),
(9223, 'Capuano', 0, 1),
(9224, 'Caradonna', 0, 1),
(9225, 'Carasiti', 0, 1),
(9226, 'Caratini', 0, 1),
(9227, 'Carbonell', 0, 1),
(9228, 'Cardenas', 0, 1),
(9229, 'Cardona', 0, 1),
(9230, 'Cardullo', 0, 1),
(9231, 'Carey', 0, 1),
(9232, 'Caridad', 0, 1),
(9233, 'Carignan', 0, 1),
(9234, 'Carle', 0, 1),
(9235, 'Carlin', 0, 1),
(9236, 'Carlson', 0, 1),
(9237, 'Carlyle', 0, 1),
(9238, 'Carmichael', 0, 1),
(9239, 'Carmona', 0, 1),
(9240, 'Caro', 0, 1),
(9241, 'Carp', 0, 1),
(9242, 'Carpenter', 0, 1),
(9243, 'Carpio', 0, 1),
(9244, 'Carr', 0, 1),
(9245, 'Carrara', 0, 1),
(9246, 'Carrasco', 0, 1),
(9247, 'Carraway', 0, 1),
(9248, 'Carreno', 0, 1),
(9249, 'Carreon', 0, 1),
(9250, 'Carrera', 0, 1),
(9251, 'Carreras', 0, 1),
(9252, 'Carrier-Ward', 0, 1),
(9253, 'Carrillo', 0, 1),
(9254, 'Carrithers', 0, 1),
(9255, 'Carrizales', 0, 1),
(9256, 'Carroll', 0, 1),
(9257, 'Carson', 0, 1),
(9258, 'Carte', 0, 1),
(9259, 'Carter', 0, 1),
(9260, 'Caruso', 0, 1),
(9261, 'Carvajal', 0, 1),
(9262, 'Carver', 0, 1),
(9263, 'Casali', 0, 1),
(9264, 'Casanova', 0, 1),
(9265, 'Case', 0, 1),
(9266, 'Casey', 0, 1),
(9267, 'Cash', 0, 1),
(9268, 'Cashner', 0, 1),
(9269, 'Casian', 0, 1),
(9270, 'Casilla', 0, 1),
(9271, 'Casimiro', 0, 1),
(9272, 'Cassel', 0, 1),
(9273, 'Cassevah', 0, 1),
(9274, 'Cassidy', 0, 1),
(9275, 'Castaneda', 0, 1),
(9276, 'Castano', 0, 1),
(9277, 'Casteel', 0, 1),
(9278, 'Castellani', 0, 1),
(9279, 'Castellano', 0, 1),
(9280, 'Castellanos', 0, 1),
(9281, 'Castilla', 0, 1),
(9282, 'Castillo', 0, 1),
(9283, 'Casto', 0, 1),
(9284, 'Castro', 0, 1),
(9285, 'Catalanotto', 0, 1),
(9286, 'Cate', 0, 1),
(9287, 'Cates', 0, 1),
(9288, 'Cather', 0, 1),
(9289, 'Catricala', 0, 1),
(9290, 'Cavazos', 0, 1),
(9291, 'Cavazos-Galvez', 0, 1),
(9292, 'Cave', 0, 1),
(9293, 'Cayones', 0, 1),
(9294, 'Cease', 0, 1),
(9295, 'Cecchini', 0, 1),
(9296, 'Cecil', 0, 1),
(9297, 'Ceciliani', 0, 1),
(9298, 'Ceda', 0, 1),
(9299, 'Cedeno', 0, 1),
(9300, 'Cederoth', 0, 1),
(9301, 'Cedrola', 0, 1),
(9302, 'Cegarra', 0, 1),
(9303, 'Celestino', 0, 1),
(9304, 'Centeno', 0, 1),
(9305, 'Cepeda', 0, 1),
(9306, 'Cephas', 0, 1),
(9307, 'Cepicky', 0, 1),
(9308, 'Cerda', 0, 1),
(9309, 'Cerros', 0, 1),
(9310, 'Cerse', 0, 1),
(9311, 'Cervelli', 0, 1),
(9312, 'Cervenak', 0, 1),
(9313, 'Cervenka', 0, 1),
(9314, 'Cespedes', 0, 1),
(9315, 'Cessa', 0, 1),
(9316, 'Chacin', 0, 1),
(9317, 'Chacon', 0, 1),
(9318, 'Chaffee', 0, 1),
(9319, 'Chafin', 0, 1),
(9320, 'Chalas', 0, 1),
(9321, 'Chalk', 0, 1),
(9322, 'Chalmers', 0, 1),
(9323, 'Chamberlain', 0, 1),
(9324, 'Chambers', 0, 1),
(9325, 'Chamblee', 0, 1),
(9326, 'Chang', 0, 1),
(9327, 'Chantres', 0, 1),
(9328, 'Chao', 0, 1),
(9329, 'Chapman', 0, 1),
(9330, 'Chargois', 0, 1),
(9331, 'Charles', 0, 1),
(9332, 'Charlton', 0, 1),
(9333, 'Chatham', 0, 1),
(9334, 'Chatwood', 0, 1),
(9335, 'Chavarez', 0, 1),
(9336, 'Chaves', 0, 1),
(9337, 'Chavez', 0, 1),
(9338, 'Chavis', 0, 1),
(9339, 'Checo', 0, 1),
(9340, 'Cheeseits', 0, 1),
(9341, 'Chen', 0, 1),
(9342, 'Cheng', 0, 1),
(9343, 'Cherry', 0, 1),
(9344, 'Chiang', 0, 1),
(9345, 'Chiaramonte', 0, 1),
(9346, 'Chiaravalloti', 0, 1),
(9347, 'Chiasson', 0, 1),
(9348, 'Chiavacci', 0, 1),
(9349, 'Chick', 0, 1),
(9350, 'Chico', 0, 1),
(9351, 'Chigges', 0, 1),
(9352, 'Childers', 0, 1),
(9353, 'Childress', 0, 1),
(9354, 'Chirinos', 0, 1),
(9355, 'Chisek', 0, 1),
(9356, 'Chisenhall', 0, 1),
(9357, 'Chisholm', 0, 1),
(9358, 'Cho', 0, 1),
(9359, 'Choate', 0, 1),
(9360, 'Choi', 0, 1),
(9361, 'Choice', 0, 1),
(9362, 'Chong', 0, 1),
(9363, 'Chono', 0, 1),
(9364, 'Choo', 0, 1),
(9365, 'Chouinard', 0, 1),
(9366, 'Christensen', 0, 1),
(9367, 'Christenson', 0, 1),
(9368, 'Christian', 0, 1),
(9369, 'Christiani', 0, 1),
(9370, 'Christiansen', 0, 1),
(9371, 'Christianson', 0, 1),
(9372, 'Christman', 0, 1),
(9373, 'Christmastree', 0, 1),
(9374, 'Christopher', 0, 1),
(9375, 'Chulk', 0, 1),
(9376, 'Chung', 0, 1),
(9377, 'Church', 0, 1),
(9378, 'Cianfrocco', 0, 1),
(9379, 'Cimber', 0, 1),
(9380, 'Cingrani', 0, 1),
(9381, 'Cintron', 0, 1),
(9382, 'Ciofrone', 0, 1),
(9383, 'Ciolli', 0, 1),
(9384, 'Ciriaco', 0, 1),
(9385, 'Cirillo', 0, 1),
(9386, 'Cisco', 0, 1),
(9387, 'Cishek', 0, 1),
(9388, 'Cisnero', 0, 1),
(9389, 'Ciuffo', 0, 1),
(9390, 'Civale', 0, 1),
(9391, 'Claggett', 0, 1),
(9392, 'Claiborne', 0, 1),
(9393, 'Clapinski', 0, 1),
(9394, 'Clapp', 0, 1),
(9395, 'Clark', 0, 1),
(9396, 'Clarke', 0, 1),
(9397, 'Clarkin', 0, 1),
(9398, 'Claudio', 0, 1),
(9399, 'Claussen', 0, 1),
(9400, 'Clay', 0, 1),
(9401, 'Clayton', 0, 1),
(9402, 'Cleary', 0, 1),
(9403, 'Cleavinger', 0, 1),
(9404, 'Clem', 0, 1),
(9405, 'Clemens', 0, 1),
(9406, 'Clement', 0, 1),
(9407, 'Clemente', 0, 1),
(9408, 'Clementina', 0, 1),
(9409, 'Clemons', 0, 1),
(9410, 'Cleto', 0, 1),
(9411, 'Cleveland', 0, 1),
(9412, 'Clevenger', 0, 1),
(9413, 'Clevinger', 0, 1),
(9414, 'Clevlen', 0, 1),
(9415, 'Clifton', 0, 1),
(9416, 'Cline', 0, 1),
(9417, 'Clippard', 0, 1),
(9418, 'Clontz', 0, 1),
(9419, 'Closser', 0, 1),
(9420, 'Cloude', 0, 1),
(9421, 'Cloyd', 0, 1),
(9422, 'Clyburn', 0, 1),
(9423, 'Clyne', 0, 1),
(9424, 'Coats', 0, 1),
(9425, 'Cobb', 0, 1),
(9426, 'Coca', 0, 1),
(9427, 'Cochran', 0, 1),
(9428, 'Cochran-Gill', 0, 1),
(9429, 'Cockrell', 0, 1),
(9430, 'Coco', 0, 1),
(9431, 'Cody', 0, 1),
(9432, 'Coello', 0, 1),
(9433, 'Coenen', 0, 1),
(9434, 'Coffey', 0, 1),
(9435, 'Coffie', 0, 1),
(9436, 'Cofield', 0, 1),
(9437, 'Cogan', 0, 1),
(9438, 'Coggin', 0, 1),
(9439, 'Coghlan', 0, 1),
(9440, 'Cohoes', 0, 1),
(9441, 'Cohoon', 0, 1),
(9442, 'Coke', 0, 1),
(9443, 'Cokinos', 0, 1),
(9444, 'Colabello', 0, 1),
(9445, 'Colamarino', 0, 1),
(9446, 'Colangelo', 0, 1),
(9447, 'Colantonio', 0, 1),
(9448, 'Colbrunn', 0, 1),
(9449, 'Cole', 0, 1),
(9450, 'Coleman', 0, 1),
(9451, 'Coles', 0, 1),
(9452, 'Colina', 0, 1),
(9453, 'Collaro', 0, 1),
(9454, 'Collazo', 0, 1),
(9455, 'Collet', 0, 1),
(9456, 'Collett', 0, 1),
(9457, 'Collier', 0, 1),
(9458, 'Collins', 0, 1),
(9459, 'Collmenter', 0, 1),
(9460, 'Collup', 0, 1),
(9461, 'Collymore', 0, 1),
(9462, 'Cologne', 0, 1),
(9463, 'Colome', 0, 1),
(9464, 'Colon', 0, 1),
(9465, 'Colonel', 0, 1),
(9466, 'Colvin', 0, 1),
(9467, 'Colyer', 0, 1),
(9468, 'Comer', 0, 1),
(9469, 'Commings', 0, 1),
(9470, 'Concepcion', 0, 1),
(9471, 'Conder', 0, 1),
(9472, 'Condrey', 0, 1),
(9473, 'Cone', 0, 1),
(9474, 'Conforto', 0, 1),
(9475, 'Conger', 0, 1),
(9476, 'Conine', 0, 1),
(9477, 'Conley', 0, 1),
(9478, 'Conlon', 0, 1),
(9479, 'Connaughton', 0, 1),
(9480, 'Connell', 0, 1),
(9481, 'Connelly', 0, 1),
(9482, 'Conner', 0, 1),
(9483, 'Connolly', 0, 1),
(9484, 'Conrad', 0, 1),
(9485, 'Consigli', 0, 1),
(9486, 'Constanza', 0, 1),
(9487, 'Conti', 0, 1),
(9488, 'Contreras', 0, 1),
(9489, 'Converse', 0, 1),
(9490, 'Conway', 0, 1),
(9491, 'Cook', 0, 1),
(9492, 'Cooke', 0, 1),
(9493, 'Cookson', 0, 1),
(9494, 'Coolbaugh', 0, 1),
(9495, 'Coomer', 0, 1),
(9496, 'Coon', 0, 1),
(9497, 'Cooney', 0, 1),
(9498, 'Coonrod', 0, 1),
(9499, 'Cooper', 0, 1),
(9500, 'Copeland', 0, 1),
(9501, 'Coppinger', 0, 1),
(9502, 'Coquillette', 0, 1),
(9503, 'Cora', 0, 1),
(9504, 'Corbin', 0, 1),
(9505, 'Corcino', 0, 1),
(9506, 'Corcoran', 0, 1),
(9507, 'Cordell', 0, 1),
(9508, 'Cordemans', 0, 1),
(9509, 'Cordero', 0, 1),
(9510, 'Cordido', 0, 1),
(9511, 'Cordier', 0, 1),
(9512, 'Cordoba', 0, 1),
(9513, 'Cordova', 0, 1),
(9514, 'Corey', 0, 1),
(9515, 'Corgan', 0, 1),
(9516, 'Corley', 0, 1),
(9517, 'Cormier', 0, 1),
(9518, 'Corn', 0, 1),
(9519, 'Cornejo', 0, 1),
(9520, 'Cornelius', 0, 1),
(9521, 'Cornely', 0, 1),
(9522, 'Corona', 0, 1),
(9523, 'Coronado', 0, 1),
(9524, 'Corpas', 0, 1),
(9525, 'Corporan', 0, 1),
(9526, 'Corrado', 0, 1),
(9527, 'Correa', 0, 1),
(9528, 'Correia', 0, 1),
(9529, 'Correll', 0, 1),
(9530, 'Corry', 0, 1),
(9531, 'Corsaletti', 0, 1),
(9532, 'Corsi', 0, 1),
(9533, 'Cortes', 0, 1),
(9534, 'Cortez', 0, 1),
(9535, 'Cosart', 0, 1),
(9536, 'Cosby', 0, 1),
(9537, 'Costa', 0, 1),
(9538, 'Costanzo', 0, 1),
(9539, 'Coste', 0, 1),
(9540, 'Cota', 0, 1),
(9541, 'Cote', 0, 1),
(9542, 'Cotham', 0, 1),
(9543, 'Cotto', 0, 1),
(9544, 'Cotton', 0, 1),
(9545, 'Cotts', 0, 1),
(9546, 'Coulombe', 0, 1),
(9547, 'Coulter', 0, 1),
(9548, 'Counsell', 0, 1),
(9549, 'Court', 0, 1),
(9550, 'Cousino', 0, 1),
(9551, 'Cousins', 0, 1),
(9552, 'Coutlangus', 0, 1),
(9553, 'Covey', 0, 1),
(9554, 'Cowan', 0, 1),
(9555, 'Cowart', 0, 1),
(9556, 'Cowgill', 0, 1),
(9557, 'Cox', 0, 1),
(9558, 'Coyle', 0, 1),
(9559, 'Cozart', 0, 1),
(9560, 'Cozens', 0, 1),
(9561, 'Crabbe', 0, 1),
(9562, 'Crabtree', 0, 1),
(9563, 'Cradle', 0, 1),
(9564, 'Craig', 0, 1),
(9565, 'Crain', 0, 1),
(9566, 'Cramer', 0, 1),
(9567, 'Cravy', 0, 1),
(9568, 'Crawford', 0, 1),
(9569, 'Crede', 0, 1),
(9570, 'Creek', 0, 1),
(9571, 'Cremidan', 0, 1),
(9572, 'Crespo', 0, 1),
(9573, 'Cresse', 0, 1),
(9574, 'Cressend', 0, 1),
(9575, 'Crichton', 0, 1),
(9576, 'Crick', 0, 1),
(9577, 'Crim', 0, 1),
(9578, 'Crismatt', 0, 1),
(9579, 'Crisp', 0, 1),
(9580, 'Crist', 0, 1),
(9581, 'Crockett', 0, 1),
(9582, 'Cromer', 0, 1),
(9583, 'Cron', 0, 1),
(9584, 'Cronenworth', 0, 1),
(9585, 'Crosby', 0, 1),
(9586, 'Crotta', 0, 1),
(9587, 'Crouse', 0, 1),
(9588, 'Croushore', 0, 1),
(9589, 'Crouthers', 0, 1),
(9590, 'Crow', 0, 1),
(9591, 'Crowe', 0, 1),
(9592, 'Crowell', 0, 1),
(9593, 'Crozier', 0, 1),
(9594, 'Cruceta', 0, 1),
(9595, 'Crudale', 0, 1),
(9596, 'Cruse', 0, 1),
(9597, 'Cruz', 0, 1),
(9598, 'Crystal', 0, 1),
(9599, 'Cuadrado', 0, 1),
(9600, 'Cubillan', 0, 1),
(9601, 'Cuddyer', 0, 1),
(9602, 'Cuesta', 0, 1),
(9603, 'Cueto', 0, 1),
(9604, 'Cuevas', 0, 1),
(9605, 'Cuffman', 0, 1),
(9606, 'Culberson', 0, 1),
(9607, 'Culbreth', 0, 1),
(9608, 'Culp', 0, 1),
(9609, 'Culver', 0, 1),
(9610, 'Cumberland', 0, 1),
(9611, 'Cummings', 0, 1),
(9612, 'Cumpton', 0, 1),
(9613, 'Cunnane', 0, 1),
(9614, 'Cunniff', 0, 1),
(9615, 'Cunningham', 0, 1),
(9616, 'Curbelo', 0, 1),
(9617, 'Curletta', 0, 1),
(9618, 'Curry', 0, 1),
(9619, 'Curtice', 0, 1),
(9620, 'Curtis', 0, 1),
(9621, 'Curtiss', 0, 1),
(9622, 'Cusick', 0, 1),
(9623, 'Cust', 0, 1),
(9624, 'Cuthbert', 0, 1),
(9625, 'Cutler', 0, 1),
(9626, 'Cuyler', 0, 1),
(9627, 'Cyr', 0, 1),
(9628, 'Czarniecki', 0, 1),
(9629, 'Czyz', 0, 1),
(9630, 'DAmico', 0, 1),
(9631, 'DAntona', 0, 1),
(9632, 'dArnaud', 0, 1),
(9633, 'D.', 0, 1),
(9634, 'Daal', 0, 1),
(9635, 'Dae-sung', 0, 1),
(9636, 'Daeges', 0, 1),
(9637, 'Dahl', 0, 1),
(9638, 'Dahlstrand', 0, 1),
(9639, 'Daigle', 0, 1),
(9640, 'Dalbec', 0, 1),
(9641, 'Dale', 0, 1),
(9642, 'Dalesandro', 0, 1),
(9643, 'Daley', 0, 1),
(9644, 'Dalfonso', 0, 1),
(9645, 'Dalles', 0, 1),
(9646, 'Dallimore', 0, 1),
(9647, 'Damon', 0, 1),
(9648, 'Daneker', 0, 1),
(9649, 'Daniel', 0, 1),
(9650, 'Danielson', 0, 1),
(9651, 'Danish', 0, 1),
(9652, 'Danks', 0, 1),
(9653, 'Dannemiller', 0, 1),
(9654, 'Danner', 0, 1),
(9655, 'Darcy', 0, 1),
(9656, 'Darensbourg', 0, 1),
(9657, 'Darnell', 0, 1),
(9658, 'Darr', 0, 1),
(9659, 'Darrow', 0, 1),
(9660, 'Darvill', 0, 1),
(9661, 'Darvish', 0, 1),
(9662, 'Darwin', 0, 1),
(9663, 'Dascenzo', 0, 1),
(9664, 'Datres', 0, 1),
(9665, 'Daubach', 0, 1),
(9666, 'Daulton', 0, 1),
(9667, 'DaVanon', 0, 1),
(9668, 'Davenport', 0, 1),
(9669, 'Davey', 0, 1),
(9670, 'David', 0, 1),
(9671, 'Davidson', 0, 1),
(9672, 'Davies', 0, 1),
(9673, 'Davila', 0, 1),
(9674, 'Davis', 0, 1),
(9675, 'Davison', 0, 1),
(9676, 'Dawkins', 0, 1),
(9677, 'Dawley', 0, 1),
(9678, 'Dawson', 0, 1),
(9679, 'Day', 0, 1),
(9680, 'Dayton', 0, 1),
(9681, 'Daza', 0, 1),
(9682, 'De Aza', 0, 1),
(9683, 'De Fratus', 0, 1),
(9684, 'De Horta', 0, 1),
(9685, 'De Jesus', 0, 1),
(9686, 'De Jong', 0, 1),
(9687, 'de la Craz', 0, 1),
(9688, 'De La Cruz', 0, 1),
(9689, 'de la Rosa', 0, 1),
(9690, 'De La Torre', 0, 1),
(9691, 'de la Vara', 0, 1),
(9692, 'De Leon', 0, 1),
(9693, 'De Los Santos', 0, 1),
(9694, 'De Maria', 0, 1),
(9695, 'De Paula', 0, 1),
(9696, 'De Vries', 0, 1),
(9697, 'Deago', 0, 1),
(9698, 'Dean', 0, 1),
(9699, 'Deardorff', 0, 1),
(9700, 'Dease', 0, 1),
(9701, 'DeBarr', 0, 1),
(9702, 'DeCarlo', 0, 1),
(9703, 'DeCarr', 0, 1),
(9704, 'DeCaster', 0, 1),
(9705, 'Decker', 0, 1),
(9706, 'Declarmen', 0, 1),
(9707, 'Deduno', 0, 1),
(9708, 'Deeds', 0, 1),
(9709, 'Deer', 0, 1),
(9710, 'Deetz', 0, 1),
(9711, 'Degano', 0, 1),
(9712, 'Degerman', 0, 1),
(9713, 'Deglan', 0, 1),
(9714, 'deGrom', 0, 1),
(9715, 'DeHaan', 0, 1),
(9716, 'DeHart', 0, 1),
(9717, 'DeHoyos', 0, 1),
(9718, 'Deichmann', 0, 1),
(9719, 'DeJaynes', 0, 1),
(9720, 'DeJean', 0, 1),
(9721, 'DeJesus', 0, 1),
(9722, 'DeJong', 0, 1),
(9723, 'Del Chiaro', 0, 1),
(9724, 'Del Pozo', 0, 1),
(9725, 'Del Rosario', 0, 1),
(9726, 'Del Toro', 0, 1),
(9727, 'Del Valle', 0, 1),
(9728, 'Delabar', 0, 1),
(9729, 'Delaney', 0, 1),
(9730, 'Delay', 0, 1),
(9731, 'Delcarmen', 0, 1),
(9732, 'DeLeon', 0, 1),
(9733, 'delete', 0, 0),
(9734, 'Delfino', 0, 1),
(9735, 'Delgado', 0, 1),
(9736, 'Dellaero', 0, 1),
(9737, 'Dellucci', 0, 1),
(9738, 'Delmonico', 0, 1),
(9739, 'DeLome', 0, 1),
(9740, 'Delucchi', 0, 1),
(9741, 'Delucia', 0, 1),
(9742, 'Deluzio', 0, 1),
(9743, 'Demaria', 0, 1),
(9744, 'Demel', 0, 1),
(9745, 'Demeritte', 0, 1),
(9746, 'DeMichele', 0, 1),
(9747, 'Demny', 0, 1),
(9748, 'Dempsey', 0, 1),
(9749, 'Dempster', 0, 1),
(9750, 'den Dekker', 0, 1),
(9751, 'Denham', 0, 1),
(9752, 'Dening', 0, 1),
(9753, 'Denker', 0, 1),
(9754, 'Denney', 0, 1),
(9755, 'Dennick', 0, 1),
(9756, 'Dennis', 0, 1),
(9757, 'Denorfia', 0, 1),
(9758, 'Denson', 0, 1),
(9759, 'Dent', 0, 1),
(9760, 'Denton', 0, 1),
(9761, 'Depastino', 0, 1),
(9762, 'DePaula', 0, 1),
(9763, 'DePew', 0, 1),
(9764, 'DePriest', 0, 1),
(9765, 'Derby', 0, 1),
(9766, 'Dermody', 0, 1),
(9767, 'DeRosa', 0, 1),
(9768, 'DeSalvo', 0, 1),
(9769, 'Descalso', 0, 1),
(9770, 'Deschenes', 0, 1),
(9771, 'DeSclafani', 0, 1),
(9772, 'DeShields', 0, 1),
(9773, 'DeShields Jr.', 0, 1),
(9774, 'Desme', 0, 1),
(9775, 'Desmond', 0, 1),
(9776, 'Despaigne', 0, 1),
(9777, 'Dessens', 0, 1),
(9778, 'Deters', 0, 1),
(9779, 'Detwiler', 0, 1),
(9780, 'DeVall', 0, 1),
(9781, 'Devaney', 0, 1),
(9782, 'Devarez', 0, 1),
(9783, 'Deveaux', 0, 1),
(9784, 'Devenski', 0, 1),
(9785, 'Devereaux', 0, 1),
(9786, 'Devers', 0, 1),
(9787, 'Devine', 0, 1),
(9788, 'DeVito', 0, 1),
(9789, 'DeVore', 0, 1),
(9790, 'DeVoss', 0, 1),
(9791, 'Dewees', 0, 1),
(9792, 'Dewey', 0, 1),
(9793, 'DeWitt', 0, 1),
(9794, 'Deza', 0, 1),
(9795, 'DFdfasfsajgodas', 0, 1),
(9796, 'Dials', 0, 1),
(9797, 'Diamond', 0, 1),
(9798, 'DiAngelo', 0, 1),
(9799, 'Diaz', 0, 1),
(9800, 'Dibble', 0, 1),
(9801, 'Dibrell', 0, 1),
(9802, 'Dicker', 0, 1),
(9803, 'Dickerson', 0, 1),
(9804, 'Dickey', 0, 1),
(9805, 'Dickson', 0, 1),
(9806, 'Didder', 0, 1),
(9807, 'Didjurgis', 0, 1),
(9808, 'Diekman', 0, 1),
(9809, 'Diekroeger', 0, 1),
(9810, 'Diemer', 0, 1),
(9811, 'Dietrich', 0, 1),
(9812, 'Dietz', 0, 1),
(9813, 'DiFelice', 0, 1),
(9814, 'Difo', 0, 1),
(9815, 'Digby', 0, 1),
(9816, 'Diggins', 0, 1),
(9817, 'Dillard', 0, 1),
(9818, 'Dillon', 0, 1),
(9819, 'DiNardo', 0, 1),
(9820, 'Dinelli', 0, 1),
(9821, 'Dingman', 0, 1),
(9822, 'Dini', 0, 1),
(9823, 'Dinkelman', 0, 1),
(9824, 'Diplan', 0, 1),
(9825, 'Dipoto', 0, 1),
(9826, 'Dirks', 0, 1),
(9827, 'Dirocie', 0, 1),
(9828, 'DiSarcina', 0, 1),
(9829, 'Dishman', 0, 1),
(9830, 'Dittfurth', 0, 1),
(9831, 'Dittler', 0, 1),
(9832, 'Dixon', 0, 1),
(9833, 'Dlugach', 0, 1),
(9834, 'Dobbs', 0, 1),
(9835, 'Dobies', 0, 1),
(9836, 'Dobzanski', 0, 1),
(9837, 'Dodd', 0, 1),
(9838, 'Dodson', 0, 1),
(9839, 'Doherty', 0, 1),
(9840, 'Dohmann', 0, 1),
(9841, 'Doi', 0, 1),
(9842, 'Dolis', 0, 1),
(9843, 'Dolsi', 0, 1),
(9844, 'Dominguez', 0, 1),
(9845, 'Dominique', 0, 1),
(9846, 'Donachie', 0, 1),
(9847, 'Donald', 0, 1),
(9848, 'Donaldson', 0, 1),
(9849, 'Donnelly', 0, 1),
(9850, 'Donnels', 0, 1),
(9851, 'Donovan', 0, 1),
(9852, 'Doolittle', 0, 1),
(9853, 'Dopirak', 0, 1),
(9854, 'Dorame', 0, 1),
(9855, 'Doran', 0, 1),
(9856, 'Dore', 0, 1),
(9857, 'Dorman', 0, 1),
(9858, 'Dorminy', 0, 1),
(9859, 'Dorn', 0, 1),
(9860, 'Dorta', 0, 1),
(9861, 'Dosch', 0, 1),
(9862, 'Doster', 0, 1),
(9863, 'Dotel', 0, 1),
(9864, 'Dotson', 0, 1),
(9865, 'Dott', 0, 1),
(9866, 'Doubront', 0, 1),
(9867, 'Doue', 0, 1),
(9868, 'Dougherty', 0, 1),
(9869, 'Douglas', 0, 1),
(9870, 'Douglass', 0, 1),
(9871, 'Doumit', 0, 1),
(9872, 'Dove', 0, 1),
(9873, 'Dowdy', 0, 1),
(9874, 'Downs', 0, 1),
(9875, 'Doyle', 0, 1),
(9876, 'Doyne', 0, 1),
(9877, 'Dozier', 0, 1),
(9878, 'Drabek', 0, 1),
(9879, 'Dragmire', 0, 1),
(9880, 'Drake', 0, 1),
(9881, 'Drama', 0, 1),
(9882, 'Dransfeldt', 0, 1),
(9883, 'Dreifort', 0, 1),
(9884, 'Drennen', 0, 1),
(9885, 'Drennenbad', 0, 1),
(9886, 'Drese', 0, 1),
(9887, 'Dressendorfer', 0, 1),
(9888, 'Drew', 0, 1),
(9889, 'Drews', 0, 1),
(9890, 'Driskill', 0, 1),
(9891, 'Driver', 0, 1),
(9892, 'Drohan', 0, 1),
(9893, 'Drullard', 0, 1),
(9894, 'Drumright', 0, 1),
(9895, 'Drury', 0, 1),
(9896, 'Duarte', 0, 1),
(9897, 'Dubee', 0, 1),
(9898, 'Dubois', 0, 1),
(9899, 'Dubon', 0, 1),
(9900, 'DuBose', 0, 1),
(9901, 'Ducey', 0, 1),
(9902, 'Duchscherer', 0, 1),
(9903, 'Duckworth', 0, 1),
(9904, 'Duda', 0, 1),
(9905, 'Duenas', 0, 1),
(9906, 'Duenez', 0, 1),
(9907, 'Duensing', 0, 1),
(9908, 'Duff', 0, 1),
(9909, 'Duffey', 0, 1),
(9910, 'Duffy', 0, 1),
(9911, 'Dugan', 0, 1),
(9912, 'Dugas', 0, 1),
(9913, 'Duggar', 0, 1),
(9914, 'Dugger', 0, 1),
(9915, 'Duke', 0, 1),
(9916, 'Dukes', 0, 1),
(9917, 'Dull', 0, 1),
(9918, 'Dumatrait', 0, 1),
(9919, 'Dunand', 0, 1),
(9920, 'Duncan', 0, 1),
(9921, 'Dunigan', 0, 1),
(9922, 'Dunn', 0, 1),
(9923, 'Dunning', 0, 1),
(9924, 'Dunshee', 0, 1),
(9925, 'Dunston', 0, 1),
(9926, 'Dunwoody', 0, 1),
(9927, 'Duplantier', 0, 1),
(9928, 'Duran', 0, 1),
(9929, 'Durango', 0, 1),
(9930, 'Durazo', 0, 1),
(9931, 'Durbin', 0, 1),
(9932, 'Durham', 0, 1),
(9933, 'Durkin', 0, 1),
(9934, 'Durocher', 0, 1),
(9935, 'Durrington', 0, 1),
(9936, 'Duvall', 0, 1),
(9937, 'Dwyer', 0, 1),
(9938, 'Dydalewicz', 0, 1),
(9939, 'Dye', 0, 1),
(9940, 'Dyer', 0, 1),
(9941, 'Dykhoff', 0, 1),
(9942, 'Dykstra', 0, 1),
(9943, 'Dyson', 0, 1),
(9944, 'Eades', 0, 1),
(9945, 'Eager', 0, 1),
(9946, 'Easley', 0, 1),
(9947, 'Eaton', 0, 1),
(9948, 'Eaves', 0, 1),
(9949, 'Ebert', 0, 1),
(9950, 'Eberwein', 0, 1),
(9951, 'Echevarria', 0, 1),
(9952, 'Echols', 0, 1),
(9953, 'Eckenstahler', 0, 1),
(9954, 'Eckersley', 0, 1),
(9955, 'Eckert', 0, 1),
(9956, 'Eckstein', 0, 1),
(9957, 'Edell', 0, 1),
(9958, 'Eden', 0, 1),
(9959, 'Edenfield', 0, 1),
(9960, 'Eder', 0, 1),
(9961, 'Edgin', 0, 1),
(9962, 'Edlefsen', 0, 1),
(9963, 'Edmonds', 0, 1),
(9964, 'Edmondson', 0, 1),
(9965, 'Edsell', 0, 1),
(9966, 'Edwards', 0, 1),
(9967, 'Edwards Jr.', 0, 1),
(9968, 'Eenhoorn', 0, 1),
(9969, 'Eflin', 0, 1),
(9970, 'Egan', 0, 1),
(9971, 'Egbert', 0, 1),
(9972, 'Ege', 0, 1),
(9973, 'Egnatuk', 0, 1),
(9974, 'Ehlers', 0, 1),
(9975, 'Eibner', 0, 1),
(9976, 'Eichelberger', 0, 1),
(9977, 'Eichhorn', 0, 1),
(9978, 'Eickhoff', 0, 1),
(9979, 'Eierman', 0, 1),
(9980, 'Eiland', 0, 1),
(9981, 'Einertson', 0, 1),
(9982, 'Eischen', 0, 1),
(9983, 'Eisenberg', 0, 1),
(9984, 'Eisenreich', 0, 1),
(9985, 'Ekstrom', 0, 1),
(9986, 'El-Abour', 0, 1),
(9987, 'Elander', 0, 1),
(9988, 'Elarton', 0, 1),
(9989, 'Elbert', 0, 1),
(9990, 'Eldemire', 0, 1),
(9991, 'Elder', 0, 1),
(9992, 'Eldred', 0, 1),
(9993, 'Elias', 0, 1),
(9994, 'Eliopoulos', 0, 1),
(9995, 'Elizalde', 0, 1),
(9996, 'Elledge', 0, 1),
(9997, 'Ellington', 0, 1),
(9998, 'Elliott', 0, 1),
(9999, 'Ellis', 0, 1),
(10000, 'Ellison', 0, 1),
(10001, 'Ellsbury', 0, 1),
(10002, 'Elmore', 0, 1),
(10003, 'Elster', 0, 1),
(10004, 'Ely', 0, 1),
(10005, 'Emanuel', 0, 1),
(10006, 'Emaus', 0, 1),
(10007, 'Embree', 0, 1),
(10008, 'Embry', 0, 1),
(10009, 'Emery', 0, 1),
(10010, 'Emmanuel', 0, 1),
(10011, 'Encarnacion', 0, 1),
(10012, 'Encinas', 0, 1),
(10013, 'Endl', 0, 1),
(10014, 'Engel', 0, 1),
(10015, 'Englebrook', 0, 1),
(10016, 'English', 0, 1),
(10017, 'Englund', 0, 1),
(10018, 'Enlow', 0, 1),
(10019, 'Ennis', 0, 1),
(10020, 'Enns', 0, 1),
(10021, 'Enochs', 0, 1),
(10022, 'Enright', 0, 1),
(10023, 'Enriquez', 0, 1),
(10024, 'Ensberg', 0, 1),
(10025, 'Entenza', 0, 1),
(10026, 'Eovaldi', 0, 1),
(10027, 'Eppley', 0, 1),
(10028, 'Epps', 0, 1),
(10029, 'Erbe', 0, 1),
(10030, 'Erceg', 0, 1),
(10031, 'Erdos', 0, 1),
(10032, 'Eric', 0, 1),
(10033, 'Ericks', 0, 1),
(10034, 'Erickson', 0, 1),
(10035, 'Erlin', 0, 1),
(10036, 'Ernesto', 0, 1),
(10037, 'Errecart', 0, 1),
(10038, 'Erstad', 0, 1),
(10039, 'Ervin', 0, 1),
(10040, 'Erwin', 0, 1),
(10041, 'Escalona', 0, 1),
(10042, 'Esch', 0, 1),
(10043, 'Escobar', 0, 1),
(10044, 'Eshelman', 0, 1),
(10045, 'Espada', 0, 1),
(10046, 'Esparza', 0, 1),
(10047, 'Espina', 0, 1),
(10048, 'Espinal', 0, 1),
(10049, 'Espineli', 0, 1),
(10050, 'Espino', 0, 1),
(10051, 'Espinosa', 0, 1),
(10052, 'Espinoza', 0, 1),
(10053, 'Esplin', 0, 1),
(10054, 'Esposito', 0, 1),
(10055, 'Esquivel', 0, 1),
(10056, 'Estalella', 0, 1),
(10057, 'Estanga', 0, 1),
(10058, 'Estes', 0, 1),
(10059, 'Esteves', 0, 1),
(10060, 'Estevez', 0, 1),
(10061, 'Estrada', 0, 1),
(10062, 'Estrella', 0, 1),
(10063, 'Etherton', 0, 1),
(10064, 'Ethier', 0, 1),
(10065, 'Ethridge', 0, 1),
(10066, 'Eure', 0, 1),
(10067, 'Eusebio', 0, 1),
(10068, 'Evans', 0, 1),
(10069, 'Evarts', 0, 1),
(10070, 'Eveland', 0, 1),
(10071, 'Eveld', 0, 1),
(10072, 'Everett', 0, 1),
(10073, 'Everidge', 0, 1),
(10074, 'Eversgerd', 0, 1),
(10075, 'Evert', 0, 1),
(10076, 'Everts', 0, 1),
(10077, 'Ewing', 0, 1),
(10078, 'Exposito', 0, 1),
(10079, 'Extremity', 0, 1),
(10080, 'Eylward', 0, 1),
(10081, 'Eyre', 0, 1),
(10082, 'Fabian', 0, 1),
(10083, 'Fabregas', 0, 1),
(10084, 'Faedo', 0, 1),
(10085, 'Fagan', 0, 1),
(10086, 'Fahey', 0, 1),
(10087, 'Fahner', 0, 1),
(10088, 'Faiola', 0, 1),
(10089, 'Fairchild', 0, 1),
(10090, 'Fairel', 0, 1),
(10091, 'Fairley', 0, 1),
(10092, 'Faison', 0, 1),
(10093, 'Falkenborg', 0, 1),
(10094, 'Falteisek', 0, 1),
(10095, 'Falter', 0, 1),
(10096, 'Falu', 0, 1),
(10097, 'Familia', 0, 1),
(10098, 'Fanti', 0, 1),
(10099, 'Farfan', 0, 1),
(10100, 'Faria', 0, 1),
(10101, 'Farina', 0, 1),
(10102, 'Faris', 0, 1),
(10103, 'Farmer', 0, 1),
(10104, 'Farnsworth', 0, 1),
(10105, 'Farquhar', 0, 1),
(10106, 'Farrell', 0, 1),
(10107, 'Farris', 0, 1),
(10108, 'Fasano', 0, 1),
(10109, 'Fassero', 0, 1),
(10110, 'Faulkner', 0, 1),
(10111, 'Featherston', 0, 1),
(10112, 'Febles', 0, 1),
(10113, 'Fedde', 0, 1),
(10114, 'Federowicz', 0, 1),
(10115, 'Fedroff', 0, 1),
(10116, 'Feeney', 0, 1),
(10117, 'Feierabend', 0, 1),
(10118, 'Feigl', 0, 1),
(10119, 'Feldman', 0, 1),
(10120, 'Feliciano', 0, 1),
(10121, 'Felix', 0, 1),
(10122, 'Feliz', 0, 1),
(10123, 'Fellhauer', 0, 1),
(10124, 'Fellman', 0, 1),
(10125, 'Felston', 0, 1),
(10126, 'Fenster', 0, 1),
(10127, 'Fenton', 0, 1),
(10128, 'Ferguson', 0, 1),
(10129, 'Fermaint', 0, 1),
(10130, 'Fermin', 0, 1),
(10131, 'Fernandez', 0, 1),
(10132, 'Fernando', 0, 1),
(10133, 'Ferrari', 0, 1),
(10134, 'Ferreira', 0, 1),
(10135, 'Ferrell', 0, 1),
(10136, 'Ferreras', 0, 1),
(10137, 'Ferris', 0, 1),
(10138, 'Fesh', 0, 1),
(10139, 'Festa', 0, 1),
(10140, 'Fetters', 0, 1),
(10141, 'Feyereisen', 0, 1),
(10142, 'Fick', 0, 1),
(10143, 'Ficociello', 0, 1),
(10144, 'Field', 0, 1),
(10145, 'Fielder', 0, 1),
(10146, 'Fields', 0, 1),
(10147, 'Fien', 0, 1),
(10148, 'Fiers', 0, 1),
(10149, 'Fife', 0, 1),
(10150, 'Figaro', 0, 1),
(10151, 'Figga', 0, 1),
(10152, 'Figgins', 0, 1),
(10153, 'Figueroa', 0, 1),
(10154, 'Fikac', 0, 1),
(10155, 'Filak', 0, 1),
(10156, 'File', 0, 1),
(10157, 'Filia', 0, 1),
(10158, 'Fillmyer', 0, 1),
(10159, 'Finch', 0, 1),
(10160, 'Finigan', 0, 1),
(10161, 'Finley', 0, 1),
(10162, 'Finnegan', 0, 1),
(10163, 'Fiore', 0, 1),
(10164, 'Fiorentino', 0, 1),
(10165, 'Fischer', 0, 1),
(10166, 'Fish', 0, 1),
(10167, 'Fisher', 0, 1),
(10168, 'Fister', 0, 1),
(10169, 'Fitzgerald', 0, 1),
(10170, 'Flaherty', 0, 1),
(10171, 'Flaig', 0, 1),
(10172, 'Flames', 0, 1),
(10173, 'Flande', 0, 1),
(10174, 'Flannery', 0, 1),
(10175, 'Fleck', 0, 1),
(10176, 'Fleet', 0, 1),
(10177, 'Fleetham', 0, 1),
(10178, 'Fleming', 0, 1),
(10179, 'Flener', 0, 1),
(10180, 'Fletcher', 0, 1),
(10181, 'Flete', 0, 1),
(10182, 'Fleury', 0, 1),
(10183, 'Flexen', 0, 1),
(10184, 'Flinn', 0, 1),
(10185, 'Flores', 0, 1),
(10186, 'Florial', 0, 1),
(10187, 'Florie', 0, 1),
(10188, 'Florimon', 0, 1),
(10189, 'Floro', 0, 1),
(10190, 'Flowers', 0, 1),
(10191, 'Floyd', 0, 1),
(10192, 'Flury', 0, 1),
(10193, 'Flynn', 0, 1),
(10194, 'Fogg', 0, 1),
(10195, 'Foley', 0, 1),
(10196, 'Foltynewicz', 0, 1),
(10197, 'Font', 0, 1),
(10198, 'Fontaine', 0, 1),
(10199, 'Fontana', 0, 1),
(10200, 'Fontenot', 0, 1),
(10201, 'Fonville', 0, 1),
(10202, 'Foody', 0, 1),
(10203, 'Foppert', 0, 1),
(10204, 'Forbes', 0, 1),
(10205, 'Ford', 0, 1),
(10206, 'Fordham', 0, 1),
(10207, 'Fordyce', 0, 1),
(10208, 'Forjet', 0, 1),
(10209, 'Fornataro', 0, 1),
(10210, 'Forster', 0, 1),
(10211, 'Forsythe', 0, 1),
(10212, 'Fortunato', 0, 1),
(10213, 'Forystek', 0, 1),
(10214, 'Fossas', 0, 1),
(10215, 'Fossum', 0, 1),
(10216, 'Foster', 0, 1),
(10217, 'Foulke', 0, 1),
(10218, 'Foust', 0, 1),
(10219, 'Fowler', 0, 1),
(10220, 'Fox', 0, 1),
(10221, 'Fraizer', 0, 1),
(10222, 'Fraley', 0, 1),
(10223, 'France', 0, 1),
(10224, 'Francees', 0, 1),
(10225, 'Francia', 0, 1),
(10226, 'Francis', 0, 1),
(10227, 'Francisco', 0, 1),
(10228, 'Franco', 0, 1),
(10229, 'Francoeur', 0, 1),
(10230, 'Frandsen', 0, 1),
(10231, 'Frank', 0, 1),
(10232, 'Franklin', 0, 1),
(10233, 'Frankoff', 0, 1),
(10234, 'Frascatore', 0, 1),
(10235, 'Frasor', 0, 1),
(10236, 'Frazier', 0, 1),
(10237, 'Frederick', 0, 1),
(10238, 'Frederickson', 0, 1),
(10239, 'Freed', 0, 1),
(10240, 'Freel', 0, 1),
(10241, 'Freeland', 0, 1),
(10242, 'Freeman', 0, 1),
(10243, 'Freese', 0, 1),
(10244, 'Freiman', 0, 1),
(10245, 'Freire', 0, 1),
(10246, 'Freitas', 0, 1),
(10247, 'French', 0, 1),
(10248, 'Frese', 0, 1),
(10249, 'Frey', 0, 1),
(10250, 'Frias', 0, 1),
(10251, 'Friday', 0, 1),
(10252, 'Fried', 0, 1),
(10253, 'Friedl', 0, 1),
(10254, 'Friedrich', 0, 1),
(10255, 'Friend', 0, 1),
(10256, 'Frieri', 0, 1),
(10257, 'Fritz', 0, 1),
(10258, 'Frohwirth', 0, 1),
(10259, 'Froneberger', 0, 1),
(10260, 'Fronk', 0, 1),
(10261, 'Frontz', 0, 1),
(10262, 'Fruto', 0, 1),
(10263, 'Fry', 0, 1),
(10264, 'Frye', 0, 1),
(10265, 'Fryer', 0, 1),
(10266, 'Fryman', 0, 1),
(10267, 'Fuell', 0, 1),
(10268, 'Fuenmayor', 0, 1),
(10269, 'Fuentes', 0, 1),
(10270, 'Fujikawa', 0, 1),
(10271, 'Fujinami', 0, 1),
(10272, 'Fukofuka', 0, 1),
(10273, 'Fukudome', 0, 1),
(10274, 'Fukuhara', 0, 1),
(10275, 'Fukumori', 0, 1),
(10276, 'Fulchino', 0, 1),
(10277, 'Fuld', 0, 1),
(10278, 'Fulenchek', 0, 1),
(10279, 'Fuller', 0, 1),
(10280, 'Fullmer', 0, 1),
(10281, 'Fulmer', 0, 1),
(10282, 'Fultz', 0, 1),
(10283, 'Funkhouser', 0, 1),
(10284, 'Furbush', 0, 1),
(10285, 'Furcal', 0, 1),
(10286, 'Furmaniak', 0, 1),
(10287, 'Furnish', 0, 1),
(10288, 'Fussell', 0, 1),
(10289, 'Fyhrie', 0, 1),
(10290, 'Gabbard', 0, 1),
(10291, 'Gabino', 0, 1),
(10292, 'Gabryszwski', 0, 1),
(10293, 'Gac', 0, 1),
(10294, 'Gaddis', 0, 1),
(10295, 'Gadea', 0, 1),
(10296, 'Gaetti', 0, 1),
(10297, 'Gage', 0, 1),
(10298, 'Gagne', 0, 1),
(10299, 'Gagnier', 0, 1),
(10300, 'Gagnon', 0, 1),
(10301, 'Gailey', 0, 1),
(10302, 'Gaillard', 0, 1),
(10303, 'Gaither', 0, 1),
(10304, 'Gajkowski', 0, 1),
(10305, 'Galarraga', 0, 1),
(10306, 'Gale', 0, 1),
(10307, 'Galindo', 0, 1),
(10308, 'Gall', 0, 1),
(10309, 'Gallagher', 0, 1),
(10310, 'Gallardo', 0, 1),
(10311, 'Gallas', 0, 1),
(10312, 'Gallego', 0, 1),
(10313, 'Gallegos', 0, 1),
(10314, 'Gallen', 0, 1),
(10315, 'Gallo', 0, 1),
(10316, 'Galloway', 0, 1),
(10317, 'Galvez', 0, 1),
(10318, 'Galvis', 0, 1),
(10319, 'Gamache', 0, 1),
(10320, 'Gamble', 0, 1),
(10321, 'Gamboa', 0, 1),
(10322, 'Gamel', 0, 1),
(10323, 'Gandarillas', 0, 1),
(10324, 'Gannon', 0, 1),
(10325, 'Gant', 0, 1),
(10326, 'Garabedian', 0, 1),
(10327, 'Garabito', 0, 1),
(10328, 'Garate', 0, 1),
(10329, 'Garbe', 0, 1),
(10330, 'Garces', 0, 1),
(10331, 'Garcia', 0, 1),
(10332, 'Garciaparra', 0, 1),
(10333, 'Gardeck', 0, 1),
(10334, 'Gardewine', 0, 1),
(10335, 'Gardner', 0, 1),
(10336, 'Garfield', 0, 1),
(10337, 'Garibay', 0, 1),
(10338, 'Garko', 0, 1),
(10339, 'Garland', 0, 1),
(10340, 'Garlobo', 0, 1),
(10341, 'Garneau', 0, 1),
(10342, 'Garner', 0, 1),
(10343, 'Garrabrants', 0, 1),
(10344, 'Garrett', 0, 1),
(10345, 'Garrido', 0, 1),
(10346, 'Garrison', 0, 1),
(10347, 'Garthwaite', 0, 1),
(10348, 'Garton', 0, 1),
(10349, 'Gartrell', 0, 1),
(10350, 'Garver', 0, 1),
(10351, 'Garvey', 0, 1),
(10352, 'Garvin', 0, 1),
(10353, 'Garza', 0, 1),
(10354, 'Gasparini', 0, 1),
(10355, 'Gassaway', 0, 1),
(10356, 'Gassner', 0, 1),
(10357, 'Gast', 0, 1),
(10358, 'Gaston', 0, 1),
(10359, 'Gates', 0, 1),
(10360, 'Gatewood', 0, 1),
(10361, 'Gathright', 0, 1),
(10362, 'Gattis', 0, 1),
(10363, 'Gatto', 0, 1),
(10364, 'Gaub', 0, 1),
(10365, 'Gaudin', 0, 1),
(10366, 'Gausman', 0, 1),
(10367, 'Gautreau', 0, 1),
(10368, 'Gaviglio', 0, 1),
(10369, 'Gayhart', 0, 1),
(10370, 'Gaynor', 0, 1),
(10371, 'Gearrin', 0, 1),
(10372, 'Geary', 0, 1),
(10373, 'Gee', 0, 1),
(10374, 'Geer', 0, 1),
(10375, 'Geiger', 0, 1),
(10376, 'Gelalich', 0, 1),
(10377, 'Gelinas', 0, 1),
(10378, 'Geltz', 0, 1),
(10379, 'Gennett', 0, 1),
(10380, 'Genoves', 0, 1),
(10381, 'Gentry', 0, 1),
(10382, 'George', 0, 1),
(10383, 'Gerbe', 0, 1),
(10384, 'Gerber', 0, 1),
(10385, 'German', 0, 1),
(10386, 'Germano', 0, 1),
(10387, 'Germen', 0, 1),
(10388, 'Gerut', 0, 1),
(10389, 'Gervacio', 0, 1),
(10390, 'Gettis', 0, 1),
(10391, 'Gettys', 0, 1),
(10392, 'Getz', 0, 1),
(10393, 'Giambi', 0, 1),
(10394, 'Giarratano', 0, 1),
(10395, 'Giavotella', 0, 1),
(10396, 'Gibbons', 0, 1),
(10397, 'Gibbs', 0, 1),
(10398, 'Gibralter', 0, 1),
(10399, 'Gibson', 0, 1),
(10400, 'Giese', 0, 1),
(10401, 'Gigliotti', 0, 1),
(10402, 'Gil', 0, 1),
(10403, 'Gilbert', 0, 1),
(10404, 'Giles', 0, 1),
(10405, 'Gilfillan', 0, 1),
(10406, 'Gilkey', 0, 1),
(10407, 'Gillaspie', 0, 1),
(10408, 'Gillespie', 0, 1),
(10409, 'Gilliam', 0, 1),
(10410, 'Gillies', 0, 1),
(10411, 'Gillingham', 0, 1),
(10412, 'Gilmartin', 0, 1),
(10413, 'Gilmore', 0, 1),
(10414, 'Gimenez', 0, 1),
(10415, 'Gindl', 0, 1),
(10416, 'Ginley', 0, 1),
(10417, 'Ginter', 0, 1),
(10418, 'Giolito', 0, 1),
(10419, 'Giovanola', 0, 1),
(10420, 'Gipson', 0, 1),
(10421, 'Girardi', 0, 1),
(10422, 'Girodo', 0, 1),
(10423, 'Giron', 0, 1),
(10424, 'Gissell', 0, 1),
(10425, 'Gittens', 0, 1),
(10426, 'Givens', 0, 1),
(10427, 'Glaesmann', 0, 1),
(10428, 'Glant', 0, 1),
(10429, 'Glanville', 0, 1),
(10430, 'Glasnow', 0, 1),
(10431, 'Glauber', 0, 1),
(10432, 'Glaus', 0, 1),
(10433, 'Glavine', 0, 1),
(10434, 'Gleason', 0, 1),
(10435, 'Glen', 0, 1),
(10436, 'Glenn', 0, 1),
(10437, 'Gload', 0, 1),
(10438, 'Glover', 0, 1),
(10439, 'Glynn', 0, 1),
(10440, 'Gobble', 0, 1),
(10441, 'Godfrey', 0, 1),
(10442, 'Godin', 0, 1),
(10443, 'Godley', 0, 1),
(10444, 'Godwin', 0, 1),
(10445, 'Goebbert', 0, 1),
(10446, 'Goeddel', 0, 1),
(10447, 'Goedert', 0, 1),
(10448, 'Goetz', 0, 1),
(10449, 'Goetzman', 0, 1),
(10450, 'Goff', 0, 1),
(10451, 'Goforth', 0, 1),
(10452, 'Gohara', 0, 1),
(10453, 'Gohr', 0, 1),
(10454, 'Goins', 0, 1),
(10455, 'Gold', 0, 1),
(10456, 'Goldberg', 0, 1),
(10457, 'Golden', 0, 1),
(10458, 'Goldschmidt', 0, 1),
(10459, 'Goleski', 0, 1),
(10460, 'Golson', 0, 1),
(10461, 'Gomber', 0, 1),
(10462, 'Gomes', 0, 1),
(10463, 'Gomez', 0, 1),
(10464, 'Gonsalves', 0, 1),
(10465, 'Gonzales', 0, 1),
(10466, 'Gonzalez', 0, 1),
(10467, 'Gooch', 0, 1),
(10468, 'Goocher', 0, 1),
(10469, 'Good', 0, 1),
(10470, 'Gooden', 0, 1),
(10471, 'Goodnight', 0, 1),
(10472, 'Goodrum', 0, 1),
(10473, 'Goodson', 0, 1),
(10474, 'Goodwin', 0, 1),
(10475, 'Goody', 0, 1),
(10476, 'Gordon', 0, 1),
(10477, 'Gore', 0, 1),
(10478, 'Gorecki', 0, 1),
(10479, 'Gorgen', 0, 1),
(10480, 'Goris', 0, 1),
(10481, 'Gorneault', 0, 1);
INSERT INTO `master_player_names` (`name_id`, `name`, `is_first_name`, `is_active`) VALUES
(10482, 'Gorski', 0, 1),
(10483, 'Gorzelanny', 0, 1),
(10484, 'Gose', 0, 1),
(10485, 'Gosewisch', 0, 1),
(10486, 'Gosling', 0, 1),
(10487, 'Gossage', 0, 1),
(10488, 'Gosselin', 0, 1),
(10489, 'Gossett', 0, 1),
(10490, 'Gotay', 0, 1),
(10491, 'Gothreaux', 0, 1),
(10492, 'Gott', 0, 1),
(10493, 'Goudeau', 0, 1),
(10494, 'Gougeaway', 0, 1),
(10495, 'Gould', 0, 1),
(10496, 'Gourriel', 0, 1),
(10497, 'Gowdy', 0, 1),
(10498, 'Goyen', 0, 1),
(10499, 'Grabow', 0, 1),
(10500, 'Grabowski', 0, 1),
(10501, 'Grace', 0, 1),
(10502, 'Gracesqui', 0, 1),
(10503, 'Gradoville', 0, 1),
(10504, 'Graffanino', 0, 1),
(10505, 'Gragg III', 0, 1),
(10506, 'Gragnani', 0, 1),
(10507, 'Graham', 0, 1),
(10508, 'Grahe', 0, 1),
(10509, 'Graman', 0, 1),
(10510, 'Granadillo', 0, 1),
(10511, 'Grandal', 0, 1),
(10512, 'Granderson', 0, 1),
(10513, 'Granger', 0, 1),
(10514, 'Granier', 0, 1),
(10515, 'Granite', 0, 1),
(10516, 'Grant', 0, 1),
(10517, 'Graterol', 0, 1),
(10518, 'Graveman', 0, 1),
(10519, 'Graves', 0, 1),
(10520, 'Gray', 0, 1),
(10521, 'Grebeck', 0, 1),
(10522, 'Gredvig', 0, 1),
(10523, 'Green', 0, 1),
(10524, 'Greenberg', 0, 1),
(10525, 'Greene', 0, 1),
(10526, 'Greenwalt', 0, 1),
(10527, 'Greenwell', 0, 1),
(10528, 'Greenwood', 0, 1),
(10529, 'Greer', 0, 1),
(10530, 'Gregerson', 0, 1),
(10531, 'Gregg', 0, 1),
(10532, 'Gregorio', 0, 1),
(10533, 'Gregorius', 0, 1),
(10534, 'Greiner', 0, 1),
(10535, 'Greinke', 0, 1),
(10536, 'Greisinger', 0, 1),
(10537, 'Grey', 0, 1),
(10538, 'Grichuk', 0, 1),
(10539, 'Grier', 0, 1),
(10540, 'Grieve', 0, 1),
(10541, 'Griffey Jr.', 0, 1),
(10542, 'Griffin', 0, 1),
(10543, 'Griffith', 0, 1),
(10544, 'Griffiths', 0, 1),
(10545, 'Grigsby', 0, 1),
(10546, 'Grilli', 0, 1),
(10547, 'Grills', 0, 1),
(10548, 'Grimes', 0, 1),
(10549, 'Grimm', 0, 1),
(10550, 'Grimsley', 0, 1),
(10551, 'Grisham', 0, 1),
(10552, 'Grissom', 0, 1),
(10553, 'Gronkiewicz', 0, 1),
(10554, 'Gronkowski', 0, 1),
(10555, 'Groom', 0, 1),
(10556, 'Groome', 0, 1),
(10557, 'Gross', 0, 1),
(10558, 'Grossman', 0, 1),
(10559, 'Groves', 0, 1),
(10560, 'Grube', 0, 1),
(10561, 'Gruber', 0, 1),
(10562, 'Grudzielanek', 0, 1),
(10563, 'Gruler', 0, 1),
(10564, 'Grullon', 0, 1),
(10565, 'Grundt', 0, 1),
(10566, 'Gryboski', 0, 1),
(10567, 'Grzanich', 0, 1),
(10568, 'Gsellman', 0, 1),
(10569, 'Guaimaro', 0, 1),
(10570, 'Guaipe', 0, 1),
(10571, 'Guardado', 0, 1),
(10572, 'Gubanich', 0, 1),
(10573, 'Gubicza', 0, 1),
(10574, 'Guduan', 0, 1),
(10575, 'Gueller', 0, 1),
(10576, 'Guerra', 0, 1),
(10577, 'Guerrero', 0, 1),
(10578, 'Guerrero Jr.', 0, 1),
(10579, 'Guerrier', 0, 1),
(10580, 'Guerrieri', 0, 1),
(10581, 'Guetterman', 0, 1),
(10582, 'Guevara', 0, 1),
(10583, 'Guez', 0, 1),
(10584, 'Guiel', 0, 1),
(10585, 'Guilan', 0, 1),
(10586, 'Guillen', 0, 1),
(10587, 'Guillon', 0, 1),
(10588, 'Guillorme', 0, 1),
(10589, 'Guilmet', 0, 1),
(10590, 'Gulan', 0, 1),
(10591, 'Gulin', 0, 1),
(10592, 'Gulledge', 0, 1),
(10593, 'Gumbs', 0, 1),
(10594, 'Gunderson', 0, 1),
(10595, 'Gunkel', 0, 1),
(10596, 'Gurka', 0, 1),
(10597, 'Gurriel', 0, 1),
(10598, 'Gushue', 0, 1),
(10599, 'Gustave', 0, 1),
(10600, 'Guthrie', 0, 1),
(10601, 'Gutierrez', 0, 1),
(10602, 'Guttormson', 0, 1),
(10603, 'Guyer', 0, 1),
(10604, 'Guyette', 0, 1),
(10605, 'Guzman', 0, 1),
(10606, 'Gwyn', 0, 1),
(10607, 'Gwynn', 0, 1),
(10608, 'Gwynn Jr.', 0, 1),
(10609, 'Gxzxvx', 0, 1),
(10610, 'Gyorko', 0, 1),
(10611, 'Ha', 0, 1),
(10612, 'Haad', 0, 1),
(10613, 'Haas', 0, 1),
(10614, 'Haase', 0, 1),
(10615, 'Habel', 0, 1),
(10616, 'Haberer', 0, 1),
(10617, 'Hacker', 0, 1),
(10618, 'Hackimer', 0, 1),
(10619, 'Hackman', 0, 1),
(10620, 'Hader', 0, 1),
(10621, 'Haeger', 0, 1),
(10622, 'Haerther', 0, 1),
(10623, 'Hafner', 0, 1),
(10624, 'Hagadone', 0, 1),
(10625, 'Hagens', 0, 1),
(10626, 'Hager', 0, 1),
(10627, 'Hagerty', 0, 1),
(10628, 'Haggerty', 0, 1),
(10629, 'Hague', 0, 1),
(10630, 'Hahn', 0, 1),
(10631, 'Haigwood', 0, 1),
(10632, 'Haines', 0, 1),
(10633, 'Hairston', 0, 1),
(10634, 'Hairston Jr.', 0, 1),
(10635, 'Hajek', 0, 1),
(10636, 'Halama', 0, 1),
(10637, 'Hale', 0, 1),
(10638, 'Haley', 0, 1),
(10639, 'Hall', 0, 1),
(10640, 'Halladay', 0, 1),
(10641, 'Hallberg', 0, 1),
(10642, 'Halman', 0, 1),
(10643, 'Halsey', 0, 1),
(10644, 'Halter', 0, 1),
(10645, 'Haltiwanger', 0, 1),
(10646, 'Halton', 0, 1),
(10647, 'Hamblet', 0, 1),
(10648, 'Hamburger', 0, 1),
(10649, 'Hamelin', 0, 1),
(10650, 'Hamels', 0, 1),
(10651, 'Hamilton', 0, 1),
(10652, 'Hamman', 0, 1),
(10653, 'Hammel', 0, 1),
(10654, 'Hammer', 0, 1),
(10655, 'Hammes', 0, 1),
(10656, 'Hammock', 0, 1),
(10657, 'Hammond', 0, 1),
(10658, 'Hammonds', 0, 1),
(10659, 'Hampson', 0, 1),
(10660, 'Hampton', 0, 1),
(10661, 'Hamren', 0, 1),
(10662, 'Hamulack', 0, 1),
(10663, 'Hancock', 0, 1),
(10664, 'Hand', 0, 1),
(10665, 'Haney', 0, 1),
(10666, 'Hanifee', 0, 1),
(10667, 'Hanigan', 0, 1),
(10668, 'Haniger', 0, 1),
(10669, 'Hankerd', 0, 1),
(10670, 'Hankins', 0, 1),
(10671, 'Hanks', 0, 1),
(10672, 'Hannahan', 0, 1),
(10673, 'Hannaman', 0, 1),
(10674, 'Hannemann', 0, 1),
(10675, 'Hanrahan', 0, 1),
(10676, 'Hansack', 0, 1),
(10677, 'Hansell', 0, 1),
(10678, 'Hansen', 0, 1),
(10679, 'Hanson', 0, 1),
(10680, 'Happ', 0, 1),
(10681, 'Harang', 0, 1),
(10682, 'Harben', 0, 1),
(10683, 'Harden', 0, 1),
(10684, 'Hardtke', 0, 1),
(10685, 'Hardy', 0, 1),
(10686, 'Haren', 0, 1),
(10687, 'Harikkala', 0, 1),
(10688, 'Harkey', 0, 1),
(10689, 'Harman', 0, 1),
(10690, 'Harnisch', 0, 1),
(10691, 'Harper', 0, 1),
(10692, 'Harrell', 0, 1),
(10693, 'Harriger', 0, 1),
(10694, 'Harrington', 0, 1),
(10695, 'Harris', 0, 1),
(10696, 'Harrison', 0, 1),
(10697, 'Hart', 0, 1),
(10698, 'Hartgraves', 0, 1),
(10699, 'Harts', 0, 1),
(10700, 'Harvey', 0, 1),
(10701, 'Harville', 0, 1),
(10702, 'Hasegawa', 0, 1),
(10703, 'Haseley', 0, 1),
(10704, 'Haselman', 0, 1),
(10705, 'Hassan', 0, 1),
(10706, 'Hasselhoff', 0, 1),
(10707, 'Hatch', 0, 1),
(10708, 'Hatcher', 0, 1),
(10709, 'Hathaway', 0, 1),
(10710, 'Hatley', 0, 1),
(10711, 'Hatteberg', 0, 1),
(10712, 'Hattig', 0, 1),
(10713, 'Hatton', 0, 1),
(10714, 'Hauschild', 0, 1),
(10715, 'Hauser', 0, 1),
(10716, 'Havens', 0, 1),
(10717, 'Hawblitzel', 0, 1),
(10718, 'Hawk', 0, 1),
(10719, 'Hawkins', 0, 1),
(10720, 'Hawksworth', 0, 1),
(10721, 'Hawn', 0, 1),
(10722, 'Hawpe', 0, 1),
(10723, 'Haydel', 0, 1),
(10724, 'Hayenga', 0, 1),
(10725, 'Hayes', 0, 1),
(10726, 'Hayhurst', 0, 1),
(10727, 'Haynes', 0, 1),
(10728, 'Hays', 0, 1),
(10729, 'Hayward', 0, 1),
(10730, 'Hazelbaker', 0, 1),
(10731, 'Head', 0, 1),
(10732, 'Headley', 0, 1),
(10733, 'Healy', 0, 1),
(10734, 'Heames', 0, 1),
(10735, 'Heams', 0, 1),
(10736, 'Heaney', 0, 1),
(10737, 'Hearn', 0, 1),
(10738, 'Heath', 0, 1),
(10739, 'Heathcott', 0, 1),
(10740, 'Heatherly', 0, 1),
(10741, 'Heaverlo', 0, 1),
(10742, 'Hebson', 0, 1),
(10743, 'Hechavarria', 0, 1),
(10744, 'Heckathorn', 0, 1),
(10745, 'Hedges', 0, 1),
(10746, 'Hedrick', 0, 1),
(10747, 'Heether', 0, 1),
(10748, 'Hefflinger', 0, 1),
(10749, 'Hefner', 0, 1),
(10750, 'Hehr', 0, 1),
(10751, 'Heidenreich', 0, 1),
(10752, 'Heilman', 0, 1),
(10753, 'Heim', 0, 1),
(10754, 'Heimlich', 0, 1),
(10755, 'Heineman', 0, 1),
(10756, 'Heintz', 0, 1),
(10757, 'Heiserman', 0, 1),
(10758, 'Heisey', 0, 1),
(10759, 'Heller', 0, 1),
(10760, 'Hellickson', 0, 1),
(10761, 'Helling', 0, 1),
(10762, 'Hellweg', 0, 1),
(10763, 'Helm', 0, 1),
(10764, 'Helms', 0, 1),
(10765, 'Helsley', 0, 1),
(10766, 'Helton', 0, 1),
(10767, 'Hembree', 0, 1),
(10768, 'Hemphill', 0, 1),
(10769, 'Henderson', 0, 1),
(10770, 'Hendricks', 0, 1),
(10771, 'Hendrickson', 0, 1),
(10772, 'Hendriks', 0, 1),
(10773, 'Hendrix', 0, 1),
(10774, 'Henkel', 0, 1),
(10775, 'Henley', 0, 1),
(10776, 'Henn', 0, 1),
(10777, 'Henneman', 0, 1),
(10778, 'Hennessey', 0, 1),
(10779, 'Henriquez', 0, 1),
(10780, 'Henry', 0, 1),
(10781, 'Hensley', 0, 1),
(10782, 'Henson', 0, 1),
(10783, 'Hentgen', 0, 1),
(10784, 'Hentges', 0, 1),
(10785, 'Henzman', 0, 1),
(10786, 'Heras', 0, 1),
(10787, 'Herb', 0, 1),
(10788, 'Herbert', 0, 1),
(10789, 'Heredia', 0, 1),
(10790, 'Herges', 0, 1),
(10791, 'Herget', 0, 1),
(10792, 'Hermansen', 0, 1),
(10793, 'Hermanson', 0, 1),
(10794, 'Hermelyn', 0, 1),
(10795, 'Hermida', 0, 1),
(10796, 'Hermosillo', 0, 1),
(10797, 'Hermsen', 0, 1),
(10798, 'Hernandez', 0, 1),
(10799, 'Herndon', 0, 1),
(10800, 'Herr', 0, 1),
(10801, 'Herrera', 0, 1),
(10802, 'Herrmann', 0, 1),
(10803, 'Herron', 0, 1),
(10804, 'Hershiser', 0, 1),
(10805, 'Herum', 0, 1),
(10806, 'Hess', 0, 1),
(10807, 'Hessler', 0, 1),
(10808, 'Hessman', 0, 1),
(10809, 'Hester', 0, 1),
(10810, 'Heston', 0, 1),
(10811, 'Hewitt', 0, 1),
(10812, 'Heyer', 0, 1),
(10813, 'Heyward', 0, 1),
(10814, 'Hiatt', 0, 1),
(10815, 'Hibbard', 0, 1),
(10816, 'Hicklen', 0, 1),
(10817, 'Hickman', 0, 1),
(10818, 'Hicks', 0, 1),
(10819, 'Hidaka', 0, 1),
(10820, 'Hidalgo', 0, 1),
(10821, 'Hietpas', 0, 1),
(10822, 'Higashioka', 0, 1),
(10823, 'Higginson', 0, 1),
(10824, 'Hildenberger', 0, 1),
(10825, 'Hiljus', 0, 1),
(10826, 'Hill', 0, 1),
(10827, 'Hillenbrand', 0, 1),
(10828, 'Hilliard', 0, 1),
(10829, 'Hilligoss', 0, 1),
(10830, 'Hillman', 0, 1),
(10831, 'Himes', 0, 1),
(10832, 'Hinch', 0, 1),
(10833, 'Hinchliffe', 0, 1),
(10834, 'Hinckley', 0, 1),
(10835, 'Hines', 0, 1),
(10836, 'Hinojosa', 0, 1),
(10837, 'Hinshaw', 0, 1),
(10838, 'Hinske', 0, 1),
(10839, 'Hinsz', 0, 1),
(10840, 'Hinton', 0, 1),
(10841, 'Hirai', 0, 1),
(10842, 'Hiraldo', 0, 1),
(10843, 'Hirano', 0, 1),
(10844, 'Hirsh', 0, 1),
(10845, 'Hissey', 0, 1),
(10846, 'Hitchcock', 0, 1),
(10847, 'Hiura', 0, 1),
(10848, 'Hoard', 0, 1),
(10849, 'Hobgood', 0, 1),
(10850, 'Hobson', 0, 1),
(10851, 'Hochevar', 0, 1),
(10852, 'Hock', 0, 1),
(10853, 'Hockin', 0, 1),
(10854, 'Hocking', 0, 1),
(10855, 'Hodge', 0, 1),
(10856, 'Hodges', 0, 1),
(10857, 'Hoehn', 0, 1),
(10858, 'Hoelscher', 0, 1),
(10859, 'Hoerman', 0, 1),
(10860, 'Hoes', 0, 1),
(10861, 'Hoey', 0, 1),
(10862, 'Hoffman', 0, 1),
(10863, 'Hoffmann', 0, 1),
(10864, 'Hoffpauir', 0, 1),
(10865, 'Hogan', 0, 1),
(10866, 'Hoiles', 0, 1),
(10867, 'Holaday', 0, 1),
(10868, 'Holbert', 0, 1),
(10869, 'Holbrooks', 0, 1),
(10870, 'Holcomb', 0, 1),
(10871, 'Holden', 0, 1),
(10872, 'Holder', 0, 1),
(10873, 'Holdridge', 0, 1),
(10874, 'Holdzkom', 0, 1),
(10875, 'Holland', 0, 1),
(10876, 'Hollands', 0, 1),
(10877, 'Hollandsworth', 0, 1),
(10878, 'Holliday', 0, 1),
(10879, 'Holliman', 0, 1),
(10880, 'Hollimon', 0, 1),
(10881, 'Hollingsworth', 0, 1),
(10882, 'Hollins', 0, 1),
(10883, 'Hollon', 0, 1),
(10884, 'Holm', 0, 1),
(10885, 'Holmberg', 0, 1),
(10886, 'Holmes', 0, 1),
(10887, 'Holt', 0, 1),
(10888, 'Holtz', 0, 1),
(10889, 'Holzemer', 0, 1),
(10890, 'Homer', 0, 1),
(10891, 'Honel', 0, 1),
(10892, 'Honeycutt', 0, 1),
(10893, 'Honeywell', 0, 1),
(10894, 'Hood', 0, 1),
(10895, 'Hook', 0, 1),
(10896, 'Hooker', 0, 1),
(10897, 'Hooper', 0, 1),
(10898, 'Hoorelbeke', 0, 1),
(10899, 'Hoover', 0, 1),
(10900, 'Hope', 0, 1),
(10901, 'Hopkins', 0, 1),
(10902, 'Hopper', 0, 1),
(10903, 'Horacek', 0, 1),
(10904, 'Horgan', 0, 1),
(10905, 'Horn', 0, 1),
(10906, 'Hornbeck', 0, 1),
(10907, 'Horne', 0, 1),
(10908, 'Horst', 0, 1),
(10909, 'Horton', 0, 1),
(10910, 'Horwitz', 0, 1),
(10911, 'Hosey', 0, 1),
(10912, 'Hoshino', 0, 1),
(10913, 'Hoskins', 0, 1),
(10914, 'Hosmer', 0, 1),
(10915, 'Hottovy', 0, 1),
(10916, 'Houck', 0, 1),
(10917, 'Houlton', 0, 1),
(10918, 'House', 0, 1),
(10919, 'Houser', 0, 1),
(10920, 'Housman', 0, 1),
(10921, 'Houston', 0, 1),
(10922, 'Howard', 0, 1),
(10923, 'Howe', 0, 1),
(10924, 'Howell', 0, 1),
(10925, 'Howington', 0, 1),
(10926, 'Howry', 0, 1),
(10927, 'Hoying', 0, 1),
(10928, 'Hoyman', 0, 1),
(10929, 'Hoyt', 0, 1),
(10930, 'Hu', 0, 1),
(10931, 'Huang', 0, 1),
(10932, 'Hubbard', 0, 1),
(10933, 'Hubbs', 0, 1),
(10934, 'Hubele', 0, 1),
(10935, 'Huber', 0, 1),
(10936, 'Huchingson', 0, 1),
(10937, 'Huckaby', 0, 1),
(10938, 'Hudek', 0, 1),
(10939, 'Hudgins', 0, 1),
(10940, 'Hudler', 0, 1),
(10941, 'Hudson', 0, 1),
(10942, 'Hudspeth', 0, 1),
(10943, 'Huerta', 0, 1),
(10944, 'Huff', 0, 1),
(10945, 'Huffman', 0, 1),
(10946, 'Huggins', 0, 1),
(10947, 'Hughes', 0, 1),
(10948, 'Hughston', 0, 1),
(10949, 'Huisman', 0, 1),
(10950, 'Hulett', 0, 1),
(10951, 'Hull', 0, 1),
(10952, 'Hulse', 0, 1),
(10953, 'Hulsman', 0, 1),
(10954, 'Hultzen', 0, 1),
(10955, 'Humber', 0, 1),
(10956, 'Hummel', 0, 1),
(10957, 'Humphreys', 0, 1),
(10958, 'Humphries', 0, 1),
(10959, 'Hundley', 0, 1),
(10960, 'Hunt', 0, 1),
(10961, 'Hunter', 0, 1),
(10962, 'Huntzinger', 0, 1),
(10963, 'Hurk', 0, 1),
(10964, 'Hurlbut', 0, 1),
(10965, 'Hurley', 0, 1),
(10966, 'Hursh', 0, 1),
(10967, 'Hurst', 0, 1),
(10968, 'Hurt', 0, 1),
(10969, 'Hurtado', 0, 1),
(10970, 'Huseby', 0, 1),
(10971, 'Huskey', 0, 1),
(10972, 'Huson', 0, 1),
(10973, 'Hussey', 0, 1),
(10974, 'Hutchins', 0, 1),
(10975, 'Hutchinson', 0, 1),
(10976, 'Hutchison', 0, 1),
(10977, 'Hutting', 0, 1),
(10978, 'Hutton', 0, 1),
(10979, 'Hwang', 0, 1),
(10980, 'Hyatt', 0, 1),
(10981, 'Hyde', 0, 1),
(10982, 'Hyers', 0, 1),
(10983, 'Hynes', 0, 1),
(10984, 'Hynick', 0, 1),
(10985, 'Hyun-Jin', 0, 1),
(10986, 'Hyzdu', 0, 1),
(10987, 'Iannetta', 0, 1),
(10988, 'Iapoce', 0, 1),
(10989, 'Ibanez', 0, 1),
(10990, 'Ibarra', 0, 1),
(10991, 'Ice', 0, 1),
(10992, 'Igarashi', 0, 1),
(10993, 'Igawa', 0, 1),
(10994, 'Iglesias', 0, 1),
(10995, 'Iguchi', 0, 1),
(10996, 'Iida', 0, 1),
(10997, 'Ilk', 0, 1),
(10998, 'Imhof', 0, 1),
(10999, 'Inaba', 0, 1),
(11000, 'Incaviglia', 0, 1),
(11001, 'Inch', 0, 1),
(11002, 'Inciarte', 0, 1),
(11003, 'Infante', 0, 1),
(11004, 'Inge', 0, 1),
(11005, 'Inglett', 0, 1),
(11006, 'Ingram', 0, 1),
(11007, 'Inman', 0, 1),
(11008, 'Inoa', 0, 1),
(11009, 'Iorg', 0, 1),
(11010, 'Irabu', 0, 1),
(11011, 'Ireland', 0, 1),
(11012, 'Iribarren', 0, 1),
(11013, 'Iriki', 0, 1),
(11014, 'Irvin', 0, 1),
(11015, 'Irwin', 0, 1),
(11016, 'Isenberg', 0, 1),
(11017, 'Isenia', 0, 1),
(11018, 'Ishii', 0, 1),
(11019, 'Ishikawa', 0, 1),
(11020, 'Isringhausen', 0, 1),
(11021, 'Italiano', 0, 1),
(11022, 'Itoi', 0, 1),
(11023, 'Ivany', 0, 1),
(11024, 'Ivey', 0, 1),
(11025, 'Iwakuma', 0, 1),
(11026, 'Iwamura', 0, 1),
(11027, 'Iwase', 0, 1),
(11028, 'Izquierdo', 0, 1),
(11029, 'Izturis', 0, 1),
(11030, 'Izturis Jr.', 0, 1),
(11031, 'Jackson', 0, 1),
(11032, 'Jacob', 0, 1),
(11033, 'Jacobo', 0, 1),
(11034, 'Jacobs', 0, 1),
(11035, 'Jacobsen', 0, 1),
(11036, 'Jacobson', 0, 1),
(11037, 'Jacome', 0, 1),
(11038, 'Jacquez', 0, 1),
(11039, 'Jae-Hoon', 0, 1),
(11040, 'Jaffe', 0, 1),
(11041, 'Jagielo', 0, 1),
(11042, 'Jaha', 0, 1),
(11043, 'Jaime', 0, 1),
(11044, 'Jakubauskas', 0, 1),
(11045, 'James', 0, 1),
(11046, 'Jamie', 0, 1),
(11047, 'Jamison', 0, 1),
(11048, 'Jang', 0, 1),
(11049, 'Janish', 0, 1),
(11050, 'Jankowski', 0, 1),
(11051, 'Jansen', 0, 1),
(11052, 'Janssen', 0, 1),
(11053, 'Januario', 0, 1),
(11054, 'January', 0, 1),
(11055, 'Janzen', 0, 1),
(11056, 'Jaramillo', 0, 1),
(11057, 'Jarmon', 0, 1),
(11058, 'Jarvis', 0, 1),
(11059, 'Jasco', 0, 1),
(11060, 'Jaskie', 0, 1),
(11061, 'Jaso', 0, 1),
(11062, 'Javier', 0, 1),
(11063, 'Jax', 0, 1),
(11064, 'Jay', 0, 1),
(11065, 'Jaye', 0, 1),
(11066, 'Jebavy', 0, 1),
(11067, 'Jefferies', 0, 1),
(11068, 'Jefferson', 0, 1),
(11069, 'Jeffress', 0, 1),
(11070, 'Jemiola', 0, 1),
(11071, 'Jenkins', 0, 1),
(11072, 'Jenks', 0, 1),
(11073, 'Jennings', 0, 1),
(11074, 'Jensen', 0, 1),
(11075, 'Jepsen', 0, 1),
(11076, 'Jerez', 0, 1),
(11077, 'Jeroloman', 0, 1),
(11078, 'Jerzembeck', 0, 1),
(11079, 'JesusJesus', 0, 1),
(11080, 'Jeter', 0, 1),
(11081, 'Jewell', 0, 1),
(11082, 'Jimenez', 0, 1),
(11083, 'Jimerson', 0, 1),
(11084, 'Jiminian', 0, 1),
(11085, 'Jipping', 0, 1),
(11086, 'Joaquin', 0, 1),
(11087, 'Jodie', 0, 1),
(11088, 'Joe', 0, 1),
(11089, 'Johansen', 0, 1),
(11090, 'Johjima', 0, 1),
(11091, 'Johns', 0, 1),
(11092, 'Johnson', 0, 1),
(11093, 'Johnston', 0, 1),
(11094, 'Johnstone', 0, 1),
(11095, 'joke', 0, 0),
(11096, 'Jokisch', 0, 1),
(11097, 'Jones', 0, 1),
(11098, 'Jordan', 0, 1),
(11099, 'Jorge', 0, 1),
(11100, 'Jorgensen', 0, 1),
(11101, 'Jorgenson', 0, 1),
(11102, 'Jose', 0, 1),
(11103, 'Joseph', 0, 1),
(11104, 'Journell', 0, 1),
(11105, 'Joyce', 0, 1),
(11106, 'Joyner', 0, 1),
(11107, 'Juarez', 0, 1),
(11108, 'Judd', 0, 1),
(11109, 'Juden', 0, 1),
(11110, 'Judge', 0, 1),
(11111, 'Judy', 0, 1),
(11112, 'Juengel', 0, 1),
(11113, 'Jukich', 0, 1),
(11114, 'Julianel', 0, 1),
(11115, 'Julio', 0, 1),
(11116, 'Julius', 0, 1),
(11117, 'Jung', 0, 1),
(11118, 'Junge', 0, 1),
(11119, 'Jungmann', 0, 1),
(11120, 'Junis', 0, 1),
(11121, 'Jurado', 0, 1),
(11122, 'Jurica', 0, 1),
(11123, 'Jurries', 0, 1),
(11124, 'Jurrjens', 0, 1),
(11125, 'Justice', 0, 1),
(11126, 'Justus', 0, 1),
(11127, 'Kaaihue', 0, 1),
(11128, 'Kadokura', 0, 1),
(11129, 'Kahaloa', 0, 1),
(11130, 'Kahn', 0, 1),
(11131, 'Kahnle', 0, 1),
(11132, 'Kaiser', 0, 1),
(11133, 'Kalinowski', 0, 1),
(11134, 'Kalish', 0, 1),
(11135, 'Kalita', 0, 1),
(11136, 'Kamieniecki', 0, 1),
(11137, 'Kaminska', 0, 1),
(11138, 'Kaminsky', 0, 1),
(11139, 'Kanaby', 0, 1),
(11140, 'Kandilas', 0, 1),
(11141, 'Kaneko', 0, 1),
(11142, 'Kanemoto', 0, 1),
(11143, 'Kang', 0, 1),
(11144, 'Kanzler', 0, 1),
(11145, 'Kapler', 0, 1),
(11146, 'Kaprielian', 0, 1),
(11147, 'Karchner', 0, 1),
(11148, 'Karinchak', 0, 1),
(11149, 'Karkovice', 0, 1),
(11150, 'Karl', 0, 1),
(11151, 'Karns', 0, 1),
(11152, 'Karnuth', 0, 1),
(11153, 'Karp', 0, 1),
(11154, 'Karros', 0, 1),
(11155, 'Karsay', 0, 1),
(11156, 'Karstens', 0, 1),
(11157, 'Kashiwada', 0, 1),
(11158, 'Kata', 0, 1),
(11159, 'Katin', 0, 1),
(11160, 'Katoh', 0, 1),
(11161, 'Katz', 0, 1),
(11162, 'Kawagoe', 0, 1),
(11163, 'Kawakami', 0, 1),
(11164, 'Kawasaki', 0, 1),
(11165, 'Kay', 0, 1),
(11166, 'Kaye', 0, 1),
(11167, 'Kazmar', 0, 1),
(11168, 'Kazmir', 0, 1),
(11169, 'Keagle', 0, 1),
(11170, 'Kearns', 0, 1),
(11171, 'Keating', 0, 1),
(11172, 'Keefer', 0, 1),
(11173, 'Keel', 0, 1),
(11174, 'Kehrer', 0, 1),
(11175, 'Keim', 0, 1),
(11176, 'Keisler', 0, 1),
(11177, 'Kela', 0, 1),
(11178, 'Keller', 0, 1),
(11179, 'Kelley', 0, 1),
(11180, 'Kelly', 0, 1),
(11181, 'Kelton', 0, 1),
(11182, 'Kemp', 0, 1),
(11183, 'Kempf', 0, 1),
(11184, 'Ken', 0, 1),
(11185, 'Kendall', 0, 1),
(11186, 'Kendrick', 0, 1),
(11187, 'Keng', 0, 1),
(11188, 'Kennard', 0, 1),
(11189, 'Kennedy', 0, 1),
(11190, 'Kennelly', 0, 1),
(11191, 'Kensing', 0, 1),
(11192, 'Kent', 0, 1),
(11193, 'Kepler', 0, 1),
(11194, 'Keppel', 0, 1),
(11195, 'Keppinger', 0, 1),
(11196, 'Kern', 0, 1),
(11197, 'Kershaw', 0, 1),
(11198, 'Kershner', 0, 1),
(11199, 'Ketchner', 0, 1),
(11200, 'Keuchel', 0, 1),
(11201, 'Keudell', 0, 1),
(11202, 'Key', 0, 1),
(11203, 'Keyes', 0, 1),
(11204, 'Keylor', 0, 1),
(11205, 'Keys', 0, 1),
(11206, 'Keyser', 0, 1),
(11207, 'Kibler', 0, 1),
(11208, 'Kickham', 0, 1),
(11209, 'Kida', 0, 1),
(11210, 'Kieboom', 0, 1),
(11211, 'Kiekhefer', 0, 1),
(11212, 'Kielty', 0, 1),
(11213, 'Kiermaier', 0, 1),
(11214, 'Kieschnick', 0, 1),
(11215, 'Kiger', 0, 1),
(11216, 'Kiker', 0, 1),
(11217, 'Kikuchi', 0, 1),
(11218, 'Kilby', 0, 1),
(11219, 'Kile', 0, 1),
(11220, 'Killian', 0, 1),
(11221, 'Kilome', 0, 1),
(11222, 'Kim', 0, 1),
(11223, 'Kimball', 0, 1),
(11224, 'Kimbrel', 0, 1),
(11225, 'Kime', 0, 1),
(11226, 'Kindel', 0, 1),
(11227, 'Kiner-Falefa', 0, 1),
(11228, 'King', 0, 1),
(11229, 'Kingery', 0, 1),
(11230, 'Kingham', 0, 1),
(11231, 'Kingsale', 0, 1),
(11232, 'Kiniry', 0, 1),
(11233, 'Kinjoh', 0, 1),
(11234, 'Kinkade', 0, 1),
(11235, 'Kinley', 0, 1),
(11236, 'Kinney', 0, 1),
(11237, 'Kinsler', 0, 1),
(11238, 'Kintzler', 0, 1),
(11239, 'Kipnis', 0, 1),
(11240, 'Kipper', 0, 1),
(11241, 'Kirby', 0, 1),
(11242, 'Kirilloff', 0, 1),
(11243, 'Kirk', 0, 1),
(11244, 'Kirkland', 0, 1),
(11245, 'Kirkman', 0, 1),
(11246, 'Kite', 0, 1),
(11247, 'Kittredge', 0, 1),
(11248, 'Kivlehan', 0, 1),
(11249, 'Kjeldgaard', 0, 1),
(11250, 'Klassen', 0, 1),
(11251, 'Klatt', 0, 1),
(11252, 'Klein', 0, 1),
(11253, 'Klesko', 0, 1),
(11254, 'Kline', 0, 1),
(11255, 'Klingenbeck', 0, 1),
(11256, 'Klink', 0, 1),
(11257, 'Klinker', 0, 1),
(11258, 'Kloess', 0, 1),
(11259, 'Kloosterman', 0, 1),
(11260, 'Kluber', 0, 1),
(11261, 'Kmak', 0, 1),
(11262, 'Knackert', 0, 1),
(11263, 'Knapp', 0, 1),
(11264, 'Knebel', 0, 1),
(11265, 'Knecht', 0, 1),
(11266, 'Knigge', 0, 1),
(11267, 'Knight', 0, 1),
(11268, 'Kniginyzky', 0, 1),
(11269, 'Knizner', 0, 1),
(11270, 'Knoblauch', 0, 1),
(11271, 'Knoedler', 0, 1),
(11272, 'Knorr', 0, 1),
(11273, 'Knott', 0, 1),
(11274, 'Knotts', 0, 1),
(11275, 'Knowles', 0, 1),
(11276, 'Knox', 0, 1),
(11277, 'Knudson', 0, 1),
(11278, 'Kobayashi', 0, 1),
(11279, 'Kobernus', 0, 1),
(11280, 'Koch', 0, 1),
(11281, 'Koehler', 0, 1),
(11282, 'Kohler', 0, 1),
(11283, 'Kohlmeier', 0, 1),
(11284, 'Kohlscheen', 0, 1),
(11285, 'Kohn', 0, 1),
(11286, 'Kolarek', 0, 1),
(11287, 'Kolb', 0, 1),
(11288, 'Kolek', 0, 1),
(11289, 'Komatsu', 0, 1),
(11290, 'Kometani', 0, 1),
(11291, 'Komine', 0, 1),
(11292, 'Komiyama', 0, 1),
(11293, 'Konerko', 0, 1),
(11294, 'Kontos', 0, 1),
(11295, 'Koo', 0, 1),
(11296, 'Koonce', 0, 1),
(11297, 'Kopech', 0, 1),
(11298, 'Kopitzke', 0, 1),
(11299, 'Koplove', 0, 1),
(11300, 'Kopp', 0, 1),
(11301, 'Korecky', 0, 1),
(11302, 'Korneev', 0, 1),
(11303, 'Koronka', 0, 1),
(11304, 'Koshansky', 0, 1),
(11305, 'Koskie', 0, 1),
(11306, 'Koss', 0, 1),
(11307, 'Kotchman', 0, 1),
(11308, 'Kotsay', 0, 1),
(11309, 'Kottaras', 0, 1),
(11310, 'Kouzmanoff', 0, 1),
(11311, 'Kown', 0, 1),
(11312, 'Kozlowski', 0, 1),
(11313, 'Kozma', 0, 1),
(11314, 'Kral', 0, 1),
(11315, 'Kramer', 0, 1),
(11316, 'Kranick', 0, 1),
(11317, 'Kratz', 0, 1),
(11318, 'Krause', 0, 1),
(11319, 'Krauss', 0, 1),
(11320, 'Krehbiel', 0, 1),
(11321, 'Kreuter', 0, 1),
(11322, 'Kreuzer', 0, 1),
(11323, 'Krieger', 0, 1),
(11324, 'Krivda', 0, 1),
(11325, 'Krizan', 0, 1),
(11326, 'Kroeger', 0, 1),
(11327, 'Kroenke', 0, 1),
(11328, 'Krol', 0, 1),
(11329, 'Krook', 0, 1),
(11330, 'Kroon', 0, 1),
(11331, 'Krosschell', 0, 1),
(11332, 'Krum', 0, 1),
(11333, 'Krynzel', 0, 1),
(11334, 'Kubel', 0, 1),
(11335, 'Kubenka', 0, 1),
(11336, 'Kubinski', 0, 1),
(11337, 'Kubitza', 0, 1),
(11338, 'Kuhl', 0, 1),
(11339, 'Kuhn', 0, 1),
(11340, 'Kukuk', 0, 1),
(11341, 'Kulbacki', 0, 1),
(11342, 'Kumagai', 0, 1),
(11343, 'Kunz', 0, 1),
(11344, 'Kuo', 0, 1),
(11345, 'Kurcz', 0, 1),
(11346, 'Kurihara', 0, 1),
(11347, 'Kuroda', 0, 1),
(11348, 'Kusiewicz', 0, 1),
(11349, 'Kuwata', 0, 1),
(11350, 'Kvasnicka', 0, 1),
(11351, 'Kzldrjgsa', 0, 1),
(11352, 'La O', 0, 1),
(11353, 'La Stella', 0, 1),
(11354, 'Labandeira', 0, 1),
(11355, 'Labas', 0, 1),
(11356, 'Labourt', 0, 1),
(11357, 'Lackey', 0, 1),
(11358, 'Lacy', 0, 1),
(11359, 'Ladendorf', 0, 1),
(11360, 'Lafferty', 0, 1),
(11361, 'Laffey', 0, 1),
(11362, 'LaForest', 0, 1),
(11363, 'LaFromboise', 0, 1),
(11364, 'Lagares', 0, 1),
(11365, 'LaHair', 0, 1),
(11366, 'Lahey', 0, 1),
(11367, 'Lail', 0, 1),
(11368, 'Laird', 0, 1),
(11369, 'Lake', 0, 1),
(11370, 'Laker', 0, 1),
(11371, 'Lakins', 0, 1),
(11372, 'Lakman', 0, 1),
(11373, 'Lalli', 0, 1),
(11374, 'LaMacchia', 0, 1),
(11375, 'LaMarre', 0, 1),
(11376, 'Lamb', 0, 1),
(11377, 'Lambert', 0, 1),
(11378, 'Lambin', 0, 1),
(11379, 'Lambo', 0, 1),
(11380, 'Lambson', 0, 1),
(11381, 'Lamet', 0, 1),
(11382, 'Lamontagne', 0, 1),
(11383, 'Lampkin', 0, 1),
(11384, 'Lancellotti', 0, 1),
(11385, 'Landa', 0, 1),
(11386, 'Landazuri', 0, 1),
(11387, 'Landing', 0, 1),
(11388, 'Landry', 0, 1),
(11389, 'Lane', 0, 1),
(11390, 'Lange', 0, 1),
(11391, 'Langerhans', 0, 1),
(11392, 'Langfels', 0, 1),
(11393, 'Langfield', 0, 1),
(11394, 'Langill', 0, 1),
(11395, 'Langley', 0, 1),
(11396, 'Langston', 0, 1),
(11397, 'Langwell', 0, 1),
(11398, 'Lanigan', 0, 1),
(11399, 'Lankford', 0, 1),
(11400, 'Lannan', 0, 1),
(11401, 'Lansford', 0, 1),
(11402, 'Lansing', 0, 1),
(11403, 'Lantigua', 0, 1),
(11404, 'LaPorta', 0, 1),
(11405, 'Lara', 0, 1),
(11406, 'Large', 0, 1),
(11407, 'Larish', 0, 1),
(11408, 'Larkin', 0, 1),
(11409, 'LaRocca', 0, 1),
(11410, 'LaRoche', 0, 1),
(11411, 'Larrison', 0, 1),
(11412, 'Larson', 0, 1),
(11413, 'LaRue', 0, 1),
(11414, 'Lasker', 0, 1),
(11415, 'Laskey', 0, 1),
(11416, 'Laster', 0, 1),
(11417, 'Latham', 0, 1),
(11418, 'Latimore', 0, 1),
(11419, 'Latos', 0, 1),
(11420, 'Lattimore', 0, 1),
(11421, 'Lauer', 0, 1),
(11422, 'Laurean', 0, 1),
(11423, 'Laureano', 0, 1),
(11424, 'Laurencio', 0, 1),
(11425, 'LaValley', 0, 1),
(11426, 'Lavarnway', 0, 1),
(11427, 'Lavery', 0, 1),
(11428, 'Lavisky', 0, 1),
(11429, 'Law', 0, 1),
(11430, 'Lawley', 0, 1),
(11431, 'Lawrence', 0, 1),
(11432, 'Lawrie', 0, 1),
(11433, 'Lawson', 0, 1),
(11434, 'Lawton', 0, 1),
(11435, 'Laxton', 0, 1),
(11436, 'Layfield', 0, 1),
(11437, 'Layman', 0, 1),
(11438, 'Layne', 0, 1),
(11439, 'Lazo', 0, 1),
(11440, 'Leach', 0, 1),
(11441, 'League', 0, 1),
(11442, 'Leahy', 0, 1),
(11443, 'Leake', 0, 1),
(11444, 'Leandro', 0, 1),
(11445, 'Leathersich', 0, 1),
(11446, 'LeBlanc', 0, 1),
(11447, 'Leblebijian', 0, 1),
(11448, 'Lebron', 0, 1),
(11449, 'Leclair', 0, 1),
(11450, 'Leclerc', 0, 1),
(11451, 'LeCroy', 0, 1),
(11452, 'LeCure', 0, 1),
(11453, 'Ledbetter', 0, 1),
(11454, 'Ledee', 0, 1),
(11455, 'Ledesma', 0, 1),
(11456, 'Ledezma', 0, 1),
(11457, 'Leduc', 0, 1),
(11458, 'Lee', 0, 1),
(11459, 'Leesman', 0, 1),
(11460, 'Lefave', 0, 1),
(11461, 'Leffler', 0, 1),
(11462, 'Leftwich', 0, 1),
(11463, 'Lehman', 0, 1),
(11464, 'Lehr', 0, 1),
(11465, 'Leicester', 0, 1),
(11466, 'Leiper', 0, 1),
(11467, 'Leiter', 0, 1),
(11468, 'Leius', 0, 1),
(11469, 'LeMahieu', 0, 1),
(11470, 'Lemanczyk', 0, 1),
(11471, 'Lemke', 0, 1),
(11472, 'Lemmerman', 0, 1),
(11473, 'Lemoine', 0, 1),
(11474, 'Lemon', 0, 1),
(11475, 'Lemond', 0, 1),
(11476, 'Lemons', 0, 1),
(11477, 'Lennerton', 0, 1),
(11478, 'Lennon', 0, 1),
(11479, 'Leon', 0, 1),
(11480, 'Leonard', 0, 1),
(11481, 'Leone', 0, 1),
(11482, 'Leonida', 0, 1),
(11483, 'Lerew', 0, 1),
(11484, 'Leroux', 0, 1),
(11485, 'LeRoy', 0, 1),
(11486, 'Lerud', 0, 1),
(11487, 'Lesher', 0, 1),
(11488, 'Leskanic', 0, 1),
(11489, 'Leslie', 0, 1),
(11490, 'Lester', 0, 1),
(11491, 'Levine', 0, 1),
(11492, 'Levinski', 0, 1),
(11493, 'Levis', 0, 1),
(11494, 'Levrault', 0, 1),
(11495, 'Lewicki', 0, 1),
(11496, 'Lewis', 0, 1),
(11497, 'Leyba', 0, 1),
(11498, 'Leyland', 0, 1),
(11499, 'Leyritz', 0, 1),
(11500, 'Liberato', 0, 1),
(11501, 'Liberatore', 0, 1),
(11502, 'Licea', 0, 1),
(11503, 'Liddi', 0, 1),
(11504, 'Lidge', 0, 1),
(11505, 'Lidle', 0, 1),
(11506, 'Liebel', 0, 1),
(11507, 'Lieber', 0, 1),
(11508, 'Lieberthal', 0, 1),
(11509, 'Liefer', 0, 1),
(11510, 'Lien', 0, 1),
(11511, 'Lietz', 0, 1),
(11512, 'Light', 0, 1),
(11513, 'Ligtenberg', 0, 1),
(11514, 'Lilek', 0, 1),
(11515, 'Lillibridge', 0, 1),
(11516, 'Lillie', 0, 1),
(11517, 'Lilly', 0, 1),
(11518, 'Lim', 0, 1),
(11519, 'Lima', 0, 1),
(11520, 'Lin', 0, 1),
(11521, 'Linares', 0, 1),
(11522, 'Lincecum', 0, 1),
(11523, 'Lincoln', 0, 1),
(11524, 'Lind', 0, 1),
(11525, 'Lindblom', 0, 1),
(11526, 'Linden', 0, 1),
(11527, 'Lindgren', 0, 1),
(11528, 'Lindor', 0, 1),
(11529, 'Lindsay', 0, 1),
(11530, 'Lindsey', 0, 1),
(11531, 'Lindstrom', 0, 1),
(11532, 'Linebrink', 0, 1),
(11533, 'Linginfelter', 0, 1),
(11534, 'Liniak', 0, 1),
(11535, 'Link', 0, 1),
(11536, 'Lino', 0, 1),
(11537, 'Linsky', 0, 1),
(11538, 'Linton', 0, 1),
(11539, 'Lintz', 0, 1),
(11540, 'Liotta', 0, 1),
(11541, 'Lipka', 0, 1),
(11542, 'Lira', 0, 1),
(11543, 'Liranzo', 0, 1),
(11544, 'Liriano', 0, 1),
(11545, 'Lis', 0, 1),
(11546, 'Lisk', 0, 1),
(11547, 'Lisson', 0, 1),
(11548, 'Listach', 0, 1),
(11549, 'Litsch', 0, 1),
(11550, 'Littell', 0, 1),
(11551, 'Little', 0, 1),
(11552, 'Littleton', 0, 1),
(11553, 'Littlewood', 0, 1),
(11554, 'Littrell', 0, 1),
(11555, 'Liu', 0, 1),
(11556, 'Lively', 0, 1),
(11557, 'Livengood', 0, 1),
(11558, 'Livingston', 0, 1),
(11559, 'Livingstone', 0, 1),
(11560, 'Liz', 0, 1),
(11561, 'Lizarraga', 0, 1),
(11562, 'Llanos', 0, 1),
(11563, 'Llovera', 0, 1),
(11564, 'Lloyd', 0, 1),
(11565, 'Lluberes', 0, 1),
(11566, 'Lo', 0, 1),
(11567, 'Lo Duca', 0, 1),
(11568, 'Loadenthal', 0, 1),
(11569, 'Loaisiga', 0, 1),
(11570, 'Loaiza', 0, 1),
(11571, 'Lobaton', 0, 1),
(11572, 'Lobstein', 0, 1),
(11573, 'Locante', 0, 1),
(11574, 'Locastro', 0, 1),
(11575, 'Locke', 0, 1),
(11576, 'Locker', 0, 1),
(11577, 'Lockett', 0, 1),
(11578, 'Lockhart', 0, 1),
(11579, 'Lockwood', 0, 1),
(11580, 'Lodolo', 0, 1),
(11581, 'Loe', 0, 1),
(11582, 'Loewen', 0, 1),
(11583, 'Loewer', 0, 1),
(11584, 'Lofgren', 0, 1),
(11585, 'Lofton', 0, 1),
(11586, 'Logan', 0, 1),
(11587, 'Lohman', 0, 1),
(11588, 'Lohse', 0, 1),
(11589, 'Loiselle', 0, 1),
(11590, 'Lollis', 0, 1),
(11591, 'Loman', 0, 1),
(11592, 'Lomasney', 0, 1),
(11593, 'Lombard', 0, 1),
(11594, 'Lombardozzi', 0, 1),
(11595, 'Loney', 0, 1),
(11596, 'Long', 0, 1),
(11597, 'Longhi', 0, 1),
(11598, 'Longmire', 0, 1),
(11599, 'Longo', 0, 1),
(11600, 'Longoria', 0, 1),
(11601, 'Lonsway', 0, 1),
(11602, 'Loo', 0, 1),
(11603, 'Looper', 0, 1),
(11604, 'Loopstok', 0, 1),
(11605, 'Loosen', 0, 1),
(11606, 'Lopes', 0, 1),
(11607, 'Lopez', 0, 1),
(11608, 'Lora', 0, 1),
(11609, 'Loree', 0, 1),
(11610, 'Lorenzen', 0, 1),
(11611, 'Lorenzo', 0, 1),
(11612, 'Loretta', 0, 1),
(11613, 'Lorin', 0, 1),
(11614, 'Lorraine', 0, 1),
(11615, 'Lotzkar', 0, 1),
(11616, 'Lough', 0, 1),
(11617, 'Louis', 0, 1),
(11618, 'Loup', 0, 1),
(11619, 'Loux', 0, 1),
(11620, 'Lovegrove', 0, 1),
(11621, 'Lovelady', 0, 1),
(11622, 'Lovullo', 0, 1),
(11623, 'Lowe', 0, 1),
(11624, 'Lowell', 0, 1),
(11625, 'Lowery', 0, 1),
(11626, 'Lowrie', 0, 1),
(11627, 'Lowry', 0, 1),
(11628, 'Lowther', 0, 1),
(11629, 'Loyola', 0, 1),
(11630, 'Lozada', 0, 1),
(11631, 'Lubanski', 0, 1),
(11632, 'Lucas', 0, 1),
(11633, 'Lucati', 0, 1),
(11634, 'Lucchesi', 0, 1),
(11635, 'Lucroy', 0, 1),
(11636, 'Lucy', 0, 1),
(11637, 'Ludwick', 0, 1),
(11638, 'Luebbers', 0, 1),
(11639, 'Luebke', 0, 1),
(11640, 'Lueke', 0, 1),
(11641, 'Luellwitz', 0, 1),
(11642, 'Luetge', 0, 1),
(11643, 'Lugbauer', 0, 1),
(11644, 'Lugo', 0, 1),
(11645, 'Luis', 0, 1),
(11646, 'Lujan', 0, 1),
(11647, 'Lukasiewicz', 0, 1),
(11648, 'Luke', 0, 1),
(11649, 'Lumsden', 0, 1),
(11650, 'Luna', 0, 1),
(11651, 'Lunar', 0, 1),
(11652, 'Lund', 0, 1),
(11653, 'Lundberg', 0, 1),
(11654, 'Lundquist', 0, 1),
(11655, 'Lunsford', 0, 1),
(11656, 'Luplow', 0, 1),
(11657, 'Lutz', 0, 1),
(11658, 'Luuloa', 0, 1),
(11659, 'Lux', 0, 1),
(11660, 'Luzardo', 0, 1),
(11661, 'Lydon', 0, 1),
(11662, 'Lyerly', 0, 1),
(11663, 'Lyles', 0, 1),
(11664, 'Lyman', 0, 1),
(11665, 'Lynch', 0, 1),
(11666, 'Lynn', 0, 1),
(11667, 'Lyon', 0, 1),
(11668, 'Lyons', 0, 1),
(11669, 'Mabeus', 0, 1),
(11670, 'Mabry', 0, 1),
(11671, 'Macdonald', 0, 1),
(11672, 'MacDougal', 0, 1),
(11673, 'Macfarlane', 0, 1),
(11674, 'MacGregor', 0, 1),
(11675, 'Mach', 0, 1),
(11676, 'Machado', 0, 1),
(11677, 'Machi', 0, 1),
(11678, 'Maci', 0, 1),
(11679, 'Macias', 0, 1),
(11680, 'Maciel', 0, 1),
(11681, 'Mack', 0, 1),
(11682, 'Mackowiak', 0, 1),
(11683, 'MacLane', 0, 1),
(11684, 'MacRae', 0, 1),
(11685, 'Macri', 0, 1),
(11686, 'Maday', 0, 1),
(11687, 'Madden', 0, 1),
(11688, 'Maddox', 0, 1),
(11689, 'Maddux', 0, 1),
(11690, 'Made', 0, 1),
(11691, 'Mader', 0, 1),
(11692, 'Madera', 0, 1),
(11693, 'Madero', 0, 1),
(11694, 'Madrigal', 0, 1),
(11695, 'Madritsch', 0, 1),
(11696, 'Madsen', 0, 1),
(11697, 'Madson', 0, 1),
(11698, 'Maduro', 0, 1),
(11699, 'Maeda', 0, 1),
(11700, 'Maekawa', 0, 1),
(11701, 'Maese', 0, 1),
(11702, 'Maestrales', 0, 1),
(11703, 'Maestri', 0, 1),
(11704, 'Magadan', 0, 1),
(11705, 'Magee', 0, 1),
(11706, 'Mager', 0, 1),
(11707, 'Maggi', 0, 1),
(11708, 'Magill', 0, 1),
(11709, 'Magnante', 0, 1),
(11710, 'Magnifico', 0, 1),
(11711, 'Magnuson', 0, 1),
(11712, 'Magrane', 0, 1),
(11713, 'Magruder', 0, 1),
(11714, 'Mahalic', 0, 1),
(11715, 'Mahan', 0, 1),
(11716, 'Mahar', 0, 1),
(11717, 'Mahay', 0, 1),
(11718, 'Mahle', 0, 1),
(11719, 'Maholm', 0, 1),
(11720, 'Mahomes', 0, 1),
(11721, 'Mahoney', 0, 1),
(11722, 'Mahtook', 0, 1),
(11723, 'Maier', 0, 1),
(11724, 'Maile', 0, 1),
(11725, 'Mailman', 0, 1),
(11726, 'Main', 0, 1),
(11727, 'Maine', 0, 1),
(11728, 'Maiques', 0, 1),
(11729, 'Mairena', 0, 1),
(11730, 'Maitan', 0, 1),
(11731, 'Majewski', 0, 1),
(11732, 'Makita', 0, 1),
(11733, 'Malaska', 0, 1),
(11734, 'Malave', 0, 1),
(11735, 'Maldonado', 0, 1),
(11736, 'Malek', 0, 1),
(11737, 'Mallen', 0, 1),
(11738, 'Mallette', 0, 1),
(11739, 'Malloy', 0, 1),
(11740, 'Malm', 0, 1),
(11741, 'Malo', 0, 1),
(11742, 'Malone', 0, 1),
(11743, 'Maloney', 0, 1),
(11744, 'Manaea', 0, 1),
(11745, 'Mancini', 0, 1),
(11746, 'Mandel', 0, 1),
(11747, 'Maness', 0, 1),
(11748, 'Mangini', 0, 1),
(11749, 'Mangum', 0, 1),
(11750, 'Mann', 0, 1),
(11751, 'Manning', 0, 1),
(11752, 'Manno', 0, 1),
(11753, 'Manon', 0, 1),
(11754, 'Manship', 0, 1),
(11755, 'Mantei', 0, 1),
(11756, 'Mantiply', 0, 1),
(11757, 'Manto', 0, 1),
(11758, 'Manuel', 0, 1),
(11759, 'Manwaring', 0, 1),
(11760, 'Manzanillo', 0, 1),
(11761, 'Manzella', 0, 1),
(11762, 'Maples', 0, 1),
(11763, 'Marban', 0, 1),
(11764, 'Marceau', 0, 1),
(11765, 'Marceaux', 0, 1),
(11766, 'Marchan', 0, 1),
(11767, 'Marcum', 0, 1),
(11768, 'Marek', 0, 1),
(11769, 'Margot', 0, 1),
(11770, 'Marimon', 0, 1),
(11771, 'Marin', 0, 1),
(11772, 'Marinan', 0, 1),
(11773, 'Marinez', 0, 1),
(11774, 'Mariot', 0, 1),
(11775, 'Mariotti', 0, 1),
(11776, 'Marisnick', 0, 1),
(11777, 'Marjama', 0, 1),
(11778, 'Markakis', 0, 1),
(11779, 'Markray', 0, 1),
(11780, 'Marks', 0, 1),
(11781, 'Marksberry', 0, 1),
(11782, 'Markwell', 0, 1),
(11783, 'Marlette', 0, 1),
(11784, 'Marlowe', 0, 1),
(11785, 'Marmol', 0, 1),
(11786, 'Marmolejos', 0, 1),
(11787, 'Maronde', 0, 1),
(11788, 'Maroth', 0, 1),
(11789, 'Marquez', 0, 1),
(11790, 'Marquis', 0, 1),
(11791, 'Marrero', 0, 1),
(11792, 'Marsden', 0, 1),
(11793, 'Marsh', 0, 1),
(11794, 'Marshall', 0, 1),
(11795, 'Marson', 0, 1),
(11796, 'Marsonek', 0, 1),
(11797, 'Marsters', 0, 1),
(11798, 'Marte', 0, 1),
(11799, 'Martes', 0, 1),
(11800, 'Marti', 0, 1),
(11801, 'Martin', 0, 1),
(11802, 'Martinelli', 0, 1),
(11803, 'Martinez', 0, 1),
(11804, 'Martinez Jr.', 0, 1),
(11805, 'Martinez Mesa', 0, 1),
(11806, 'Martinez-Esteve', 0, 1),
(11807, 'Martinson', 0, 1),
(11808, 'Martis', 0, 1),
(11809, 'Maru', 0, 1),
(11810, 'Marzano', 0, 1),
(11811, 'Marzilli', 0, 1),
(11812, 'Masaoka', 0, 1),
(11813, 'Masek', 0, 1),
(11814, 'Mashore', 0, 1),
(11815, 'Mason', 0, 1),
(11816, 'Masset', 0, 1),
(11817, 'Massey', 0, 1),
(11818, 'Massiatte', 0, 1),
(11819, 'Masters', 0, 1),
(11820, 'Masterson', 0, 1),
(11821, 'Mastny', 0, 1),
(11822, 'Mastroianni', 0, 1),
(11823, 'Mata', 0, 1),
(11824, 'Mateo', 0, 1),
(11825, 'Materano', 0, 1),
(11826, 'Matheny', 0, 1),
(11827, 'Mather', 0, 1),
(11828, 'Mathes', 0, 1),
(11829, 'Mathews', 0, 1),
(11830, 'Mathias', 0, 1),
(11831, 'Mathieson', 0, 1),
(11832, 'Mathis', 0, 1),
(11833, 'Mathisen', 0, 1),
(11834, 'Matias', 0, 1),
(11835, 'Matienzo', 0, 1),
(11836, 'Matijevic', 0, 1),
(11837, 'Maton', 0, 1),
(11838, 'Matos', 0, 1),
(11839, 'Matranga', 0, 1),
(11840, 'Matsuda', 0, 1),
(11841, 'Matsui', 0, 1),
(11842, 'Matsunaka', 0, 1),
(11843, 'Matsuo', 0, 1),
(11844, 'Matsuzaka', 0, 1),
(11845, 'Mattair', 0, 1),
(11846, 'Mattaliano', 0, 1),
(11847, 'Mattes', 0, 1),
(11848, 'Matthes', 0, 1),
(11849, 'Mattheus', 0, 1),
(11850, 'Matthews', 0, 1),
(11851, 'Matthews Jr.', 0, 1),
(11852, 'Mattingly', 0, 1),
(11853, 'Mattison', 0, 1),
(11854, 'Mattox', 0, 1),
(11855, 'Matuella', 0, 1),
(11856, 'Matumoto', 0, 1),
(11857, 'Matusz', 0, 1),
(11858, 'Matz', 0, 1),
(11859, 'Matzek', 0, 1),
(11860, 'Mauer', 0, 1),
(11861, 'Maurer', 0, 1),
(11862, 'Mauricio', 0, 1),
(11863, 'Maust', 0, 1),
(11864, 'Maxcy', 0, 1),
(11865, 'Maxwell', 0, 1),
(11866, 'May', 0, 1),
(11867, 'Maya', 0, 1),
(11868, 'Mayberry', 0, 1),
(11869, 'Maybin', 0, 1),
(11870, 'Mayers', 0, 1),
(11871, 'Maynard', 0, 1),
(11872, 'Mayne', 0, 1),
(11873, 'Mayora', 0, 1),
(11874, 'Mayorson', 0, 1),
(11875, 'Mays', 0, 1),
(11876, 'Maysonet', 0, 1),
(11877, 'Mayza', 0, 1),
(11878, 'Maza', 0, 1),
(11879, 'Mazara', 0, 1),
(11880, 'Mazeika', 0, 1),
(11881, 'Mazone', 0, 1),
(11882, 'Mazzaro', 0, 1),
(11883, 'Mazzilli', 0, 1),
(11884, 'Mazzoni', 0, 1),
(11885, 'Mc', 0, 1),
(11886, 'McAllister', 0, 1),
(11887, 'McAndrew', 0, 1),
(11888, 'McAnulty', 0, 1),
(11889, 'McAvoy', 0, 1),
(11890, 'McBeth', 0, 1),
(11891, 'McBride', 0, 1),
(11892, 'McBroom', 0, 1),
(11893, 'McBryde', 0, 1),
(11894, 'McCallum', 0, 1),
(11895, 'McCann', 0, 1),
(11896, 'McCardell', 0, 1),
(11897, 'McCarthy', 0, 1),
(11898, 'McCarty', 0, 1),
(11899, 'McCaskill', 0, 1),
(11900, 'McClain', 0, 1),
(11901, 'McClanahan', 0, 1),
(11902, 'McClaskey', 0, 1),
(11903, 'McClellan', 0, 1),
(11904, 'McClendon', 0, 1),
(11905, 'McClune', 0, 1),
(11906, 'McClung', 0, 1),
(11907, 'McConnell', 0, 1),
(11908, 'McCormick', 0, 1),
(11909, 'McCoy', 0, 1),
(11910, 'McCracken', 0, 1),
(11911, 'McCreery', 0, 1),
(11912, 'McCrory', 0, 1),
(11913, 'McCullers', 0, 1),
(11914, 'McCulloch', 0, 1),
(11915, 'McCullough', 0, 1),
(11916, 'McCurdy', 0, 1),
(11917, 'McCurry', 0, 1),
(11918, 'McCutchen', 0, 1),
(11919, 'McDade', 0, 1),
(11920, 'McDill', 0, 1),
(11921, 'McDonald', 0, 1),
(11922, 'McDougall', 0, 1),
(11923, 'McDowell', 0, 1),
(11924, 'McElroy', 0, 1),
(11925, 'McEwing', 0, 1),
(11926, 'McFall', 0, 1),
(11927, 'McFarland', 0, 1),
(11928, 'McGarry', 0, 1),
(11929, 'McGary', 0, 1),
(11930, 'McGeary', 0, 1),
(11931, 'McGee', 0, 1),
(11932, 'McGehee', 0, 1),
(11933, 'McGinley', 0, 1),
(11934, 'McGlinchy', 0, 1),
(11935, 'McGough', 0, 1),
(11936, 'McGowan', 0, 1),
(11937, 'McGowin', 0, 1),
(11938, 'McGrath', 0, 1),
(11939, 'McGraw', 0, 1),
(11940, 'McGriff', 0, 1),
(11941, 'McGuiness', 0, 1),
(11942, 'McGuire', 0, 1),
(11943, 'McGwire', 0, 1),
(11944, 'McHugh', 0, 1),
(11945, 'McKae', 0, 1),
(11946, 'McKay', 0, 1),
(11947, 'McKeel', 0, 1),
(11948, 'McKenna', 0, 1),
(11949, 'McKenry', 0, 1),
(11950, 'McKenzie', 0, 1),
(11951, 'McKinley', 0, 1),
(11952, 'McKinney', 0, 1),
(11953, 'McKirahan', 0, 1),
(11954, 'McKnight', 0, 1),
(11955, 'McLeary', 0, 1),
(11956, 'McLemore', 0, 1),
(11957, 'McLouth', 0, 1),
(11958, 'McMahan', 0, 1),
(11959, 'McMahon', 0, 1),
(11960, 'McMichael', 0, 1),
(11961, 'McMillan', 0, 1),
(11962, 'McMillon', 0, 1),
(11963, 'McNally', 0, 1),
(11964, 'McNeil', 0, 1),
(11965, 'McNichol', 0, 1),
(11966, 'McNiven', 0, 1),
(11967, 'McNutt', 0, 1),
(11968, 'McOwen', 0, 1),
(11969, 'McPherson', 0, 1),
(11970, 'McRae', 0, 1),
(11971, 'Meacham', 0, 1),
(11972, 'Meadows', 0, 1),
(11973, 'Means', 0, 1),
(11974, 'Meares', 0, 1),
(11975, 'Mears', 0, 1),
(11976, 'Meaux', 0, 1),
(11977, 'Meche', 0, 1),
(11978, 'Mecias', 0, 1),
(11979, 'Mecir', 0, 1),
(11980, 'Medchill', 0, 1),
(11981, 'Medders', 0, 1),
(11982, 'Medeiros', 0, 1),
(11983, 'Medica', 0, 1),
(11984, 'Medina', 0, 1),
(11985, 'Medlen', 0, 1),
(11986, 'Medlock', 0, 1),
(11987, 'Medrano', 0, 1),
(11988, 'Meek', 0, 1),
(11989, 'Megill', 0, 1),
(11990, 'Megrew', 0, 1),
(11991, 'Meisner', 0, 1),
(11992, 'Mejia', 0, 1),
(11993, 'Mejias', 0, 1),
(11994, 'Mejias-Brean', 0, 1),
(11995, 'Melancon', 0, 1),
(11996, 'Melean', 0, 1),
(11997, 'Melendez', 0, 1),
(11998, 'Melhuse', 0, 1),
(11999, 'Melian', 0, 1),
(12000, 'Melillo', 0, 1),
(12001, 'Mella', 0, 1),
(12002, 'Melo', 0, 1),
(12003, 'Meloan', 0, 1),
(12004, 'Melotakis', 0, 1),
(12005, 'Meluskey', 0, 1),
(12006, 'Melville', 0, 1),
(12007, 'Mena', 0, 1),
(12008, 'Mench', 0, 1),
(12009, 'Mendez', 0, 1),
(12010, 'Mendonca', 0, 1),
(12011, 'Mendoza', 0, 1),
(12012, 'Menechino', 0, 1),
(12013, 'Meneses', 0, 1),
(12014, 'Mengden', 0, 1),
(12015, 'Menhart', 0, 1),
(12016, 'Meo', 0, 1),
(12017, 'Mercado', 0, 1),
(12018, 'Merced', 0, 1),
(12019, 'Mercedes', 0, 1),
(12020, 'Mercer', 0, 1),
(12021, 'Mercker', 0, 1),
(12022, 'Meredith', 0, 1),
(12023, 'Merklinger', 0, 1),
(12024, 'Merloni', 0, 1),
(12025, 'Merrell', 0, 1),
(12026, 'Merricks', 0, 1),
(12027, 'Merrifield', 0, 1),
(12028, 'Merrill', 0, 1),
(12029, 'Merritt', 0, 1),
(12030, 'Merryweather', 0, 1),
(12031, 'Mesa', 0, 1),
(12032, 'Mesaraco', 0, 1),
(12033, 'Mesoraco', 0, 1),
(12034, 'Messenger', 0, 1),
(12035, 'Metcalf', 0, 1),
(12036, 'Metcalfe', 0, 1),
(12037, 'Meyer', 0, 1),
(12038, 'Meyers', 0, 1),
(12039, 'Meza', 0, 1),
(12040, 'Miadich', 0, 1),
(12041, 'Miceli', 0, 1),
(12042, 'Michael', 0, 1),
(12043, 'Michaels', 0, 1),
(12044, 'Michalak', 0, 1),
(12045, 'Michalczewski', 0, 1),
(12046, 'Mickelson', 0, 1),
(12047, 'Mickolio', 0, 1),
(12048, 'Miclat', 0, 1),
(12049, 'Middlebrook', 0, 1),
(12050, 'Middlebrooks', 0, 1),
(12051, 'Middleton', 0, 1),
(12052, 'Mientkiewicz', 0, 1),
(12053, 'Mier', 0, 1),
(12054, 'Mieses', 0, 1),
(12055, 'Mieske', 0, 1),
(12056, 'Miguelez', 0, 1),
(12057, 'Mijares', 0, 1),
(12058, 'Mikolas', 0, 1),
(12059, 'Milacki', 0, 1),
(12060, 'Milbrath', 0, 1),
(12061, 'Mildren', 0, 1),
(12062, 'Miles', 0, 1),
(12063, 'Miley', 0, 1),
(12064, 'Miliano', 0, 1),
(12065, 'Millar', 0, 1),
(12066, 'Milledge', 0, 1),
(12067, 'Miller', 0, 1),
(12068, 'Milleville', 0, 1),
(12069, 'Milliard', 0, 1),
(12070, 'Milligan', 0, 1),
(12071, 'Mills', 0, 1),
(12072, 'Millwood', 0, 1),
(12073, 'Milner', 0, 1),
(12074, 'Milone', 0, 1),
(12075, 'Milons', 0, 1),
(12076, 'Milton', 0, 1),
(12077, 'Mimbs', 0, 1),
(12078, 'Mims', 0, 1),
(12079, 'Minaker', 0, 1),
(12080, 'Minami', 0, 1),
(12081, 'Minaya', 0, 1),
(12082, 'Minchey', 0, 1),
(12083, 'Miner', 0, 1),
(12084, 'Minicozzi', 0, 1),
(12085, 'Miniel', 0, 1),
(12086, 'Minier', 0, 1),
(12087, 'Minix', 0, 1),
(12088, 'Minnis', 0, 1),
(12089, 'Minor', 0, 1),
(12090, 'Minter', 0, 1),
(12091, 'Mirabelli', 0, 1),
(12092, 'Miranda', 0, 1),
(12093, 'Misch', 0, 1),
(12094, 'Missaki', 0, 1),
(12095, 'Misuraca', 0, 1),
(12096, 'Mitchell', 0, 1),
(12097, 'Mitre', 0, 1),
(12098, 'Mitsui', 0, 1),
(12099, 'Mizuo', 0, 1),
(12100, 'Mlicki', 0, 1),
(12101, 'Mobley', 0, 1),
(12102, 'Mock', 0, 1),
(12103, 'Moehler', 0, 1),
(12104, 'Moeller', 0, 1),
(12105, 'Mohler', 0, 1),
(12106, 'Mohr', 0, 1),
(12107, 'Moldenhauer', 0, 1),
(12108, 'Molina', 0, 1),
(12109, 'Molitor', 0, 1),
(12110, 'Moll', 0, 1),
(12111, 'Molleken', 0, 1),
(12112, 'Molnar', 0, 1),
(12113, 'Monahan', 0, 1),
(12114, 'Monasterios', 0, 1),
(12115, 'Moncada', 0, 1),
(12116, 'Moncrief', 0, 1),
(12117, 'Monda', 0, 1),
(12118, 'Mondesi', 0, 1),
(12119, 'Mondesi Jr.', 0, 1),
(12120, 'Mondile', 0, 1),
(12121, 'Monell', 0, 1),
(12122, 'Monge', 0, 1),
(12123, 'Moniak', 0, 1),
(12124, 'Monroe', 0, 1),
(12125, 'Montalbano', 0, 1),
(12126, 'Montane', 0, 1),
(12127, 'Montanez', 0, 1),
(12128, 'Montano', 0, 1),
(12129, 'Montas', 0, 1),
(12130, 'Monteleone', 0, 1),
(12131, 'Montero', 0, 1),
(12132, 'Montes', 0, 1),
(12133, 'Montes de Oca', 0, 1),
(12134, 'Montgomery', 0, 1),
(12135, 'Montz', 0, 1),
(12136, 'Moody', 0, 1),
(12137, 'Mooneyham', 0, 1),
(12138, 'Moore', 0, 1),
(12139, 'Moorhead', 0, 1),
(12140, 'Mora', 0, 1),
(12141, 'Moraga', 0, 1),
(12142, 'Morales', 0, 1),
(12143, 'Moran', 0, 1),
(12144, 'Morandini', 0, 1),
(12145, 'Morban', 0, 1),
(12146, 'Mordecai', 0, 1),
(12147, 'Moreira', 0, 1),
(12148, 'Morejon', 0, 1),
(12149, 'Morel', 0, 1),
(12150, 'Moreland', 0, 1),
(12151, 'Moreno', 0, 1),
(12152, 'Moresi', 0, 1),
(12153, 'Morey', 0, 1),
(12154, 'Morgado', 0, 1),
(12155, 'Morgan', 0, 1),
(12156, 'Mori', 0, 1),
(12157, 'Moriarty', 0, 1),
(12158, 'Morillo', 0, 1),
(12159, 'Morimando', 0, 1),
(12160, 'Morin', 0, 1),
(12161, 'Morino', 0, 1),
(12162, 'Morla', 0, 1),
(12163, 'Morlan', 0, 1),
(12164, 'Morman', 0, 1),
(12165, 'Morneau', 0, 1),
(12166, 'Moroff', 0, 1),
(12167, 'Moronta', 0, 1),
(12168, 'Morris', 0, 1),
(12169, 'Morrison', 0, 1),
(12170, 'Morrissey', 0, 1),
(12171, 'Morrow', 0, 1),
(12172, 'Morse', 0, 1),
(12173, 'Mortensen', 0, 1),
(12174, 'Morton', 0, 1),
(12175, 'Moscoso', 0, 1),
(12176, 'Moscot', 0, 1),
(12177, 'Mosebach', 0, 1),
(12178, 'Moseley', 0, 1),
(12179, 'Moses', 0, 1),
(12180, 'Moskos', 0, 1),
(12181, 'Mosquera', 0, 1),
(12182, 'Moss', 0, 1),
(12183, 'Mota', 0, 1),
(12184, 'Motooka', 0, 1),
(12185, 'Motte', 0, 1),
(12186, 'Motter', 0, 1),
(12187, 'Mottola', 0, 1),
(12188, 'Mounce', 0, 1),
(12189, 'Mount', 0, 1),
(12190, 'Mountcastle', 0, 1),
(12191, 'Moustakas', 0, 1),
(12192, 'Mouton', 0, 1),
(12193, 'Moviel', 0, 1),
(12194, 'Moya', 0, 1),
(12195, 'Moye', 0, 1),
(12196, 'Moyer', 0, 1),
(12197, 'Moylan', 0, 1),
(12198, 'Mozingo', 0, 1),
(12199, 'Muecke', 0, 1),
(12200, 'Muegge', 0, 1),
(12201, 'Muelens', 0, 1),
(12202, 'Mueller', 0, 1),
(12203, 'Mugarian', 0, 1),
(12204, 'Mujica', 0, 1),
(12205, 'Mulder', 0, 1),
(12206, 'Muldowney', 0, 1),
(12207, 'Mulhern', 0, 1),
(12208, 'Mulholland', 0, 1),
(12209, 'Mullee', 0, 1),
(12210, 'Mullen', 0, 1),
(12211, 'Muller', 0, 1),
(12212, 'Mulligan', 0, 1),
(12213, 'Mullins', 0, 1),
(12214, 'Mulvey', 0, 1),
(12215, 'Mummey', 0, 1),
(12216, 'Muncy', 0, 1),
(12217, 'Mundell', 0, 1),
(12218, 'Munguia', 0, 1),
(12219, 'Muniz', 0, 1),
(12220, 'Muno', 0, 1),
(12221, 'Munoz', 0, 1),
(12222, 'Munro', 0, 1),
(12223, 'Munson', 0, 1),
(12224, 'Munter', 0, 1),
(12225, 'Murata', 0, 1),
(12226, 'Murillo', 0, 1),
(12227, 'Murphy', 0, 1),
(12228, 'Murray', 0, 1),
(12229, 'Murton', 0, 1),
(12230, 'Musgrave', 0, 1),
(12231, 'Musgrove', 0, 1),
(12232, 'Musser', 0, 1),
(12233, 'Mussina', 0, 1),
(12234, 'Mustain', 0, 1),
(12235, 'Mustelier', 0, 1),
(12236, 'Mutz', 0, 1),
(12237, 'Muzziotti', 0, 1),
(12238, 'Myers', 0, 1),
(12239, 'Myette', 0, 1),
(12240, 'Myrow', 0, 1),
(12241, 'Nady', 0, 1),
(12242, 'Naehring', 0, 1),
(12243, 'Nageotte', 0, 1),
(12244, 'Nagy', 0, 1),
(12245, 'Nakajima', 0, 1),
(12246, 'Nakamura', 0, 1),
(12247, 'Nakata', 0, 1),
(12248, 'Nakaushiro', 0, 1),
(12249, 'Nall', 0, 1),
(12250, 'Nance', 0, 1),
(12251, 'Nanita', 0, 1),
(12252, 'Nannini', 0, 1),
(12253, 'Napoli', 0, 1),
(12254, 'Nappo', 0, 1),
(12255, 'Naquin', 0, 1),
(12256, 'Narron', 0, 1),
(12257, 'Naruse', 0, 1),
(12258, 'Narvaez', 0, 1),
(12259, 'Narveson', 0, 1),
(12260, 'Nash', 0, 1),
(12261, 'Natal', 0, 1),
(12262, 'Natale', 0, 1),
(12263, 'Nathan', 0, 1),
(12264, 'Nation', 0, 1),
(12265, 'Naughton', 0, 1),
(12266, 'Naulty', 0, 1),
(12267, 'Nava', 0, 1),
(12268, 'Navarrette', 0, 1),
(12269, 'Navarro', 0, 1),
(12270, 'Nay', 0, 1),
(12271, 'Naylor', 0, 1),
(12272, 'Ndungidi', 0, 1),
(12273, 'Neagle', 0, 1),
(12274, 'Neal', 0, 1),
(12275, 'Needy', 0, 1),
(12276, 'Neel', 0, 1),
(12277, 'Negrette', 0, 1),
(12278, 'Negron', 0, 1),
(12279, 'Negrych', 0, 1),
(12280, 'Neidert', 0, 1),
(12281, 'Neighborgall', 0, 1),
(12282, 'Neill', 0, 1),
(12283, 'Nelo', 0, 1),
(12284, 'Nelson', 0, 1),
(12285, 'Nen', 0, 1),
(12286, 'Neris', 0, 1),
(12287, 'Nesbitt', 0, 1),
(12288, 'Neshek', 0, 1),
(12289, 'Ness', 0, 1),
(12290, 'Nesseth', 0, 1),
(12291, 'Nestor', 0, 1),
(12292, 'Netzer', 0, 1),
(12293, 'Neu', 0, 1),
(12294, 'Neugebauer', 0, 1),
(12295, 'Neuhaus', 0, 1),
(12296, 'Neuse', 0, 1),
(12297, 'Nevarez', 0, 1),
(12298, 'Neverauskas', 0, 1),
(12299, 'Nevin', 0, 1),
(12300, 'Newby', 0, 1),
(12301, 'Newcomb', 0, 1),
(12302, 'Newfield', 0, 1),
(12303, 'Newhan', 0, 1),
(12304, 'Newman', 0, 1),
(12305, 'Newmann', 0, 1),
(12306, 'Newsom', 0, 1),
(12307, 'Newsome', 0, 1),
(12308, 'Newson', 0, 1),
(12309, 'Newton', 0, 1),
(12310, 'Ngoepe', 0, 1),
(12311, 'Ni', 0, 1),
(12312, 'Nicasio', 0, 1),
(12313, 'Nicholas', 0, 1),
(12314, 'Nicholson', 0, 1),
(12315, 'Nichting', 0, 1),
(12316, 'Nick', 0, 1),
(12317, 'Nickeas', 0, 1),
(12318, 'Nickerson', 0, 1),
(12319, 'Nickle', 0, 1),
(12320, 'Nicolas', 0, 1),
(12321, 'Nicolino', 0, 1),
(12322, 'Nicoll', 0, 1),
(12323, 'Nido', 0, 1),
(12324, 'Nied', 0, 1),
(12325, 'Niekro', 0, 1),
(12326, 'Niemann', 0, 1),
(12327, 'Niese', 0, 1),
(12328, 'Niesen', 0, 1),
(12329, 'Nieto', 0, 1),
(12330, 'Nieuwenhuis', 0, 1),
(12331, 'Nieve', 0, 1),
(12332, 'Nieves', 0, 1),
(12333, 'Nikorak', 0, 1),
(12334, 'Niles', 0, 1),
(12335, 'Nilsson', 0, 1),
(12336, 'Nimmo', 0, 1),
(12337, 'Nin', 0, 1),
(12338, 'Nina', 0, 1),
(12339, 'Nioka', 0, 1),
(12340, 'Nippert', 0, 1),
(12341, 'Nishi', 0, 1),
(12342, 'Nishioka', 0, 1),
(12343, 'Nitkowski', 0, 1),
(12344, 'Nivar', 0, 1),
(12345, 'Nix', 0, 1),
(12346, 'Nixon', 0, 1),
(12347, 'Noda', 0, 1),
(12348, 'Noel', 0, 1),
(12349, 'Noesi', 0, 1),
(12350, 'Nogosek', 0, 1),
(12351, 'Noguchi', 0, 1),
(12352, 'Nokes', 0, 1),
(12353, 'Nola', 0, 1),
(12354, 'Nolasco', 0, 1),
(12355, 'Nolin', 0, 1),
(12356, 'Noll', 0, 1),
(12357, 'Nolte', 0, 1),
(12358, 'Nomo', 0, 1),
(12359, 'Nomura', 0, 1),
(12360, 'Noonan', 0, 1),
(12361, 'Norberto', 0, 1),
(12362, 'Noriega', 0, 1),
(12363, 'Norimoto', 0, 1),
(12364, 'Norman', 0, 1),
(12365, 'Norrick', 0, 1),
(12366, 'Norris', 0, 1),
(12367, 'Norrito', 0, 1),
(12368, 'Northcraft', 0, 1),
(12369, 'Norton', 0, 1),
(12370, 'Norwood', 0, 1),
(12371, 'Nottingham', 0, 1),
(12372, 'Nova', 0, 1),
(12373, 'Novinsky', 0, 1),
(12374, 'Novoa', 0, 1),
(12375, 'Nowak', 0, 1),
(12376, 'Noyce', 0, 1),
(12377, 'Nuding', 0, 1),
(12378, 'Nunez', 0, 1),
(12379, 'Nunnally', 0, 1),
(12380, 'Nunnari', 0, 1),
(12381, 'Nuno', 0, 1),
(12382, 'Nussbeck', 0, 1),
(12383, 'Nye', 0, 1),
(12384, 'OBrien', 0, 1),
(12385, 'OConner', 0, 1),
(12386, 'OConnor', 0, 1),
(12387, 'ODay', 0, 1),
(12388, 'ODowd', 0, 1),
(12389, 'OFlaherty', 0, 1),
(12390, 'OGrady', 0, 1),
(12391, 'OHearn', 0, 1),
(12392, 'OLeary', 0, 1),
(12393, 'OMalley', 0, 1),
(12394, 'ONeil', 0, 1),
(12395, 'ONeill', 0, 1),
(12396, 'ORourke', 0, 1),
(12397, 'OSullivan', 0, 1),
(12398, 'Oakes', 0, 1),
(12399, 'Oaks', 0, 1),
(12400, 'Obando', 0, 1),
(12401, 'Obenchain', 0, 1),
(12402, 'Oberacker', 0, 1),
(12403, 'Oberg', 0, 1),
(12404, 'Oberholtzer', 0, 1),
(12405, 'Obermueller', 0, 1),
(12406, 'Oberste', 0, 1),
(12407, 'Obispo', 0, 1),
(12408, 'Ochinko', 0, 1),
(12409, 'Ochoa', 0, 1),
(12410, 'Ockimey', 0, 1),
(12411, 'Odom', 0, 1),
(12412, 'Odor', 0, 1),
(12413, 'Odorizzi', 0, 1),
(12414, 'Oeltjen', 0, 1),
(12415, 'Offerman', 0, 1),
(12416, 'OfSandwich', 0, 1),
(12417, 'Ogando', 0, 1),
(12418, 'Ogasawara', 0, 1),
(12419, 'Ogea', 0, 1),
(12420, 'Ogle', 0, 1),
(12421, 'Oh', 0, 1),
(12422, 'Ohka', 0, 1),
(12423, 'Ohlendorf', 0, 1),
(12424, 'Ohlman', 0, 1),
(12425, 'Ohman', 0, 1),
(12426, 'Ohme', 0, 1),
(12427, 'Ohmura', 0, 1),
(12428, 'Ohtani', 0, 1),
(12429, 'Ojala', 0, 1),
(12430, 'Ojeda', 0, 1),
(12431, 'Okada', 0, 1),
(12432, 'Okajima', 0, 1),
(12433, 'Okamoto', 0, 1),
(12434, 'Okert', 0, 1),
(12435, 'Okey', 0, 1),
(12436, 'Okoye', 0, 1),
(12437, 'Olbrychowski', 0, 1),
(12438, 'Olenberger', 0, 1),
(12439, 'Olerud', 0, 1),
(12440, 'Oliva', 0, 1),
(12441, 'Olivares', 0, 1),
(12442, 'Oliver', 0, 1),
(12443, 'Olivera', 0, 1),
(12444, 'Oliveros', 0, 1),
(12445, 'Olivo', 0, 1),
(12446, 'Olmedo', 0, 1),
(12447, 'Olmos', 0, 1),
(12448, 'Olmsted', 0, 1),
(12449, 'Olow', 0, 1),
(12450, 'Olsen', 0, 1),
(12451, 'Olson', 0, 1),
(12452, 'Olt', 0, 1),
(12453, 'Omogrosso', 0, 1),
(12454, 'Ona', 0, 1),
(12455, 'Onaka', 0, 1),
(12456, 'Ondrusek', 0, 1),
(12457, 'Ontiveros', 0, 1),
(12458, 'Oquist', 0, 1),
(12459, 'Oramas', 0, 1),
(12460, 'Ordaz', 0, 1),
(12461, 'Ordonez', 0, 1),
(12462, 'Orenduff', 0, 1),
(12463, 'Orie', 0, 1),
(12464, 'Orimoloye', 0, 1),
(12465, 'Orlando', 0, 1),
(12466, 'Orloski', 0, 1),
(12467, 'Ornelas', 0, 1),
(12468, 'Oropesa', 0, 1),
(12469, 'Orosco', 0, 1),
(12470, 'Orozco', 0, 1),
(12471, 'Orr', 0, 1),
(12472, 'Orsulak', 0, 1),
(12473, 'Orta', 0, 1),
(12474, 'Ortega', 0, 1),
(12475, 'Ortegano', 0, 1),
(12476, 'Ortiz', 0, 1),
(12477, 'Ortmeier', 0, 1),
(12478, 'Orvella', 0, 1),
(12479, 'Osberg', 0, 1),
(12480, 'Osborn', 0, 1),
(12481, 'Osborne', 0, 1),
(12482, 'Osich', 0, 1),
(12483, 'Osik', 0, 1),
(12484, 'Osoria', 0, 1),
(12485, 'Ostberg', 0, 1),
(12486, 'Osterbrock', 0, 1),
(12487, 'Osting', 0, 1),
(12488, 'Ostlund', 0, 1),
(12489, 'Osuna', 0, 1),
(12490, 'Oswalt', 0, 1),
(12491, 'Otake', 0, 1),
(12492, 'Otanez', 0, 1),
(12493, 'Otero', 0, 1),
(12494, 'Otsuka', 0, 1),
(12495, 'Ott', 0, 1),
(12496, 'Ottavino', 0, 1),
(12497, 'Ottesen', 0, 1),
(12498, 'Otto', 0, 1),
(12499, 'Outman', 0, 1),
(12500, 'Ovalle', 0, 1),
(12501, 'Overbay', 0, 1),
(12502, 'Overbeck', 0, 1),
(12503, 'Overbey', 0, 1),
(12504, 'Overstreet', 0, 1),
(12505, 'Overton', 0, 1),
(12506, 'Oviedo', 0, 1),
(12507, 'Owen', 0, 1),
(12508, 'Owens', 0, 1),
(12509, 'Owings', 0, 1),
(12510, 'Oxnevad', 0, 1),
(12511, 'Oxspring', 0, 1),
(12512, 'Ozeki', 0, 1),
(12513, 'Ozuna', 0, 1),
(12514, 'Pache', 0, 1),
(12515, 'Pacheco', 0, 1),
(12516, 'Packer', 0, 1),
(12517, 'Paddack', 0, 1),
(12518, 'Padgett', 0, 1),
(12519, 'Padilla', 0, 1),
(12520, 'Padlo', 0, 1),
(12521, 'Padron', 0, 1),
(12522, 'Padua', 0, 1),
(12523, 'Paduch', 0, 1),
(12524, 'Paez', 0, 1),
(12525, 'Pagan', 0, 1),
(12526, 'Pagnozzi', 0, 1),
(12527, 'Painter', 0, 1),
(12528, 'Palacios', 0, 1),
(12529, 'Palica', 0, 1),
(12530, 'Palka', 0, 1),
(12531, 'Pall', 0, 1),
(12532, 'Palma', 0, 1),
(12533, 'Palmeiro', 0, 1),
(12534, 'Palmer', 0, 1),
(12535, 'Palmisano', 0, 1),
(12536, 'Palumbo', 0, 1),
(12537, 'Paniagua', 0, 1),
(12538, 'Panik', 0, 1),
(12539, 'Pannone', 0, 1),
(12540, 'Panther', 0, 1),
(12541, 'Pantoja', 0, 1),
(12542, 'Papelbon', 0, 1),
(12543, 'Papi', 0, 1),
(12544, 'Pappas', 0, 1),
(12545, 'Paquette', 0, 1),
(12546, 'Paradis', 0, 1),
(12547, 'Paramore', 0, 1),
(12548, 'Parcell', 0, 1),
(12549, 'Pardinho', 0, 1),
(12550, 'Paredes', 0, 1),
(12551, 'Parent', 0, 1),
(12552, 'Parisi', 0, 1),
(12553, 'Park', 0, 1),
(12554, 'Parker', 0, 1),
(12555, 'Parmelee', 0, 1),
(12556, 'Parmley', 0, 1),
(12557, 'Parnell', 0, 1),
(12558, 'Paronto', 0, 1),
(12559, 'Paroubeck', 0, 1),
(12560, 'Parque', 0, 1),
(12561, 'Parr', 0, 1),
(12562, 'Parra', 0, 1),
(12563, 'Parraz', 0, 1),
(12564, 'Parrett', 0, 1),
(12565, 'Parrino', 0, 1),
(12566, 'Parris', 0, 1),
(12567, 'Parrish', 0, 1),
(12568, 'Parrott', 0, 1),
(12569, 'Partch', 0, 1),
(12570, 'Pascual', 0, 1),
(12571, 'Pascucci', 0, 1),
(12572, 'Pasquale', 0, 1),
(12573, 'Passini', 0, 1),
(12574, 'Pastornicky', 0, 1),
(12575, 'Patchett', 0, 1),
(12576, 'Patel', 0, 1),
(12577, 'Paterson', 0, 1),
(12578, 'Patino', 0, 1),
(12579, 'Patrick', 0, 1),
(12580, 'Patterson', 0, 1),
(12581, 'Patton', 0, 1),
(12582, 'Paul', 0, 1),
(12583, 'Paulauskas', 0, 1),
(12584, 'Pauley', 0, 1),
(12585, 'Paulino', 0, 1),
(12586, 'Paullus', 0, 1),
(12587, 'Paulsen', 0, 1),
(12588, 'Pauly', 0, 1),
(12589, 'Pavano', 0, 1),
(12590, 'Pavkovich', 0, 1),
(12591, 'Pavlas', 0, 1),
(12592, 'Pavlik', 0, 1),
(12593, 'Pawelczyk', 0, 1),
(12594, 'Pawelek', 0, 1),
(12595, 'Paxton', 0, 1),
(12596, 'Payano', 0, 1),
(12597, 'Payne', 0, 1);
INSERT INTO `master_player_names` (`name_id`, `name`, `is_first_name`, `is_active`) VALUES
(12598, 'Payton', 0, 1),
(12599, 'Pazos', 0, 1),
(12600, 'Peacock', 0, 1),
(12601, 'Pearce', 0, 1),
(12602, 'Pearson', 0, 1),
(12603, 'Peavey', 0, 1),
(12604, 'Peavy', 0, 1),
(12605, 'Pederson', 0, 1),
(12606, 'Pedroia', 0, 1),
(12607, 'Pedroza', 0, 1),
(12608, 'Peel', 0, 1),
(12609, 'Peeples', 0, 1),
(12610, 'Peguero', 0, 1),
(12611, 'Pelaez', 0, 1),
(12612, 'Pelfrey', 0, 1),
(12613, 'Pelland', 0, 1),
(12614, 'Pellegrini', 0, 1),
(12615, 'Pelletier', 0, 1),
(12616, 'Pellot', 0, 1),
(12617, 'Pellow', 0, 1),
(12618, 'Peltier', 0, 1),
(12619, 'Pelzer', 0, 1),
(12620, 'Pember', 0, 1),
(12621, 'Pemberton', 0, 1),
(12622, 'Pena', 0, 1),
(12623, 'Pena Jr.', 0, 1),
(12624, 'Pena Sr.', 0, 1),
(12625, 'Pence', 0, 1),
(12626, 'Pendergrass', 0, 1),
(12627, 'Pendleton', 0, 1),
(12628, 'Penn', 0, 1),
(12629, 'Pennington', 0, 1),
(12630, 'Penny', 0, 1),
(12631, 'Pentecost', 0, 1),
(12632, 'Peoples', 0, 1),
(12633, 'Peralta', 0, 1),
(12634, 'Peraza', 0, 1),
(12635, 'Percival', 0, 1),
(12636, 'Perdomo', 0, 1),
(12637, 'Pereira', 0, 1),
(12638, 'Perez', 0, 1),
(12639, 'Periard', 0, 1),
(12640, 'Perio', 0, 1),
(12641, 'Perisho', 0, 1),
(12642, 'Perkins', 0, 1),
(12643, 'Perlaza', 0, 1),
(12644, 'Perrin', 0, 1),
(12645, 'Perry', 0, 1),
(12646, 'Person', 0, 1),
(12647, 'Pertusati', 0, 1),
(12648, 'Pesco', 0, 1),
(12649, 'Pestano', 0, 1),
(12650, 'Petagine', 0, 1),
(12651, 'Peter', 0, 1),
(12652, 'Peters', 0, 1),
(12653, 'Petersen', 0, 1),
(12654, 'Peterson', 0, 1),
(12655, 'Petit', 0, 1),
(12656, 'Petkovsek', 0, 1),
(12657, 'Petrick', 0, 1),
(12658, 'Petricka', 0, 1),
(12659, 'Pettibone', 0, 1),
(12660, 'Pettit', 0, 1),
(12661, 'Pettitte', 0, 1),
(12662, 'Pettway', 0, 1),
(12663, 'Petty', 0, 1),
(12664, 'Pettyjohn', 0, 1),
(12665, 'Pfeifer', 0, 1),
(12666, 'Pfinsgraff', 0, 1),
(12667, 'Pham', 0, 1),
(12668, 'Phegley', 0, 1),
(12669, 'Phelps', 0, 1),
(12670, 'Phillips', 0, 1),
(12671, 'Phipps', 0, 1),
(12672, 'Piatt', 0, 1),
(12673, 'Piazza', 0, 1),
(12674, 'Pichardo', 0, 1),
(12675, 'Pickering', 0, 1),
(12676, 'Pickett', 0, 1),
(12677, 'Pickford', 0, 1),
(12678, 'Pie', 0, 1),
(12679, 'Piedra', 0, 1),
(12680, 'Pierce', 0, 1),
(12681, 'Pierre', 0, 1),
(12682, 'Piersoll', 0, 1),
(12683, 'Pierzynski', 0, 1),
(12684, 'Pietsch', 0, 1),
(12685, 'Pignatiello', 0, 1),
(12686, 'Pike', 0, 1),
(12687, 'Pilittere', 0, 1),
(12688, 'Pilkington', 0, 1),
(12689, 'Pill', 0, 1),
(12690, 'Pillar', 0, 1),
(12691, 'Pimentel', 0, 1),
(12692, 'Pina', 0, 1),
(12693, 'Pinango', 0, 1),
(12694, 'Pinckard', 0, 1),
(12695, 'Pinder', 0, 1),
(12696, 'Pineda', 0, 1),
(12697, 'Pineiro', 0, 1),
(12698, 'Pinero', 0, 1),
(12699, 'Pineyro', 0, 1),
(12700, 'Pino', 0, 1),
(12701, 'Pint', 0, 1),
(12702, 'Pinto', 0, 1),
(12703, 'Pippin', 0, 1),
(12704, 'Pirela', 0, 1),
(12705, 'Pirkl', 0, 1),
(12706, 'Pisciotta', 0, 1),
(12707, 'Piscotty', 0, 1),
(12708, 'Pittsburgh', 0, 1),
(12709, 'Pittsley', 0, 1),
(12710, 'Pivetta', 0, 1),
(12711, 'Pizziconi', 0, 1),
(12712, 'Place', 0, 1),
(12713, 'Plantenberg', 0, 1),
(12714, 'Plantier', 0, 1),
(12715, 'Plawecki', 0, 1),
(12716, 'Pleiness', 0, 1),
(12717, 'Plesac', 0, 1),
(12718, 'Plouffe', 0, 1),
(12719, 'Plummer', 0, 1),
(12720, 'Plunk', 0, 1),
(12721, 'Pluta', 0, 1),
(12722, 'Plutko', 0, 1),
(12723, 'Podsednik', 0, 1),
(12724, 'Polanco', 0, 1),
(12725, 'Polcovich', 0, 1),
(12726, 'Politte', 0, 1),
(12727, 'Polkovich', 0, 1),
(12728, 'Pollock', 0, 1),
(12729, 'Polo', 0, 1),
(12730, 'Polonia', 0, 1),
(12731, 'Pomeranz', 0, 1),
(12732, 'Pompey', 0, 1),
(12733, 'Ponce', 0, 1),
(12734, 'Poncedeleon', 0, 1),
(12735, 'Pond', 0, 1),
(12736, 'Ponson', 0, 1),
(12737, 'Poole', 0, 1),
(12738, 'Pop', 0, 1),
(12739, 'Pope', 0, 1),
(12740, 'Porcello', 0, 1),
(12741, 'Poreda', 0, 1),
(12742, 'Porter', 0, 1),
(12743, 'Portes', 0, 1),
(12744, 'Portice', 0, 1),
(12745, 'Portillo', 0, 1),
(12746, 'Portugal', 0, 1),
(12747, 'Portuondo', 0, 1),
(12748, 'Porzio', 0, 1),
(12749, 'Posada', 0, 1),
(12750, 'Pose', 0, 1),
(12751, 'Posey', 0, 1),
(12752, 'Possum', 0, 1),
(12753, 'Pote', 0, 1),
(12754, 'Poteet', 0, 1),
(12755, 'Poterson', 0, 1),
(12756, 'Potts', 0, 1),
(12757, 'Poulson', 0, 1),
(12758, 'Pounders', 0, 1),
(12759, 'Poveda', 0, 1),
(12760, 'Povse', 0, 1),
(12761, 'Powell', 0, 1),
(12762, 'Poyner', 0, 1),
(12763, 'Poythress', 0, 1),
(12764, 'Pozo', 0, 1),
(12765, 'Prades', 0, 1),
(12766, 'Prado', 0, 1),
(12767, 'Prasch', 0, 1),
(12768, 'Pratt', 0, 1),
(12769, 'Pratto', 0, 1),
(12770, 'Prenza', 0, 1),
(12771, 'Presley', 0, 1),
(12772, 'Pressley', 0, 1),
(12773, 'Pressly', 0, 1),
(12774, 'Prettyman', 0, 1),
(12775, 'Pribanic', 0, 1),
(12776, 'Price', 0, 1),
(12777, 'Pride', 0, 1),
(12778, 'Pridie', 0, 1),
(12779, 'Pries', 0, 1),
(12780, 'Priest', 0, 1),
(12781, 'Prieto', 0, 1),
(12782, 'Prime', 0, 1),
(12783, 'Prince', 0, 1),
(12784, 'Principe', 0, 1),
(12785, 'Prinz', 0, 1),
(12786, 'Prior', 0, 1),
(12787, 'Pritchett', 0, 1),
(12788, 'Privett', 0, 1),
(12789, 'Proctor', 0, 1),
(12790, 'Profar', 0, 1),
(12791, 'Prokopec', 0, 1),
(12792, 'Proscia', 0, 1),
(12793, 'Province', 0, 1),
(12794, 'Pruitt', 0, 1),
(12795, 'Pruneda', 0, 1),
(12796, 'Pryor', 0, 1),
(12797, 'Psomas', 0, 1),
(12798, 'Pucetas', 0, 1),
(12799, 'Puckett', 0, 1),
(12800, 'Puello', 0, 1),
(12801, 'Puffer', 0, 1),
(12802, 'Pugh', 0, 1),
(12803, 'Puig', 0, 1),
(12804, 'Pujols', 0, 1),
(12805, 'Puk', 0, 1),
(12806, 'Pulido', 0, 1),
(12807, 'Pulliam', 0, 1),
(12808, 'Pullin', 0, 1),
(12809, 'Pulsipher', 0, 1),
(12810, 'Punto', 0, 1),
(12811, 'Purcey', 0, 1),
(12812, 'Purke', 0, 1),
(12813, 'Putkonen', 0, 1),
(12814, 'Putnam', 0, 1),
(12815, 'Putz', 0, 1),
(12816, 'Quackenbush', 0, 1),
(12817, 'Qualis', 0, 1),
(12818, 'Qualls', 0, 1),
(12819, 'Quantrill', 0, 1),
(12820, 'Quarles', 0, 1),
(12821, 'Quate', 0, 1),
(12822, 'Quentin', 0, 1),
(12823, 'Querecuto', 0, 1),
(12824, 'Quesada', 0, 1),
(12825, 'Quevedo', 0, 1),
(12826, 'Quezada', 0, 1),
(12827, 'Quiala', 0, 1),
(12828, 'Quinlan', 0, 1),
(12829, 'Quinn', 0, 1),
(12830, 'Quintana', 0, 1),
(12831, 'Quintanilla', 0, 1),
(12832, 'Quintero', 0, 1),
(12833, 'Quirarte', 0, 1),
(12834, 'Quiroz', 0, 1),
(12835, 'Raabe', 0, 1),
(12836, 'Rabago', 0, 1),
(12837, 'Rabe', 0, 1),
(12838, 'Rabelo', 0, 1),
(12839, 'Raben', 0, 1),
(12840, 'Raburn', 0, 1),
(12841, 'Radinsky', 0, 1),
(12842, 'Radke', 0, 1),
(12843, 'Radlosky', 0, 1),
(12844, 'Radmanovich', 0, 1),
(12845, 'Rafael', 0, 1),
(12846, 'Rafferty', 0, 1),
(12847, 'Ragans', 0, 1),
(12848, 'Raggio', 0, 1),
(12849, 'Ragira', 0, 1),
(12850, 'Raglani', 0, 1),
(12851, 'Rahier', 0, 1),
(12852, 'Rahl', 0, 1),
(12853, 'Railey', 0, 1),
(12854, 'Rain', 0, 1),
(12855, 'Raines', 0, 1),
(12856, 'Raines Jr.', 0, 1),
(12857, 'Rainey', 0, 1),
(12858, 'Rainville', 0, 1),
(12859, 'Rainwater', 0, 1),
(12860, 'Rakers', 0, 1),
(12861, 'Raley', 0, 1),
(12862, 'Ramirez', 0, 1),
(12863, 'Ramos', 0, 1),
(12864, 'Rams', 0, 1),
(12865, 'Ramsay', 0, 1),
(12866, 'Ramsey', 0, 1),
(12867, 'Ranaudo', 0, 1),
(12868, 'Randa', 0, 1),
(12869, 'Randall', 0, 1),
(12870, 'Randazzo', 0, 1),
(12871, 'Randel', 0, 1),
(12872, 'Randolph', 0, 1),
(12873, 'Ransom', 0, 1),
(12874, 'Rapada', 0, 1),
(12875, 'Rapp', 0, 1),
(12876, 'Raquet', 0, 1),
(12877, 'Rash', 0, 1),
(12878, 'Rasmus', 0, 1),
(12879, 'Rasmussen', 0, 1),
(12880, 'Rasner', 0, 1),
(12881, 'Rath', 0, 1),
(12882, 'Rathjen', 0, 1),
(12883, 'Ratliff', 0, 1),
(12884, 'Rauch', 0, 1),
(12885, 'Raudes', 0, 1),
(12886, 'Ravelo', 0, 1),
(12887, 'Ravenelle', 0, 1),
(12888, 'Ravin', 0, 1),
(12889, 'Ray', 0, 1),
(12890, 'Raynor', 0, 1),
(12891, 'Rea', 0, 1),
(12892, 'Read', 0, 1),
(12893, 'Realmuto', 0, 1),
(12894, 'Reames', 0, 1),
(12895, 'Rearick', 0, 1),
(12896, 'Reboulet', 0, 1),
(12897, 'Recker', 0, 1),
(12898, 'Reckling', 0, 1),
(12899, 'Reddick', 0, 1),
(12900, 'Redding', 0, 1),
(12901, 'Redman', 0, 1),
(12902, 'Redmond', 0, 1),
(12903, 'Reed', 0, 1),
(12904, 'Reeder', 0, 1),
(12905, 'Reedy', 0, 1),
(12906, 'Reese', 0, 1),
(12907, 'Reetz', 0, 1),
(12908, 'Refsnyder', 0, 1),
(12909, 'Regan', 0, 1),
(12910, 'Regilio', 0, 1),
(12911, 'Reginatto', 0, 1),
(12912, 'Register', 0, 1),
(12913, 'Rei', 0, 1),
(12914, 'Reichert', 0, 1),
(12915, 'Reid', 0, 1),
(12916, 'Reid-Foley', 0, 1),
(12917, 'Reifer', 0, 1),
(12918, 'Reimers', 0, 1),
(12919, 'Reimold', 0, 1),
(12920, 'Reina', 0, 1),
(12921, 'Reineke', 0, 1),
(12922, 'Reinhard', 0, 1),
(12923, 'Reinheimer', 0, 1),
(12924, 'Reininger', 0, 1),
(12925, 'Reith', 0, 1),
(12926, 'Reitsma', 0, 1),
(12927, 'Rekar', 0, 1),
(12928, 'Relaford', 0, 1),
(12929, 'Remlinger', 0, 1),
(12930, 'Renda', 0, 1),
(12931, 'Rendon', 0, 1),
(12932, 'Rene', 0, 1),
(12933, 'Renfroe', 0, 1),
(12934, 'Rengifo', 0, 1),
(12935, 'Renken', 0, 1),
(12936, 'Renteria', 0, 1),
(12937, 'Repko', 0, 1),
(12938, 'Requena', 0, 1),
(12939, 'Resop', 0, 1),
(12940, 'Restovich', 0, 1),
(12941, 'Retherford', 0, 1),
(12942, 'Revere', 0, 1),
(12943, 'Reyes', 0, 1),
(12944, 'Reynolds', 0, 1),
(12945, 'Reynoso', 0, 1),
(12946, 'Rhame', 0, 1),
(12947, 'Rhee', 0, 1),
(12948, 'Rheinecker', 0, 1),
(12949, 'Rhinehart', 0, 1),
(12950, 'Rhoades', 0, 1),
(12951, 'Rhoads', 0, 1),
(12952, 'Rhodes', 0, 1),
(12953, 'Rhymes', 0, 1),
(12954, 'Rice', 0, 1),
(12955, 'Rich', 0, 1),
(12956, 'Richar', 0, 1),
(12957, 'Richard', 0, 1),
(12958, 'Richards', 0, 1),
(12959, 'Richardson', 0, 1),
(12960, 'Richie', 0, 1),
(12961, 'Richmond', 0, 1),
(12962, 'Richy', 0, 1),
(12963, 'Rickard', 0, 1),
(12964, 'Ricketts', 0, 1),
(12965, 'Rico', 0, 1),
(12966, 'Riddle', 0, 1),
(12967, 'Ridgway', 0, 1),
(12968, 'Riedling', 0, 1),
(12969, 'Riefenhauser', 0, 1),
(12970, 'Rienzo', 0, 1),
(12971, 'Rifaela', 0, 1),
(12972, 'Rigby', 0, 1),
(12973, 'Rigdon', 0, 1),
(12974, 'Riggan', 0, 1),
(12975, 'Riggans', 0, 1),
(12976, 'Riggins', 0, 1),
(12977, 'Riggon', 0, 1),
(12978, 'Riggs', 0, 1),
(12979, 'Rijo', 0, 1),
(12980, 'Rike', 0, 1),
(12981, 'Riley', 0, 1),
(12982, 'Rincon', 0, 1),
(12983, 'Rincones', 0, 1),
(12984, 'Rindfleisch', 0, 1),
(12985, 'Ring', 0, 1),
(12986, 'Riordan', 0, 1),
(12987, 'Rios', 0, 1),
(12988, 'Ripken', 0, 1),
(12989, 'Riportella', 0, 1),
(12990, 'Risedorf', 0, 1),
(12991, 'Riske', 0, 1),
(12992, 'Risley', 0, 1),
(12993, 'Risser', 0, 1),
(12994, 'Ritcheson', 0, 1),
(12995, 'Ritchie', 0, 1),
(12996, 'Ritz', 0, 1),
(12997, 'Rivas', 0, 1),
(12998, 'Rivera', 0, 1),
(12999, 'Rivero', 0, 1),
(13000, 'Rivers', 0, 1),
(13001, 'Rizzo', 0, 1),
(13002, 'Rizzotti', 0, 1),
(13003, 'Rleal', 0, 1),
(13004, 'Roa', 0, 1),
(13005, 'Roach', 0, 1),
(13006, 'Roache', 0, 1),
(13007, 'Roark', 0, 1),
(13008, 'Robbins', 0, 1),
(13009, 'Roberson', 0, 1),
(13010, 'Robert', 0, 1),
(13011, 'Roberts', 0, 1),
(13012, 'Robertson', 0, 1),
(13013, 'Robinson', 0, 1),
(13014, 'Robles', 0, 1),
(13015, 'Robnett', 0, 1),
(13016, 'Robson', 0, 1),
(13017, 'Rocha', 0, 1),
(13018, 'Rocker', 0, 1),
(13019, 'Rockett', 0, 1),
(13020, 'Rodgers', 0, 1),
(13021, 'Rodland', 0, 1),
(13022, 'Rodney', 0, 1),
(13023, 'Rodon', 0, 1),
(13024, 'Rodriguez', 0, 1),
(13025, 'Roe', 0, 1),
(13026, 'Roemer', 0, 1),
(13027, 'Roenicke', 0, 1),
(13028, 'Rogelstad', 0, 1),
(13029, 'Rogers', 0, 1),
(13030, 'Rogowski', 0, 1),
(13031, 'Rohlfing', 0, 1),
(13032, 'Rohlicek', 0, 1),
(13033, 'Rohlinger', 0, 1),
(13034, 'Rohrbaugh', 0, 1),
(13035, 'Rohrbough', 0, 1),
(13036, 'Roibal ', 0, 1),
(13037, 'Rojas', 0, 1),
(13038, 'Rojas, Jr', 0, 1),
(13039, 'Rolen', 0, 1),
(13040, 'Roling', 0, 1),
(13041, 'Rolison', 0, 1),
(13042, 'Rollandini', 0, 1),
(13043, 'Roller', 0, 1),
(13044, 'Rollins', 0, 1),
(13045, 'Rolls', 0, 1),
(13046, 'Romak', 0, 1),
(13047, 'Romano', 0, 1),
(13048, 'Romanski', 0, 1),
(13049, 'Romero', 0, 1),
(13050, 'Romine', 0, 1),
(13051, 'Romo', 0, 1),
(13052, 'Rondon', 0, 1),
(13053, 'Roney', 0, 1),
(13054, 'Roof', 0, 1),
(13055, 'Rooi', 0, 1),
(13056, 'Rooker', 0, 1),
(13057, 'Root', 0, 1),
(13058, 'Roper', 0, 1),
(13059, 'Roque', 0, 1),
(13060, 'Rortvedt', 0, 1),
(13061, 'Rosa', 0, 1),
(13062, 'Rosado', 0, 1),
(13063, 'Rosales', 0, 1),
(13064, 'Rosamond', 0, 1),
(13065, 'Rosario', 0, 1),
(13066, 'Rose', 0, 1),
(13067, 'Rose Jr.', 0, 1),
(13068, 'Roseboom', 0, 1),
(13069, 'Rosen', 0, 1),
(13070, 'Rosenbaum', 0, 1),
(13071, 'Rosenberg', 0, 1),
(13072, 'Rosengren', 0, 1),
(13073, 'Rosenthal', 0, 1),
(13074, 'Rosin', 0, 1),
(13075, 'Roskos', 0, 1),
(13076, 'Ross', 0, 1),
(13077, 'Rosscup', 0, 1),
(13078, 'Rossy', 0, 1),
(13079, 'Rote', 0, 1),
(13080, 'Roth', 0, 1),
(13081, 'Rottino', 0, 1),
(13082, 'Rouse', 0, 1),
(13083, 'Rouwenhorst', 0, 1),
(13084, 'Rowand', 0, 1),
(13085, 'Rowell', 0, 1),
(13086, 'Rowen', 0, 1),
(13087, 'Rowland', 0, 1),
(13088, 'Rowland-Smith', 0, 1),
(13089, 'Rowley', 0, 1),
(13090, 'Royse', 0, 1),
(13091, 'Royster', 0, 1),
(13092, 'Rozier', 0, 1),
(13093, 'Rua', 0, 1),
(13094, 'Ruan', 0, 1),
(13095, 'Rucinski', 0, 1),
(13096, 'Ruckle', 0, 1),
(13097, 'Ruebel', 0, 1),
(13098, 'Rueckel', 0, 1),
(13099, 'Rueter', 0, 1),
(13100, 'Ruf', 0, 1),
(13101, 'Ruffcorn', 0, 1),
(13102, 'Ruffin', 0, 1),
(13103, 'Ruggiano', 0, 1),
(13104, 'Ruiz', 0, 1),
(13105, 'Rulez', 0, 1),
(13106, 'Rumbelow', 0, 1),
(13107, 'Rundgren', 0, 1),
(13108, 'Rundles', 0, 1),
(13109, 'Runion', 0, 1),
(13110, 'Runyan', 0, 1),
(13111, 'Runzler', 0, 1),
(13112, 'Rupe', 0, 1),
(13113, 'Rupp', 0, 1),
(13114, 'Rusch', 0, 1),
(13115, 'Rushford', 0, 1),
(13116, 'Rusin', 0, 1),
(13117, 'Russ', 0, 1),
(13118, 'Russell', 0, 1),
(13119, 'Russo', 0, 1),
(13120, 'Rust', 0, 1),
(13121, 'Rustich', 0, 1),
(13122, 'Rutckyj', 0, 1),
(13123, 'Ruth', 0, 1),
(13124, 'Rutherford', 0, 1),
(13125, 'Rutledge', 0, 1),
(13126, 'Ryal', 0, 1),
(13127, 'Ryan', 0, 1),
(13128, 'Ryu', 0, 1),
(13129, 'Rzepczynski', 0, 1),
(13130, 'S.', 0, 1),
(13131, 'Saarloos', 0, 1),
(13132, 'Sabathia', 0, 1),
(13133, 'Sabel', 0, 1),
(13134, 'Saberhagen', 0, 1),
(13135, 'Sabo', 0, 1),
(13136, 'Sabol', 0, 1),
(13137, 'Saccomanno', 0, 1),
(13138, 'Sack', 0, 1),
(13139, 'Sadler', 0, 1),
(13140, 'Sadowski', 0, 1),
(13141, 'Sadzeck', 0, 1),
(13142, 'Saenz', 0, 1),
(13143, 'Saffer', 0, 1),
(13144, 'Sager', 0, 1),
(13145, 'Sagmoen', 0, 1),
(13146, 'Sain', 0, 1),
(13147, 'Saipe', 0, 1),
(13148, 'Saito', 0, 1),
(13149, 'Saitoh', 0, 1),
(13150, 'Sak', 0, 1),
(13151, 'Sakamoto', 0, 1),
(13152, 'Saladin', 0, 1),
(13153, 'Saladino', 0, 1),
(13154, 'Salas', 0, 1),
(13155, 'Salazar', 0, 1),
(13156, 'Salberg', 0, 1),
(13157, 'Salcedo', 0, 1),
(13158, 'Saldana', 0, 1),
(13159, 'Sale', 0, 1),
(13160, 'Salem', 0, 1),
(13161, 'Sales', 0, 1),
(13162, 'Salinas', 0, 1),
(13163, 'Salkeld', 0, 1),
(13164, 'Salmon', 0, 1),
(13165, 'Salome', 0, 1),
(13166, 'Saltalamacchia', 0, 1),
(13167, 'Salvo', 0, 1),
(13168, 'Samardzija', 0, 1),
(13169, 'Sammons', 0, 1),
(13170, 'Sample', 0, 1),
(13171, 'Sampson', 0, 1),
(13172, 'Samuel', 0, 1),
(13173, 'San Pedro', 0, 1),
(13174, 'Sanabia', 0, 1),
(13175, 'Sanada', 0, 1),
(13176, 'Sanburn', 0, 1),
(13177, 'Sanches', 0, 1),
(13178, 'Sanchez', 0, 1),
(13179, 'Sandberg', 0, 1),
(13180, 'Sanders', 0, 1),
(13181, 'Sanderson', 0, 1),
(13182, 'Sandes', 0, 1),
(13183, 'Sandfort', 0, 1),
(13184, 'Sandoval', 0, 1),
(13185, 'Sands', 0, 1),
(13186, 'Sanford', 0, 1),
(13187, 'Sanger', 0, 1),
(13188, 'Sanit', 0, 1),
(13189, 'Sanmartin', 0, 1),
(13190, 'Sano', 0, 1),
(13191, 'Sansoe', 0, 1),
(13192, 'Santana', 0, 1),
(13193, 'Santander', 0, 1),
(13194, 'Santangelo', 0, 1),
(13195, 'Santeliz', 0, 1),
(13196, 'Santiago', 0, 1),
(13197, 'Santillan', 0, 1),
(13198, 'Santomauro', 0, 1),
(13199, 'Santor', 0, 1),
(13200, 'Santos', 0, 1),
(13201, 'Sapp', 0, 1),
(13202, 'Sappelt', 0, 1),
(13203, 'Sappington', 0, 1),
(13204, 'Sardinas', 0, 1),
(13205, 'Sardinha', 0, 1),
(13206, 'Sarfate', 0, 1),
(13207, 'Sarmiento', 0, 1),
(13208, 'Sasaki', 0, 1),
(13209, 'Sasser', 0, 1),
(13210, 'Satin', 0, 1),
(13211, 'Satterwhite', 0, 1),
(13212, 'Saturria', 0, 1),
(13213, 'Sauer', 0, 1),
(13214, 'Sauerbeck', 0, 1),
(13215, 'Saunders', 0, 1),
(13216, 'Saupold', 0, 1),
(13217, 'Sauveur', 0, 1),
(13218, 'Savage', 0, 1),
(13219, 'Savery', 0, 1),
(13220, 'Sawamura', 0, 1),
(13221, 'Sawatski', 0, 1),
(13222, 'Sawyer', 0, 1),
(13223, 'Sborz', 0, 1),
(13224, 'Scahill', 0, 1),
(13225, 'Scalamandre', 0, 1),
(13226, 'Scales', 0, 1),
(13227, 'Scanlan', 0, 1),
(13228, 'Scarborough', 0, 1),
(13229, 'Scarduzio', 0, 1),
(13230, 'Scarpetta', 0, 1),
(13231, 'Scarsone', 0, 1),
(13232, 'Scavuzzo', 0, 1),
(13233, 'Schaeffer', 0, 1),
(13234, 'Schafer', 0, 1),
(13235, 'Schales', 0, 1),
(13236, 'Schall', 0, 1),
(13237, 'Schappert', 0, 1),
(13238, 'Schebler', 0, 1),
(13239, 'Scheffer', 0, 1),
(13240, 'Scheiner', 0, 1),
(13241, 'Schellenger', 0, 1),
(13242, 'Scheppers', 0, 1),
(13243, 'Scherer', 0, 1),
(13244, 'Scherff', 0, 1),
(13245, 'Scherzer', 0, 1),
(13246, 'Schierholtz', 0, 1),
(13247, 'Schilling', 0, 1),
(13248, 'Schimpf', 0, 1),
(13249, 'Schiraldi', 0, 1),
(13250, 'Schlehuber', 0, 1),
(13251, 'Schlereth', 0, 1),
(13252, 'Schlichting', 0, 1),
(13253, 'Schliem', 0, 1),
(13254, 'Schlitter', 0, 1),
(13255, 'Schlosser', 0, 1),
(13256, 'Schmack', 0, 1),
(13257, 'Schmidt', 0, 1),
(13258, 'Schmitt', 0, 1),
(13259, 'Schmoll', 0, 1),
(13260, 'Schneider', 0, 1),
(13261, 'Schnurstein', 0, 1),
(13262, 'Schoeneweis', 0, 1),
(13263, 'Schofield', 0, 1),
(13264, 'Schoop', 0, 1),
(13265, 'Schotts', 0, 1),
(13266, 'Schourek', 0, 1),
(13267, 'Schrader', 0, 1),
(13268, 'Schramek', 0, 1),
(13269, 'Schreiber', 0, 1),
(13270, 'Schrenk', 0, 1),
(13271, 'Schrock', 0, 1),
(13272, 'Schroder', 0, 1),
(13273, 'Schroyer', 0, 1),
(13274, 'Schu', 0, 1),
(13275, 'Schuerholz', 0, 1),
(13276, 'Schugel', 0, 1),
(13277, 'Schuler', 0, 1),
(13278, 'Schultz', 0, 1),
(13279, 'Schumaker', 0, 1),
(13280, 'Schuster', 0, 1),
(13281, 'Schutz', 0, 1),
(13282, 'Schwarber', 0, 1),
(13283, 'Schwartz', 0, 1),
(13284, 'Schwimer', 0, 1),
(13285, 'Schwindel', 0, 1),
(13286, 'Schwinden', 0, 1),
(13287, 'Schwindenhammer', 0, 1),
(13288, 'Scivicque', 0, 1),
(13289, 'Sclafani', 0, 1),
(13290, 'Scobie', 0, 1),
(13291, 'Scott', 0, 1),
(13292, 'Scram', 0, 1),
(13293, 'Scribner', 0, 1),
(13294, 'Scruggs', 0, 1),
(13295, 'Scutaro', 0, 1),
(13296, 'Seabol', 0, 1),
(13297, 'Seabold', 0, 1),
(13298, 'Seager', 0, 1),
(13299, 'Seanez', 0, 1),
(13300, 'Searle', 0, 1),
(13301, 'Searles', 0, 1),
(13302, 'Sears', 0, 1),
(13303, 'Seaton', 0, 1),
(13304, 'Seay', 0, 1),
(13305, 'Seddon', 0, 1),
(13306, 'Sedlacek', 0, 1),
(13307, 'Sedlock', 0, 1),
(13308, 'Seelbach', 0, 1),
(13309, 'Sefcik', 0, 1),
(13310, 'Seferina', 0, 1),
(13311, 'Segedin', 0, 1),
(13312, 'Segovia', 0, 1),
(13313, 'Segui', 0, 1),
(13314, 'Seguignol', 0, 1),
(13315, 'Segura', 0, 1),
(13316, 'Seibel', 0, 1),
(13317, 'Seidel', 0, 1),
(13318, 'Seifrig', 0, 1),
(13319, 'Seijas', 0, 1),
(13320, 'Seise', 0, 1),
(13321, 'Seitzer', 0, 1),
(13322, 'Sekany', 0, 1),
(13323, 'Selby', 0, 1),
(13324, 'Sele', 0, 1),
(13325, 'Self', 0, 1),
(13326, 'Sellers', 0, 1),
(13327, 'Selman', 0, 1),
(13328, 'Selsky', 0, 1),
(13329, 'Semien', 0, 1),
(13330, 'Semmelhack', 0, 1),
(13331, 'Senga', 0, 1),
(13332, 'Senzatela', 0, 1),
(13333, 'Senzel', 0, 1),
(13334, 'Seo', 0, 1),
(13335, 'Septimo', 0, 1),
(13336, 'Sequea', 0, 1),
(13337, 'Serafini', 0, 1),
(13338, 'Seratelli', 0, 1),
(13339, 'Serrano', 0, 1),
(13340, 'Servais', 0, 1),
(13341, 'Serven', 0, 1),
(13342, 'Service', 0, 1),
(13343, 'Settsu', 0, 1),
(13344, 'Seung-Yeop', 0, 1),
(13345, 'Seuss', 0, 1),
(13346, 'Severino', 0, 1),
(13347, 'Sevilla', 0, 1),
(13348, 'Sewald', 0, 1),
(13349, 'Sexson', 0, 1),
(13350, 'Sexton', 0, 1),
(13351, 'Seymour', 0, 1),
(13352, 'sfdklai', 0, 1),
(13353, 'Shabala', 0, 1),
(13354, 'Shackelford', 0, 1),
(13355, 'Shafer', 0, 1),
(13356, 'Shaffar', 0, 1),
(13357, 'Shaffer', 0, 1),
(13358, 'Shanks', 0, 1),
(13359, 'Sharber', 0, 1),
(13360, 'Sharpless', 0, 1),
(13361, 'Shave', 0, 1),
(13362, 'Shaver', 0, 1),
(13363, 'Shaw', 0, 1),
(13364, 'Shawaryn', 0, 1),
(13365, 'Sheaffer', 0, 1),
(13366, 'Shealy', 0, 1),
(13367, 'Shearn', 0, 1),
(13368, 'Sheets', 0, 1),
(13369, 'Sheffield', 0, 1),
(13370, 'Shelby', 0, 1),
(13371, 'Sheldon', 0, 1),
(13372, 'Shell', 0, 1),
(13373, 'Shelton', 0, 1),
(13374, 'Shepherd', 0, 1),
(13375, 'Sherfy', 0, 1),
(13376, 'Sheridan', 0, 1),
(13377, 'Sherriff', 0, 1),
(13378, 'Sherrill', 0, 1),
(13379, 'Shibilo', 0, 1),
(13380, 'Shibuya', 0, 1),
(13381, 'Shields', 0, 1),
(13382, 'Shiell', 0, 1),
(13383, 'Shim', 0, 1),
(13384, 'Shimizu', 0, 1),
(13385, 'Shinjo', 0, 1),
(13386, 'Shinskie', 0, 1),
(13387, 'Shipley', 0, 1),
(13388, 'Shipman', 0, 1),
(13389, 'Shirek', 0, 1),
(13390, 'Shirley', 0, 1),
(13391, 'Shoda', 0, 1),
(13392, 'Shoemaker', 0, 1),
(13393, 'Shoppach', 0, 1),
(13394, 'Shore', 0, 1),
(13395, 'Short', 0, 1),
(13396, 'Shortslef', 0, 1),
(13397, 'Shoulders', 0, 1),
(13398, 'Shouse', 0, 1),
(13399, 'Shreve', 0, 1),
(13400, 'Shuck', 0, 1),
(13401, 'Shuey', 0, 1),
(13402, 'Shumaker', 0, 1),
(13403, 'Shuman', 0, 1),
(13404, 'Shumpert', 0, 1),
(13405, 'Shunick', 0, 1),
(13406, 'Sibrian', 0, 1),
(13407, 'Siddall', 0, 1),
(13408, 'Side', 0, 1),
(13409, 'Siegrist', 0, 1),
(13410, 'Sierra', 0, 1),
(13411, 'Sierra, Jr', 0, 1),
(13412, 'Sikaras', 0, 1),
(13413, 'Sikorski', 0, 1),
(13414, 'Sillman', 0, 1),
(13415, 'Silva', 0, 1),
(13416, 'Silverino', 0, 1),
(13417, 'Silverio', 0, 1),
(13418, 'Silvestri', 0, 1),
(13419, 'Silviano', 0, 1),
(13420, 'Simard', 0, 1),
(13421, 'Simas', 0, 1),
(13422, 'Simmons', 0, 1),
(13423, 'Simms', 0, 1),
(13424, 'Simon', 0, 1),
(13425, 'Simonitsch', 0, 1),
(13426, 'Simons', 0, 1),
(13427, 'Simontacchi', 0, 1),
(13428, 'Simpson', 0, 1),
(13429, 'Sims', 0, 1),
(13430, 'Simunic', 0, 1),
(13431, 'Sinclair', 0, 1),
(13432, 'Sing', 0, 1),
(13433, 'Singer', 0, 1),
(13434, 'Singleton', 0, 1),
(13435, 'Sinisi', 0, 1),
(13436, 'Sinkbeil', 0, 1),
(13437, 'Sinnery', 0, 1),
(13438, 'Sipp', 0, 1),
(13439, 'Siri', 0, 1),
(13440, 'Sirotka', 0, 1),
(13441, 'Sisco', 0, 1),
(13442, 'Sisk', 0, 1),
(13443, 'Sitton', 0, 1),
(13444, 'Siverio', 0, 1),
(13445, 'Sizemore', 0, 1),
(13446, 'Skaggs', 0, 1),
(13447, 'Skelton', 0, 1),
(13448, 'Skipworth', 0, 1),
(13449, 'Skoglund', 0, 1),
(13450, 'Skole', 0, 1),
(13451, 'Skoug', 0, 1),
(13452, 'Skrehot', 0, 1),
(13453, 'Skrmetta', 0, 1),
(13454, 'Slaats', 0, 1),
(13455, 'Slama', 0, 1),
(13456, 'Slania', 0, 1),
(13457, 'Slaten', 0, 1),
(13458, 'Slater', 0, 1),
(13459, 'Slaught', 0, 1),
(13460, 'Slavik', 0, 1),
(13461, 'Slayden', 0, 1),
(13462, 'Sledge', 0, 1),
(13463, 'Sleeth', 0, 1),
(13464, 'Slegers', 0, 1),
(13465, 'Sloan', 0, 1),
(13466, 'Slocum', 0, 1),
(13467, 'Slocumb', 0, 1),
(13468, 'Slowey', 0, 1),
(13469, 'Slusarski', 0, 1),
(13470, 'Small', 0, 1),
(13471, 'Smalling', 0, 1),
(13472, 'Smart', 0, 1),
(13473, 'Smelter', 0, 1),
(13474, 'Smiley', 0, 1),
(13475, 'Smit', 0, 1),
(13476, 'Smith', 0, 1),
(13477, 'Smitherman', 0, 1),
(13478, 'Smoak', 0, 1),
(13479, 'Smoker', 0, 1),
(13480, 'Smolinski', 0, 1),
(13481, 'Smoltz', 0, 1),
(13482, 'Smoral', 0, 1),
(13483, 'Smyly', 0, 1),
(13484, 'Smyth', 0, 1),
(13485, 'Snare', 0, 1),
(13486, 'Snead', 0, 1),
(13487, 'Sneed', 0, 1),
(13488, 'Snell', 0, 1),
(13489, 'Snelling', 0, 1),
(13490, 'Snelten', 0, 1),
(13491, 'Snider', 0, 1),
(13492, 'Snodgress', 0, 1),
(13493, 'Snopek', 0, 1),
(13494, 'Snow', 0, 1),
(13495, 'Snusz', 0, 1),
(13496, 'Snyder', 0, 1),
(13497, 'Sobkowiak', 0, 1),
(13498, 'Sobolewski', 0, 1),
(13499, 'Sobotka', 0, 1),
(13500, 'Socarras', 0, 1),
(13501, 'Socolovich', 0, 1),
(13502, 'Sodders', 0, 1),
(13503, 'Soderstrom', 0, 1),
(13504, 'Sodowsky', 0, 1),
(13505, 'Sogard', 0, 1),
(13506, 'Sojo', 0, 1),
(13507, 'Solak', 0, 1),
(13508, 'Solano', 0, 1),
(13509, 'Solarte', 0, 1),
(13510, 'Soler', 0, 1),
(13511, 'Solich', 0, 1),
(13512, 'Soliman', 0, 1),
(13513, 'Solis', 0, 1),
(13514, 'Solomon', 0, 1),
(13515, 'Solorzano', 0, 1),
(13516, 'Somsen', 0, 1),
(13517, 'Song', 0, 1),
(13518, 'Songco', 0, 1),
(13519, 'Songster', 0, 1),
(13520, 'Sonnanstine', 0, 1),
(13521, 'Sonnier', 0, 1),
(13522, 'Soptic', 0, 1),
(13523, 'Sorensen', 0, 1),
(13524, 'Soria', 0, 1),
(13525, 'Soriano', 0, 1),
(13526, 'Soroka', 0, 1),
(13527, 'Sorrento', 0, 1),
(13528, 'Sosa', 0, 1),
(13529, 'Sota', 0, 1),
(13530, 'Soto', 0, 1),
(13531, 'Souza', 0, 1),
(13532, 'Sowers', 0, 1),
(13533, 'Span', 0, 1),
(13534, 'Spanberger', 0, 1),
(13535, 'Spangenberg', 0, 1),
(13536, 'Spanjer-Furstenburg', 0, 1),
(13537, 'Spann', 0, 1),
(13538, 'Spanos', 0, 1),
(13539, 'Sparkman', 0, 1),
(13540, 'Sparks', 0, 1),
(13541, 'Spataro', 0, 1),
(13542, 'Spears', 0, 1),
(13543, 'Speas', 0, 1),
(13544, 'Specht', 0, 1),
(13545, 'Spehr', 0, 1),
(13546, 'Speier', 0, 1),
(13547, 'Speigner', 0, 1),
(13548, 'Spence', 0, 1),
(13549, 'Spencer', 0, 1),
(13550, 'Spicer', 0, 1),
(13551, 'Spiegel', 0, 1),
(13552, 'Spiehs', 0, 1),
(13553, 'Spiers', 0, 1),
(13554, 'Spiezio', 0, 1),
(13555, 'Spilborghs', 0, 1),
(13556, 'Spitzbarth', 0, 1),
(13557, 'Spivey', 0, 1),
(13558, 'Spoljaric', 0, 1),
(13559, 'Spoone', 0, 1),
(13560, 'Spooneybarger', 0, 1),
(13561, 'Spottiswood', 0, 1),
(13562, 'Spradlin', 0, 1),
(13563, 'Sprague', 0, 1),
(13564, 'Spring', 0, 1),
(13565, 'Springer', 0, 1),
(13566, 'Sprout', 0, 1),
(13567, 'Sprowl', 0, 1),
(13568, 'Spruill', 0, 1),
(13569, 'Spurgeon', 0, 1),
(13570, 'Spurling', 0, 1),
(13571, 'Squires', 0, 1),
(13572, 'St. Pierre', 0, 1),
(13573, 'St.Clair', 0, 1),
(13574, 'Stafford', 0, 1),
(13575, 'Stahl', 0, 1),
(13576, 'Stahoviak', 0, 1),
(13577, 'Stairs', 0, 1),
(13578, 'Stallings', 0, 1),
(13579, 'Stamets', 0, 1),
(13580, 'Stammen', 0, 1),
(13581, 'Standridge', 0, 1),
(13582, 'Stanek', 0, 1),
(13583, 'Stanford', 0, 1),
(13584, 'Stange', 0, 1),
(13585, 'Stanifer', 0, 1),
(13586, 'Stankiewicz', 0, 1),
(13587, 'Stanley', 0, 1),
(13588, 'Stansberry', 0, 1),
(13589, 'Stanton', 0, 1),
(13590, 'Stark', 0, 1),
(13591, 'Starling', 0, 1),
(13592, 'Startup', 0, 1),
(13593, 'Stassi', 0, 1),
(13594, 'Statia', 0, 1),
(13595, 'Staton', 0, 1),
(13596, 'Stauffer', 0, 1),
(13597, 'Staumont', 0, 1),
(13598, 'Stavert', 0, 1),
(13599, 'Stavinoha', 0, 1),
(13600, 'Stavisky', 0, 1),
(13601, 'Stechschulte', 0, 1),
(13602, 'Steckenrider', 0, 1),
(13603, 'Steele', 0, 1),
(13604, 'Steenstra', 0, 1),
(13605, 'Stegall', 0, 1),
(13606, 'Steik', 0, 1),
(13607, 'Stein', 0, 1),
(13608, 'Steinbach', 0, 1),
(13609, 'Stemle', 0, 1),
(13610, 'Stenson', 0, 1),
(13611, 'Stentz', 0, 1),
(13612, 'Stephan', 0, 1),
(13613, 'Stephen', 0, 1),
(13614, 'Stephens', 0, 1),
(13615, 'Stephenson', 0, 1),
(13616, 'Stern', 0, 1),
(13617, 'Stertzbach', 0, 1),
(13618, 'Stetter', 0, 1),
(13619, 'Stevens', 0, 1),
(13620, 'Stevenson', 0, 1),
(13621, 'Steverson', 0, 1),
(13622, 'Stewart', 0, 1),
(13623, 'Stidfole', 0, 1),
(13624, 'Stieb', 0, 1),
(13625, 'Still', 0, 1),
(13626, 'Stillwell', 0, 1),
(13627, 'Stilson', 0, 1),
(13628, 'Stinnett', 0, 1),
(13629, 'Stinson', 0, 1),
(13630, 'Stites', 0, 1),
(13631, 'Stobbe', 0, 1),
(13632, 'Stock', 0, 1),
(13633, 'Stocker', 0, 1),
(13634, 'Stockman', 0, 1),
(13635, 'Stocks', 0, 1),
(13636, 'Stodolka', 0, 1),
(13637, 'Stoffel', 0, 1),
(13638, 'Stohr', 0, 1),
(13639, 'Stokes', 0, 1),
(13640, 'Stokes Jr.', 0, 1),
(13641, 'Stonard', 0, 1),
(13642, 'Stone', 0, 1),
(13643, 'Stoneburner', 0, 1),
(13644, 'Stoner', 0, 1),
(13645, 'Stoops', 0, 1),
(13646, 'Storen', 0, 1),
(13647, 'Storey', 0, 1),
(13648, 'Story', 0, 1),
(13649, 'Storz', 0, 1),
(13650, 'Stottlemyre', 0, 1),
(13651, 'Stotts', 0, 1),
(13652, 'Stouffer', 0, 1),
(13653, 'Stout', 0, 1),
(13654, 'Stovall', 0, 1),
(13655, 'Stowell', 0, 1),
(13656, 'Stowers', 0, 1),
(13657, 'Strahan', 0, 1),
(13658, 'Strahm', 0, 1),
(13659, 'Straily', 0, 1),
(13660, 'Strange', 0, 1),
(13661, 'Strasburg', 0, 1),
(13662, 'Stratton', 0, 1),
(13663, 'Strausborger', 0, 1),
(13664, 'Straw', 0, 1),
(13665, 'Strawberry', 0, 1),
(13666, 'Strayhorn', 0, 1),
(13667, 'Street', 0, 1),
(13668, 'Streich', 0, 1),
(13669, 'Strickland', 0, 1),
(13670, 'Strider', 0, 1),
(13671, 'Strieby', 0, 1),
(13672, 'Stripling', 0, 1),
(13673, 'Strittmatter', 0, 1),
(13674, 'Striz', 0, 1),
(13675, 'Stroman', 0, 1),
(13676, 'Strong', 0, 1),
(13677, 'Strop', 0, 1),
(13678, 'Strotman', 0, 1),
(13679, 'Struck', 0, 1),
(13680, 'Stuart', 0, 1),
(13681, 'Stubbs', 0, 1),
(13682, 'Stuckenschneider', 0, 1),
(13683, 'Stuifbergen', 0, 1),
(13684, 'Stull', 0, 1),
(13685, 'Stults', 0, 1),
(13686, 'Stumm', 0, 1),
(13687, 'Stumpf', 0, 1),
(13688, 'Sturdevant', 0, 1),
(13689, 'Sturtze', 0, 1),
(13690, 'Stutes', 0, 1),
(13691, 'Stutts', 0, 1),
(13692, 'Stynes', 0, 1),
(13693, 'Suarez', 0, 1),
(13694, 'Sublett', 0, 1),
(13695, 'Sucre', 0, 1),
(13696, 'Suero', 0, 1),
(13697, 'Sues', 0, 1),
(13698, 'Sugano', 0, 1),
(13699, 'Suggs', 0, 1),
(13700, 'Sugilio', 0, 1),
(13701, 'Sugiuchi', 0, 1),
(13702, 'Sulbaran', 0, 1),
(13703, 'Sulentic', 0, 1),
(13704, 'Sullivan', 0, 1),
(13705, 'Sumoza', 0, 1),
(13706, 'Supak', 0, 1),
(13707, 'Suppan', 0, 1),
(13708, 'Surhoff', 0, 1),
(13709, 'Surkamp', 0, 1),
(13710, 'Susac', 0, 1),
(13711, 'Suschak', 0, 1),
(13712, 'Susdorf', 0, 1),
(13713, 'Suter', 0, 1),
(13714, 'Sutil', 0, 1),
(13715, 'Sutter', 0, 1),
(13716, 'Suttle', 0, 1),
(13717, 'Sutton', 0, 1),
(13718, 'Suzuki', 0, 1),
(13719, 'Sveum', 0, 1),
(13720, 'Swagerty', 0, 1),
(13721, 'Swanda', 0, 1),
(13722, 'Swann', 0, 1),
(13723, 'Swanner', 0, 1),
(13724, 'Swanson', 0, 1),
(13725, 'Swartzbaugh', 0, 1),
(13726, 'Swarzak', 0, 1),
(13727, 'Sweaney', 0, 1),
(13728, 'Swedlow', 0, 1),
(13729, 'Sweeney', 0, 1),
(13730, 'Sweet', 0, 1),
(13731, 'Swift', 0, 1),
(13732, 'Swihart', 0, 1),
(13733, 'Swindell', 0, 1),
(13734, 'Swindle', 0, 1),
(13735, 'Swisher', 0, 1),
(13736, 'Switzer', 0, 1),
(13737, 'Sylvester', 0, 1),
(13738, 'Syndergaard', 0, 1),
(13739, 'Szapucki', 0, 1),
(13740, 'Szczur', 0, 1),
(13741, 'Szuminski', 0, 1),
(13742, 'Szymanski', 0, 1),
(13743, 'Szynski', 0, 1),
(13744, 'T', 0, 1),
(13745, 'Tabaka', 0, 1),
(13746, 'Tabata', 0, 1),
(13747, 'Tablado', 0, 1),
(13748, 'Tabor', 0, 1),
(13749, 'Tabrett', 0, 1),
(13750, 'Tadano', 0, 1),
(13751, 'Taffer Bar Rescue', 0, 0),
(13752, 'Taglienti', 0, 1),
(13753, 'Tago', 0, 1),
(13754, 'Taguchi', 0, 1),
(13755, 'Taijeron', 0, 1),
(13756, 'Taillon', 0, 1),
(13757, 'Takahashi', 0, 1),
(13758, 'Takatsu', 0, 1),
(13759, 'Takeda', 0, 1),
(13760, 'Talavera', 0, 1),
(13761, 'Talbot', 0, 1),
(13762, 'Tallet', 0, 1),
(13763, 'Tam', 0, 1),
(13764, 'Tamayo', 0, 1),
(13765, 'Tanaka', 0, 1),
(13766, 'Taniguchi', 0, 1),
(13767, 'Tankersley', 0, 1),
(13768, 'Tanner', 0, 1),
(13769, 'Tanos', 0, 1),
(13770, 'Tansel', 0, 1),
(13771, 'Tapani', 0, 1),
(13772, 'Tapia', 0, 1),
(13773, 'Tarasco', 0, 1),
(13774, 'Tarnok', 0, 1),
(13775, 'Tarpley', 0, 1),
(13776, 'Tarsi', 0, 1),
(13777, 'Tartabull', 0, 1),
(13778, 'Tartamella', 0, 1),
(13779, 'Taschner', 0, 1),
(13780, 'Tata', 0, 1),
(13781, 'Tate', 0, 1),
(13782, 'Tateyama', 0, 1),
(13783, 'Tatis', 0, 1),
(13784, 'Tatis Jr.', 0, 1),
(13785, 'Tatum', 0, 1),
(13786, 'Tatusko', 0, 1),
(13787, 'Taubenheim', 0, 1),
(13788, 'Taubensee', 0, 1),
(13789, 'Tauchman', 0, 1),
(13790, 'Tavarez', 0, 1),
(13791, 'Taveras', 0, 1),
(13792, 'Taylor', 0, 1),
(13793, 'Tazawa', 0, 1),
(13794, 'Teaford', 0, 1),
(13795, 'Teagarden', 0, 1),
(13796, 'Teahen', 0, 1),
(13797, 'Tebow', 0, 1),
(13798, 'Teheran', 0, 1),
(13799, 'Teixeira', 0, 1),
(13800, 'Tejada', 0, 1),
(13801, 'Tejeda', 0, 1),
(13802, 'Tejera', 0, 1),
(13803, 'Tekotte', 0, 1),
(13804, 'Telemaco', 0, 1),
(13805, 'Telford', 0, 1),
(13806, 'Telgheder', 0, 1),
(13807, 'Telis', 0, 1),
(13808, 'Tellez', 0, 1),
(13809, 'Tenbrink', 0, 1),
(13810, 'Teng', 0, 1),
(13811, 'Tepera', 0, 1),
(13812, 'Tepesch', 0, 1),
(13813, 'Terahara', 0, 1),
(13814, 'Terdoslavich', 0, 1),
(13815, 'Terrero', 0, 1),
(13816, 'Terry', 0, 1),
(13817, 'Tessmer', 0, 1),
(13818, 'Testa', 0, 1),
(13819, 'Tetreault', 0, 1),
(13820, 'Tettleton', 0, 1),
(13821, 'Teut', 0, 1),
(13822, 'Tewksbury', 0, 1),
(13823, 'Texeira', 0, 1),
(13824, 'Thaiss', 0, 1),
(13825, 'Thames', 0, 1),
(13826, 'Thatcher', 0, 1),
(13827, 'Thayer', 0, 1),
(13828, 'Then', 0, 1),
(13829, 'Theriot', 0, 1),
(13830, 'Therrien', 0, 1),
(13831, 'Thibault', 0, 1),
(13832, 'Thielbar', 0, 1),
(13833, 'Thigpen', 0, 1),
(13834, 'Thole', 0, 1),
(13835, 'Thomas', 0, 1),
(13836, 'Thome', 0, 1),
(13837, 'Thomore', 0, 1),
(13838, 'Thompson', 0, 1),
(13839, 'Thomson', 0, 1),
(13840, 'Thon, Jr', 0, 1),
(13841, 'Thorman', 0, 1),
(13842, 'Thornburg', 0, 1),
(13843, 'Thornton', 0, 1),
(13844, 'Thorpe', 0, 1),
(13845, 'Threets', 0, 1),
(13846, 'Thurman', 0, 1),
(13847, 'Thurston', 0, 1),
(13848, 'Tiberi', 0, 1),
(13849, 'Tice', 0, 1),
(13850, 'Tierney', 0, 1),
(13851, 'Tiffany', 0, 1),
(13852, 'Tiffee', 0, 1),
(13853, 'Till', 0, 1),
(13854, 'Tillman', 0, 1),
(13855, 'Tillo', 0, 1),
(13856, 'Tilson', 0, 1),
(13857, 'Timlin', 0, 1),
(13858, 'Timmons', 0, 1),
(13859, 'Timpner', 0, 1),
(13860, 'Tinoco', 0, 1),
(13861, 'Tinsley', 0, 1),
(13862, 'Tintor', 0, 1),
(13863, 'Tirado', 0, 1),
(13864, 'Tisch', 0, 1),
(13865, 'Tobias', 0, 1),
(13866, 'Tobin', 0, 1),
(13867, 'Toca', 0, 1),
(13868, 'Tocci', 0, 1),
(13869, 'Todd', 0, 1),
(13870, 'Toffey', 0, 1),
(13871, 'Tolar', 0, 1),
(13872, 'Tolbert', 0, 1),
(13873, 'Toledo', 0, 1),
(13874, 'Toles', 0, 1),
(13875, 'Tolisano', 0, 1),
(13876, 'Tollberg', 0, 1),
(13877, 'Tolleson', 0, 1),
(13878, 'Tolliver', 0, 1),
(13879, 'Tomas', 0, 1),
(13880, 'Tomberlin', 0, 1),
(13881, 'Tomey', 0, 1),
(13882, 'Tomko', 0, 1),
(13883, 'Tomlin', 0, 1),
(13884, 'Tomlinson', 0, 1),
(13885, 'Tomori', 0, 1),
(13886, 'Tomshaw', 0, 1),
(13887, 'Toney', 0, 1),
(13888, 'Tonis', 0, 1),
(13889, 'Tonkin', 0, 1),
(13890, 'Tootle', 0, 1),
(13891, 'Toral', 0, 1),
(13892, 'Torcato', 0, 1),
(13893, 'Toregas', 0, 1),
(13894, 'Toritani', 0, 1),
(13895, 'Toro-Hernandez', 0, 1),
(13896, 'Torra', 0, 1),
(13897, 'Torrealba', 0, 1),
(13898, 'Torrence', 0, 1),
(13899, 'Torrens', 0, 1),
(13900, 'Torres', 0, 1),
(13901, 'Torreyes', 0, 1),
(13902, 'Toscano', 0, 1),
(13903, 'Tosoni', 0, 1),
(13904, 'Totten', 0, 1),
(13905, 'Tousa', 0, 1),
(13906, 'Toussaint', 0, 1),
(13907, 'Tovar', 0, 1),
(13908, 'Towers', 0, 1),
(13909, 'Towle', 0, 1),
(13910, 'Towles', 0, 1),
(13911, 'Townsend', 0, 1),
(13912, 'Toyoda', 0, 1),
(13913, 'Traber', 0, 1),
(13914, 'Tracey', 0, 1),
(13915, 'Trachsel', 0, 1),
(13916, 'Tracy', 0, 1),
(13917, 'Trahan', 0, 1),
(13918, 'Trahern', 0, 1),
(13919, 'Trammell', 0, 1),
(13920, 'Travieso', 0, 1),
(13921, 'Travis', 0, 1),
(13922, 'Treanor', 0, 1),
(13923, 'Treinen', 0, 1),
(13924, 'Trejo', 0, 1),
(13925, 'Tremie', 0, 1),
(13926, 'Trevino', 0, 1),
(13927, 'Triggs', 0, 1),
(13928, 'Trinidad', 0, 1),
(13929, 'Tripp', 0, 1),
(13930, 'Triunfel', 0, 1),
(13931, 'Trivino', 0, 1),
(13932, 'Trlicek', 0, 1),
(13933, 'Trombley', 0, 1),
(13934, 'Troncoso', 0, 1),
(13935, 'Troop', 0, 1),
(13936, 'Tropeano', 0, 1),
(13937, 'Trout', 0, 1),
(13938, 'Truby', 0, 1),
(13939, 'Trujillo', 0, 1),
(13940, 'Trumbo', 0, 1),
(13941, 'Tsao', 0, 1),
(13942, 'Tseng', 0, 1),
(13943, 'Tsutsugoh', 0, 1),
(13944, 'Tucci', 0, 1),
(13945, 'Tucker', 0, 1),
(13946, 'Tuiasosopo', 0, 1),
(13947, 'Tuivailala', 0, 1),
(13948, 'Tullis', 0, 1),
(13949, 'Tulowitzki', 0, 1),
(13950, 'Tupman', 0, 1),
(13951, 'Turay', 0, 1),
(13952, 'Turley', 0, 1),
(13953, 'Turman', 0, 1),
(13954, 'Turnbow', 0, 1),
(13955, 'Turnbull', 0, 1),
(13956, 'Turner', 0, 1),
(13957, 'Turney', 0, 1),
(13958, 'Turpen', 0, 1),
(13959, 'Tuttle', 0, 1),
(13960, 'Twine', 0, 1),
(13961, 'Twomey', 0, 1),
(13962, 'Tyler', 0, 1),
(13963, 'Tyner', 0, 1),
(13964, 'Uchikawa', 0, 1),
(13965, 'Uchiyama', 0, 1),
(13966, 'Uehara', 0, 1),
(13967, 'Uelmen', 0, 1),
(13968, 'Uggla', 0, 1),
(13969, 'Ugueto', 0, 1),
(13970, 'Ulloa', 0, 1),
(13971, 'Underwood', 0, 1),
(13972, 'Ungs', 0, 1),
(13973, 'Unroe', 0, 1),
(13974, 'Unsworth', 0, 1),
(13975, 'Update', 0, 1),
(13976, 'Upperman', 0, 1),
(13977, 'Upton', 0, 1),
(13978, 'Upton Jr.', 0, 1),
(13979, 'Urban', 0, 1),
(13980, 'Urbani', 0, 1),
(13981, 'Urbanus', 0, 1),
(13982, 'Urbina', 0, 1),
(13983, 'Urckfitz', 0, 1),
(13984, 'Urdaneta', 0, 1),
(13985, 'Urena', 0, 1),
(13986, 'Uriarte', 0, 1),
(13987, 'Urias', 0, 1),
(13988, 'Uribe', 0, 1),
(13989, 'Urrutia', 0, 1),
(13990, 'Urshela', 0, 1),
(13991, 'Uselton', 0, 1),
(13992, 'Ust', 0, 1),
(13993, 'Utley', 0, 1),
(13994, 'Uviedo', 0, 1),
(13995, 'v', 0, 1),
(13996, 'Vadjer', 0, 1),
(13997, 'Vail', 0, 1),
(13998, 'Valaika', 0, 1),
(13999, 'Valbuena', 0, 1),
(14000, 'Valderrama', 0, 1),
(14001, 'Valdes', 0, 1),
(14002, 'Valdespin', 0, 1),
(14003, 'Valdespina', 0, 1),
(14004, 'Valdez', 0, 1),
(14005, 'Valencia', 0, 1),
(14006, 'Valent', 0, 1),
(14007, 'Valentin', 0, 1),
(14008, 'Valentine', 0, 1),
(14009, 'Valenzuela', 0, 1),
(14010, 'Valenzuela Jr.', 0, 1),
(14011, 'Valera', 0, 1),
(14012, 'Valerio', 0, 1),
(14013, 'Valido', 0, 1),
(14014, 'Valiquette', 0, 1),
(14015, 'Valle', 0, 1),
(14016, 'Vallejo', 0, 1),
(14017, 'Vallone', 0, 1),
(14018, 'Vallot', 0, 1),
(14019, 'Valverde', 0, 1),
(14020, 'Van Allen', 0, 1),
(14021, 'Van Benschoten', 0, 1),
(14022, 'Van Buren', 0, 1),
(14023, 'Van Dusen', 0, 1),
(14024, 'Van Every', 0, 1),
(14025, 'Van Eyk', 0, 1),
(14026, 'Van Hekken', 0, 1),
(14027, 'Van Mil', 0, 1),
(14028, 'Van Ostrand', 0, 1),
(14029, 'Van Poppel', 0, 1),
(14030, 'Van Slyke', 0, 1),
(14031, 'Vance', 0, 1),
(14032, 'VandenHurk', 0, 1),
(14033, 'Vander Tuig', 0, 1),
(14034, 'Vander Wal', 0, 1),
(14035, 'Vanegas', 0, 1),
(14036, 'Vanegmond', 0, 1),
(14037, 'Vanlandingham', 0, 1),
(14038, 'VanMeter', 0, 1),
(14039, 'VanRyn', 0, 1),
(14040, 'VanSlyke', 0, 1),
(14041, 'Vaquedano', 0, 1),
(14042, 'Varga', 0, 1),
(14043, 'Vargas', 0, 1),
(14044, 'Varitek', 0, 1),
(14045, 'Varner', 0, 1),
(14046, 'Varona', 0, 1),
(14047, 'Varsho', 0, 1),
(14048, 'Varvaro', 0, 1),
(14049, 'Vasquez', 0, 1),
(14050, 'Vaughan', 0, 1),
(14051, 'Vaughn', 0, 1),
(14052, 'Vavrek', 0, 1),
(14053, 'Vazquez', 0, 1),
(14054, 'Veal', 0, 1),
(14055, 'Vechionacci', 0, 1),
(14056, 'Velandia', 0, 1),
(14057, 'Velarde', 0, 1),
(14058, 'Velasquez', 0, 1),
(14059, 'Velazquez', 0, 1),
(14060, 'Velez', 0, 1),
(14061, 'Veloz', 0, 1),
(14062, 'Venable', 0, 1),
(14063, 'Venafro', 0, 1),
(14064, 'Venditte', 0, 1),
(14065, 'Venters', 0, 1),
(14066, 'Vento', 0, 1),
(14067, 'Ventura', 0, 1),
(14068, 'Vera', 0, 1),
(14069, 'Veras', 0, 1),
(14070, 'Verbitsky', 0, 1),
(14071, 'Verdugo', 0, 1),
(14072, 'Veres', 0, 1),
(14073, 'VerHagen', 0, 1),
(14074, 'Verlander', 0, 1),
(14075, 'Vermilyea', 0, 1),
(14076, 'Vernooij', 0, 1),
(14077, 'Verplancke', 0, 1),
(14078, 'Verrett', 0, 1),
(14079, 'Vettleson', 0, 1),
(14080, 'Viciedo', 0, 1),
(14081, 'Vick', 0, 1),
(14082, 'Victorino', 0, 1),
(14083, 'Vicuna', 0, 1),
(14084, 'Vidal', 0, 1),
(14085, 'Vidro', 0, 1),
(14086, 'Vieira', 0, 1),
(14087, 'Vielma', 0, 1),
(14088, 'Vientos', 0, 1),
(14089, 'Viera', 0, 1),
(14090, 'Vilade', 0, 1),
(14091, 'Villa', 0, 1),
(14092, 'Villacis', 0, 1),
(14093, 'Villafuerte', 0, 1),
(14094, 'Villalobos', 0, 1),
(14095, 'Villalona', 0, 1),
(14096, 'Villanueva', 0, 1),
(14097, 'Villar', 0, 1),
(14098, 'Villarreal', 0, 1),
(14099, 'Villatoro', 0, 1),
(14100, 'Villegas', 0, 1),
(14101, 'Villone', 0, 1),
(14102, 'Viloria', 0, 1),
(14103, 'Vilter', 0, 1),
(14104, 'Vina', 0, 1),
(14105, 'Vincej', 0, 1),
(14106, 'Vincent', 0, 1),
(14107, 'Vines', 0, 1),
(14108, 'Vineyard', 0, 1),
(14109, 'Vinicio', 0, 1),
(14110, 'Vining', 0, 1),
(14111, 'Vinyard', 0, 1),
(14112, 'Viola', 0, 1),
(14113, 'Virant', 0, 1),
(14114, 'Vitek', 0, 1),
(14115, 'Vitiello', 0, 1),
(14116, 'Vitters', 0, 1),
(14117, 'Viza', 0, 1),
(14118, 'Vizcaino', 0, 1),
(14119, 'Vizquel', 0, 1),
(14120, 'Vogelbach', 0, 1),
(14121, 'Vogelsong', 0, 1),
(14122, 'Vogt', 0, 1),
(14123, 'Voigt', 0, 1),
(14124, 'Voit', 0, 1),
(14125, 'Vollmuth', 0, 1),
(14126, 'Volquez', 0, 1),
(14127, 'Volstad', 0, 1),
(14128, 'Volz', 0, 1),
(14129, 'Von Rosenberg', 0, 1),
(14130, 'von Schamann', 0, 1),
(14131, 'Vosberg', 0, 1),
(14132, 'Vosler', 0, 1),
(14133, 'Voss', 0, 1),
(14134, 'Voth', 0, 1),
(14135, 'Votto', 0, 1),
(14136, 'Voyles', 0, 1),
(14137, 'Wacha', 0, 1),
(14138, 'Wada', 0, 1),
(14139, 'Waddell', 0, 1),
(14140, 'Wade', 0, 1),
(14141, 'Waechter', 0, 1),
(14142, 'Wagner', 0, 1),
(14143, 'Wahl', 0, 1),
(14144, 'Wahpepah', 0, 1),
(14145, 'Wainhouse', 0, 1),
(14146, 'Wainwright', 0, 1),
(14147, 'Wakefield', 0, 1),
(14148, 'Wakeland', 0, 1),
(14149, 'Wakui', 0, 1),
(14150, 'Walbeck', 0, 1),
(14151, 'Walden', 0, 1),
(14152, 'Walding', 0, 1),
(14153, 'Waldron', 0, 1),
(14154, 'Waldrop', 0, 1),
(14155, 'Walker', 0, 1),
(14156, 'Wall', 0, 1),
(14157, 'Walla', 0, 1),
(14158, 'Wallace', 0, 1),
(14159, 'Wallach', 0, 1),
(14160, 'Walling', 0, 1),
(14161, 'Walls', 0, 1),
(14162, 'Walrond', 0, 1),
(14163, 'Walsh', 0, 1),
(14164, 'Walter', 0, 1),
(14165, 'Walters', 0, 1),
(14166, 'Walton', 0, 1),
(14167, 'Wang', 0, 1),
(14168, 'Ward', 0, 1),
(14169, 'Warden', 0, 1),
(14170, 'Ware', 0, 1),
(14171, 'Waring', 0, 1),
(14172, 'Warmoth', 0, 1),
(14173, 'Warren', 0, 1),
(14174, 'Wasdin', 0, 1),
(14175, 'Washburn', 0, 1),
(14176, 'Washington', 0, 1),
(14177, 'Wassermann', 0, 1),
(14178, 'Waszgis', 0, 1),
(14179, 'Watanabe', 0, 1),
(14180, 'Waters', 0, 1),
(14181, 'Wates', 0, 1),
(14182, 'Wathan', 0, 1),
(14183, 'Watkins', 0, 1),
(14184, 'Watrous', 0, 1),
(14185, 'Watson', 0, 1),
(14186, 'Watt', 0, 1),
(14187, 'Watts', 0, 1),
(14188, 'Way', 0, 1),
(14189, 'Wayne', 0, 1),
(14190, 'Weatherford', 0, 1),
(14191, 'Weathers', 0, 1),
(14192, 'Weaver', 0, 1),
(14193, 'Webb', 0, 1),
(14194, 'Webber', 0, 1),
(14195, 'Weber', 0, 1),
(14196, 'Webster', 0, 1),
(14197, 'Wechsler', 0, 1),
(14198, 'Wedel', 0, 1),
(14199, 'Weeden', 0, 1),
(14200, 'Weeks', 0, 1),
(14201, 'Weems', 0, 1),
(14202, 'Weglarz', 0, 1),
(14203, 'Wehner', 0, 1),
(14204, 'Weibl', 0, 1),
(14205, 'Weickel', 0, 1),
(14206, 'Weigel', 0, 1),
(14207, 'Weiland', 0, 1),
(14208, 'Weinhardt', 0, 1),
(14209, 'Weisenberg', 0, 1),
(14210, 'Weiser', 0, 1),
(14211, 'Weiss', 0, 1),
(14212, 'Welch', 0, 1),
(14213, 'Welker', 0, 1),
(14214, 'Wellemeyer', 0, 1),
(14215, 'Weller', 0, 1),
(14216, 'Wells', 0, 1),
(14217, 'Welty', 0, 1),
(14218, 'Wendelken', 0, 1),
(14219, 'Wendell', 0, 1),
(14220, 'Wendle', 0, 1),
(14221, 'Wendt', 0, 1),
(14222, 'Wengert', 0, 1),
(14223, 'Wentz', 0, 1),
(14224, 'Werner', 0, 1),
(14225, 'Werth', 0, 1),
(14226, 'Wertz', 0, 1),
(14227, 'Wesson', 0, 1),
(14228, 'West', 0, 1),
(14229, 'Westbrook', 0, 1),
(14230, 'Westlake', 0, 1),
(14231, 'Westmoreland', 0, 1),
(14232, 'Weston', 0, 1),
(14233, 'Wetteland', 0, 1),
(14234, 'Wetzler', 0, 1),
(14235, 'Whalen', 0, 1),
(14236, 'Whatley', 0, 1),
(14237, 'Whealy', 0, 1),
(14238, 'Wheat', 0, 1),
(14239, 'Wheatland', 0, 1),
(14240, 'Wheeler', 0, 1),
(14241, 'Whelan', 0, 1),
(14242, 'Whisenant', 0, 1),
(14243, 'Whisler', 0, 1),
(14244, 'Whitaker', 0, 1),
(14245, 'White', 0, 1),
(14246, 'Whitefield', 0, 1),
(14247, 'Whiteman', 0, 1),
(14248, 'Whiten', 0, 1),
(14249, 'Whitenack', 0, 1),
(14250, 'Whitesell', 0, 1),
(14251, 'Whiteside', 0, 1),
(14252, 'Whiting', 0, 1),
(14253, 'Whitley', 0, 1),
(14254, 'Whitney', 0, 1),
(14255, 'Whitson', 0, 1),
(14256, 'Whittington', 0, 1),
(14257, 'Whittleman', 0, 1),
(14258, 'Wick', 0, 1),
(14259, 'Wickman', 0, 1),
(14260, 'Wideman', 0, 1),
(14261, 'Widener', 0, 1),
(14262, 'Widger', 0, 1),
(14263, 'Widlansky', 0, 1),
(14264, 'Wieck', 0, 1),
(14265, 'Wieland', 0, 1),
(14266, 'Wieters', 0, 1),
(14267, 'Wiggins', 0, 1),
(14268, 'Wigginton', 0, 1),
(14269, 'Wikoff', 0, 1),
(14270, 'Wilcox', 0, 1),
(14271, 'Wilder', 0, 1),
(14272, 'Wilding', 0, 1),
(14273, 'Wiles', 0, 1),
(14274, 'Wilhelmsen', 0, 1),
(14275, 'Wilhite', 0, 1),
(14276, 'Wilk', 0, 1),
(14277, 'Wilken', 0, 1),
(14278, 'Wilkerson', 0, 1),
(14279, 'Wilkins', 0, 1),
(14280, 'Wilkinson', 0, 1),
(14281, 'Willems', 0, 1),
(14282, 'Williams', 0, 1),
(14283, 'Williams, Jr', 0, 1),
(14284, 'Williamson', 0, 1),
(14285, 'Willingham', 0, 1),
(14286, 'Willis', 0, 1),
(14287, 'Willits', 0, 1),
(14288, 'Willoughby', 0, 1),
(14289, 'Wilson', 0, 1),
(14290, 'Wimberly', 0, 1),
(14291, 'Wimmers', 0, 1),
(14292, 'Winchester', 0, 1),
(14293, 'Windle', 0, 1),
(14294, 'Windsor', 0, 1),
(14295, 'Winfree', 0, 1),
(14296, 'Wing', 0, 1),
(14297, 'Wingenter', 0, 1),
(14298, 'Winkelsas', 0, 1),
(14299, 'Winker', 0, 1),
(14300, 'Winkler', 0, 1),
(14301, 'Winn', 0, 1),
(14302, 'Winston', 0, 1),
(14303, 'Winters', 0, 1),
(14304, 'Wipke', 0, 1),
(14305, 'Wisdom', 0, 1),
(14306, 'Wise', 0, 1),
(14307, 'Wiseman', 0, 1),
(14308, 'Wisler', 0, 1),
(14309, 'Wiswall', 0, 1),
(14310, 'Witasick', 0, 1),
(14311, 'Withem', 0, 1),
(14312, 'Withers', 0, 1),
(14313, 'Witherspoon', 0, 1),
(14314, 'Withrow', 0, 1),
(14315, 'Witt', 0, 1),
(14316, 'Witte', 0, 1),
(14317, 'Witter', 0, 1),
(14318, 'Wittgren', 0, 1),
(14319, 'Wohlers', 0, 1),
(14320, 'Wojciechowski', 0, 1),
(14321, 'Wolcott', 0, 1),
(14322, 'Wolf', 0, 1),
(14323, 'Wolfe', 0, 1),
(14324, 'Wolff', 0, 1),
(14325, 'Wolters', 0, 1),
(14326, 'Womack', 0, 1),
(14327, 'Wong', 0, 1),
(14328, 'Woo', 0, 1),
(14329, 'Wood', 0, 1),
(14330, 'Woodall', 0, 1),
(14331, 'Woodard', 0, 1),
(14332, 'Woodards', 0, 1),
(14333, 'Woodford', 0, 1),
(14334, 'Woodman', 0, 1),
(14335, 'Woodmansee', 0, 1),
(14336, 'Woodruff', 0, 1),
(14337, 'Woods', 0, 1),
(14338, 'Woodwall', 0, 1),
(14339, 'Woodward', 0, 1),
(14340, 'Woody', 0, 1),
(14341, 'Woodyard', 0, 1),
(14342, 'Woolard', 0, 1),
(14343, 'Woolf', 0, 1),
(14344, 'Woolley', 0, 1),
(14345, 'Wooten', 0, 1),
(14346, 'Workman', 0, 1),
(14347, 'Worley', 0, 1),
(14348, 'Worrell', 0, 1),
(14349, 'Wort', 0, 1),
(14350, 'Worth', 0, 1),
(14351, 'Worthington', 0, 1),
(14352, 'Wotell', 0, 1),
(14353, 'Wren', 0, 1),
(14354, 'Wrenn', 0, 1),
(14355, 'Wright', 0, 1),
(14356, 'Wrona', 0, 1),
(14357, 'Wuertz', 0, 1),
(14358, 'Wunsch', 0, 1),
(14359, 'Wylie', 0, 1),
(14360, 'Wynns', 0, 1),
(14361, 'Xanadu', 0, 1),
(14362, 'Yabu', 0, 1),
(14363, 'Yabuta', 0, 1),
(14364, 'Yacabonis', 0, 1),
(14365, 'Yamada', 0, 1),
(14366, 'Yamaguchi', 0, 1),
(14367, 'Yamakita', 0, 1),
(14368, 'Yamamoto', 0, 1),
(14369, 'Yamarin', 0, 1),
(14370, 'Yambati', 0, 1),
(14371, 'Yan', 0, 1),
(14372, 'Yanagita', 0, 1),
(14373, 'Yang', 0, 1),
(14374, 'Yanuki', 0, 1),
(14375, 'Yarbrough', 0, 1),
(14376, 'Yarnall', 0, 1),
(14377, 'Yastrzemski', 0, 1),
(14378, 'Yates', 0, 1),
(14379, 'Ybarra', 0, 1),
(14380, 'Yeatman', 0, 1),
(14381, 'Yelich', 0, 1),
(14382, 'Yepez', 0, 1),
(14383, 'Yerzy', 0, 1),
(14384, 'Ynfante', 0, 1),
(14385, 'Ynoa', 0, 1),
(14386, 'Yoon', 0, 1),
(14387, 'Yoshii', 0, 1),
(14388, 'Yoshimi', 0, 1),
(14389, 'Youkilis', 0, 1),
(14390, 'Youman', 0, 1),
(14391, 'Young', 0, 1),
(14392, 'Young Jr.', 0, 1),
(14393, 'Younginer', 0, 1),
(14394, 'Yourkin', 0, 1),
(14395, 'Yrizarri', 0, 1),
(14396, 'Ysla', 0, 1),
(14397, 'Yurchak', 0, 1),
(14398, 'Zabala', 0, 1),
(14399, 'Zagone', 0, 1),
(14400, 'Zagunis', 0, 1),
(14401, 'Zagurski', 0, 1),
(14402, 'Zamarripa', 0, 1),
(14403, 'Zambrano', 0, 1),
(14404, 'Zammarelli', 0, 1),
(14405, 'Zamora', 0, 1),
(14406, 'Zangari', 0, 1),
(14407, 'Zapata', 0, 1),
(14408, 'Zapp', 0, 1),
(14409, 'Zarate', 0, 1),
(14410, 'Zarraga', 0, 1),
(14411, 'Zastryzny', 0, 1),
(14412, 'Zaun', 0, 1),
(14413, 'Zavada', 0, 1),
(14414, 'Zavala', 0, 1),
(14415, 'Zavaras', 0, 1),
(14416, 'Zawadzki', 0, 1),
(14417, 'Zeferjahn', 0, 1),
(14418, 'Zeid', 0, 1),
(14419, 'Zeile', 0, 1),
(14420, 'Zell', 0, 1),
(14421, 'Zerbe', 0, 1),
(14422, 'Zeringue', 0, 1),
(14423, 'Zerpa', 0, 1),
(14424, 'Zeuch', 0, 1),
(14425, 'Zhang', 0, 1),
(14426, 'Ziegler', 0, 1),
(14427, 'Zimmer', 0, 1),
(14428, 'Zimmerman', 0, 1),
(14429, 'Zimmermann', 0, 1),
(14430, 'Zinicola', 0, 1),
(14431, 'Zink', 0, 1),
(14432, 'Zinter', 0, 1),
(14433, 'Ziomek', 0, 1),
(14434, 'Zito', 0, 1),
(14435, 'Zobrist', 0, 1),
(14436, 'Zoccolillo', 0, 1),
(14437, 'Zoolander', 0, 1),
(14438, 'Zosky', 0, 1),
(14439, 'Zuanich', 0, 1),
(14440, 'Zuber', 0, 1),
(14441, 'Zuleta', 0, 1),
(14442, 'Zumaya', 0, 1),
(14443, 'Zumwalt', 0, 1),
(14444, 'Zunino', 0, 1),
(14445, 'Zych', 0, 1),
(14446, 'Zywica', 0, 1),
(14447, 'Alex', 1, 1),
(14448, 'Carl', 1, 1),
(14449, 'Clay', 1, 1),
(14450, 'Lars', 1, 1),
(14451, 'Jiwan', 1, 1),
(14452, 'Jett', 1, 1),
(14453, 'Brusdar', 1, 1),
(14454, 'Delvis', 1, 1),
(14455, 'Kennard', 1, 1),
(14456, 'Jock', 1, 1),
(14457, 'Taylor', 1, 1),
(14458, 'Daisuke', 1, 1),
(14459, 'Coty', 1, 1),
(14460, 'CJ', 1, 1),
(14461, 'Mac', 1, 1),
(14462, 'John', 1, 1),
(14463, 'Pablo', 1, 1),
(14464, 'Erik', 1, 1),
(14465, 'Esteban', 1, 1),
(14466, 'Alexis', 1, 1),
(14467, 'Yovanny', 1, 1),
(14468, 'Toshihisa', 1, 1),
(14469, 'Hideaki', 1, 1),
(14470, 'Dom', 1, 1),
(14471, 'Franly', 1, 1),
(14472, 'Nik', 1, 1),
(14473, 'Wade', 1, 1),
(14474, 'Seth', 1, 1),
(14475, 'Chipper', 1, 1),
(14476, 'Devon', 1, 1),
(14477, 'Reymin', 1, 1),
(14478, 'Ernesto Wilson', 1, 1),
(14479, 'Rangel', 1, 1),
(14480, 'Samad', 1, 1),
(14481, 'Donaldo', 1, 1),
(14482, 'Tetsuto', 1, 1),
(14483, 'Torii', 1, 1),
(14484, 'James', 1, 1),
(14485, 'Terrell', 1, 1),
(14486, 'Bo', 1, 1),
(14487, 'Kieran', 1, 1),
(14488, 'Keegan', 1, 1),
(14489, 'Jalen', 1, 1),
(14490, 'Quentin', 1, 1),
(14491, 'Lukas', 1, 1),
(14492, 'Todd', 1, 1),
(14493, 'Torre', 1, 1),
(14494, 'Nestor', 1, 1),
(14495, 'Lachlan', 1, 1),
(14496, 'K.C.', 1, 1),
(14497, 'Ellis', 1, 1),
(14498, 'Esix', 1, 1),
(14499, 'Benny', 1, 1),
(14500, 'Dylan', 1, 1),
(14501, 'Kiko', 1, 1),
(14502, 'Barbaro', 1, 1),
(14503, 'Yorkis', 1, 1),
(14504, 'Yasmani', 1, 1),
(14505, 'Osleivis', 1, 1),
(14506, 'Bret', 1, 1),
(14507, 'Brook', 1, 1),
(14508, 'Rigo', 1, 1),
(14509, 'Woody', 1, 1),
(14510, 'Leyson', 1, 1),
(14511, 'Kentrail', 1, 1),
(14512, 'Jhonathan', 1, 1),
(14513, 'OKoyea', 1, 1),
(14514, 'Jhailyn', 1, 1),
(14515, 'Jose', 1, 1),
(14516, 'Dan', 1, 1),
(14517, 'Alejandro', 1, 1),
(14518, 'Tomoki', 1, 1),
(14519, 'Terrence', 1, 1),
(14520, 'Juan.', 1, 1),
(14521, 'Omar Luis', 1, 1),
(14522, 'Ji-Hwan', 1, 1),
(14523, 'Gareth', 1, 1),
(14524, 'Florian', 1, 1),
(14525, 'Jacoby', 1, 1),
(14526, 'Ramon A.', 1, 1),
(14527, 'Polin', 1, 1),
(14528, 'Suk-Min', 1, 1),
(14529, 'Cooper', 1, 1),
(14530, 'Jermaine', 1, 1),
(14531, 'Sid', 1, 1),
(14532, 'Roscoe', 1, 1),
(14533, 'Shed', 1, 1),
(14534, 'Raisel', 1, 1),
(14535, 'Kerry', 1, 1),
(14536, 'Chance', 1, 1),
(14537, 'Mauro', 1, 1),
(14538, 'Derrek', 1, 1),
(14539, 'Maximo', 1, 1),
(14540, 'Gregor', 1, 1),
(14541, 'Esmil', 1, 1),
(14542, 'Trea', 1, 1),
(14543, 'Justin', 1, 1),
(14544, 'Sidney', 1, 1),
(14545, 'Anel', 1, 1),
(14546, 'Wilking', 1, 1),
(14547, 'Rio', 1, 1),
(14548, 'Jhan', 1, 1),
(14549, 'Pat', 1, 1),
(14550, 'Kevin L', 1, 1),
(14551, 'Ryne', 1, 1),
(14552, 'J.P.', 1, 1),
(14553, 'Brant', 1, 1),
(14554, 'Alden', 1, 1),
(14555, 'Randolph', 1, 1),
(14556, 'Justus', 1, 1),
(14557, 'Esteury', 1, 1),
(14558, 'Gene', 1, 1),
(14559, 'Ismel', 1, 1),
(14560, 'Yung-Chi', 1, 1),
(14561, 'Leonard', 1, 1),
(14562, 'Gaspar', 1, 1),
(14563, 'Wei-Chung', 1, 1),
(14564, 'Cornelius', 1, 1),
(14565, 'Randy', 1, 1),
(14566, 'Olmedo', 1, 1),
(14567, 'Evan', 1, 1),
(14568, 'Zach', 1, 1),
(14569, 'Colby', 1, 1),
(14570, 'Kenard', 1, 1),
(14571, 'Jarrett', 1, 1),
(14572, 'Hidetaka', 1, 1),
(14573, 'Kasey', 1, 1),
(14574, 'Garin', 1, 1),
(14575, 'Mookie', 1, 1),
(14576, 'Rowan', 1, 1),
(14577, 'Phil', 1, 1),
(14578, 'Paul', 1, 1),
(14579, 'Roy', 1, 1),
(14580, 'Hideyoshi', 1, 1),
(14581, 'Emiliano', 1, 1),
(14582, 'Noah', 1, 1),
(14583, 'Wilfrido', 1, 1),
(14584, 'Wilin', 1, 1),
(14585, 'John Ryan', 1, 1),
(14586, 'Yan', 1, 1),
(14587, 'Corbin', 1, 1),
(14588, 'Wil', 1, 1),
(14589, 'Cory', 1, 1),
(14590, 'Edgardo', 1, 1),
(14591, 'Shelley', 1, 1),
(14592, 'Jose Carlos', 1, 1),
(14593, 'Randey', 1, 1),
(14594, 'Breyvic', 1, 1),
(14595, 'Aledmys', 1, 1),
(14596, 'Craig', 1, 1),
(14597, 'Lee', 1, 1),
(14598, 'Todd Van', 1, 1),
(14599, 'Elvis', 1, 1),
(14600, 'Terumasa', 1, 1),
(14601, 'Danry', 1, 1),
(14602, 'Tomohiro', 1, 1),
(14603, 'Lenyn', 1, 1),
(14604, 'Magneuris', 1, 1),
(14605, 'Juremi', 1, 1),
(14606, 'Ruben', 1, 1),
(14607, 'Terry', 1, 1),
(14608, 'Luany', 1, 1),
(14609, 'Wilfredo', 1, 1),
(14610, 'Helder', 1, 1),
(14611, 'Deibinson', 1, 1),
(14612, 'Arcenio', 1, 1),
(14613, 'Tae Kyung', 1, 1),
(14614, 'Otis', 1, 1),
(14615, 'Wennington', 1, 1),
(14616, 'Hal', 1, 1),
(14617, 'Geovanny', 1, 1),
(14618, 'Ovandy', 1, 1),
(14619, 'Norihiro', 1, 1),
(14620, 'Scot', 1, 1),
(14621, 'Jai', 1, 1),
(14622, 'Granden', 1, 1),
(14623, 'Cesar', 1, 1),
(14624, 'Garvin', 1, 1),
(14625, 'Joel', 1, 1),
(14626, 'Torsten', 1, 1),
(14627, 'Erisbel', 1, 1),
(14628, 'Cito', 1, 1),
(14629, 'Nicolas', 1, 1),
(14630, 'Zech', 1, 1),
(14631, 'Desmond', 1, 1),
(14632, 'Seigi', 1, 1),
(14633, 'Jantzen', 1, 1),
(14634, 'Cy', 1, 1),
(14635, 'Habelito', 1, 1),
(14636, 'Von', 1, 1),
(14637, 'Judd', 1, 1),
(14638, 'Vernon', 1, 1),
(14639, 'Reese', 1, 1),
(14640, 'Kendal', 1, 1),
(14641, 'Arodys', 1, 1),
(14642, 'Jackie', 1, 1),
(14643, 'Devin', 1, 1),
(14644, 'Timo', 1, 1),
(14645, 'Vinnie', 1, 1),
(14646, 'Deik', 1, 1),
(14647, 'Kraig', 1, 1),
(14648, 'Rashun', 1, 1),
(14649, 'Osmani', 1, 1),
(14650, 'Kensuke', 1, 1),
(14651, 'Keibert', 1, 1),
(14652, 'Nash', 1, 1),
(14653, 'Jarred', 1, 1),
(14654, 'Tobi', 1, 1),
(14655, 'Scooter', 1, 1),
(14656, 'Yangervis', 1, 1),
(14657, 'Ryan', 1, 1),
(14658, 'Rickey', 1, 1),
(14659, 'Nevin', 1, 1),
(14660, 'Dioner', 1, 1),
(14661, 'Domonic', 1, 1),
(14662, 'Yohannis', 1, 1),
(14663, 'Nonie', 1, 1),
(14664, 'Ofelky', 1, 1),
(14665, 'Junichi', 1, 1),
(14666, 'Willians', 1, 1),
(14667, 'Sonny', 1, 1),
(14668, 'Andrew', 1, 1),
(14669, 'Tyrell', 1, 1),
(14670, 'Augustus ', 1, 1),
(14671, 'Bubbie', 1, 1),
(14672, 'Jonah', 1, 1),
(14673, 'Jose A.', 1, 1),
(14674, 'Braxton', 1, 1),
(14675, 'Champ', 1, 1),
(14676, 'Seranthony', 1, 1),
(14677, 'Pedro', 1, 1),
(14678, 'Davey', 1, 1),
(14679, 'Delwyn', 1, 1),
(14680, 'Garett', 1, 1),
(14681, 'Kohl', 1, 1),
(14682, 'Tom', 1, 1),
(14683, 'Elio', 1, 1),
(14684, 'Vincent', 1, 1),
(14685, 'Bear', 1, 1),
(14686, 'Cutter', 1, 1),
(14687, 'Chun Hsiu', 1, 1),
(14688, 'Madison', 1, 1),
(14689, 'Quintin', 1, 1),
(14690, 'Paulino', 1, 1),
(14691, 'Dakota', 1, 1),
(14692, 'Braeden', 1, 1),
(14693, 'Tayron', 1, 1),
(14694, 'Jessen', 1, 1),
(14695, 'Deck', 1, 1),
(14696, 'Stu', 1, 1),
(14697, 'Su-Min', 1, 1),
(14698, 'Kes', 1, 1),
(14699, 'Jasseel', 1, 1),
(14700, 'Joakim', 1, 1),
(14701, 'Yoanis', 1, 1),
(14702, 'Rogelio', 1, 1),
(14703, 'Kory', 1, 1),
(14704, 'Satoshi', 1, 1),
(14705, 'Estarlin', 1, 1),
(14706, 'Benino', 1, 1);
INSERT INTO `master_player_names` (`name_id`, `name`, `is_first_name`, `is_active`) VALUES
(14707, 'Duanel', 1, 1),
(14708, 'D.K.', 1, 1),
(14709, 'Branden', 1, 1),
(14710, 'KeBryan', 1, 1),
(14711, 'Norm', 1, 1),
(14712, 'Jake', 1, 1),
(14713, 'Darvin', 1, 1),
(14714, 'Noel', 1, 1),
(14715, 'Asher', 1, 1),
(14716, 'Jeison', 1, 1),
(14717, 'Ambiorix', 1, 1),
(14718, 'Russell', 1, 1),
(14719, 'Brian N.', 1, 1),
(14720, 'Tyreace', 1, 1),
(14721, 'Kramer', 1, 1),
(14722, 'Yoan', 1, 1),
(14723, 'Hoby', 1, 1),
(14724, 'Kazuki', 1, 1),
(14725, 'Glen', 1, 1),
(14726, 'Odalis', 1, 1),
(14727, 'Yordano', 1, 1),
(14728, 'Howard', 1, 1),
(14729, 'Yamil', 1, 1),
(14730, 'Yonder', 1, 1),
(14731, 'Jurickson', 1, 1),
(14732, 'Kurt', 1, 1),
(14733, 'Ken', 1, 1),
(14734, 'Fernando', 1, 1),
(14735, 'Jong-Soo', 1, 1),
(14736, 'Claudio', 1, 1),
(14737, 'Edgmer', 1, 1),
(14738, 'Zoilo', 1, 1),
(14739, 'Raul', 1, 1),
(14740, 'Nathanel', 1, 1),
(14741, 'Giuseppe', 1, 1),
(14742, 'Victor ', 1, 1),
(14743, 'Gilberto', 1, 1),
(14744, 'Reed', 1, 1),
(14745, 'Yean Carlos', 1, 1),
(14746, 'Tito', 1, 1),
(14747, 'Vinny', 1, 1),
(14748, 'Marty', 1, 1),
(14749, 'Giovanni', 1, 1),
(14750, 'Geoff', 1, 1),
(14751, 'Alfredo', 1, 1),
(14752, 'Kelley', 1, 1),
(14753, 'Koby', 1, 1),
(14754, 'Konrad', 1, 1),
(14755, 'Starling', 1, 1),
(14756, 'Antoan', 1, 1),
(14757, 'Kai-Wei', 1, 1),
(14758, 'Tirso', 1, 1),
(14759, 'Darron', 1, 1),
(14760, 'Delvin', 1, 1),
(14761, 'Tripper', 1, 1),
(14762, 'Jalal', 1, 1),
(14763, 'Darin', 1, 1),
(14764, 'Keiichi', 1, 1),
(14765, 'Arocha', 1, 1),
(14766, 'Masato', 1, 1),
(14767, 'Trey', 1, 1),
(14768, 'J.J.', 1, 1),
(14769, 'Horacio', 1, 1),
(14770, 'Hayato', 1, 1),
(14771, 'Yacksel', 1, 1),
(14772, 'Tatsuhiko', 1, 1),
(14773, 'Reidier', 1, 1),
(14774, 'Martires', 1, 1),
(14775, 'Sug', 1, 1),
(14776, 'Brenan', 1, 1),
(14777, 'Efren', 1, 1),
(14778, 'Joe', 1, 1),
(14779, 'Wilson', 1, 1),
(14780, 'Zhenwang', 1, 1),
(14781, 'Chip', 1, 1),
(14782, 'Ike', 1, 1),
(14783, 'Yorvit', 1, 1),
(14784, 'Jerrick', 1, 1),
(14785, 'Yandy', 1, 1),
(14786, 'Jandel', 1, 1),
(14787, 'Duane', 1, 1),
(14788, 'Corey', 1, 1),
(14789, 'Marino', 1, 1),
(14790, 'Willis', 1, 1),
(14791, 'Alhaji', 1, 1),
(14792, 'Vasili', 1, 1),
(14793, 'Wadye', 1, 1),
(14794, 'Jakson', 1, 1),
(14795, 'Martinez', 1, 1),
(14796, 'Orionny', 1, 1),
(14797, 'Yoshihiro', 1, 1),
(14798, 'Juan Yasser', 1, 1),
(14799, 'Harrison', 1, 1),
(14800, 'Kelby', 1, 1),
(14801, 'Shawn', 1, 1),
(14802, 'Hunter', 1, 1),
(14803, 'Elizardo', 1, 1),
(14804, 'Logan', 1, 1),
(14805, 'Adys', 1, 1),
(14806, 'Hildemaro', 1, 1),
(14807, 'Ynmanol', 1, 1),
(14808, 'Yerdeluis', 1, 1),
(14809, 'Bryson', 1, 1),
(14810, 'Hanser', 1, 1),
(14811, 'Tyreque', 1, 1),
(14812, 'Alan', 1, 1),
(14813, 'Wendell', 1, 1),
(14814, 'Satoru', 1, 1),
(14815, 'Enger', 1, 1),
(14816, 'Takaki', 1, 1),
(14817, 'Francis', 1, 1),
(14818, 'Blas', 1, 1),
(14819, 'Sicnarf', 1, 1),
(14820, 'Dellin', 1, 1),
(14821, 'Abiatal', 1, 1),
(14822, 'JoJo', 1, 1),
(14823, 'Danny', 1, 1),
(14824, 'Dave', 1, 1),
(14825, 'Lastings', 1, 1),
(14826, 'Jamal', 1, 1),
(14827, 'Ernesto', 1, 1),
(14828, 'Atahualpa', 1, 1),
(14829, 'Moises', 1, 1),
(14830, 'Moody', 1, 1),
(14831, 'Gustavo', 1, 1),
(14832, 'Abraham', 1, 1),
(14833, 'Lyle', 1, 1),
(14834, 'Enrique', 1, 1),
(14835, 'Mitch', 1, 1),
(14836, 'Chan Ho', 1, 1),
(14837, 'Glendon', 1, 1),
(14838, 'Santo', 1, 1),
(14839, 'Niuman', 1, 1),
(14840, 'Eddi', 1, 1),
(14841, 'Bobby M.', 1, 1),
(14842, 'Trent', 1, 1),
(14843, 'Mason', 1, 1),
(14844, 'Clayton', 1, 1),
(14845, 'Romulo', 1, 1),
(14846, 'Darwinzon', 1, 1),
(14847, 'Gregg', 1, 1),
(14848, 'Rendy', 1, 1),
(14849, 'Jacque', 1, 1),
(14850, 'Dontrelle', 1, 1),
(14851, 'Shooter', 1, 1),
(14852, 'Lazaro', 1, 1),
(14853, 'Skyler', 1, 1),
(14854, 'Dace', 1, 1),
(14855, 'Alcides', 1, 1),
(14856, 'Damien', 1, 1),
(14857, 'Garth', 1, 1),
(14858, 'Kolbrin', 1, 1),
(14859, 'Ubaldo', 1, 1),
(14860, 'Lariel', 1, 1),
(14861, 'Dedgar', 1, 1),
(14862, 'Kendrys', 1, 1),
(14863, 'Rusty', 1, 1),
(14864, 'Dernell', 1, 1),
(14865, 'Tydus', 1, 1),
(14866, 'Elvin', 1, 1),
(14867, 'Franklin', 1, 1),
(14868, 'Tuffy', 1, 1),
(14869, 'Chairon', 1, 1),
(14870, 'Geovany', 1, 1),
(14871, 'Kean', 1, 1),
(14872, 'Mariano', 1, 1),
(14873, 'Dallas', 1, 1),
(14874, 'Yordy', 1, 1),
(14875, 'Trayvon', 1, 1),
(14876, 'Yamaico', 1, 1),
(14877, 'Brendon', 1, 1),
(14878, 'Kyeong', 1, 1),
(14879, 'Jean Carlos', 1, 1),
(14880, 'Aderlin', 1, 1),
(14881, 'Darrell', 1, 1),
(14882, 'Jentry', 1, 1),
(14883, 'Jodam', 1, 1),
(14884, 'Reynaldo', 1, 1),
(14885, 'Guillermo', 1, 1),
(14886, 'Cha Seung', 1, 1),
(14887, 'Shaver', 1, 1),
(14888, 'Rookie', 1, 1),
(14889, 'Chaz', 1, 1),
(14890, 'Roger', 1, 1),
(14891, 'Osniel', 1, 1),
(14892, 'Pasqual', 1, 1),
(14893, 'Johan', 1, 1),
(14894, 'Eider', 1, 1),
(14895, 'Drake', 1, 1),
(14896, 'Asa', 1, 1),
(14897, 'Bradin', 1, 1),
(14898, 'Silvino', 1, 1),
(14899, 'Roenis', 1, 1),
(14900, 'Will', 1, 1),
(14901, 'Rob', 1, 1),
(14902, 'Steve', 1, 1),
(14903, 'Stetson', 1, 1),
(14904, 'Isabel', 1, 1),
(14905, 'Chin-Feng', 1, 1),
(14906, 'Kazuhisa', 1, 1),
(14907, 'Hyeon-jong', 1, 1),
(14908, 'Runelvys', 1, 1),
(14909, 'Yoslan', 1, 1),
(14910, 'Jansiel', 1, 1),
(14911, 'Chris', 1, 1),
(14912, 'Lewis', 1, 1),
(14913, 'Micah', 1, 1),
(14914, 'Heath', 1, 1),
(14915, 'Jonathan', 1, 1),
(14916, 'Allan', 1, 1),
(14917, 'Wesley', 1, 1),
(14918, 'Hernan', 1, 1),
(14919, 'Mat', 1, 1),
(14920, 'Dinesh', 1, 1),
(14921, 'Shinji', 1, 1),
(14922, 'Damion', 1, 1),
(14923, 'Ted', 1, 1),
(14924, 'Levale', 1, 1),
(14925, 'DeAndre', 1, 1),
(14926, 'Leoner', 1, 1),
(14927, 'Jeferson', 1, 1),
(14928, 'Dairon', 1, 1),
(14929, 'Jefrey', 1, 1),
(14930, 'Wynton', 1, 1),
(14931, 'Dorssys', 1, 1),
(14932, 'Avery', 1, 1),
(14933, 'Meibrys', 1, 1),
(14934, 'Kellin', 1, 1),
(14935, 'Jeff', 1, 1),
(14936, 'Keith', 1, 1),
(14937, 'Freddy', 1, 1),
(14938, 'Miguel Alfredo', 1, 1),
(14939, 'Carlos M.', 1, 1),
(14940, 'Kolby', 1, 1),
(14941, 'Hisashi', 1, 1),
(14942, 'Rod', 1, 1),
(14943, 'Shinobu', 1, 1),
(14944, 'Geraldo', 1, 1),
(14945, 'Elyvs', 1, 1),
(14946, 'Teddy', 1, 1),
(14947, 'Julian', 1, 1),
(14948, 'Trot', 1, 1),
(14949, 'Dana', 1, 1),
(14950, 'Welington', 1, 1),
(14951, 'Wirfin', 1, 1),
(14952, 'Hyun-Jin', 1, 1),
(14953, 'Charlie', 1, 1),
(14954, 'Masafumi', 1, 1),
(14955, 'Fautino', 1, 1),
(14956, 'Sawyer', 1, 1),
(14957, 'Cesare', 1, 1),
(14958, 'Lolo', 1, 1),
(14959, 'Raudy', 1, 1),
(14960, 'Adam', 1, 1),
(14961, 'Bud', 1, 1),
(14962, 'Kip', 1, 1),
(14963, 'Yefri', 1, 1),
(14964, 'Riley', 1, 1),
(14965, 'Isiah', 1, 1),
(14966, 'D.T.', 1, 1),
(14967, 'Choo', 1, 1),
(14968, 'Henri', 1, 1),
(14969, 'Caleb', 1, 1),
(14970, 'Brendan', 1, 1),
(14971, 'Barret', 1, 1),
(14972, 'Wilberto', 1, 1),
(14973, 'Pil Joon', 1, 1),
(14974, 'Braulio', 1, 1),
(14975, 'Luis Alejandro', 1, 1),
(14976, 'Benito', 1, 1),
(14977, 'Salomon', 1, 1),
(14978, 'DAngelo', 1, 1),
(14979, 'Juri', 1, 1),
(14980, 'Yolmer', 1, 1),
(14981, 'Nicky', 1, 1),
(14982, 'Rajai', 1, 1),
(14983, 'Yohanny', 1, 1),
(14984, 'Sean', 1, 1),
(14985, 'Julius', 1, 1),
(14986, 'Shunsuke', 1, 1),
(14987, 'Lorenzo', 1, 1),
(14988, 'Tadahito', 1, 1),
(14989, 'Alibay', 1, 1),
(14990, 'Yadel', 1, 1),
(14991, 'Wily', 1, 1),
(14992, 'Eduar', 1, 1),
(14993, 'Quinton', 1, 1),
(14994, 'Rene', 1, 1),
(14995, 'Antoin', 1, 1),
(14996, 'Daylan', 1, 1),
(14997, 'Christopher.', 1, 1),
(14998, 'Wilmy', 1, 1),
(14999, 'Jolbert', 1, 1),
(15000, 'Engel', 1, 1),
(15001, 'AJ', 1, 1),
(15002, 'Akeem', 1, 1),
(15003, 'Yusniel', 1, 1),
(15004, 'Kimera', 1, 1),
(15005, 'Damian', 1, 1),
(15006, 'Placido', 1, 1),
(15007, 'Bronson', 1, 1),
(15008, 'Kala', 1, 1),
(15009, 'Gaby', 1, 1),
(15010, 'Stefan', 1, 1),
(15011, 'Yoshinori', 1, 1),
(15012, 'Forrest', 1, 1),
(15013, 'Rony', 1, 1),
(15014, 'Luke', 1, 1),
(15015, 'Byung-Hyun', 1, 1),
(15016, 'Robinzon', 1, 1),
(15017, 'Joselo', 1, 1),
(15018, 'Eliezer', 1, 1),
(15019, 'Talmadge', 1, 1),
(15020, 'Turk', 1, 1),
(15021, 'Mario', 1, 1),
(15022, 'Daryl.', 1, 1),
(15023, 'Tug', 1, 1),
(15024, 'Munenori', 1, 1),
(15025, 'Chih-Hsien', 1, 1),
(15026, 'Marinus', 1, 1),
(15027, 'Delmon', 1, 1),
(15028, 'Engelb', 1, 1),
(15029, 'Colton', 1, 1),
(15030, 'K.J.', 1, 1),
(15031, 'Jumbo', 1, 1),
(15032, 'Elias', 1, 1),
(15033, 'Sendy', 1, 1),
(15034, 'Huston', 1, 1),
(15035, 'Oneli', 1, 1),
(15036, 'Fu-Te', 1, 1),
(15037, 'Eliecer', 1, 1),
(15038, 'Kendrick', 1, 1),
(15039, 'Tavo', 1, 1),
(15040, 'Yu', 1, 1),
(15041, 'J.B. ', 1, 1),
(15042, 'Boog', 1, 1),
(15043, 'Lucius', 1, 1),
(15044, 'Cam', 1, 1),
(15045, 'Tomas', 1, 1),
(15046, 'Saburo', 1, 1),
(15047, 'Daric', 1, 1),
(15048, 'Lendy', 1, 1),
(15049, 'Yadil', 1, 1),
(15050, 'Bryse', 1, 1),
(15051, 'Kent', 1, 1),
(15052, 'Jared', 1, 1),
(15053, 'R.D.', 1, 1),
(15054, 'Grant', 1, 1),
(15055, 'Yonata', 1, 1),
(15056, 'Jayhawk', 1, 1),
(15057, 'Dilson', 1, 1),
(15058, 'Tarik', 1, 1),
(15059, 'Keston', 1, 1),
(15060, 'Vince', 1, 1),
(15061, 'Deivi', 1, 1),
(15062, 'Gary', 1, 1),
(15063, 'Dick', 1, 1),
(15064, 'Marc', 1, 1),
(15065, 'Julio', 1, 1),
(15066, 'Ronaldo', 1, 1),
(15067, 'Tyrone', 1, 1),
(15068, 'Atsunori', 1, 1),
(15069, 'Naoya', 1, 1),
(15070, 'Dalier', 1, 1),
(15071, 'Jeanmar', 1, 1),
(15072, 'Genesis', 1, 1),
(15073, 'Chad', 1, 1),
(15074, 'Ray', 1, 1),
(15075, 'Lenny', 1, 1),
(15076, 'Tino', 1, 1),
(15077, 'Gerron', 1, 1),
(15078, 'Nelson', 1, 1),
(15079, 'Israel', 1, 1),
(15080, 'Audy', 1, 1),
(15081, 'Kyrell', 1, 1),
(15082, 'Anfernee', 1, 1),
(15083, 'Marcus', 1, 1),
(15084, 'Amaury', 1, 1),
(15085, 'Chi-Hung', 1, 1),
(15086, 'Jedidiah', 1, 1),
(15087, 'Clark', 1, 1),
(15088, 'Gerson', 1, 1),
(15089, 'Yordan', 1, 1),
(15090, 'Ranger', 1, 1),
(15091, 'Dovydas', 1, 1),
(15092, 'Elliott', 1, 1),
(15093, 'Jelfry', 1, 1),
(15094, 'Marvin', 1, 1),
(15095, 'Dwayne', 1, 1),
(15096, 'Bronswell', 1, 1),
(15097, 'Masahiko', 1, 1),
(15098, 'Reid', 1, 1),
(15099, 'Jarlin', 1, 1),
(15100, 'Raimfer', 1, 1),
(15101, 'Abrahan', 1, 1),
(15102, 'Bart', 1, 1),
(15103, 'Jose Miguel', 1, 1),
(15104, 'Harvey', 1, 1),
(15105, 'Gavin', 1, 1),
(15106, 'Kieron', 1, 1),
(15107, 'Yeison', 1, 1),
(15108, 'Osmel', 1, 1),
(15109, 'Shae', 1, 1),
(15110, 'Lewin', 1, 1),
(15111, 'Jharel', 1, 1),
(15112, 'Dax', 1, 1),
(15113, 'Kodai', 1, 1),
(15114, 'Braden', 1, 1),
(15115, 'Jailen', 1, 1),
(15116, 'Leandro', 1, 1),
(15117, 'Cleuluis', 1, 1),
(15118, 'Tristen', 1, 1),
(15119, 'Bryant', 1, 1),
(15120, 'Alexander', 1, 1),
(15121, 'Rhett', 1, 1),
(15122, 'Josh R.', 1, 1),
(15123, 'Isaac', 1, 1),
(15124, 'Gosuke', 1, 1),
(15125, 'Barry', 1, 1),
(15126, 'Larry', 1, 1),
(15127, 'Curtis', 1, 1),
(15128, 'Albie', 1, 1),
(15129, 'Ivan', 1, 1),
(15130, 'Aramis', 1, 1),
(15131, 'Khris', 1, 1),
(15132, 'Kila', 1, 1),
(15133, 'Chin-Hui', 1, 1),
(15134, 'Chorye', 1, 1),
(15135, 'Kennil', 1, 1),
(15136, 'Petey', 1, 1),
(15137, 'Luken', 1, 1),
(15138, 'Gar', 1, 1),
(15139, 'Masumi', 1, 1),
(15140, 'Humberto', 1, 1),
(15141, 'Jharmidy ', 1, 1),
(15142, 'Dominique', 1, 1),
(15143, 'Laynce', 1, 1),
(15144, 'Yanio', 1, 1),
(15145, 'Khalil', 1, 1),
(15146, 'Edwar', 1, 1),
(15147, 'Flint', 1, 1),
(15148, 'Roque', 1, 1),
(15149, 'Jaff', 1, 1),
(15150, 'Jhoan', 1, 1),
(15151, 'Rhys', 1, 1),
(15152, 'Orlando', 1, 1),
(15153, 'Seung', 1, 1),
(15154, 'Vic', 1, 1),
(15155, 'Liu', 1, 1),
(15156, 'Seiichi', 1, 1),
(15157, 'Yorman', 1, 1),
(15158, 'Loek', 1, 1),
(15159, 'Eury', 1, 1),
(15160, 'Yairo', 1, 1),
(15161, 'Correlle', 1, 1),
(15162, 'Martin', 1, 1),
(15163, 'Jean', 1, 1),
(15164, 'John-Paul', 1, 1),
(15165, 'Tatsuya', 1, 1),
(15166, 'Juniel', 1, 1),
(15167, 'Stryker', 1, 1),
(15168, 'Alika', 1, 1),
(15169, 'Conner', 1, 1),
(15170, 'Ji-Man', 1, 1),
(15171, 'Luis', 1, 1),
(15172, 'Lance', 1, 1),
(15173, 'Neifi', 1, 1),
(15174, 'Cole', 1, 1),
(15175, 'Nyjer', 1, 1),
(15176, 'Alexandre', 1, 1),
(15177, 'Riaan', 1, 1),
(15178, 'Steve2', 1, 1),
(15179, 'Shota', 1, 1),
(15180, 'Bartolo', 1, 1),
(15181, 'Domingo', 1, 1),
(15182, 'Xavier', 1, 1),
(15183, 'Bubba', 1, 1),
(15184, 'Hector', 1, 1),
(15185, 'C.J.', 1, 1),
(15186, 'So', 1, 1),
(15187, 'Bernardo', 1, 1),
(15188, 'Yonny', 1, 1),
(15189, 'Val', 1, 1),
(15190, 'Wladimir', 1, 1),
(15191, 'Eudor', 1, 1),
(15192, 'Hisanori', 1, 1),
(15193, 'Arnold', 1, 1),
(15194, 'Jomar', 1, 1),
(15195, 'Steven', 1, 1),
(15196, 'Manuel', 1, 1),
(15197, 'Jed', 1, 1),
(15198, 'Alexi', 1, 1),
(15199, 'Trystan', 1, 1),
(15200, 'Keaton ', 1, 1),
(15201, 'Adron', 1, 1),
(15202, 'Adolis', 1, 1),
(15203, 'Tripp', 1, 1),
(15204, 'Mandy', 1, 1),
(15205, 'Walker', 1, 1),
(15206, 'Kenta', 1, 1),
(15207, 'Jozzen', 1, 1),
(15208, 'Yohan', 1, 1),
(15209, 'Emeel', 1, 1),
(15210, 'Jeter', 1, 1),
(15211, 'Gresuan', 1, 1),
(15212, 'Edwin', 1, 1),
(15213, 'Shigeki', 1, 1),
(15214, 'Johermyn', 1, 1),
(15215, 'Konner', 1, 1),
(15216, 'Dickie', 1, 1),
(15217, 'Tracy', 1, 1),
(15218, 'Nobihuko', 1, 1),
(15219, 'Cameron', 1, 1),
(15220, 'Magglio', 1, 1),
(15221, 'Archie', 1, 1),
(15222, 'Heliot', 1, 1),
(15223, 'Pascual', 1, 1),
(15224, 'Dont', 1, 1),
(15225, 'Maicer', 1, 1),
(15226, 'Ryohei', 1, 1),
(15227, 'Elier', 1, 1),
(15228, 'Rusney', 1, 1),
(15229, 'Fred', 1, 1),
(15230, 'Jon', 1, 1),
(15231, 'Henry', 1, 1),
(15232, 'Rodrigo', 1, 1),
(15233, 'Aneudis', 1, 1),
(15234, 'Void', 1, 1),
(15235, 'Callix', 1, 1),
(15236, 'Valentino', 1, 1),
(15237, 'Jair', 1, 1),
(15238, 'Giomar', 1, 1),
(15239, 'Marwin', 1, 1),
(15240, 'Hoy Jun', 1, 1),
(15241, 'Jeffrey', 1, 1),
(15242, 'Khalid', 1, 1),
(15243, 'Colter', 1, 1),
(15244, 'R.A.', 1, 1),
(15245, 'Yunel', 1, 1),
(15246, 'Amir', 1, 1),
(15247, 'Joan', 1, 1),
(15248, 'Slade', 1, 1),
(15249, 'Yenci', 1, 1),
(15250, 'Johnny', 1, 1),
(15251, 'Yurendell', 1, 1),
(15252, 'Montreal', 1, 1),
(15253, 'Jim Ed', 1, 1),
(15254, 'Kody', 1, 1),
(15255, 'Jairo', 1, 1),
(15256, 'Norichika', 1, 1),
(15257, 'Brayan', 1, 1),
(15258, 'Rubi', 1, 1),
(15259, 'Anibal', 1, 1),
(15260, 'Chasen', 1, 1),
(15261, 'Anyelo', 1, 1),
(15262, 'Wilton', 1, 1),
(15263, 'Melvin', 1, 1),
(15264, 'Ramiro', 1, 1),
(15265, 'Felix', 1, 1),
(15266, 'Ian', 1, 1),
(15267, 'Yorkin', 1, 1),
(15268, 'Canaan', 1, 1),
(15269, 'Darick', 1, 1),
(15270, 'Gorkys', 1, 1),
(15271, 'Danilo', 1, 1),
(15272, 'Enemencio', 1, 1),
(15273, 'Orber', 1, 1),
(15274, 'Jeramy', 1, 1),
(15275, 'Esmerling', 1, 1),
(15276, 'Rubby', 1, 1),
(15277, 'Dean', 1, 1),
(15278, 'Richard', 1, 1),
(15279, 'Josias', 1, 1),
(15280, 'P.J', 1, 1),
(15281, 'Freddie', 1, 1),
(15282, 'Yao-Hsun', 1, 1),
(15283, 'Jahmai', 1, 1),
(15284, 'Yorvin', 1, 1),
(15285, 'Yeyson', 1, 1),
(15286, 'Amado', 1, 1),
(15287, 'Brewer', 1, 1),
(15288, 'Josh', 1, 1),
(15289, 'Anton', 1, 1),
(15290, 'Ryoji', 1, 1),
(15291, 'Damaso', 1, 1),
(15292, 'Santos', 1, 1),
(15293, 'Osiris', 1, 1),
(15294, 'Rhiner', 1, 1),
(15295, 'Alonzo', 1, 1),
(15296, 'Tomoyuki', 1, 1),
(15297, 'Daulton', 1, 1),
(15298, 'Ervin', 1, 1),
(15299, 'Wilkerman', 1, 1),
(15300, 'Dermis', 1, 1),
(15301, 'Michael', 1, 1),
(15302, 'Oscar', 1, 1),
(15303, 'Wascar', 1, 1),
(15304, 'Makoto', 1, 1),
(15305, 'Trace', 1, 1),
(15306, 'Jamey', 1, 1),
(15307, 'Federico', 1, 1),
(15308, 'Derrik', 1, 1),
(15309, 'Tory', 1, 1),
(15310, 'Jeurys', 1, 1),
(15311, 'Donn', 1, 1),
(15312, 'Nicholas', 1, 1),
(15313, 'Dansby', 1, 1),
(15314, 'Deven', 1, 1),
(15315, 'Kats', 1, 1),
(15316, 'Dee', 1, 1),
(15317, 'Courtney', 1, 1),
(15318, 'Homero', 1, 1),
(15319, 'Takuya', 1, 1),
(15320, 'Wyatt', 1, 1),
(15321, 'Gus', 1, 1),
(15322, 'JC', 1, 1),
(15323, 'Mikie', 1, 1),
(15324, 'Lourdes', 1, 1),
(15325, 'Turner', 1, 1),
(15326, 'Yoshitaka', 1, 1),
(15327, 'Homer', 1, 1),
(15328, 'Myron', 1, 1),
(15329, 'Grundt', 1, 1),
(15330, 'Jefry', 1, 1),
(15331, 'TJ', 1, 1),
(15332, 'Frandy', 1, 1),
(15333, 'Easton', 1, 1),
(15334, 'Bobby', 1, 1),
(15335, 'BrianL', 1, 1),
(15336, 'Calvin', 1, 1),
(15337, 'Adrian', 1, 1),
(15338, 'Vance', 1, 1),
(15339, 'Octavio', 1, 1),
(15340, 'Chien-Ming', 1, 1),
(15341, 'Yem', 1, 1),
(15342, 'Terrance', 1, 1),
(15343, 'Pete', 1, 1),
(15344, 'Takeshi', 1, 1),
(15345, 'Whit', 1, 1),
(15346, 'Carmen', 1, 1),
(15347, 'Vin', 1, 1),
(15348, 'Tobias', 1, 1),
(15349, 'Alvido', 1, 1),
(15350, 'Hobbs', 1, 1),
(15351, 'Jeisson', 1, 1),
(15352, 'Adeiny', 1, 1),
(15353, 'Greg', 1, 1),
(15354, 'Ty', 1, 1),
(15355, 'Wandy', 1, 1),
(15356, 'Diory', 1, 1),
(15357, 'Yhency', 1, 1),
(15358, 'Chin-lung', 1, 1),
(15359, 'Cedric', 1, 1),
(15360, 'L.J.', 1, 1),
(15361, 'Donald', 1, 1),
(15362, 'Ehire', 1, 1),
(15363, 'Wanel', 1, 1),
(15364, 'Elniery', 1, 1),
(15365, 'William', 1, 1),
(15366, 'Miguel', 1, 1),
(15367, 'Anderson', 1, 1),
(15368, 'Yoshihisa', 1, 1),
(15369, 'Shun', 1, 1),
(15370, 'Mychal', 1, 1),
(15371, 'Colten', 1, 1),
(15372, 'Herbert', 1, 1),
(15373, 'Desi', 1, 1),
(15374, 'Cal', 1, 1),
(15375, 'Talley', 1, 1),
(15376, 'Eugenio', 1, 1),
(15377, 'Jameson', 1, 1),
(15378, 'Noe', 1, 1),
(15379, 'Rogearvin', 1, 1),
(15380, 'Dusty', 1, 1),
(15381, 'Toshiyuki', 1, 1),
(15382, 'Grady', 1, 1),
(15383, 'Oswaldo', 1, 1),
(15384, 'Rhyne', 1, 1),
(15385, 'Deryk ', 1, 1),
(15386, 'Marquise', 1, 1),
(15387, 'Noberto', 1, 1),
(15388, 'F.P.', 1, 1),
(15389, 'Jarett', 1, 1),
(15390, 'Michel', 1, 1),
(15391, 'Ryo', 1, 1),
(15392, 'Chone', 1, 1),
(15393, 'Randor', 1, 1),
(15394, 'Clinton', 1, 1),
(15395, 'Wei-Chieh', 1, 1),
(15396, 'Wenceel', 1, 1),
(15397, 'Framber', 1, 1),
(15398, 'Isael', 1, 1),
(15399, 'Rontrez', 1, 1),
(15400, 'Anfrew', 1, 1),
(15401, 'Winston', 1, 1),
(15402, 'Koichi', 1, 1),
(15403, 'Lake', 1, 1),
(15404, 'Hayden', 1, 1),
(15405, 'Ender', 1, 1),
(15406, 'Wander', 1, 1),
(15407, 'Liam', 1, 1),
(15408, 'Les', 1, 1),
(15409, 'Rick', 1, 1),
(15410, 'Arias', 1, 1),
(15411, 'Kane', 1, 1),
(15412, 'Neal', 1, 1),
(15413, 'Agustin', 1, 1),
(15414, 'Art', 1, 1),
(15415, 'Garey', 1, 1),
(15416, 'Audry', 1, 1),
(15417, 'Freudis', 1, 1),
(15418, 'Dae Sung', 1, 1),
(15419, 'Toe', 1, 1),
(15420, 'Franklyn', 1, 1),
(15421, 'Mauricio', 1, 1),
(15422, 'Theo', 1, 1),
(15423, 'Raywilly', 1, 1),
(15424, 'Royce', 1, 1),
(15425, 'Joshua', 1, 1),
(15426, 'Taggert', 1, 1),
(15427, 'Rowdy', 1, 1),
(15428, 'Kosuke', 1, 1),
(15429, 'Niko', 1, 1),
(15430, 'Matthias', 1, 1),
(15431, 'Milt', 1, 1),
(15432, 'A.J.', 1, 1),
(15433, 'Dennis', 1, 1),
(15434, 'Donny', 1, 1),
(15435, 'Byung-Kyu', 1, 1),
(15436, 'Ross', 1, 1),
(15437, 'Antone', 1, 1),
(15438, 'Addison', 1, 1),
(15439, 'Pearson', 1, 1),
(15440, 'Rylan', 1, 1),
(15441, 'Skylar', 1, 1),
(15442, 'Rolando', 1, 1),
(15443, 'Michael M.', 1, 1),
(15444, 'Efrain', 1, 1),
(15445, 'Colin', 1, 1),
(15446, 'Maverick', 1, 1),
(15447, 'Charcer', 1, 1),
(15448, 'Johendi', 1, 1),
(15449, 'Ben', 1, 1),
(15450, 'Garrett', 1, 1),
(15451, 'Daryl', 1, 1),
(15452, 'Burke', 1, 1),
(15453, 'Jensen', 1, 1),
(15454, 'Markus', 1, 1),
(15455, 'Tate', 1, 1),
(15456, 'Brown', 1, 1),
(15457, 'Roosevelt', 1, 1),
(15458, 'Chadd', 1, 1),
(15459, 'Keoni', 1, 1),
(15460, 'Taijuan', 1, 1),
(15461, 'Wily Mo', 1, 1),
(15462, 'Elehuris', 1, 1),
(15463, 'Darryl', 1, 1),
(15464, 'Nobuhiro', 1, 1),
(15465, 'Hideki', 1, 1),
(15466, 'Masahide', 1, 1),
(15467, 'Manuarys', 1, 1),
(15468, 'Arnie', 1, 1),
(15469, 'Isranel', 1, 1),
(15470, 'CC', 1, 1),
(15471, 'Marquis', 1, 1),
(15472, 'Tyler', 1, 1),
(15473, 'Max', 1, 1),
(15474, 'Eude', 1, 1),
(15475, 'Misael', 1, 1),
(15476, 'Leonys', 1, 1),
(15477, 'Ignacio', 1, 1),
(15478, 'Albert', 1, 1),
(15479, 'Ed', 1, 1),
(15480, 'John Michael', 1, 1),
(15481, 'Blank', 1, 1),
(15482, 'Giovanny', 1, 1),
(15483, 'Aaron', 1, 1),
(15484, 'Deion', 1, 1),
(15485, 'Erick', 1, 1),
(15486, 'Jacob', 1, 1),
(15487, 'Coco', 1, 1),
(15488, 'Andury', 1, 1),
(15489, 'Gian', 1, 1),
(15490, 'Ferdin', 1, 1),
(15491, 'Tae-Hyon', 1, 1),
(15492, 'Rommie', 1, 1),
(15493, 'Devern', 1, 1),
(15494, 'Neftali', 1, 1),
(15495, 'Anthony', 1, 1),
(15496, 'Chandler', 1, 1),
(15497, 'Alec', 1, 1),
(15498, 'Brenden', 1, 1),
(15499, 'Cavan', 1, 1),
(15500, 'Raimel', 1, 1),
(15501, 'Felipe', 1, 1),
(15502, 'Chuck', 1, 1),
(15503, 'Hanley', 1, 1),
(15504, 'Sergio', 1, 1),
(15505, 'Koyie', 1, 1),
(15506, 'Yimi', 1, 1),
(15507, 'Luigi', 1, 1),
(15508, 'Dwight', 1, 1),
(15509, 'Nathan', 1, 1),
(15510, 'Dwaine', 1, 1),
(15511, 'Etanislao', 1, 1),
(15512, 'Hiroki', 1, 1),
(15513, 'Jordany', 1, 1),
(15514, 'Yoelly', 1, 1),
(15515, 'Dawel', 1, 1),
(15516, 'Yadiel', 1, 1),
(15517, 'Curt', 1, 1),
(15518, 'Peter', 1, 1),
(15519, 'Dominic', 1, 1),
(15520, 'Jose Rafael', 1, 1),
(15521, 'Samuel', 1, 1),
(15522, 'Gilbert', 1, 1),
(15523, 'Payton', 1, 1),
(15524, 'Creighton', 1, 1),
(15525, 'Brailyn', 1, 1),
(15526, 'Beau', 1, 1),
(15527, 'Naoyuki', 1, 1),
(15528, 'Chase', 1, 1),
(15529, 'Rocky', 1, 1),
(15530, 'Michihiro', 1, 1),
(15531, 'Andruw', 1, 1),
(15532, 'Yeudy', 1, 1),
(15533, 'Ichiro', 1, 1),
(15534, 'Cedrick', 1, 1),
(15535, 'Enerio', 1, 1),
(15536, 'Jeffry', 1, 1),
(15537, 'Cesarin', 1, 1),
(15538, 'Florencio', 1, 1),
(15539, 'Elieser', 1, 1),
(15540, 'Harold', 1, 1),
(15541, 'Jay', 1, 1),
(15542, 'Damon', 1, 1),
(15543, 'Midre', 1, 1),
(15544, 'Leo', 1, 1),
(15545, 'Bernie', 1, 1),
(15546, 'Layne', 1, 1),
(15547, 'Yoel', 1, 1),
(15548, 'John-Ford', 1, 1),
(15549, 'Omir', 1, 1),
(15550, 'Alving', 1, 1),
(15551, 'JB', 1, 1),
(15552, 'Touki', 1, 1),
(15553, 'Jace', 1, 1),
(15554, 'Jereme', 1, 1),
(15555, 'Anastacio', 1, 1),
(15556, 'Yamid', 1, 1),
(15557, 'Frankie', 1, 1),
(15558, 'Guilder', 1, 1),
(15559, 'Ketel', 1, 1),
(15560, 'McKay', 1, 1),
(15561, 'Bengie', 1, 1),
(15562, 'Reyes', 1, 1),
(15563, 'Kyle', 1, 1),
(15564, 'Gil', 1, 1),
(15565, 'Christian', 1, 1),
(15566, 'Arlington', 1, 1),
(15567, 'Shuichi', 1, 1),
(15568, 'Graham', 1, 1),
(15569, 'Gookie', 1, 1),
(15570, 'Yeremi', 1, 1),
(15571, 'Phillippe', 1, 1),
(15572, 'Miguelangel', 1, 1),
(15573, 'Mikey', 1, 1),
(15574, 'Tim', 1, 1),
(15575, 'Al', 1, 1),
(15576, 'Rudy', 1, 1),
(15577, 'Edison', 1, 1),
(15578, 'Milton', 1, 1),
(15579, 'Tyson', 1, 1),
(15580, 'Khiry', 1, 1),
(15581, 'B.A.', 1, 1),
(15582, 'Monte', 1, 1),
(15583, 'Alvaro', 1, 1),
(15584, 'Jordan', 1, 1),
(15585, 'Gerald', 1, 1),
(15586, 'Nook', 1, 1),
(15587, 'Skip', 1, 1),
(15588, 'Prince', 1, 1),
(15589, 'Jakob', 1, 1),
(15590, 'Arquimedez', 1, 1),
(15591, 'Asdrubal', 1, 1),
(15592, 'Michell', 1, 1),
(15593, 'Mel', 1, 1),
(15594, 'Billy', 1, 1),
(15595, 'Gerrit', 1, 1),
(15596, 'Timothy', 1, 1),
(15597, 'Glenn', 1, 1),
(15598, 'Jeremy', 1, 1),
(15599, 'Corwin', 1, 1),
(15600, 'Itsuki', 1, 1),
(15601, 'Jon Michael', 1, 1),
(15602, 'Yonathan', 1, 1),
(15603, 'Dariel', 1, 1),
(15604, 'Hans', 1, 1),
(15605, 'Drew', 1, 1),
(15606, 'Yoshitomo', 1, 1),
(15607, 'Willy', 1, 1),
(15608, 'Roman', 1, 1),
(15609, 'Abel', 1, 1),
(15610, 'Kristian', 1, 1),
(15611, 'Lamar', 1, 1),
(15612, 'Gregorio', 1, 1),
(15613, 'Shane', 1, 1),
(15614, 'Bruce', 1, 1),
(15615, 'Tommy', 1, 1),
(15616, 'Tae Kyun', 1, 1),
(15617, 'Howie', 1, 1),
(15618, 'Clevelan', 1, 1),
(15619, 'Andrelton', 1, 1),
(15620, 'Gabby', 1, 1),
(15621, 'Hiroyuki', 1, 1),
(15622, 'Shay', 1, 1),
(15623, 'Geronimo', 1, 1),
(15624, 'Jeudy', 1, 1),
(15625, 'Jhondaniel', 1, 1),
(15626, 'Agapito', 1, 1),
(15627, 'Carson', 1, 1),
(15628, 'Ronnier', 1, 1),
(15629, 'Yasiel', 1, 1),
(15630, 'Ashe', 1, 1),
(15631, 'Manny', 1, 1),
(15632, 'Wes', 1, 1),
(15633, 'Karsten', 1, 1),
(15634, 'Yusei', 1, 1),
(15635, 'Dario', 1, 1),
(15636, 'Leonardo', 1, 1),
(15637, 'Gerry', 1, 1),
(15638, 'Stuart ', 1, 1),
(15639, 'Mark', 1, 1),
(15640, 'Willie', 1, 1),
(15641, 'Shannon', 1, 1),
(15642, 'Cody', 1, 1),
(15643, 'D.J.', 1, 1),
(15644, 'Kwang-Hyun', 1, 1),
(15645, 'Wally', 1, 1),
(15646, 'Lonnie', 1, 1),
(15647, 'Daz', 1, 1),
(15648, 'Pavel', 1, 1),
(15649, 'Kameron', 1, 1),
(15650, 'Kenji', 1, 1),
(15651, 'Teodoro', 1, 1),
(15652, 'Jhonatan', 1, 1),
(15653, 'Dixon', 1, 1),
(15654, 'Hipolito', 1, 1),
(15655, 'Edwards', 1, 1),
(15656, 'Atlee', 1, 1),
(15657, 'Exicardo', 1, 1),
(15658, 'Kenshin', 1, 1),
(15659, 'Peanut', 1, 1),
(15660, 'Yankory', 1, 1),
(15661, 'Jeremias', 1, 1),
(15662, 'Rashad', 1, 1),
(15663, 'Tres', 1, 1),
(15664, 'Kade', 1, 1),
(15665, 'Hyang-Nam', 1, 1),
(15666, 'Ydwin', 1, 1),
(15667, 'Duke', 1, 1),
(15668, 'Rymer', 1, 1),
(15669, 'Jaycob', 1, 1),
(15670, 'Vito', 1, 1),
(15671, 'Elian', 1, 1),
(15672, 'Jae', 1, 1),
(15673, 'Ronnie', 1, 1),
(15674, 'Paxton', 1, 1),
(15675, 'Louis', 1, 1),
(15676, 'Cristhian', 1, 1),
(15677, 'Chang-Yong', 1, 1),
(15678, 'Telvin', 1, 1),
(15679, 'Yaniel', 1, 1),
(15680, 'Jarret', 1, 1),
(15681, 'Resly', 1, 1),
(15682, 'Irving', 1, 1),
(15683, 'Jerry', 1, 1),
(15684, 'Francisco', 1, 1),
(15685, 'Kiyoshi', 1, 1),
(15686, 'Toby', 1, 1),
(15687, 'Dayron', 1, 1),
(15688, 'Dainer', 1, 1),
(15689, 'LaMonte', 1, 1),
(15690, 'Scarborough', 1, 1),
(15691, 'Jeriome', 1, 1),
(15692, 'Marland', 1, 1),
(15693, 'Stolmy', 1, 1),
(15694, 'Huck', 1, 1),
(15695, 'Radhames', 1, 1),
(15696, 'Breckin', 1, 1),
(15697, 'KJ', 1, 1),
(15698, 'Didi', 1, 1),
(15699, 'Edmundo', 1, 1),
(15700, 'Gerardo', 1, 1),
(15701, 'Trever', 1, 1),
(15702, 'Danys', 1, 1),
(15703, 'Rickie', 1, 1),
(15704, 'Dayan', 1, 1),
(15705, 'Brodie', 1, 1),
(15706, 'Isan', 1, 1),
(15707, 'Ramon', 1, 1),
(15708, 'Nate', 1, 1),
(15709, 'Zane', 1, 1),
(15710, 'Bert', 1, 1),
(15711, 'Chai-An', 1, 1),
(15712, 'Baron', 1, 1),
(15713, 'Yusmeiro', 1, 1),
(15714, 'Rainis', 1, 1),
(15715, 'Koji', 1, 1),
(15716, 'Brian A.', 1, 1),
(15717, 'Yuki', 1, 1),
(15718, 'Brahiam', 1, 1),
(15719, 'Dalton', 1, 1),
(15720, 'Avisail', 1, 1),
(15721, 'Troy', 1, 1),
(15722, 'Sammy', 1, 1),
(15723, 'Arian', 1, 1),
(15724, 'Enmanuel', 1, 1),
(15725, 'Kelvim', 1, 1),
(15726, 'Marshall', 1, 1),
(15727, 'Walt', 1, 1),
(15728, 'Toshiya', 1, 1),
(15729, 'Rayan', 1, 1),
(15730, 'Andujar', 1, 1),
(15731, 'Robin', 1, 1),
(15732, 'T.J.', 1, 1),
(15733, 'Luther', 1, 1),
(15734, 'Nigel', 1, 1),
(15735, 'Rosman', 1, 1),
(15736, 'Cla', 1, 1),
(15737, 'Ntema', 1, 1),
(15738, 'Koda', 1, 1),
(15739, 'Eddy', 1, 1),
(15740, 'Erubiel', 1, 1),
(15741, 'Wardell', 1, 1),
(15742, 'Charlton', 1, 1),
(15743, 'Hainley', 1, 1),
(15744, 'Parker', 1, 1),
(15745, 'Mitchell', 1, 1),
(15746, 'Sanders', 1, 1),
(15747, 'Deunte', 1, 1),
(15748, 'Carlos', 1, 1),
(15749, 'Richie', 1, 1),
(15750, 'Jino', 1, 1),
(15751, 'Yowill', 1, 1),
(15752, 'Deolis', 1, 1),
(15753, 'Randal', 1, 1),
(15754, 'Mo', 1, 1),
(15755, 'Jon-Mark', 1, 1),
(15756, 'Aron', 1, 1),
(15757, 'Ismael', 1, 1),
(15758, 'Kazumi', 1, 1),
(15759, 'Tanyon', 1, 1),
(15760, 'Karim', 1, 1),
(15761, 'M.P.', 1, 1),
(15762, 'Imani', 1, 1),
(15763, 'Glenallen', 1, 1),
(15764, 'Landon', 1, 1),
(15765, 'Taber', 1, 1),
(15766, 'Jud', 1, 1),
(15767, 'Dexter', 1, 1),
(15768, 'Kyri', 1, 1),
(15769, 'Endrys', 1, 1),
(15770, 'Andres', 1, 1),
(15771, 'Takashi', 1, 1),
(15772, 'Po-Hsuan', 1, 1),
(15773, 'Buddy', 1, 1),
(15774, 'Eugene', 1, 1),
(15775, 'Davis', 1, 1),
(15776, 'Adalberto', 1, 1),
(15777, 'Sebastian', 1, 1),
(15778, 'Ryder', 1, 1),
(15779, 'Brent', 1, 1),
(15780, 'Mickey', 1, 1),
(15781, 'Yulieski', 1, 1),
(15782, 'Deon', 1, 1),
(15783, 'Destin', 1, 1),
(15784, 'Walter', 1, 1),
(15785, 'Vanden', 1, 1),
(15786, 'Ha', 1, 1),
(15787, 'Tomoaki', 1, 1),
(15788, 'Fabio', 1, 1),
(15789, 'Daryle', 1, 1),
(15790, 'Triston', 1, 1),
(15791, 'Guido', 1, 1),
(15792, 'Duaner', 1, 1),
(15793, 'Casper', 1, 1),
(15794, 'Brennan', 1, 1),
(15795, 'Denis', 1, 1),
(15796, 'Brody', 1, 1),
(15797, 'Erich', 1, 1),
(15798, 'Juan', 1, 1),
(15799, 'Gregory', 1, 1),
(15800, 'Jae Kuk', 1, 1),
(15801, 'Henderson', 1, 1),
(15802, 'Deivy', 1, 1),
(15803, 'Cary', 1, 1),
(15804, 'Akeel', 1, 1),
(15805, 'Yoenis', 1, 1),
(15806, 'Julio Pablo', 1, 1),
(15807, 'Darond', 1, 1),
(15808, 'Diegomar', 1, 1),
(15809, 'J.C.', 1, 1),
(15810, 'Hong-Chih', 1, 1),
(15811, 'Warner', 1, 1),
(15812, 'German', 1, 1),
(15813, 'Yondry', 1, 1),
(15814, 'Izzy', 1, 1),
(15815, 'Robb', 1, 1),
(15816, 'Shad', 1, 1),
(15817, 'Jo', 1, 1),
(15818, 'Arnaldo', 1, 1),
(15819, 'Renee', 1, 1),
(15820, 'Cullen', 1, 1),
(15821, 'Leon', 1, 1),
(15822, 'Christin', 1, 1),
(15823, 'Yadier', 1, 1),
(15824, 'Romer', 1, 1),
(15825, 'Ambriorix', 1, 1),
(15826, 'Emilio', 1, 1),
(15827, 'Angelo', 1, 1),
(15828, 'Mick', 1, 1),
(15829, 'Hyun Soo', 1, 1),
(15830, 'Osmany', 1, 1),
(15831, 'Shaun', 1, 1),
(15832, 'Alay', 1, 1),
(15833, 'Jose M.', 1, 1),
(15834, 'Yomifer', 1, 1),
(15835, 'Tony', 1, 1),
(15836, 'Brad', 1, 1),
(15837, 'Noelvis', 1, 1),
(15838, 'Tomoya', 1, 1),
(15839, 'Yasuhiko', 1, 1),
(15840, 'LeVon', 1, 1),
(15841, 'Yhonathan', 1, 1),
(15842, 'Hudson', 1, 1),
(15843, 'Carlos  P.', 1, 1),
(15844, 'Jedd', 1, 1),
(15845, 'Ricardo', 1, 1),
(15846, 'Blake', 1, 1),
(15847, 'Javi', 1, 1),
(15848, 'Thairo', 1, 1),
(15849, 'Keyber', 1, 1),
(15850, 'Matt', 1, 1),
(15851, 'Rodney', 1, 1),
(15852, 'Collin', 1, 1),
(15853, 'Robbie', 1, 1),
(15854, 'Boof', 1, 1),
(15855, 'Jennel', 1, 1),
(15856, 'Miles', 1, 1),
(15857, 'Hendrik', 1, 1),
(15858, 'Willi', 1, 1),
(15859, 'Aneurys', 1, 1),
(15860, 'Everson', 1, 1),
(15861, 'Wayne', 1, 1),
(15862, 'Armando', 1, 1),
(15863, 'Hitoki', 1, 1),
(15864, 'Growuptobe', 1, 1),
(15865, 'DeWayne', 1, 1),
(15866, 'Ehren', 1, 1),
(15867, 'Rodolfo', 1, 1),
(15868, 'Hensley', 1, 1),
(15869, 'Joely', 1, 1),
(15870, 'Cash', 1, 1),
(15871, 'Kevin', 1, 1),
(15872, 'Don', 1, 1),
(15873, 'Jesus', 1, 1),
(15874, 'Robinson', 1, 1),
(15875, 'Prentice', 1, 1),
(15876, 'Shingo', 1, 1),
(15877, 'Wynn', 1, 1),
(15878, 'Helmis', 1, 1),
(15879, 'Beiker', 1, 1),
(15880, 'Ildemaro', 1, 1),
(15881, 'Kennys', 1, 1),
(15882, 'McKenzie', 1, 1),
(15883, 'Derrick', 1, 1),
(15884, 'Elinton', 1, 1),
(15885, 'Matthew', 1, 1),
(15886, 'Ramon E.', 1, 1),
(15887, 'Red', 1, 1),
(15888, 'Ulysses', 1, 1),
(15889, 'Burch', 1, 1),
(15890, 'Giancarlo', 1, 1),
(15891, 'Wuilmer', 1, 1),
(15892, 'Benji', 1, 1),
(15893, 'Kole', 1, 1),
(15894, 'Zechry', 1, 1),
(15895, 'Nerio', 1, 1),
(15896, 'Dennys', 1, 1),
(15897, 'Yordany', 1, 1),
(15898, 'Maiko', 1, 1),
(15899, 'Kendry', 1, 1),
(15900, 'Spencer', 1, 1),
(15901, 'Shairon', 1, 1),
(15902, 'Ryon', 1, 1),
(15903, 'Buster', 1, 1),
(15904, 'Thomas', 1, 1),
(15905, 'Ronald', 1, 1),
(15906, 'Kyu Min', 1, 1),
(15907, 'Olivo', 1, 1),
(15908, 'Che-Hsuan', 1, 1),
(15909, 'Yefry', 1, 1),
(15910, 'Will H.', 1, 1),
(15911, 'Napoleon', 1, 1),
(15912, 'Reegie', 1, 1),
(15913, 'Arquimedes', 1, 1),
(15914, 'P. J.', 1, 1),
(15915, 'Wandisson', 1, 1),
(15916, 'Fletcher', 1, 1),
(15917, 'Aubrey', 1, 1),
(15918, 'Connor', 1, 1),
(15919, 'Elevys', 1, 1),
(15920, 'Jae-Gyun', 1, 1),
(15921, 'Rosell', 1, 1),
(15922, 'Abdiel', 1, 1),
(15923, 'Rafael', 1, 1),
(15924, 'Stacy', 1, 1),
(15925, 'Jaret', 1, 1),
(15926, 'Masao', 1, 1),
(15927, 'Gonzalo', 1, 1),
(15928, 'Franquelis', 1, 1),
(15929, 'Jess', 1, 1),
(15930, 'Kevan', 1, 1),
(15931, 'Franmil', 1, 1),
(15932, 'Ashton', 1, 1),
(15933, 'Jackson', 1, 1),
(15934, 'Masanori', 1, 1),
(15935, 'Cord', 1, 1),
(15936, 'Ademar', 1, 1),
(15937, 'Harol', 1, 1),
(15938, 'Renato', 1, 1),
(15939, 'Mc Gregory', 1, 1),
(15940, 'Bryce', 1, 1),
(15941, 'Darwin', 1, 1),
(15942, 'Scotty', 1, 1),
(15943, 'Javon', 1, 1),
(15944, 'Ervis', 1, 1),
(15945, 'J.D.', 1, 1),
(15946, 'Elijah', 1, 1),
(15947, 'J. Brent', 1, 1),
(15948, 'Kellen', 1, 1),
(15949, 'Delta', 1, 1),
(15950, 'Huascar', 1, 1),
(15951, 'Vidal', 1, 1),
(15952, 'Javy', 1, 1),
(15953, 'Stubby', 1, 1),
(15954, 'Cyle', 1, 1),
(15955, 'Carter', 1, 1),
(15956, 'Leonel', 1, 1),
(15957, 'Merandy', 1, 1),
(15958, 'Gage', 1, 1),
(15959, 'J.A.', 1, 1),
(15960, 'Sandy', 1, 1),
(15961, 'Jorge', 1, 1),
(15962, 'Macay', 1, 1),
(15963, 'Brok', 1, 1),
(15964, 'Caden', 1, 1),
(15965, 'Aroldis', 1, 1),
(15966, 'Kendall', 1, 1),
(15967, 'Gabe', 1, 1),
(15968, 'Rainer', 1, 1),
(15969, 'Wilmin', 1, 1),
(15970, 'Shaeffer', 1, 1),
(15971, 'Eloy', 1, 1),
(15972, 'Sheldon', 1, 1),
(15973, 'Chi Chi', 1, 1),
(15974, 'Shea', 1, 1),
(15975, 'Dustan', 1, 1),
(15976, 'Donovan', 1, 1),
(15977, 'Johnathan', 1, 1),
(15978, 'Joaquin', 1, 1),
(15979, 'Marquez', 1, 1),
(15980, 'Yimmi', 1, 1),
(15981, 'Marcell', 1, 1),
(15982, 'Tayler', 1, 1),
(15983, 'Yohander', 1, 1),
(15984, 'Elih', 1, 1),
(15985, 'Levi', 1, 1),
(15986, 'Juan C.', 1, 1),
(15987, 'Ray-Patrick', 1, 1),
(15988, 'Jeremiah', 1, 1),
(15989, 'Waldis', 1, 1),
(15990, 'Jaime', 1, 1),
(15991, 'Robert', 1, 1),
(15992, 'Jesus P.', 1, 1),
(15993, 'Ryan A', 1, 1),
(15994, 'Chihiro', 1, 1),
(15995, 'Sal', 1, 1),
(15996, 'Jo-Jo', 1, 1),
(15997, 'Dinelson', 1, 1),
(15998, 'Telmito', 1, 1),
(15999, 'Jerrod', 1, 1),
(16000, 'Cristian', 1, 1),
(16001, 'Elmer', 1, 1),
(16002, 'Luis A.', 1, 1),
(16003, 'Lane', 1, 1),
(16004, 'Yuhei', 1, 1),
(16005, 'Gonzalez', 1, 1),
(16006, 'Doug', 1, 1),
(16007, 'Alvis', 1, 1),
(16008, 'Abe', 1, 1),
(16009, 'Takahiro', 1, 1),
(16010, 'Shelby', 1, 1),
(16011, 'Amed', 1, 1),
(16012, 'Quinn', 1, 1),
(16013, 'Kazuhiro', 1, 1),
(16014, 'Marcos', 1, 1),
(16015, 'Tike', 1, 1),
(16016, 'Dae-Ho', 1, 1),
(16017, 'Jerad', 1, 1),
(16018, 'Egan', 1, 1),
(16019, 'Travis', 1, 1),
(16020, 'Erasmo', 1, 1),
(16021, 'Daniel', 1, 1),
(16022, 'Britt', 1, 1),
(16023, 'Wilmer', 1, 1),
(16024, 'Ryusuke', 1, 1),
(16025, 'Leuri', 1, 1),
(16026, 'Yasel', 1, 1),
(16027, 'Alexei', 1, 1),
(16028, 'Chia-Jen', 1, 1),
(16029, 'DShawn', 1, 1),
(16030, 'Sharlon ', 1, 1),
(16031, 'Kenley', 1, 1),
(16032, 'Demarcus', 1, 1),
(16033, 'Andre', 1, 1),
(16034, 'Reggie', 1, 1),
(16035, 'Jesse', 1, 1),
(16036, 'Brock', 1, 1),
(16037, 'Eulogia', 1, 1),
(16038, 'Jovanny', 1, 1),
(16039, 'Esmailin', 1, 1),
(16040, 'Zackry', 1, 1),
(16041, 'Kennie', 1, 1),
(16042, 'Guiseppe', 1, 1),
(16043, 'Keynan', 1, 1),
(16044, 'Keon', 1, 1),
(16045, 'Thad', 1, 1),
(16046, 'Edysbel', 1, 1),
(16047, 'Boone', 1, 1),
(16048, 'Heiker', 1, 1),
(16049, 'Butch', 1, 1),
(16050, 'Edgar', 1, 1),
(16051, 'Chevy', 1, 1),
(16052, 'Hisayoshi', 1, 1),
(16053, 'Shogo', 1, 1),
(16054, 'Starlin', 1, 1),
(16055, 'Pratt', 1, 1),
(16056, 'Sang-Hoon', 1, 1),
(16057, 'Jeimer', 1, 1),
(16058, 'Malique', 1, 1),
(16059, 'Augie', 1, 1),
(16060, 'Amalio', 1, 1),
(16061, 'Yeiper', 1, 1),
(16062, 'Keenyn', 1, 1),
(16063, 'Jae-Hoon', 1, 1),
(16064, 'Jaylin', 1, 1),
(16065, 'Quilvio', 1, 1),
(16066, 'Dustin', 1, 1),
(16067, 'Darrin', 1, 1),
(16068, 'Leslie', 1, 1),
(16069, 'Kit', 1, 1),
(16070, 'Ronny', 1, 1),
(16071, 'Zeke', 1, 1),
(16072, 'Dian', 1, 1),
(16073, 'Shayne', 1, 1),
(16074, 'Luiz', 1, 1),
(16075, 'Erling', 1, 1),
(16076, 'Skye', 1, 1),
(16077, 'Heathcliff', 1, 1),
(16078, 'Rheal', 1, 1),
(16079, 'Oleg', 1, 1),
(16080, 'Tomo', 1, 1),
(16081, 'Rian', 1, 1),
(16082, 'Yency', 1, 1),
(16083, 'Shintaro', 1, 1),
(16084, 'Buck', 1, 1),
(16085, 'Paolo ', 1, 1),
(16086, 'Kaleb', 1, 1),
(16087, 'Xander', 1, 1),
(16088, 'Janser', 1, 1),
(16089, 'Jesmuel', 1, 1),
(16090, 'Reinier', 1, 1),
(16091, 'Beltran', 1, 1),
(16092, 'Darnell', 1, 1),
(16093, 'Sung-Wei', 1, 1),
(16094, 'Josmil', 1, 1),
(16095, 'Dong-Yub', 1, 1),
(16096, 'Cleatus', 1, 1),
(16097, 'Kris', 1, 1),
(16098, 'Derrin', 1, 1),
(16099, 'Chan', 1, 1),
(16100, 'Zachary', 1, 1),
(16101, 'Ismerlin ', 1, 1),
(16102, 'Harvin', 1, 1),
(16103, 'MacKenzie', 1, 1),
(16104, 'Mayckol', 1, 1),
(16105, 'Ricky', 1, 1),
(16106, 'Shigetoshi', 1, 1),
(16107, 'Jeremie', 1, 1),
(16108, 'Raudel', 1, 1),
(16109, 'Ivanon', 1, 1),
(16110, 'Yusaku', 1, 1),
(16111, 'Salvador', 1, 1),
(16112, 'Roidany', 1, 1),
(16113, 'Japhet', 1, 1),
(16114, 'Seby', 1, 1),
(16115, 'Wang', 1, 1),
(16116, 'Christopher', 1, 1),
(16117, 'Blair', 1, 1),
(16118, 'Noochie', 1, 1),
(16119, 'Ariel', 1, 1),
(16120, 'Maels', 1, 1),
(16121, 'Leody', 1, 1),
(16122, 'DJ', 1, 1),
(16123, 'Zelous', 1, 1),
(16124, 'Thyago', 1, 1),
(16125, 'Artie', 1, 1),
(16126, 'Marten', 1, 1),
(16127, 'Sandro', 1, 1),
(16128, 'Roderick', 1, 1),
(16129, 'Sterling', 1, 1),
(16130, 'Jacobo', 1, 1),
(16131, 'Errol', 1, 1),
(16132, 'Kirby', 1, 1),
(16133, 'Franchy', 1, 1),
(16134, 'Mallex', 1, 1),
(16135, 'Nick', 1, 1),
(16136, 'Emmanuel', 1, 1),
(16137, 'Hank', 1, 1),
(16138, 'Rocco', 1, 1),
(16139, 'Clarke', 1, 1),
(16140, 'Juan Carlos', 1, 1),
(16141, 'Dai-Kang', 1, 1),
(16142, 'Melky', 1, 1),
(16143, 'Yunior', 1, 1),
(16144, 'J R', 1, 1),
(16145, 'Lucas', 1, 1),
(16146, 'Baltazar', 1, 1),
(16147, 'Guillarme', 1, 1),
(16148, 'Tucker', 1, 1),
(16149, 'Igor', 1, 1),
(16150, 'Ljay', 1, 1),
(16151, 'Russ', 1, 1),
(16152, 'Eddie', 1, 1),
(16153, 'Josue', 1, 1),
(16154, 'Sherea', 1, 1),
(16155, 'Carlton', 1, 1),
(16156, 'Jarrod', 1, 1),
(16157, 'Javier A.', 1, 1),
(16158, 'Everth', 1, 1),
(16159, 'Maikel', 1, 1),
(16160, 'Samir', 1, 1),
(16161, 'Chili', 1, 1),
(16162, 'Eduardo', 1, 1),
(16163, 'Lindsay', 1, 1),
(16164, 'Jin Ho', 1, 1),
(16165, 'Byron', 1, 1),
(16166, 'Sun Woo', 1, 1),
(16167, 'Paulo', 1, 1),
(16168, 'Reiver', 1, 1),
(16169, 'Seung-Yeop', 1, 1),
(16170, 'Zack', 1, 1),
(16171, 'Fabian', 1, 1),
(16172, 'Sheng-An', 1, 1),
(16173, 'Orel', 1, 1),
(16174, 'Tristan', 1, 1),
(16175, 'Dicky', 1, 1),
(16176, 'Emil', 1, 1),
(16177, 'Norris', 1, 1),
(16178, 'Young-Il', 1, 1),
(16179, 'Ralston', 1, 1),
(16180, 'Odubel', 1, 1),
(16181, 'Joseph', 1, 1),
(16182, 'Jonny', 1, 1),
(16183, 'Kelvin', 1, 1),
(16184, 'Geno', 1, 1),
(16185, 'Edubray', 1, 1),
(16186, 'DELETE', 1, 0),
(16187, 'Austin', 1, 1),
(16188, 'Isaiah', 1, 1),
(16189, 'Willson', 1, 1),
(16190, 'Bailey', 1, 1),
(16191, 'Ralph', 1, 1),
(16192, 'J.M.', 1, 1),
(16193, 'Virgil', 1, 1),
(16194, 'Donzell', 1, 1),
(16195, 'Masahiro', 1, 1),
(16196, 'Enyel', 1, 1),
(16197, 'Jonatan', 1, 1),
(16198, 'Yennsy', 1, 1),
(16199, 'Robby', 1, 1),
(16200, 'Vladimir', 1, 1),
(16201, 'Paco', 1, 1),
(16202, 'Sho', 1, 1),
(16203, 'Natanael', 1, 1),
(16204, 'Balbino', 1, 1),
(16205, 'Rich', 1, 1),
(16206, 'Derek', 1, 1),
(16207, 'Patrick', 1, 1),
(16208, 'Brady', 1, 1),
(16209, 'Wiki', 1, 1),
(16210, 'Lino', 1, 1),
(16211, 'Marcelo Josue', 1, 1),
(16212, 'Yoervis', 1, 1),
(16213, 'Jesus E.', 1, 1),
(16214, 'Brett', 1, 1),
(16215, 'Terrmel', 1, 1),
(16216, 'Keury', 1, 1),
(16217, 'Brenny', 1, 1),
(16218, 'Yaron', 1, 1),
(16219, 'Kazuaki', 1, 1),
(16220, 'Griff', 1, 1),
(16221, 'LeRoy', 1, 1),
(16222, 'Geison', 1, 1),
(16223, 'Yenier', 1, 1),
(16224, 'Gauntlett', 1, 1),
(16225, 'Carlos E.', 1, 1),
(16226, 'Maxwell', 1, 1),
(16227, 'Lester', 1, 1),
(16228, 'Dmitri', 1, 1),
(16229, 'Rougned', 1, 1),
(16230, 'Trevor', 1, 1),
(16231, 'Van', 1, 1),
(16232, 'Oliver', 1, 1),
(16233, 'Adonis', 1, 1),
(16234, 'Diosdany ', 1, 1),
(16235, 'Hak-Ju', 1, 1),
(16236, 'C.C.', 1, 1),
(16237, 'Kodi', 1, 1),
(16238, 'Oneil', 1, 1),
(16239, 'Luis Yander', 1, 1),
(16240, 'Kirt', 1, 1),
(16241, 'Ozwaldo', 1, 1),
(16242, 'Shohei', 1, 1),
(16243, 'Vicente', 1, 1),
(16244, 'Dimaster', 1, 1),
(16245, 'Ashur', 1, 1),
(16246, 'Jesen', 1, 1),
(16247, 'Enny', 1, 1),
(16248, 'Raffy', 1, 1),
(16249, 'Pierce', 1, 1),
(16250, 'Alen', 1, 1),
(16251, 'Bill', 1, 1),
(16252, 'Sherman', 1, 1),
(16253, 'Nic', 1, 1),
(16254, 'Ruddy', 1, 1),
(16255, 'Trenton', 1, 1),
(16256, 'Jung Ho', 1, 1),
(16257, 'Eric', 1, 1),
(16258, 'Oreste', 1, 1),
(16259, 'Blaine', 1, 1),
(16260, 'Hamlet', 1, 1),
(16261, 'Pedro Luis', 1, 1),
(16262, 'Ayumu', 1, 1),
(16263, 'Tarrik', 1, 1),
(16264, 'Takeya', 1, 1),
(16265, 'Keithron', 1, 1),
(16266, 'Rondell', 1, 1),
(16267, 'Arthur', 1, 1),
(16268, 'K.D.', 1, 1),
(16269, 'Yovani', 1, 1),
(16270, 'Gift', 1, 1),
(16271, 'Kim', 1, 1),
(16272, 'Trenidad', 1, 1),
(16273, 'Jose Julio', 1, 1),
(16274, 'Jemile', 1, 1),
(16275, 'Dock', 1, 1),
(16276, 'Jio', 1, 1),
(16277, 'Nabil', 1, 1),
(16278, 'Auston', 1, 1),
(16279, 'Einar', 1, 1),
(16280, 'Bob', 1, 1),
(16281, 'Gioskar', 1, 1),
(16282, 'Severino', 1, 1),
(16283, 'Chih-Wei', 1, 1),
(16284, 'Darren', 1, 1),
(16285, 'Jarod', 1, 1),
(16286, 'Daniel B.', 1, 1),
(16287, 'Hee Seop', 1, 1),
(16288, 'Clint', 1, 1),
(16289, 'Aric', 1, 1),
(16290, 'Aarom', 1, 1),
(16291, 'Hirotoshi', 1, 1),
(16292, 'Kai', 1, 1),
(16293, 'Abner', 1, 1),
(16294, 'Yunesky', 1, 1),
(16295, 'Osmy', 1, 1),
(16296, 'Santiago', 1, 1),
(16297, 'Pokey', 1, 1),
(16298, 'Jen-Ho', 1, 1),
(16299, 'Raydel', 1, 1),
(16300, 'David', 1, 1),
(16301, 'Jim', 1, 1),
(16302, 'Alvin', 1, 1),
(16303, 'Javier', 1, 1),
(16304, 'Tsuyoshi', 1, 1),
(16305, 'DeAngelo', 1, 1),
(16306, 'Grayson', 1, 1),
(16307, 'Socrates', 1, 1),
(16308, 'Zac', 1, 1),
(16309, 'Wynston', 1, 1),
(16310, 'Roni', 1, 1),
(16311, 'Bernard', 1, 1),
(16312, 'B.J.', 1, 1),
(16313, 'Osvaldo', 1, 1),
(16314, 'J.R.', 1, 1),
(16315, 'Randall', 1, 1),
(16316, 'Yoshio', 1, 1),
(16317, 'Merkin', 1, 1),
(16318, 'Amaurys', 1, 1),
(16319, 'Roniel', 1, 1),
(16320, 'Myles', 1, 1),
(16321, 'Odrisamer', 1, 1),
(16322, 'Seung Hwan', 1, 1),
(16323, 'J.T.', 1, 1),
(16324, 'Jarek', 1, 1),
(16325, 'Arismendy', 1, 1),
(16326, 'Stefen', 1, 1),
(16327, 'Scott', 1, 1),
(16328, 'Jason', 1, 1),
(16329, 'Denny', 1, 1),
(16330, 'Kirk', 1, 1),
(16331, 'Dewon', 1, 1),
(16332, 'Onil', 1, 1),
(16333, 'Eguy', 1, 1),
(16334, 'Kazuo', 1, 1),
(16335, 'Williams', 1, 1),
(16336, 'Luis E', 1, 1),
(16337, 'Thaddius', 1, 1),
(16338, 'TiQuan', 1, 1),
(16339, 'Warwick', 1, 1),
(16340, 'Colt', 1, 1),
(16341, 'Bucky', 1, 1),
(16342, 'Kanekoa', 1, 1),
(16343, 'Jhoandro', 1, 1),
(16344, 'Diego', 1, 1),
(16345, 'Quan', 1, 1),
(16346, 'Jamar', 1, 1),
(16347, 'Jaye', 1, 1),
(16348, 'Cale', 1, 1),
(16349, 'Mycal', 1, 1),
(16350, 'Tilson', 1, 1),
(16351, 'Amalani', 1, 1),
(16352, 'Greifer', 1, 1),
(16353, 'Omar', 1, 1),
(16354, 'Simon', 1, 1),
(16355, 'R.J.', 1, 1),
(16356, 'Ugueth', 1, 1),
(16357, 'Joey', 1, 1),
(16358, 'Frank', 1, 1),
(16359, 'Everett', 1, 1),
(16360, 'Stevenson', 1, 1),
(16361, 'Brandon', 1, 1),
(16362, 'Jung Keun', 1, 1),
(16363, 'Kyler', 1, 1),
(16364, 'Estevan', 1, 1),
(16365, 'Donnie', 1, 1),
(16366, 'Dirk', 1, 1),
(16367, 'Garret', 1, 1),
(16368, 'Marco', 1, 1),
(16369, 'Philip', 1, 1),
(16370, 'Argenis', 1, 1),
(16371, 'Jered', 1, 1),
(16372, 'Lisalverto', 1, 1),
(16373, 'Kyuji', 1, 1),
(16374, 'Roldani', 1, 1),
(16375, 'Jamie', 1, 1),
(16376, 'Geremi', 1, 1),
(16377, 'Cliff', 1, 1),
(16378, 'Estee', 1, 1),
(16379, 'Marlon', 1, 1),
(16380, 'Lincoln', 1, 1),
(16381, 'Saul', 1, 1),
(16382, 'Gabriel', 1, 1),
(16383, 'Derian', 1, 1),
(16384, 'Pavin', 1, 1),
(16385, 'Corban', 1, 1),
(16386, 'Jerome', 1, 1),
(16387, 'Melido', 1, 1),
(16388, 'Earl', 1, 1),
(16389, 'Goose', 1, 1),
(16390, 'Gordon', 1, 1),
(16391, 'Clete', 1, 1),
(16392, 'Dillon', 1, 1),
(16393, 'Jiovanni', 1, 1),
(16394, 'Keyvius', 1, 1),
(16395, 'Sandobal', 1, 1),
(16396, 'Stiward', 1, 1),
(16397, 'Freicer', 1, 1),
(16398, 'Tanner', 1, 1),
(16399, 'Koo', 1, 1),
(16400, 'Ryu', 1, 1),
(16401, 'Angelys', 1, 1),
(16402, 'Donne', 1, 1),
(16403, 'Brennon', 1, 1),
(16404, 'Chesny', 1, 1),
(16405, 'Sandber', 1, 1),
(16406, 'Kolten', 1, 1),
(16407, 'Sam', 1, 1),
(16408, 'Stephen', 1, 1),
(16409, 'Joc', 1, 1),
(16410, 'Wilkin', 1, 1),
(16411, 'Luis.', 1, 1),
(16412, 'Kazuhito', 1, 1),
(16413, 'Conor', 1, 1),
(16414, 'Andrea', 1, 1),
(16415, 'Seong-Min', 1, 1),
(16416, 'Tzu-Wei', 1, 1),
(16417, 'Edinson', 1, 1),
(16418, 'Gio', 1, 1),
(16419, 'Teoscar', 1, 1),
(16420, 'Emerson', 1, 1),
(16421, 'Hagen', 1, 1),
(16422, 'Stan', 1, 1),
(16423, 'Carlo', 1, 1),
(16424, 'Antonio', 1, 1),
(16425, 'Bradley', 1, 1),
(16426, 'Norge', 1, 1),
(16427, 'Hideo', 1, 1),
(16428, 'Stone', 1, 1),
(16429, 'Livan', 1, 1),
(16430, 'Aquilino', 1, 1),
(16431, 'Onelki', 1, 1),
(16432, 'Yasmany', 1, 1),
(16433, 'Shael', 1, 1),
(16434, 'Cionel', 1, 1),
(16435, 'Morgan', 1, 1),
(16436, 'Candido', 1, 1),
(16437, 'Nolan', 1, 1),
(16438, 'Hiram', 1, 1),
(16439, 'Kei', 1, 1),
(16440, 'Donavan', 1, 1),
(16441, 'Bip', 1, 1),
(16442, 'Pep', 1, 1),
(16443, 'Jimmie', 1, 1),
(16444, 'Sixto', 1, 1),
(16445, 'Rett', 1, 1),
(16446, 'Ching Lung', 1, 1),
(16447, 'Joba', 1, 1),
(16448, 'Yaisel', 1, 1),
(16449, 'Brian', 1, 1),
(16450, 'Cecil', 1, 1),
(16451, 'Rey', 1, 1),
(16452, 'Valerio', 1, 1),
(16453, 'Jan', 1, 1),
(16454, 'Ryota', 1, 1),
(16455, 'Griffin', 1, 1),
(16456, 'Roberto', 1, 1),
(16457, 'Dante', 1, 1),
(16458, 'Ernie', 1, 1),
(16459, 'Nomar', 1, 1),
(16460, 'Kason', 1, 1),
(16461, 'Katsuhiko', 1, 1),
(16462, 'Barrett', 1, 1),
(16463, 'Pedro A', 1, 1),
(16464, 'Lou', 1, 1),
(16465, 'joke', 1, 0),
(16466, 'P.J.', 1, 1),
(16467, 'Hirokazu', 1, 1),
(16468, 'Welinson', 1, 1),
(16469, 'Frederich', 1, 1),
(16470, 'Kelyn', 1, 1),
(16471, 'Jenrry', 1, 1),
(16472, 'Yasser', 1, 1),
(16473, 'Jordy', 1, 1),
(16474, 'Seuly', 1, 1),
(16475, 'Mike', 1, 1),
(16476, 'Rex', 1, 1),
(16477, 'Spike', 1, 1),
(16478, 'Phillip', 1, 1),
(16479, 'Akinori', 1, 1),
(16480, 'Elliot', 1, 1),
(16481, 'Wei-Yin', 1, 1),
(16482, 'Jeromy', 1, 1),
(16483, 'Bryan', 1, 1),
(16484, 'N', 1, 1),
(16485, 'Ravel', 1, 1),
(16486, 'Nefi', 1, 1),
(16487, 'Deinys', 1, 1),
(16488, 'Adbert', 1, 1),
(16489, 'Aristides', 1, 1),
(16490, 'Andy', 1, 1),
(16491, 'Roberto M.', 1, 1),
(16492, 'Kiel', 1, 1),
(16493, 'Edward', 1, 1),
(16494, 'Tadashi', 1, 1),
(16495, 'LaTroy', 1, 1),
(16496, 'Jhonny', 1, 1),
(16497, 'Francisley', 1, 1),
(16498, 'Wildred', 1, 1),
(16499, 'DAndre', 1, 1),
(16500, 'Cheslor', 1, 1),
(16501, 'Denard', 1, 1),
(16502, 'Alberto', 1, 1),
(16503, 'Kenny', 1, 1),
(16504, 'Kelly', 1, 1),
(16505, 'Graeme', 1, 1),
(16506, 'Dane', 1, 1),
(16507, 'Neil', 1, 1),
(16508, 'Luis Alexander', 1, 1),
(16509, 'Breiling', 1, 1),
(16510, 'Adam Brett', 1, 1),
(16511, 'Eammon', 1, 1),
(16512, 'Shawon', 1, 1),
(16513, 'Byungho', 1, 1),
(16514, 'Apostol', 1, 1),
(16515, 'Perci', 1, 1),
(16516, 'Angel', 1, 1),
(16517, 'Casey', 1, 1),
(16518, 'Serguey', 1, 1),
(16519, 'Fredy', 1, 1),
(16520, 'Ethan', 1, 1),
(16521, 'Micker', 1, 1),
(16522, 'Demi', 1, 1),
(16523, 'Gleyber', 1, 1),
(16524, 'Brooks', 1, 1),
(16525, 'Rico', 1, 1),
(16526, 'Bartolome', 1, 1),
(16527, 'Rayner', 1, 1),
(16528, 'Ciro', 1, 1),
(16529, 'Lew', 1, 1),
(16530, 'Ezequiel', 1, 1),
(16531, 'Leuris', 1, 1),
(16532, 'Yuniesky', 1, 1),
(16533, 'Leury', 1, 1),
(16534, 'George', 1, 1),
(16535, 'JuanR', 1, 0),
(16536, 'Yoandy', 1, 1),
(16537, 'Ysmael', 1, 1),
(16538, 'Jasrado', 1, 1),
(16539, 'Toru ', 1, 1),
(16540, 'Dietrich', 1, 1),
(16541, 'Shin-Soo', 1, 1),
(16542, 'Charles', 1, 1),
(16543, 'Jody', 1, 1),
(16544, 'Jimmy', 1, 1),
(16545, 'Yobal', 1, 1),
(16546, 'Wagner', 1, 1),
(16547, 'JeVon', 1, 1),
(16548, 'Blayne', 1, 1),
(16549, 'Jack', 1, 1),
(16550, 'BrianR.', 1, 1),
(16551, 'Mendy', 1, 1),
(16552, 'Corky', 1, 1),
(16553, 'Clemente', 1, 1),
(16554, 'Jeren', 1, 1),
(16555, 'Allen', 1, 1),
(16556, 'Dale', 1, 1),
(16557, 'Junior', 1, 1),
(16558, 'Jonathon', 1, 1),
(16559, 'Yosbany', 1, 1),
(16560, 'Hansel', 1, 1),
(16561, 'Chuckie', 1, 1),
(16562, 'DVontrey', 1, 1),
(16563, 'Mathew', 1, 1),
(16564, 'Yoilan', 1, 1),
(16565, 'Malquin', 1, 1),
(16566, 'Keone', 1, 1),
(16567, 'Delino', 1, 1),
(16568, 'Warren', 1, 1),
(16569, 'Onan', 1, 1),
(16570, 'Jessie', 1, 1),
(16571, 'Jason C.', 1, 1),
(16572, 'Quincy', 1, 1),
(16573, 'Edgard', 1, 1),
(16574, 'Aneury', 1, 1),
(16575, 'Sugar Ray', 1, 1),
(16576, 'Kier', 1, 1),
(16577, 'Trayce', 1, 1),
(16578, 'Ali', 1, 1),
(16579, 'Ozzie', 1, 1),
(16580, 'Pierre-Luc', 1, 1),
(16581, 'Cibney', 1, 1),
(16582, 'Nagisa', 1, 1),
(16583, 'Donell', 1, 1),
(16584, 'Jabari', 1, 1),
(16585, 'Wilkel', 1, 1),
(16586, 'MJ', 1, 1),
(16587, 'Oswald', 1, 1),
(16588, 'Sherten', 1, 1),
(16589, 'Vaughn', 1, 1),
(16590, 'Eli', 1, 1),
(16591, 'Jayson', 1, 1),
(16592, 'Willy Jo', 1, 1),
(16593, 'Preston', 1, 1),
(16594, 'Johnnie ', 1, 1),
(16595, 'Antoni', 1, 1),
(16596, 'Foster', 1, 1),
(16597, 'LJ', 1, 1),
(16598, 'Ron', 1, 1),
(16599, 'Arturo', 1, 1),
(16600, 'Alfonso', 1, 1),
(16601, 'Endy', 1, 1),
(16602, 'Renyel', 1, 1),
(16603, 'Mayobanex', 1, 1),
(16604, 'Dae-Eun', 1, 1),
(16605, 'DArby', 1, 1),
(16606, 'Malik', 1, 1),
(16607, 'Jhoulys', 1, 1),
(16608, 'Akil', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `master_position`
--

CREATE TABLE `master_position` (
  `position_id` int(11) NOT NULL,
  `position_name` varchar(50) NOT NULL,
  `position_abbr` varchar(3) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_position`
--

INSERT INTO `master_position` (`position_id`, `position_name`, `position_abbr`, `is_active`) VALUES
(1, 'Pitcher', 'SP', 0),
(2, 'Catcher', 'C', 1),
(3, 'First Base', '1B', 1),
(4, 'Second Base', '2B', 1),
(5, 'Third Base', '3B', 1),
(6, 'Shortstop', 'SS', 1),
(7, 'Left Field', 'LF', 1),
(8, 'Center Field', 'CF', 1),
(9, 'Right Field', 'RF', 1),
(10, 'Designated Hitter', 'DH', 0);

-- --------------------------------------------------------

--
-- Table structure for table `master_position_trait`
--

CREATE TABLE `master_position_trait` (
  `trait_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `trait_value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_position_trait`
--

INSERT INTO `master_position_trait` (`trait_id`, `position_id`, `trait_value`) VALUES
(1, 1, 24),
(1, 2, 22),
(1, 3, 23),
(1, 4, 24),
(1, 5, 24),
(1, 6, 24),
(1, 7, 23),
(1, 8, 24),
(1, 9, 23),
(1, 10, 22),
(2, 1, 33),
(2, 2, 66),
(2, 3, 61),
(2, 4, 69),
(2, 5, 64),
(2, 6, 69),
(2, 7, 65),
(2, 8, 68),
(2, 9, 64),
(2, 10, 63),
(3, 1, 33),
(3, 2, 20),
(3, 3, 21),
(3, 4, 19),
(3, 5, 20),
(3, 6, 19),
(3, 7, 20),
(3, 8, 19),
(3, 9, 20),
(3, 10, 19),
(4, 1, 1),
(4, 2, 1),
(4, 3, 1),
(4, 4, 3),
(4, 5, 2),
(4, 6, 2),
(4, 7, 2),
(4, 8, 3),
(4, 9, 2),
(4, 10, 1),
(5, 1, 32),
(5, 2, 13),
(5, 3, 17),
(5, 4, 9),
(5, 5, 14),
(5, 6, 9),
(5, 7, 13),
(5, 8, 10),
(5, 9, 14),
(5, 10, 17),
(6, 1, 1),
(6, 2, 1),
(6, 3, 1),
(6, 4, 1),
(6, 5, 1),
(6, 6, 1),
(6, 7, 1),
(6, 8, 1),
(6, 9, 1),
(6, 10, 1),
(7, 1, 8),
(7, 2, 8),
(7, 3, 10),
(7, 4, 7),
(7, 5, 8),
(7, 6, 7),
(7, 7, 8),
(7, 8, 8),
(7, 9, 9),
(7, 10, 9),
(8, 1, 33),
(8, 2, 21),
(8, 3, 21),
(8, 4, 18),
(8, 5, 19),
(8, 6, 18),
(8, 7, 21),
(8, 8, 21),
(8, 9, 21),
(8, 10, 22),
(9, 1, 34),
(9, 2, 48),
(9, 3, 45),
(9, 4, 50),
(9, 5, 48),
(9, 6, 50),
(9, 7, 47),
(9, 8, 46),
(9, 9, 46),
(9, 10, 46),
(10, 1, 2),
(10, 2, 2),
(10, 3, 2),
(10, 4, 1),
(10, 5, 2),
(10, 6, 1),
(10, 7, 1),
(10, 8, 1),
(10, 9, 1),
(10, 10, 2),
(11, 1, 1),
(11, 2, 1),
(11, 3, 1),
(11, 4, 1),
(11, 5, 1),
(11, 6, 1),
(11, 7, 1),
(11, 8, 1),
(11, 9, 1),
(11, 10, 1),
(12, 1, 7),
(12, 2, 5),
(12, 3, 5),
(12, 4, 4),
(12, 5, 5),
(12, 6, 4),
(12, 7, 4),
(12, 8, 3),
(12, 9, 4),
(12, 10, 5),
(13, 1, 15),
(13, 2, 55),
(13, 3, 65),
(13, 4, 80),
(13, 5, 65),
(13, 6, 80),
(13, 7, 80),
(13, 8, 85),
(13, 9, 75),
(13, 10, 55),
(14, 1, 15),
(14, 2, 55),
(14, 3, 65),
(14, 4, 80),
(14, 5, 65),
(14, 6, 80),
(14, 7, 80),
(14, 8, 85),
(14, 9, 75),
(14, 10, 55);

-- --------------------------------------------------------

--
-- Table structure for table `master_record`
--

CREATE TABLE `master_record` (
  `record_id` int(11) NOT NULL,
  `record_preface` varchar(20) NOT NULL,
  `stat_id` int(11) NOT NULL,
  `record_value` int(11) NOT NULL DEFAULT '0',
  `record_star_bonus` int(11) NOT NULL DEFAULT '1000',
  `is_weekly` tinyint(1) NOT NULL DEFAULT '0',
  `is_monthly` int(11) NOT NULL DEFAULT '0',
  `is_yearly` tinyint(1) NOT NULL DEFAULT '0',
  `is_career` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_record`
--

INSERT INTO `master_record` (`record_id`, `record_preface`, `stat_id`, `record_value`, `record_star_bonus`, `is_weekly`, `is_monthly`, `is_yearly`, `is_career`, `is_active`) VALUES
(1, 'Most', 1, 0, 0, 0, 0, 0, 1, 1),
(2, 'Most', 1, 765, 300, 0, 0, 1, 0, 1),
(3, 'Most', 1, 42, 50, 1, 0, 0, 0, 1),
(4, 'Most', 2, 37, 50, 1, 0, 0, 0, 1),
(5, 'Most', 2, 681, 300, 0, 0, 1, 0, 1),
(6, 'Most', 2, 0, 0, 0, 0, 0, 1, 1),
(7, 'Most', 3, 14, 50, 1, 0, 0, 0, 1),
(8, 'Most', 3, 187, 300, 0, 0, 1, 0, 1),
(9, 'Most', 3, 0, 0, 0, 0, 0, 1, 1),
(10, 'Most', 4, 20, 50, 1, 0, 0, 0, 1),
(11, 'Most', 4, 362, 300, 0, 0, 1, 0, 1),
(12, 'Most', 4, 0, 0, 0, 0, 0, 1, 1),
(13, 'Most', 5, 20, 50, 1, 0, 0, 0, 1),
(14, 'Most', 5, 247, 300, 0, 0, 1, 0, 1),
(15, 'Most', 5, 0, 0, 0, 0, 0, 1, 1),
(16, 'Most', 6, 14, 50, 1, 0, 0, 0, 1),
(17, 'Most', 6, 217, 300, 0, 0, 1, 0, 1),
(18, 'Most', 6, 0, 0, 0, 0, 0, 1, 1),
(19, 'Most', 7, 5, 50, 1, 0, 0, 0, 1),
(20, 'Most', 7, 26, 300, 0, 0, 1, 0, 1),
(21, 'Most', 7, 0, 0, 0, 0, 0, 1, 1),
(22, 'Most', 10, 16, 50, 1, 0, 0, 0, 1),
(23, 'Most', 10, 219, 300, 0, 0, 1, 0, 1),
(24, 'Most', 10, 0, 0, 0, 0, 0, 1, 1),
(25, 'Most', 11, 10, 50, 1, 0, 0, 0, 1),
(26, 'Most', 11, 75, 300, 0, 0, 1, 0, 1),
(27, 'Most', 11, 0, 0, 0, 0, 0, 1, 1),
(28, 'Most', 12, 5, 50, 1, 0, 0, 0, 1),
(29, 'Most', 12, 22, 300, 0, 0, 1, 0, 1),
(30, 'Most', 12, 0, 0, 0, 0, 0, 1, 1),
(31, 'Most', 13, 8, 50, 1, 0, 0, 0, 1),
(32, 'Most', 13, 80, 300, 0, 0, 1, 0, 1),
(33, 'Most', 13, 0, 0, 0, 0, 0, 1, 1),
(34, 'Highest', 19, 0, 50, 1, 0, 0, 0, 1),
(35, 'Highest', 19, 0, 300, 0, 0, 1, 0, 1),
(36, 'Highest', 19, 0, 0, 0, 0, 0, 1, 1),
(37, 'Highest', 20, 0, 50, 1, 0, 0, 0, 1),
(38, 'Highest', 20, 0, 300, 0, 0, 1, 0, 1),
(39, 'Highest', 20, 0, 0, 0, 0, 0, 1, 1),
(40, 'Highest', 21, 0, 50, 1, 0, 0, 0, 1),
(41, 'Highest', 21, 0, 300, 0, 0, 1, 0, 1),
(42, 'Highest', 21, 0, 0, 0, 0, 0, 1, 1),
(43, 'Highest', 22, 0, 50, 1, 0, 0, 0, 1),
(44, 'Highest', 22, 0, 300, 0, 0, 1, 0, 1),
(45, 'Highest', 22, 0, 0, 0, 0, 0, 1, 1),
(46, 'Highest', 23, 0, 50, 1, 0, 0, 0, 1),
(47, 'Highest', 23, 0, 300, 0, 0, 1, 0, 1),
(48, 'Highest', 23, 0, 0, 0, 0, 0, 1, 1),
(49, 'Most', 1, 143, 150, 0, 1, 0, 0, 1),
(50, 'Most', 2, 126, 150, 0, 1, 0, 0, 1),
(51, 'Most', 3, 40, 150, 0, 1, 0, 0, 1),
(52, 'Most', 4, 72, 150, 0, 1, 0, 0, 1),
(53, 'Most', 5, 51, 150, 0, 1, 0, 0, 1),
(54, 'Most', 6, 46, 150, 0, 1, 0, 0, 1),
(55, 'Most', 7, 9, 150, 0, 1, 0, 0, 1),
(56, 'Most', 10, 50, 150, 0, 1, 0, 0, 1),
(57, 'Most', 11, 21, 150, 0, 1, 0, 0, 1),
(58, 'Most', 12, 9, 150, 0, 1, 0, 0, 1),
(59, 'Most', 13, 20, 150, 0, 1, 0, 0, 1),
(60, 'Highest', 19, 0, 150, 0, 1, 0, 0, 1),
(61, 'Highest', 20, 0, 150, 0, 1, 0, 0, 1),
(62, 'Highest', 21, 0, 150, 0, 1, 0, 0, 1),
(63, 'Highest', 22, 0, 150, 0, 1, 0, 0, 1),
(64, 'Highest', 23, 0, 150, 0, 1, 0, 0, 1),
(65, 'Most', 16, 7, 50, 1, 0, 0, 0, 1),
(66, 'Most', 16, 16, 150, 0, 1, 0, 0, 1),
(67, 'Most', 16, 57, 300, 0, 0, 1, 0, 1),
(68, 'Most', 17, 8, 50, 1, 0, 0, 0, 1),
(69, 'Most', 17, 17, 150, 0, 1, 0, 0, 1),
(70, 'Most', 17, 57, 300, 0, 0, 1, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `master_settings`
--

CREATE TABLE `master_settings` (
  `first_game_hour` int(11) NOT NULL,
  `second_game_hour` int(11) NOT NULL,
  `third_game_hour` int(11) NOT NULL,
  `fourth_game_hour` int(11) NOT NULL,
  `fifth_game_hour` int(11) NOT NULL,
  `sixth_game_hour` int(11) NOT NULL,
  `games_until_weekly` int(11) NOT NULL DEFAULT '6',
  `games_until_monthly` int(11) NOT NULL DEFAULT '24',
  `games_until_midseason` int(11) NOT NULL DEFAULT '82',
  `games_until_yearly` int(11) NOT NULL DEFAULT '162',
  `games_until_new_order` int(11) NOT NULL DEFAULT '6',
  `min_stars_for_all_star` int(11) NOT NULL DEFAULT '1000',
  `min_pog_for_mvp` int(11) NOT NULL DEFAULT '12',
  `min_stars_for_mvp` smallint(6) NOT NULL DEFAULT '1500'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_settings`
--

INSERT INTO `master_settings` (`first_game_hour`, `second_game_hour`, `third_game_hour`, `fourth_game_hour`, `fifth_game_hour`, `sixth_game_hour`, `games_until_weekly`, `games_until_monthly`, `games_until_midseason`, `games_until_yearly`, `games_until_new_order`, `min_stars_for_all_star`, `min_pog_for_mvp`, `min_stars_for_mvp`) VALUES
(8, 11, 14, 17, 20, 23, 6, 27, 82, 162, 6, 750, 15, 1500);

-- --------------------------------------------------------

--
-- Table structure for table `master_stat`
--

CREATE TABLE `master_stat` (
  `stat_id` int(11) NOT NULL,
  `stat_name` varchar(100) NOT NULL,
  `stat_abbr` varchar(5) DEFAULT NULL,
  `stat_desc` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_stat`
--

INSERT INTO `master_stat` (`stat_id`, `stat_name`, `stat_abbr`, `stat_desc`) VALUES
(1, 'plate_appearance', 'PA', 'plate appearance'),
(2, 'at_bat', 'AB', 'at bat'),
(3, 'run', 'R', 'run'),
(4, 'hit', 'H', 'hit'),
(5, 'runs_batted_in', 'RBI', 'RBI'),
(6, 'walk', 'BB', 'walked'),
(7, 'stolen_base', 'SB', 'stole'),
(8, 'caught_stealing', 'CS', 'caught stealing'),
(9, 'strikeout', 'SO', 'struckout'),
(10, 'hit_single', '1B', 'singled'),
(11, 'hit_double', '2B', 'doubled'),
(12, 'hit_triple', '3B', 'tripled'),
(13, 'hit_homerun', 'HR', 'home run'),
(14, 'left_on_base', 'LOB', 'left on base'),
(15, 'out', 'OUT', 'out'),
(16, 'out_sac_fly', 'SF', 'sacrifice fly'),
(17, 'out_sac_hit', 'SH', 'bunted'),
(18, 'out_double_play', 'GIDP', 'double play'),
(19, 'batting_average', 'AVG', 'batting average'),
(20, 'slugging_average', 'SLG', 'slugging'),
(21, 'isolated_power', 'ISO', 'isolated power'),
(22, 'on_base_percent', 'OBP', 'on base percent'),
(23, 'weighted_on_base_percent', 'wOBA', 'weighted on base percent'),
(24, 'star_earned', 'Stars', 'stars'),
(25, 'grand_slam', 'GS', 'grand slam'),
(26, 'hit_by_pitch', 'HBP', 'hit by pitch'),
(27, 'on_base_plus_slugging', 'OPS', 'on base plus slugging'),
(28, 'total_bases', 'TB', 'Total bases'),
(29, 'extra_base_hits', 'XBH', 'Extra base hits');

-- --------------------------------------------------------

--
-- Table structure for table `master_task`
--

CREATE TABLE `master_task` (
  `task_id` int(11) NOT NULL,
  `task_name` varchar(100) NOT NULL,
  `task_category` varchar(20) NOT NULL,
  `is_daily` tinyint(1) NOT NULL DEFAULT '0',
  `is_weekly` tinyint(1) NOT NULL DEFAULT '0',
  `is_monthly` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_task`
--

INSERT INTO `master_task` (`task_id`, `task_name`, `task_category`, `is_daily`, `is_weekly`, `is_monthly`, `is_active`) VALUES
(1, 'account-deactivation', 'account', 1, 0, 0, 1),
(2, 'sim-games', 'games', 1, 0, 0, 1),
(3, 'send-game-recap-email', 'games', 1, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `master_task_log`
--

CREATE TABLE `master_task_log` (
  `log_id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL,
  `is_success` tinyint(1) NOT NULL DEFAULT '0',
  `success_details` varchar(255) NOT NULL,
  `log_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `master_team`
--

CREATE TABLE `master_team` (
  `team_id` int(11) NOT NULL,
  `league_id` int(11) NOT NULL,
  `conference_id` int(11) NOT NULL,
  `division_id` int(11) NOT NULL,
  `team_name` varchar(100) NOT NULL,
  `team_abbr` varchar(3) NOT NULL,
  `team_city` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_team`
--

INSERT INTO `master_team` (`team_id`, `league_id`, `conference_id`, `division_id`, `team_name`, `team_abbr`, `team_city`, `is_active`) VALUES
(1, 1, 1, 1, 'Crimson Socks', 'BOS', 'Boston', 1),
(2, 1, 1, 1, 'Pinstripes', 'NYP', 'New York', 1),
(3, 1, 1, 1, 'Mantas', 'TAM', 'Tampa Bay', 1),
(4, 1, 1, 1, 'Birds', 'BAL', 'Baltimore', 1),
(5, 1, 1, 2, 'Tribe', 'CLE', 'Cleveland', 1),
(6, 1, 1, 2, 'Pairs', 'MIN', 'Minnesota', 1),
(7, 1, 1, 2, 'Crowns', 'KC', 'Kansas City', 1),
(8, 1, 1, 2, 'Pale Socks', 'CHP', 'Chicago', 1),
(9, 1, 1, 2, 'Wildcats', 'DET', 'Detroit', 1),
(10, 1, 1, 3, 'Stars', 'HOU', 'Houston', 1),
(11, 1, 2, 4, 'Fish', 'MIA', 'Miami', 1),
(12, 1, 2, 4, 'Locomotives', 'NYL', 'New York', 1),
(13, 1, 2, 4, 'Fanatics', 'PHI', 'Philadelphia', 1),
(14, 1, 2, 5, 'Little Bears', 'CHL', 'Chicago', 1),
(15, 1, 2, 5, 'Crew', 'MIL', 'Milwaukee', 1),
(16, 1, 2, 5, 'Redbirds', 'STL', 'St. Louis', 1),
(17, 1, 2, 5, 'Redlegs', 'CIN', 'Cincinnati', 1),
(18, 1, 1, 1, 'Blue Birds', 'TOR', 'Toronto', 1),
(19, 1, 2, 4, 'Loyalists', 'WAS', 'Washington', 1),
(20, 1, 2, 4, 'Bravos', 'ATL', 'Atlanta', 1),
(21, 1, 1, 3, 'Halos', 'LAH', 'Los Angeles', 1),
(22, 1, 1, 3, 'Sailors', 'SEA', 'Seattle', 1),
(23, 1, 1, 3, 'Lone Stars', 'TEX', 'Texas', 1),
(24, 1, 1, 3, 'Elephants', 'OAK', 'Oakland', 1),
(25, 1, 2, 5, 'Marauders', 'PIT', 'Pittsburgh', 1),
(26, 1, 2, 6, 'Blue Crew', 'LAB', 'Los Angeles', 1),
(27, 1, 2, 6, 'Rattlesnakes', 'ARI', 'Arizona', 1),
(28, 1, 2, 6, 'Boulders', 'COL', 'Colorado', 1),
(29, 1, 2, 6, 'Friars', 'SD', 'San Diego', 1),
(30, 1, 2, 6, 'Bay Bombers', 'SF', 'San Francisco', 1);

-- --------------------------------------------------------

--
-- Table structure for table `master_trait`
--

CREATE TABLE `master_trait` (
  `trait_id` int(11) NOT NULL,
  `trait_name` varchar(100) NOT NULL,
  `trait_description` varchar(200) NOT NULL,
  `parent_trait_id` int(11) NOT NULL,
  `has_children` tinyint(1) NOT NULL DEFAULT '0',
  `is_advanced` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_trait`
--

INSERT INTO `master_trait` (`trait_id`, `trait_name`, `trait_description`, `parent_trait_id`, `has_children`, `is_advanced`) VALUES
(1, 'Hit Rate', 'Increased chance of a player\'s plate appearance resulting in any type of hit.', 1, 1, 0),
(2, 'Hit Rate: Single', 'Increased chance that a player\'s hit will result in a single.', 1, 0, 1),
(3, 'Hit Rate: Double', 'Increased chance that a player\'s hit will result in a double.', 1, 0, 1),
(4, 'Hit Rate: Triple', 'Increased chance that a player\'s hit will result in a triple.', 1, 0, 1),
(5, 'Hit Rate: Home Run', 'Increased chance that a player\'s hit will result in a home run.', 1, 0, 1),
(6, 'Hit By Pitch Rate', 'Increased chance that a player\'s plate appearance will result in a hit by pitch.', 6, 0, 0),
(7, 'Walk Rate', 'Increased chance that a player\'s plate appearance will result in a walk.', 7, 0, 0),
(8, 'Strikeout Rate', 'Decreased chance that a player\'s plate appearance will result in a strikeout.', 8, 0, 0),
(9, 'Out Rate', 'Decreased chance that a player\'s plate appearance will result in an out.', 9, 1, 0),
(10, 'Out: Sac Fly Rate', 'Increased chance that a player\'s out will result in a sacrifice fly.', 9, 0, 1),
(11, 'Out: Sac Hit Rate', 'Increased chance that a player\'s out will result in a sacrifice hit.', 9, 0, 1),
(12, 'Out: Double Play Rate', 'Decreased chance that a player\'s out will result in a double play.', 9, 0, 1),
(13, 'Base Stealing: Attempt Rate', 'Increased chance that a player will attempt to steal a base.', 13, 1, 0),
(14, 'Base Stealing: Succeed Rate', 'Increased chance that a player\'s attempted stolen base will be successful.', 13, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `notification_template`
--

CREATE TABLE `notification_template` (
  `template_id` int(11) NOT NULL,
  `template_title` varchar(100) NOT NULL,
  `template_body` varchar(250) NOT NULL,
  `template_link` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification_template`
--

INSERT INTO `notification_template` (`template_id`, `template_title`, `template_body`, `template_link`) VALUES
(1, 'Message from the General Manager!', 'Your team\'s general manager has sent you a welcome message. Please take a moment and read it if you haven\'t already.', '/player/welcome.php'),
(2, 'Batting Order Set', 'The manager of the team has chosen a new batting order. Check the upcoming team schedule to see where you were placed.', '/team/schedule.php?v=u'),
(3, 'Game MVP!', 'You were picked as the MVP of a recent game! Go to your bonuses page for more details and a link to the game recap.', '/player/bonuses.php?t=1'),
(4, 'Walk-off!', 'Congratulations, you had a walk-off in a recent game! Go to your bonuses page for more details and a link to the game recap.', '/player/bonuses.php?t=2'),
(5, 'New Batting Order: Moved Up', 'The manager has set a new batting order for the team. Your spot in the order has moved up due to your performance over the last few games.', '/team/schedule.php?v=u'),
(6, 'New Batting Order: Moved Down', 'A new batting order has been set for the team. Your productivity over the last few games has been somewhat lackluster. Your spot in the batting order has been moved down.', '/team/schedule.php?v=u'),
(7, 'New Batting Order: No Change', 'The manager has set a new batting order. After reviewing your recent performance the manager decided not to change your spot in the order.', '/team/schedule.php?v=u'),
(8, 'League MVP!', 'You had an excellent season and were picked as the MVP of your league! Congratulations! Visit the awards page for more details.', '/player/awards.php?t=3'),
(9, 'Player of the Month Award!', 'The results are in and you have been selected as the Player of the Month. Congratulations! Visit the awards page for more details.', '/player/awards.php?t=2'),
(10, 'Player of the Week Award!', 'Congratulations, you were voted the Player of the Week! Keep up the good work! Visit the awards page for more details.', '/player/awards.php?t=1'),
(11, 'Off-season: Contract Under Review', 'Your contract with the team has ended. The General Manager is reviewing your performance and will decide, shortly, if the team will extend your contract or release to to free agency.', ''),
(12, 'All-Time Weekly Record Broken!', 'Congratulations, you just broke an all-time weekly record! Go to the record book for more details.', '/player/records.php#weekly'),
(13, 'All-Time Monthly Record Broken!', 'Congratulations, you just broke an all-time monthly record! Go to the record book for more details.', '/player/records.php#monthly'),
(14, 'All-Time Yearly Record Broken!', 'Congratulations, you just broke an all-time yearly record! Go to the record book for more details.', '/player/records.php#yearly'),
(15, 'Playoffs are Beginning!', 'Congratulations, your team made it to the playoffs this season. Check the team schedule to see when the next game will be simulated.', '/team/schedule.php'),
(16, 'Playoffs: Advancing to next Round!', 'Your team has advanced to the next round of the playoffs. Please check the team schedule to see when games have been scheduled.', '/team/schedule.php'),
(17, 'Season Ended', 'Your season has ended. Go to the homepage to advance to the next season.', ''),
(18, 'Playoffs: Eliminated!', 'Your team has been eliminated from the playoffs. Better luck next season! Go to the homepage to advance to the next season.', ''),
(19, 'Playoffs: Advanced to Wild Card!', 'Your team has advanced to the Wild Card playoff round! The winner advances and the loser goes home in this single-game elimination series.', '/team/schedule.php'),
(20, 'Playoffs: Advanced to Divisional Series', 'Congratulations on advancing to the Divisional Series. One step closer! Check the schedule to see when the next round starts.', '/team/schedule.php'),
(21, 'Playoffs: Advanced to Championship Series', 'Your team has advanced to the Championship Series! Win this to play in the World Series! Visit the team schedule to see upcoming games.', '/team/schedule.php'),
(22, 'Playoffs: Advanced to World Series', 'Congratulations on your great run! Your team has advanced to the World Series! Head to the team schedule to see when the first game will be simulated.', '/team/schedule.php'),
(23, 'Playoffs: Won World Series!', 'Your team won the World Series! Congratulations! Take a moment to celebrate then head to the homepage to advance to the next season.', '/team/schedule.php'),
(24, 'Off-season: Released by Team', 'The contract with your team has ended. The General Manager has reviewed your performance during your time with the team and has decided against offering you a new contract. Head to the homepage to see if any other teams have offered you a contract.', ''),
(25, 'Off-season: New Contract Offered', 'The contract with your team has ended. Please visit the homepage to see if you have received any contract offers.', ''),
(26, 'Playoffs Started: Matchups Finalized!', 'The field has been set and the playoffs have started! Check the league playoffs page to see each matchup and to follow the progress of each round.', '/league/playoffs.php'),
(27, 'All-Star!', 'Congratulations, you were selected to the All-Star game this season. Keep up the good work but try not to let it go to your head.', '/player/awards.php?t=3'),
(28, 'New Batting Order', 'A new batting order has been set for the team. It looks like you may have found some power in your bat over the last few games. We are going to see how you do in a power-hitting role. This should give you higher-quality batting opportunities.', '/team/schedule.php?v=u');

-- --------------------------------------------------------

--
-- Table structure for table `player`
--

CREATE TABLE `player` (
  `account_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `player_firstname` varchar(100) NOT NULL,
  `player_lastname` varchar(100) NOT NULL,
  `player_position` int(11) NOT NULL,
  `player_age` smallint(6) DEFAULT NULL,
  `years_in_minors` smallint(6) DEFAULT NULL,
  `years_pro` smallint(6) NOT NULL DEFAULT '0',
  `season_id` int(11) DEFAULT NULL,
  `team_id` int(11) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `can_email` tinyint(1) NOT NULL DEFAULT '0',
  `can_sim` tinyint(1) NOT NULL DEFAULT '1',
  `is_offseason` tinyint(1) NOT NULL DEFAULT '0',
  `is_retired` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `player_award`
--

CREATE TABLE `player_award` (
  `award_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `received_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `player_contract`
--

CREATE TABLE `player_contract` (
  `contract_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `contract_length` double NOT NULL DEFAULT '2',
  `contract_remaining` double NOT NULL DEFAULT '2',
  `is_finished` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `player_contract_offer`
--

CREATE TABLE `player_contract_offer` (
  `season_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `contract_offer` int(11) NOT NULL,
  `interested_team_one` int(11) NOT NULL,
  `interested_team_two` int(11) NOT NULL,
  `interested_team_three` int(11) NOT NULL,
  `accepted_team_id` int(11) DEFAULT NULL,
  `is_accepted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `player_email_queue_game_result`
--

CREATE TABLE `player_email_queue_game_result` (
  `player_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `is_new_batting_order` tinyint(1) NOT NULL DEFAULT '0',
  `is_qualified_weekly` tinyint(1) NOT NULL DEFAULT '0',
  `is_qualified_monthly` tinyint(1) NOT NULL DEFAULT '0',
  `is_qualified_midseason` tinyint(1) NOT NULL DEFAULT '0',
  `is_qualified_yearly` tinyint(1) NOT NULL DEFAULT '0',
  `inserted_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `player_game_bonus`
--

CREATE TABLE `player_game_bonus` (
  `bonus_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `bonus_value` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `player_record`
--

CREATE TABLE `player_record` (
  `record_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `stat_id` int(11) NOT NULL,
  `record_value` int(11) NOT NULL,
  `broken_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `player_season`
--

CREATE TABLE `player_season` (
  `season_id` int(11) NOT NULL,
  `league_id` int(11) NOT NULL,
  `league_season` int(11) NOT NULL DEFAULT '1',
  `team_id` int(11) NOT NULL,
  `team_wins` smallint(6) NOT NULL DEFAULT '0',
  `team_losses` smallint(6) NOT NULL DEFAULT '0',
  `player_id` int(11) NOT NULL,
  `years_pro` smallint(6) NOT NULL DEFAULT '0',
  `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `games_until_weekly` int(11) NOT NULL DEFAULT '6',
  `games_until_monthly` int(11) NOT NULL DEFAULT '27',
  `games_until_midseason` int(11) NOT NULL DEFAULT '82',
  `games_until_yearly` int(11) NOT NULL DEFAULT '162',
  `is_postseason` tinyint(1) NOT NULL DEFAULT '0',
  `playoff_round` int(11) NOT NULL DEFAULT '0',
  `is_finished` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `player_star`
--

CREATE TABLE `player_star` (
  `player_id` int(11) NOT NULL,
  `star_value` double NOT NULL DEFAULT '450',
  `star_spent` double NOT NULL DEFAULT '0',
  `star_earned` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `player_stat_game`
--

CREATE TABLE `player_stat_game` (
  `player_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `stat_id` int(11) NOT NULL,
  `stat_value` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `player_stat_game_archive`
--

CREATE TABLE `player_stat_game_archive` (
  `player_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `stat_id` int(11) NOT NULL,
  `stat_value` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `player_stat_season`
--

CREATE TABLE `player_stat_season` (
  `player_id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `stat_id` int(11) NOT NULL,
  `stat_value` double NOT NULL,
  `is_postseason` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `player_trait`
--

CREATE TABLE `player_trait` (
  `player_id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `trait_id` int(11) NOT NULL,
  `trait_value` double NOT NULL,
  `original_trait_value` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `team_batting_order`
--

CREATE TABLE `team_batting_order` (
  `team_id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `batting_order` int(11) NOT NULL,
  `games_until_new` int(11) NOT NULL DEFAULT '6'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `team_game_batting_order`
--

CREATE TABLE `team_game_batting_order` (
  `game_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `batting_order` int(11) NOT NULL,
  `roster_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `is_owned_player` tinyint(1) NOT NULL DEFAULT '0',
  `is_designated_hitter` tinyint(1) NOT NULL DEFAULT '0',
  `is_pitcher` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `team_game_batting_order_archive`
--

CREATE TABLE `team_game_batting_order_archive` (
  `game_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `batting_order` int(11) NOT NULL,
  `roster_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `is_owned_player` tinyint(1) NOT NULL DEFAULT '0',
  `is_designated_hitter` tinyint(1) NOT NULL DEFAULT '0',
  `is_pitcher` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `team_game_opponent_half_inning`
--

CREATE TABLE `team_game_opponent_half_inning` (
  `game_id` int(11) NOT NULL,
  `game_inning` int(11) NOT NULL,
  `game_half_inning` varchar(1) NOT NULL,
  `opponent_team_id` int(11) NOT NULL,
  `opponent_start_runs` int(11) NOT NULL,
  `opponent_runs_scored` int(11) NOT NULL,
  `opponent_end_runs` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `team_game_opponent_half_inning_archive`
--

CREATE TABLE `team_game_opponent_half_inning_archive` (
  `game_id` int(11) NOT NULL,
  `game_inning` int(11) NOT NULL,
  `game_half_inning` varchar(1) NOT NULL,
  `opponent_team_id` int(11) NOT NULL,
  `opponent_start_runs` int(11) NOT NULL,
  `opponent_runs_scored` int(11) NOT NULL,
  `opponent_end_runs` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `team_game_plate_appearance`
--

CREATE TABLE `team_game_plate_appearance` (
  `appearance_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `stat_id` int(11) NOT NULL,
  `stat_value` int(11) NOT NULL,
  `ball_direction` int(11) NOT NULL DEFAULT '0',
  `is_out_sac_fly` tinyint(1) NOT NULL DEFAULT '0',
  `is_out_sac_hit` tinyint(1) NOT NULL DEFAULT '0',
  `is_sb_attempt` tinyint(1) NOT NULL DEFAULT '0',
  `is_sb_succeed` tinyint(1) NOT NULL DEFAULT '0',
  `sb_position` int(11) DEFAULT NULL,
  `sb_base` varchar(20) DEFAULT NULL,
  `is_player_sb` tinyint(1) NOT NULL DEFAULT '0',
  `is_out_double_play` tinyint(1) NOT NULL DEFAULT '0',
  `is_walkoff` tinyint(1) NOT NULL DEFAULT '0',
  `runs` int(11) NOT NULL,
  `runs_batted_in` int(11) NOT NULL,
  `left_on_base` int(11) NOT NULL,
  `game_inning` int(11) NOT NULL,
  `game_inning_half` varchar(1) NOT NULL,
  `game_outs` int(11) NOT NULL,
  `game_team_score` int(11) NOT NULL,
  `game_opponent_score` int(11) NOT NULL,
  `on_first_position_id` int(11) DEFAULT NULL,
  `on_second_position_id` int(11) DEFAULT NULL,
  `on_third_position_id` int(11) DEFAULT NULL,
  `stars_earned` float DEFAULT NULL,
  `is_inning_end` tinyint(1) NOT NULL DEFAULT '0',
  `is_extra_innings` tinyint(1) NOT NULL DEFAULT '0',
  `is_owned_player` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `team_game_plate_appearance_archive`
--

CREATE TABLE `team_game_plate_appearance_archive` (
  `appearance_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `stat_id` int(11) NOT NULL,
  `stat_value` int(11) NOT NULL,
  `ball_direction` int(11) NOT NULL DEFAULT '0',
  `is_out_sac_fly` tinyint(1) NOT NULL DEFAULT '0',
  `is_out_sac_hit` tinyint(1) NOT NULL DEFAULT '0',
  `is_sb_attempt` tinyint(1) NOT NULL DEFAULT '0',
  `is_sb_succeed` tinyint(1) NOT NULL DEFAULT '0',
  `sb_position` int(11) DEFAULT NULL,
  `sb_base` varchar(20) DEFAULT NULL,
  `is_player_sb` tinyint(1) NOT NULL DEFAULT '0',
  `is_out_double_play` tinyint(1) NOT NULL DEFAULT '0',
  `is_walkoff` tinyint(1) NOT NULL DEFAULT '0',
  `runs` int(11) NOT NULL,
  `runs_batted_in` int(11) NOT NULL,
  `left_on_base` int(11) NOT NULL,
  `game_inning` int(11) NOT NULL,
  `game_inning_half` varchar(1) NOT NULL,
  `game_outs` int(11) NOT NULL,
  `game_team_score` int(11) NOT NULL,
  `game_opponent_score` int(11) NOT NULL,
  `on_first_position_id` int(11) DEFAULT NULL,
  `on_second_position_id` int(11) DEFAULT NULL,
  `on_third_position_id` int(11) DEFAULT NULL,
  `stars_earned` float DEFAULT NULL,
  `is_inning_end` tinyint(1) NOT NULL DEFAULT '0',
  `is_extra_innings` tinyint(1) NOT NULL DEFAULT '0',
  `is_owned_player` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `team_roster`
--

CREATE TABLE `team_roster` (
  `roster_id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `pitcher_rotation_id` int(11) NOT NULL,
  `is_bench` tinyint(1) NOT NULL DEFAULT '0',
  `is_player` tinyint(1) NOT NULL DEFAULT '0',
  `is_replaced` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `team_schedule`
--

CREATE TABLE `team_schedule` (
  `game_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `opponent_id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `team_wins` int(11) NOT NULL DEFAULT '0',
  `team_losses` int(11) NOT NULL DEFAULT '0',
  `opponent_wins` int(11) NOT NULL DEFAULT '0',
  `opponent_losses` int(11) NOT NULL DEFAULT '0',
  `game_date` datetime NOT NULL,
  `is_home` tinyint(1) DEFAULT NULL,
  `team_score` double NOT NULL DEFAULT '0',
  `opponent_score` double NOT NULL DEFAULT '0',
  `innings` int(11) NOT NULL DEFAULT '9',
  `game_outcome` tinyint(1) DEFAULT NULL,
  `can_sim` tinyint(1) NOT NULL DEFAULT '1',
  `is_postseason` tinyint(1) NOT NULL DEFAULT '0',
  `is_finished` tinyint(1) NOT NULL DEFAULT '0',
  `is_hidden` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `team_schedule_archive`
--

CREATE TABLE `team_schedule_archive` (
  `game_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `opponent_id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `team_wins` int(11) NOT NULL DEFAULT '0',
  `team_losses` int(11) NOT NULL DEFAULT '0',
  `opponent_wins` int(11) NOT NULL DEFAULT '0',
  `opponent_losses` int(11) NOT NULL DEFAULT '0',
  `game_date` datetime NOT NULL,
  `is_home` tinyint(1) DEFAULT NULL,
  `team_score` double NOT NULL DEFAULT '0',
  `opponent_score` double NOT NULL DEFAULT '0',
  `innings` int(11) NOT NULL DEFAULT '9',
  `game_outcome` tinyint(1) DEFAULT NULL,
  `can_sim` tinyint(1) NOT NULL DEFAULT '1',
  `is_postseason` tinyint(1) NOT NULL DEFAULT '0',
  `is_finished` tinyint(1) NOT NULL DEFAULT '0',
  `is_hidden` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `team_stat_game`
--

CREATE TABLE `team_stat_game` (
  `game_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `stat_id` int(11) NOT NULL,
  `stat_value` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `team_stat_game_archive`
--

CREATE TABLE `team_stat_game_archive` (
  `game_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `stat_id` int(11) NOT NULL,
  `stat_value` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `team_stat_season`
--

CREATE TABLE `team_stat_season` (
  `team_id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `stat_id` int(11) NOT NULL,
  `stat_value` double NOT NULL,
  `is_postseason` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `account_notification`
--
ALTER TABLE `account_notification`
  ADD PRIMARY KEY (`notification_id`,`account_id`,`player_id`);

--
-- Indexes for table `account_season`
--
ALTER TABLE `account_season`
  ADD PRIMARY KEY (`account_id`),
  ADD UNIQUE KEY `account_id` (`account_id`),
  ADD KEY `account_id_2` (`account_id`);

--
-- Indexes for table `account_subscription`
--
ALTER TABLE `account_subscription`
  ADD PRIMARY KEY (`account_id`,`customer_id`,`plan_id`);

--
-- Indexes for table `IpAddressLog`
--
ALTER TABLE `IpAddressLog`
  ADD PRIMARY KEY (`IpAddress`);

--
-- Indexes for table `league_playoff_schedule`
--
ALTER TABLE `league_playoff_schedule`
  ADD PRIMARY KEY (`season_id`,`round`,`home_team_id`,`visit_team_id`,`conference_id`) USING BTREE;

--
-- Indexes for table `league_standings`
--
ALTER TABLE `league_standings`
  ADD PRIMARY KEY (`league_id`,`season_id`,`team_id`);

--
-- Indexes for table `master_award`
--
ALTER TABLE `master_award`
  ADD PRIMARY KEY (`award_id`);

--
-- Indexes for table `master_ball_direction`
--
ALTER TABLE `master_ball_direction`
  ADD PRIMARY KEY (`direction_id`);

--
-- Indexes for table `master_bonus`
--
ALTER TABLE `master_bonus`
  ADD PRIMARY KEY (`bonus_id`);

--
-- Indexes for table `master_league`
--
ALTER TABLE `master_league`
  ADD PRIMARY KEY (`league_id`),
  ADD UNIQUE KEY `league_id` (`league_id`),
  ADD KEY `league_id_2` (`league_id`);

--
-- Indexes for table `master_league_conference`
--
ALTER TABLE `master_league_conference`
  ADD PRIMARY KEY (`conference_id`,`league_id`),
  ADD UNIQUE KEY `conference_id` (`conference_id`);

--
-- Indexes for table `master_league_division`
--
ALTER TABLE `master_league_division`
  ADD PRIMARY KEY (`division_id`,`league_id`,`conference_id`),
  ADD UNIQUE KEY `division_id` (`division_id`),
  ADD KEY `division_id_2` (`division_id`);

--
-- Indexes for table `master_player_names`
--
ALTER TABLE `master_player_names`
  ADD PRIMARY KEY (`name_id`);

--
-- Indexes for table `master_position`
--
ALTER TABLE `master_position`
  ADD PRIMARY KEY (`position_id`),
  ADD UNIQUE KEY `position_id` (`position_id`),
  ADD UNIQUE KEY `position_id_2` (`position_id`),
  ADD KEY `position_id_3` (`position_id`);

--
-- Indexes for table `master_position_trait`
--
ALTER TABLE `master_position_trait`
  ADD PRIMARY KEY (`trait_id`,`position_id`);

--
-- Indexes for table `master_record`
--
ALTER TABLE `master_record`
  ADD PRIMARY KEY (`record_id`) USING BTREE;

--
-- Indexes for table `master_stat`
--
ALTER TABLE `master_stat`
  ADD PRIMARY KEY (`stat_id`),
  ADD UNIQUE KEY `stat_id` (`stat_id`),
  ADD KEY `stat_id_2` (`stat_id`);

--
-- Indexes for table `master_task`
--
ALTER TABLE `master_task`
  ADD PRIMARY KEY (`task_id`);

--
-- Indexes for table `master_task_log`
--
ALTER TABLE `master_task_log`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `master_team`
--
ALTER TABLE `master_team`
  ADD PRIMARY KEY (`team_id`,`league_id`,`conference_id`,`division_id`),
  ADD UNIQUE KEY `Unique` (`team_id`),
  ADD KEY `team_id` (`team_id`),
  ADD KEY `team_id_2` (`team_id`);

--
-- Indexes for table `master_trait`
--
ALTER TABLE `master_trait`
  ADD PRIMARY KEY (`trait_id`),
  ADD UNIQUE KEY `trait_id` (`trait_id`),
  ADD KEY `trait_id_2` (`trait_id`);

--
-- Indexes for table `notification_template`
--
ALTER TABLE `notification_template`
  ADD PRIMARY KEY (`template_id`);

--
-- Indexes for table `player`
--
ALTER TABLE `player`
  ADD PRIMARY KEY (`account_id`,`player_id`,`team_id`),
  ADD UNIQUE KEY `player_id` (`player_id`),
  ADD KEY `player_id_2` (`player_id`);

--
-- Indexes for table `player_award`
--
ALTER TABLE `player_award`
  ADD PRIMARY KEY (`award_id`,`player_id`,`season_id`,`received_date`) USING BTREE;

--
-- Indexes for table `player_contract`
--
ALTER TABLE `player_contract`
  ADD PRIMARY KEY (`contract_id`,`player_id`,`team_id`,`season_id`),
  ADD UNIQUE KEY `contract_id` (`contract_id`),
  ADD KEY `contract_id_2` (`contract_id`);

--
-- Indexes for table `player_contract_offer`
--
ALTER TABLE `player_contract_offer`
  ADD PRIMARY KEY (`season_id`,`player_id`,`team_id`);

--
-- Indexes for table `player_email_queue_game_result`
--
ALTER TABLE `player_email_queue_game_result`
  ADD PRIMARY KEY (`player_id`,`game_id`);

--
-- Indexes for table `player_game_bonus`
--
ALTER TABLE `player_game_bonus`
  ADD PRIMARY KEY (`bonus_id`,`game_id`,`player_id`);

--
-- Indexes for table `player_record`
--
ALTER TABLE `player_record`
  ADD PRIMARY KEY (`record_id`,`player_id`,`season_id`,`stat_id`,`broken_date`) USING BTREE;

--
-- Indexes for table `player_season`
--
ALTER TABLE `player_season`
  ADD PRIMARY KEY (`season_id`,`league_id`,`team_id`,`player_id`),
  ADD UNIQUE KEY `season_id` (`season_id`),
  ADD KEY `season_id_2` (`season_id`);

--
-- Indexes for table `player_star`
--
ALTER TABLE `player_star`
  ADD PRIMARY KEY (`player_id`),
  ADD UNIQUE KEY `player_id_3` (`player_id`),
  ADD KEY `player_id` (`player_id`),
  ADD KEY `player_id_2` (`player_id`);

--
-- Indexes for table `player_stat_game`
--
ALTER TABLE `player_stat_game`
  ADD PRIMARY KEY (`player_id`,`game_id`,`stat_id`) USING BTREE,
  ADD KEY `game_id` (`game_id`);

--
-- Indexes for table `player_stat_game_archive`
--
ALTER TABLE `player_stat_game_archive`
  ADD PRIMARY KEY (`player_id`,`game_id`,`stat_id`) USING BTREE,
  ADD KEY `game_id` (`game_id`);

--
-- Indexes for table `player_stat_season`
--
ALTER TABLE `player_stat_season`
  ADD PRIMARY KEY (`player_id`,`season_id`,`stat_id`,`is_postseason`) USING BTREE,
  ADD KEY `season_id` (`season_id`);

--
-- Indexes for table `player_trait`
--
ALTER TABLE `player_trait`
  ADD PRIMARY KEY (`player_id`,`season_id`,`trait_id`),
  ADD KEY `player_id` (`player_id`),
  ADD KEY `trait_id` (`trait_id`);

--
-- Indexes for table `team_batting_order`
--
ALTER TABLE `team_batting_order`
  ADD PRIMARY KEY (`team_id`,`season_id`,`player_id`);

--
-- Indexes for table `team_game_batting_order`
--
ALTER TABLE `team_game_batting_order`
  ADD PRIMARY KEY (`game_id`,`team_id`,`batting_order`);

--
-- Indexes for table `team_game_batting_order_archive`
--
ALTER TABLE `team_game_batting_order_archive`
  ADD PRIMARY KEY (`game_id`,`team_id`,`batting_order`);

--
-- Indexes for table `team_game_opponent_half_inning`
--
ALTER TABLE `team_game_opponent_half_inning`
  ADD PRIMARY KEY (`game_id`,`game_inning`) USING BTREE;

--
-- Indexes for table `team_game_opponent_half_inning_archive`
--
ALTER TABLE `team_game_opponent_half_inning_archive`
  ADD PRIMARY KEY (`game_id`,`game_inning`) USING BTREE;

--
-- Indexes for table `team_game_plate_appearance`
--
ALTER TABLE `team_game_plate_appearance`
  ADD PRIMARY KEY (`game_id`,`team_id`,`position_id`,`stat_id`,`game_inning`,`game_outs`,`appearance_id`,`game_inning_half`) USING BTREE,
  ADD UNIQUE KEY `appearance_id` (`appearance_id`);

--
-- Indexes for table `team_game_plate_appearance_archive`
--
ALTER TABLE `team_game_plate_appearance_archive`
  ADD PRIMARY KEY (`game_id`,`team_id`,`position_id`,`stat_id`,`game_inning`,`game_outs`,`appearance_id`,`game_inning_half`) USING BTREE,
  ADD UNIQUE KEY `appearance_id` (`appearance_id`);

--
-- Indexes for table `team_roster`
--
ALTER TABLE `team_roster`
  ADD PRIMARY KEY (`roster_id`,`season_id`,`team_id`);

--
-- Indexes for table `team_schedule`
--
ALTER TABLE `team_schedule`
  ADD PRIMARY KEY (`team_id`,`opponent_id`,`season_id`,`game_date`,`can_sim`,`is_postseason`) USING BTREE,
  ADD UNIQUE KEY `game_id` (`game_id`);

--
-- Indexes for table `team_schedule_archive`
--
ALTER TABLE `team_schedule_archive`
  ADD PRIMARY KEY (`team_id`,`opponent_id`,`season_id`,`game_date`,`can_sim`,`is_postseason`) USING BTREE,
  ADD UNIQUE KEY `game_id` (`game_id`);

--
-- Indexes for table `team_stat_game`
--
ALTER TABLE `team_stat_game`
  ADD PRIMARY KEY (`game_id`,`team_id`,`stat_id`),
  ADD KEY `game_id` (`game_id`);

--
-- Indexes for table `team_stat_game_archive`
--
ALTER TABLE `team_stat_game_archive`
  ADD PRIMARY KEY (`game_id`,`team_id`,`stat_id`),
  ADD KEY `game_id` (`game_id`);

--
-- Indexes for table `team_stat_season`
--
ALTER TABLE `team_stat_season`
  ADD PRIMARY KEY (`team_id`,`season_id`,`stat_id`,`is_postseason`) USING BTREE,
  ADD KEY `season_id` (`season_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1728;
--
-- AUTO_INCREMENT for table `account_notification`
--
ALTER TABLE `account_notification`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=209271;
--
-- AUTO_INCREMENT for table `master_award`
--
ALTER TABLE `master_award`
  MODIFY `award_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `master_ball_direction`
--
ALTER TABLE `master_ball_direction`
  MODIFY `direction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `master_bonus`
--
ALTER TABLE `master_bonus`
  MODIFY `bonus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `master_league`
--
ALTER TABLE `master_league`
  MODIFY `league_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `master_league_conference`
--
ALTER TABLE `master_league_conference`
  MODIFY `conference_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `master_league_division`
--
ALTER TABLE `master_league_division`
  MODIFY `division_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `master_player_names`
--
ALTER TABLE `master_player_names`
  MODIFY `name_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16609;
--
-- AUTO_INCREMENT for table `master_position`
--
ALTER TABLE `master_position`
  MODIFY `position_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `master_record`
--
ALTER TABLE `master_record`
  MODIFY `record_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;
--
-- AUTO_INCREMENT for table `master_stat`
--
ALTER TABLE `master_stat`
  MODIFY `stat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `master_task`
--
ALTER TABLE `master_task`
  MODIFY `task_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `master_task_log`
--
ALTER TABLE `master_task_log`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8779;
--
-- AUTO_INCREMENT for table `master_team`
--
ALTER TABLE `master_team`
  MODIFY `team_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `master_trait`
--
ALTER TABLE `master_trait`
  MODIFY `trait_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `player`
--
ALTER TABLE `player`
  MODIFY `player_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2554;
--
-- AUTO_INCREMENT for table `player_contract`
--
ALTER TABLE `player_contract`
  MODIFY `contract_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3860;
--
-- AUTO_INCREMENT for table `player_season`
--
ALTER TABLE `player_season`
  MODIFY `season_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5480;
--
-- AUTO_INCREMENT for table `team_game_plate_appearance`
--
ALTER TABLE `team_game_plate_appearance`
  MODIFY `appearance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33230075;
--
-- AUTO_INCREMENT for table `team_game_plate_appearance_archive`
--
ALTER TABLE `team_game_plate_appearance_archive`
  MODIFY `appearance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22081160;
--
-- AUTO_INCREMENT for table `team_roster`
--
ALTER TABLE `team_roster`
  MODIFY `roster_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107965;
--
-- AUTO_INCREMENT for table `team_schedule`
--
ALTER TABLE `team_schedule`
  MODIFY `game_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=910271;
--
-- AUTO_INCREMENT for table `team_schedule_archive`
--
ALTER TABLE `team_schedule_archive`
  MODIFY `game_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=557093;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
